#include <hidef.h>                           /* common defines and macros */
#include "derivative.h"                      /* derivative information */

/*
** ------------------------------------------------------------------------------
   
   File   : ModBusM.c 
   Aurthor: 
   
   Description:  
   
   Version Log    Notes                                              Changes Made by                                        
   -------------- -----                                              ---------------
   21-11-08:      Created                                                  Stuart
   
   22-06-09:      relocated CRC cde to CRC.c                               Stuart
   
   17-09-09:      Added MBSW=1 for A1149 support                           Stuart

   18-01-10:      Added derivative.h to support alternate micros           Stuart Clarke


** ------------------------------------------------------------------------------
                                    
                                    Overview
                                       

        
** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

/* library headers */
#include "string.h"

/* Application headers */
#include "Main.h"
#include "SCI 100110.h"
#include "ModBusM Int.h"
#include "CRC 100114.h"

/* Implements this interface: */
#define MODBUSM_C
#include "ModBusM.h"

/* Non-Volatile */
#pragma DATA_SEG EEPROM_DATA


#pragma CODE_SEG MODBUSM_Code
#pragma DATA_SEG MODBUSM_Data


/* private */
static SCI_Type *SCIPtr;
static byte mbDriverState;
static byte mbTimeOutCnt;



/* public */
mbtype  mb;
byte    mbMsgLength;
byte    mbStatus;
byte    mbTableIndex;

word    BusComErrCnt;
word    ExceptionErrCnt;


/*
** ------------------------------------------------------------------------------
**		Function: void ModBusM_Init(word SCIRegPtr)
** ------------------------------------------------------------------------------
*/

void ModBusM_Init(word SCIRegPtr)
{
   /* Set pointer to base address of SCI register map */
   SCIPtr = (SCI_Type *)SCIRegPtr;  
   
   /* initialize coms buffer pointers */
   mb.TxPtr = mb.TxBuf;	
   mb.RxPtr  = mb.RxBuf;	   
}

/*
** ------------------------------------------------------------------------------
**		void mbT3Timeout(void)
** ------------------------------------------------------------------------------
*/

void mbT3Timeout(void)
{
	/* stop RX IRQ */
	SCIPtr->SCICR2 &=~ _RIEN;
	
	/* minimum PDU length ? */
	if (mbMsgLength>3)				
	{
		/* received MB PDU */
		mb.In = 1;			
	}
	else			
	{
	   /* must be an error */
		BusComErrCnt++;
		//FlashErrLed();
	}	

   /* switch Green led off */
   //if (BoardType == _1162)
      //PTP_PTP7 = 1;
   //else
      PTP_PTP4 = 1;
}

/*
** ------------------------------------------------------------------------------
**		interrupt void mbMsgTimer(void)
** ------------------------------------------------------------------------------
*/

void mbMsgTimer(void)
{
   if (mb.Busy)
   {
      if (mb.TimeOut && !--mb.TimeOut)
      {	
      	/* stop RX IRQ */
      	SCIPtr->SCICR2 &=~ _RIEN;	
         /* clear busy flag */
         mb.Busy = 0;
         
         /* switch Green led off */
         //if (BoardType == _1162)
            //PTP_PTP7 = 1;
         //else
            PTP_PTP4 = 1;
       }
   }
}

/*
** ------------------------------------------------------------------------------
**		Function: void mbTx(void)
** ------------------------------------------------------------------------------
*/

void mbTx(void)
{
   word i;   
   
   /* claculate PDU check sum */
	i =  GetCRC((byte *)&mb.TxBuf, mbMsgLength);

   /* add to PDU */
	mb.TxBuf[mbMsgLength++] = *(byte *)&i;
	mb.TxBuf[mbMsgLength++] = *(((byte *)&i)+1);	

   /* initialize coms buffer pointers */
   mb.TxPtr = mb.TxBuf;	
   mb.RxPtr = mb.RxBuf;                
   
   /* 100 mS timeout */
   mb.TimeOut = 100;  
   /* set busy flag */
   mb.Busy = 1;     
   /* switch Green led on */
   //if (BoardType == _1162)
      //PTP_PTP7 = 0;
   //else
      PTP_PTP4 = 0;
 
   /* enable 485 driver */
   //if (BoardType == _1162)
      //PORTK_PK5 = 1;
   //else
      PORTK_PK4 = 1;   
   
   /* fire off interrupt */  
   SCIPtr->SCICR2 |= _TIEN;   
}

/*
** ------------------------------------------------------------------------------
**		Function: byte mbGetResponse(void)
** ------------------------------------------------------------------------------
*/

byte mbGetResponse(void)
{
   /* wait for modbus response or timeout */
   while (!mb.In && mb.TimeOut);
   
   /* which one? */
   if (!mb.TimeOut) 
   {
      /* no reply return error */
      return mbTimeoutErr;
   }
   else
   {  
      /* clear in flag */
      mb.In = 0;
      
      /* check checksum first  */ 
      if(CheckCRC((byte *)&mb.RxBuf, mbMsgLength))
      {
         /* modbus diagnostic counters */
         BusComErrCnt++;
         /* return error */
         return mbCRCErr;
      }
      else
      {
         /* look for error response */
         if((byte)mb.RxBuf[1]==0x83)
         {
            ExceptionErrCnt++;            
            /* return modbus error code */
            return mb.RxBuf[2]; 
         }
         else
         {            
            /* return OK */
            return mbOk;
         }
      }
   }
}

/*
** ------------------------------------------------------------------------------
**		Function: void mbRead_SerEE_Reg(word Adr, byte Len)
** ------------------------------------------------------------------------------
*/
 
void mbRead_SerEE_Reg(word Adr, byte Len)
{
   /* set modbus id */
   mb.TxBuf[0] = 1;
   /* set read holding reg function code */
   mb.TxBuf[1] = 0x65;
   
   /* a1186 and a1197 have cals offset in seial eeprom */
   if(mbSlave.BoardType==A1186_01 || mbSlave.BoardType==A1197_04)
      Adr += 0x3FFF;
   
   /* load start address */
   mb.TxBuf[2] = *((byte *)&Adr);
   mb.TxBuf[3] = *(((byte *)&Adr)+1);
   /* set quanitity of registers */
   mb.TxBuf[4] = 0;
   mb.TxBuf[5] = Len;

   /* set modbus message length */
   mbMsgLength = 6;
   /* send modbus PDU */
   mbTx();
}

/*
** ------------------------------------------------------------------------------
**		Function: void mbRead_Holding_Reg(word Adr, byte NoReg)
** ------------------------------------------------------------------------------
*/
 
void mbRead_Holding_Reg(word Adr, byte NoReg)
{
   /* set modbus id */
   mb.TxBuf[0] = 1;
   /* set read holding reg function code */
   mb.TxBuf[1] = 0x03;
   /* load start address */
   mb.TxBuf[2] = *((byte *)&Adr);
   mb.TxBuf[3] = *(((byte *)&Adr)+1);
   /* set quanitity of registers */
   mb.TxBuf[4] = 0;
   mb.TxBuf[5] = NoReg;

   /* set modbus message length */
   mbMsgLength = 6;
   /* send modbus PDU */
   mbTx();
}

/*
** ------------------------------------------------------------------------------
**		Function: byte Write_Single_Reg(word Adr, word Data)
** ------------------------------------------------------------------------------
*/
 
void Write_Single_Reg(word Adr, word Data)
{
   /* set modbus id */
   mb.TxBuf[0] = 1;
   /* set read holding reg function code */
   mb.TxBuf[1] = 0x06;

   /* load start address */
   mb.TxBuf[2] = *((byte *)&Adr);
   mb.TxBuf[3] = *(((byte *)&Adr)+1);
   /* set quanitity of registers */
   *((word *)&mb.TxBuf[4]) = Data;

   /* set modbus message length */
   mbMsgLength = 6;
   /* send modbus PDU */
   mbTx();   
}

/*
** ------------------------------------------------------------------------------
**		Function: byte Write_Multiple_Reg(word Adr, float Data)
** ------------------------------------------------------------------------------
*/
 
void Write_Multiple_Reg(word Adr, float Data)
{
   /* set modbus id */
   mb.TxBuf[0] = 1;
   /* set read holding reg function code */
   mb.TxBuf[1] = 0x10;
   /* load start address */
   mb.TxBuf[2] = *((byte *)&Adr);
   mb.TxBuf[3] = *(((byte *)&Adr)+1);
   /* set quanitity of registers */
   mb.TxBuf[4] = 0;
   mb.TxBuf[5] = 2;
   /* set byte count */
   mb.TxBuf[6] = 4;
   /* set data */   
   mb.TxBuf[7] = *((byte *)&Data);
   mb.TxBuf[8] = *(((byte *)&Data)+1);
   mb.TxBuf[9] = *(((byte *)&Data)+2);
   mb.TxBuf[10] = *(((byte *)&Data)+3);

   /* set modbus message length */
   mbMsgLength = 11;
   /* send modbus PDU */
   mbTx();   
}

/*
** ------------------------------------------------------------------------------
**		Function: void Write_String_Reg(word Adr, byte *Data, byte Length)
** ------------------------------------------------------------------------------
*/
 
void Write_String_Reg(word Adr, byte *Data, byte Length)
{
   /* set modbus id */
   mb.TxBuf[0] = 1;
   /* set read holding reg function code */
   mb.TxBuf[1] = 0x10;
   /* load start address */
   mb.TxBuf[2] = *((byte *)&Adr);
   mb.TxBuf[3] = *(((byte *)&Adr)+1);
   /* set quanitity of registers */
   mb.TxBuf[4] = 0;
   mb.TxBuf[5] = Length;
   /* set byte count */
   mb.TxBuf[6] = Length*2;
   
   /* set data */   
   strncpy(&mb.TxBuf[7], Data, Length*2);

   /* set modbus message length */
   mbMsgLength = 7+Length*2;
   /* send modbus PDU */
   mbTx();   
}

/*
** ------------------------------------------------------------------------------
**		Function: void mbWrite_SerEE_Reg(word Adr, byte Len, float Data)
** ------------------------------------------------------------------------------
*/
 
void mbWrite_SerEE_Reg(word Adr, byte Len, void *Data)
{
   /* set modbus id */
   mb.TxBuf[0] = 1;
   /* set read holding reg function code */
   mb.TxBuf[1] = 0x64;

   /* a1186 and a1197 have cals offset in seial eeprom */
   if(mbSlave.BoardType==A1186_01 || mbSlave.BoardType==A1197_04)
      Adr += 0x3FFF;   
   
   /* load start address */
   mb.TxBuf[2] = *((byte *)&Adr);
   mb.TxBuf[3] = *(((byte *)&Adr)+1);

   /* set quanitity of registers */
   mb.TxBuf[4] = 0;
   mb.TxBuf[5] = Len;
   /* set byte count */
   mb.TxBuf[6] = Len*2;

   switch (mbTable[mbTableIndex].Atrib&(mbStr|mbByte|mbWord|mbLong|mbFloat))
   {
   case mbStr:
   
      break;

   case mbByte:
      mb.TxBuf[7] = 0; 
      mb.TxBuf[8] = *((byte *)Data);
      /* set modbus message length */
      mbMsgLength = 9;
      break;

   case mbWord:
      mb.TxBuf[7] = *((byte *)Data);
      mb.TxBuf[8] = *(((byte *)Data)+1);
      /* set modbus message length */
      mbMsgLength = 9;
      break;

   case mbFloat:
      mb.TxBuf[7] = *((byte *)Data);
      mb.TxBuf[8] = *(((byte *)Data)+1);
      mb.TxBuf[9] = *(((byte *)Data)+2);
      mb.TxBuf[10] = *(((byte *)Data)+3);
      /* set modbus message length */
      mbMsgLength = 11;
      break;
   }
               
   /* send modbus PDU */
   mbTx();   
}

/*
** ------------------------------------------------------------------------------
**		Function: void mbModBusDriver(void)
** ------------------------------------------------------------------------------
*/

void mbModBusDriver(void)
{
   switch(mbDriverState)
   {
   case mbCONNECT:
      /* Initialze SCI2 for 485 Modbus to host */
      SCI_Init(SCI2_ADR, 38400, (EIGHTBIT|NOPARITY), (_RE|_TE));   

      /* set slcd status */
      mbStatus = mbOFFLINE;        
      /* clear registers */
      mbTimeOutCnt = 0;
      /* read version over modbus to see if a slave is connected */
      mbRead_Holding_Reg(30000, 10);   
      /* change driver state to busy */
      mbDriverState = mbBUSY;
      break;

   case mbIDLE:
      /* check modbus table write flags */
      if(mbTable[mbTableIndex].WrFlg)
      {
         switch (mbTable[mbTableIndex].WrFlg)
         {
         case 1:
            /* is the funtion pointer loaded ? */
            if(mbTable[mbTableIndex].fp)
               /* call */
               (mbTable[mbTableIndex].fp)(1);
                     
            /* is parameter RdWr */
            if(!(mbTable[mbTableIndex].Atrib&mbReadOnly))
            {
               switch (mbTable[mbTableIndex].Atrib&(mbStr|mbByte|mbWord|mbLong|mbFloat))
               {
               case mbStr:
                  Write_String_Reg(mbTable[mbTableIndex].Adr, (byte *)mbTable[mbTableIndex].RamPtr, mbTable[mbTableIndex].Size);
                  break;

               case mbByte:
                  Write_Single_Reg(mbTable[mbTableIndex].Adr, *(byte *)mbTable[mbTableIndex].RamPtr);
                  break;

               case mbWord:
                  Write_Single_Reg(mbTable[mbTableIndex].Adr, *(word *)mbTable[mbTableIndex].RamPtr);
                  break;

               case mbLong:
               case mbFloat:
                  Write_Multiple_Reg(mbTable[mbTableIndex].Adr, *(float*)mbTable[mbTableIndex].RamPtr);
                  break;
               }
            }
            break;
         
         case 0x64:
            /* build write eeprom PDU */
            mbWrite_SerEE_Reg(mbTable[mbTableIndex].Adr, mbTable[mbTableIndex].Size, mbTable[mbTableIndex].RamPtr);
            /* change driver state to busy */
            mbDriverState = mbBUSY;  
            /* clear read flag */
            mbTable[mbTableIndex].WrFlg = 0;
            break;
         }

         /* change driver state to busy */
         mbDriverState = mbBUSY;         
         /* clear read flag */
         mbTable[mbTableIndex].WrFlg = 0;
      }
      else
      {
         /* check modbus table read flags */
         if(mbTable[mbTableIndex].RdFlg)
         {
            /* what command? */
            switch(mbTable[mbTableIndex].RdFlg)
            {
            case 0x01:
               /* build read PDU */
               mbRead_Holding_Reg(mbTable[mbTableIndex].Adr, mbTable[mbTableIndex].Size);
               /* change driver state to busy */
               mbDriverState = mbBUSY;  
               /* clear read flag */
               mbTable[mbTableIndex].RdFlg = 0;
               break;

            case 0x65:
               /* build read eeprom PDU */
               mbRead_SerEE_Reg(mbTable[mbTableIndex].Adr, mbTable[mbTableIndex].Size);
               /* change driver state to busy */
               mbDriverState = mbBUSY;  
               /* clear read flag */
               mbTable[mbTableIndex].RdFlg = 0;
               break;
            }
         }
         else
         {
            if(mbTableIndex>=mbTableSize)
               mbTableIndex = 0;
             else
               /* for next pass */
               mbTableIndex++;
         }
      }
      break;
            
   case mbBUSY:
      /* wait for respons from mb or timeout */
      if (mbStatus == mbONLINE)
      {
         if (mb.In)
         {
            /* clear the in flag */
            mb.In = 0;
            /* clear busy flag */     
            mb.Busy = 0;
            
            /* clear this just incase */
            mbTimeOutCnt = 0;
            
            /* check for CRC error */
            if(!CheckCRC((byte *)&mb.RxBuf, mbMsgLength))
            {
               /* modbus diagnostic counters */
               BusComErrCnt++;
            }
            else
            {
               /* look for error response */
               if((byte)mb.RxBuf[1]&0x80)
               {
                  ExceptionErrCnt++;            
               }
               else
               {            
                  /* switch on return fuction code */
                  switch (mb.RxBuf[1])
                  {
                  case 0x03:     /* read holding reg */
                  case 0x65:     /* read EE reg */
                     
                     //if(mbTable[mbTableIndex].Adr==31126)
                     //   PTP_PTP4 = 1;   
                     
                     /* load data to pointer */            
                     if(mbTable[mbTableIndex].Atrib&mbByte)
                        memcpy((void *)mbTable[mbTableIndex].RamPtr, &mb.RxBuf[4], mbTable[mbTableIndex].Size);                   
                     else
                        memcpy((void *)mbTable[mbTableIndex].RamPtr, &mb.RxBuf[3], mbTable[mbTableIndex].Size*2);                   
                     
                     /* is the funtion pointer loaded ? */
                     if(mbTable[mbTableIndex].fp)
                        /* call */
                        (mbTable[mbTableIndex].fp)(0);
                                    
                     break;
                  
                  case 0x06:     /* write single reg */
                  
                     break;
                     
                  }
               }
            }
            /* change driver state to busy */
            mbDriverState = mbIDLE;                
         }
         else if (!mb.TimeOut)
         {
            /* are we unplugged? */
            if(++mbTimeOutCnt>5)
            {
               /* change driver state */
               mbDriverState = mbCONNECT;
            }
         }
      }
      else
      {
         if (mb.In)
         {
            /* clear the in flag */
            mb.In = 0;
            /* clear busy flag */     
            mb.Busy = 0;
               
            /* check modbus response */
            if(CheckCRC(mb.RxBuf, mbMsgLength))
            {
               /* change slcd driver state */
               mbDriverState = mbIDLE;
               /* set slcd status */
               mbStatus = mbONLINE; 

               /* load version */            
               memcpy((void *)mbTable[mbTableIndex].RamPtr, &mb.RxBuf[3], mbTable[mbTableIndex].Size*2);                   
               /* fill modbus table */
               mbIntSetRdFlags();
            }
            else
            {
               /* set busy flag to timeout and reconnect */     
               mb.Busy = 1;
            }
         }
         else 
         if (!mb.TimeOut)
         {
            /* change driver state */
            mbDriverState = mbCONNECT;         
         }
      }
      break;
   }
}


/*
** ------------------------------------------------------------------------------
**		Function: __interrupt void near ModBus_Interrupt(void)
** ------------------------------------------------------------------------------
*/

#pragma CODE_SEG NON_BANKED 

__interrupt void near ModBus_Interrupt(void)
{
   volatile byte i;
   
   /* receive Interrupt?  */		               
   if (SCIPtr->SCICR2&_RIEN && SCIPtr->SCISR1&_RDRF)          
   {
      i = SCIPtr->SCIDRL;							
      
      /* start the 3 character timeout */
      mbStartT3Timeout(38400);
         
      if (mb.RxPtr < &mb.RxBuf[mbRXBUF_SZ-1])	
         *(mb.RxPtr++) = i;              
      else
         mb.RxPtr = mb.RxBuf;   
      
      /* count message length */
      mbMsgLength++;
   }
   else
   {
      /* Transmit Interrupt ? */
		if (SCIPtr->SCICR2&_TIEN && SCIPtr->SCISR1&_TDRE)	   
      {
         i = *mb.TxPtr++;
                  
         if(mbMsgLength)               
         {
            /* send next char (clears irq) */
            SCIPtr->SCIDRL = i;                  
            /* decrement msg length counter */            
            mbMsgLength--;
         }
         else                          	
         {
            /* turn on tx complete irq */
            SCIPtr->SCICR2 |= _TCIE;
            /* turn off tx irq */		   
            SCIPtr->SCICR2 &=~ _TIEN; 
         }
      }

      /* is TCIE enabled and Tx finished */
      if (SCIPtr->SCICR2&_TCIE && SCIPtr->SCISR1&_TC)		   
      {               
         SCIPtr->SCICR2 &=~ _TCIE; 
         SCIPtr->SCICR2 |= _RIEN;

         /* turn off 485 driver */
         //if (BoardType == _1162)
            //PORTK_PK5 = 0;
         //else
            PORTK_PK4 = 0;
      }
   }    
}

