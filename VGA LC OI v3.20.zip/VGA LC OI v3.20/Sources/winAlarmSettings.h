/*
** ------------------------------------------------------------------------------
   
   File   : winAlarms.h 
   Aurthor: Stuart Clarke

** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

#ifndef WINALARMS_H
#define WINALARMS_H


/* public defines */


/*
** ------------------------------------------------------------------------------
**		#define : diagnostics handler states 
** ------------------------------------------------------------------------------
*/

#define WIN_ALARMS_PREPAINT     0
#define WIN_ALARMS_PAINT        1
#define WIN_ALARMS_PAINT_PAGE   2
#define WIN_ALARMS_UPDATE       3
#define WIN_ALARMS_NUMKEYPAD    4
#define WIN_ALARMS_UNLOAD       5




#ifndef WIN_ALARMS_C

/* public variables */
#pragma DATA_SEG WINALARMS_Data


#endif   /* WINALARMS_C */      


/* public functions */
#pragma CODE_SEG WINALARMS_Code

/*
** ------------------------------------------------------------------------------
**		Function: void ReadAlarmParameters(void)
** ------------------------------------------------------------------------------
*/

void ReadAlarmParameters(void);

/*
** ------------------------------------------------------------------------------
**		Function: byte winAlarmsHandler(void)
** ------------------------------------------------------------------------------
*/

byte winAlarmsHandler(void);

#endif   /* WINALARMS_H */
