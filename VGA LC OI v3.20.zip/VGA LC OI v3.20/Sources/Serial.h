/*
** ------------------------------------------------------------------------------
   
   File   : Serial.h 
   Aurthor: Stuart Clarke
        
** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

#ifndef SERIAL_H
#define SERIAL_H


/* public defines */



/*
** ------------------------------------------------------------------------------
**		#define : SCI base addresses
** ------------------------------------------------------------------------------
*/

#define _SCI0_ADR  0x0C8
#define _SCI1_ADR  0x0D0
#define _SCI2_ADR  0x0B8
#define _SCI3_ADR  0x0C0
#define _SCI4_ADR  0x130
#define _SCI5_ADR  0x138

/*
** ------------------------------------------------------------------------------
**		#define : SCI Control Register 1 defines
** ------------------------------------------------------------------------------
*/

#define _EIGHTBIT     0x00
#define _NINEBIT      0x10

#define _EVENPARITY   0x02
#define _ODDPARITY    0x03
#define _NOPARITY     0x00

/*
** ------------------------------------------------------------------------------
**		#define : SCI Control Register 2 defines
** ------------------------------------------------------------------------------
*/

#define __RE          0x04
#define __TE          0x08
#define __RIEN        0x20
#define __TCIE        0x40
#define __TIEN        0x80

/*
** ------------------------------------------------------------------------------
**		#define : SCI Status Register 1 defines
** ------------------------------------------------------------------------------
*/

#define __RDRF        0x20
#define __TC          0x40
#define __TDRE        0x80


/*
** ------------------------------------------------------------------------------
**		#define : SCI baud rates
** ------------------------------------------------------------------------------
*/

#define _115200 (word) ((40000000/115200)/16)  
#define _57600  (word) ((40000000/57600)/16)  
#define _38400  (word) ((40000000/38400)/16)
#define _19200  (word) ((40000000/19200)/16)
#define _9600   (word) ((40000000/9600)/16)
 
 
/*
** ------------------------------------------------------------------------------
**		typedef: SCI type 
** ------------------------------------------------------------------------------
*/

typedef struct
{
   word SCIBD;
   byte SCICR1;
   byte SCICR2;         
   byte SCISR1;         
   byte SCISR2; 
   byte SCIDRH;
   byte SCIDRL;        
}_SCI_Type;

#ifndef SERIAL_C


/* public variables */
#pragma DATA_SEG   SERIAL_DATA

extern byte InFlag;
extern byte ErrFlag;


#endif   /* SERIAL_C */ 


/* public functions */

#pragma CODE_SEG   ROM_F200_SEG

/*
** ------------------------------------------------------------------------------
**		Function: void _SCI_Init(word Baud, byte C1, byte C2);
** ------------------------------------------------------------------------------
*/

void _SCI_Init(word Baud, byte C1, byte C2);

/*
** ------------------------------------------------------------------------------
**		Function: byte *_strcpy1(byte *str_d, byte *str_s)
** ------------------------------------------------------------------------------
*/

byte *_strcpy1(byte *str_d, byte *str_s);


/*
** ------------------------------------------------------------------------------
**		Function: void _SendMsg(byte *Ptr)
** ------------------------------------------------------------------------------
*/

void _SendMsg(byte *Ptr);

/*
** ------------------------------------------------------------------------------
**		Function: void _Check_Serial(void)
** ------------------------------------------------------------------------------
*/

void _Check_Serial(void);

#pragma CODE_SEG ROM_F000_SEG


/*
** ------------------------------------------------------------------------------
**		Function: static void _SCI0_Interrupt(void)
** ------------------------------------------------------------------------------
*/

__interrupt void near _SCI0_Interrupt(void);

/*
** ------------------------------------------------------------------------------
**		Function: static void _ETC1_Interrupt(void)
** ------------------------------------------------------------------------------
*/

__interrupt void near _ETC1_Interrupt(void);


#endif   /* SERIAL_H */
