#include <hidef.h>                           /* common defines and macros */
#include "derivative.h"                      /* derivative information */

/*
** ------------------------------------------------------------------------------
   
   File   : winUserMenu.c 
   Aurthor: 
   
   Description:  
   
   Version Log          Notes                                     Changes Made by                                        
   --------------       -----                                     ---------------
   21-10-09:            Created                                   Stuart


** ------------------------------------------------------------------------------
                                    
                                    Overview
                                            
** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

/* library headers */
#include "stdio.h"
#include "float.h"
#include "math.h"

/* Application headers */
#include "CRG 100110.h" 
#include "Subs.h"
#include "SlcdSubs.h"
#include "ModBusM Int.h"
#include "ModBusM.h"
#include "EEPROM.h"
#include "SLCD 260217.h"
#include "winMain.h"
#include "winKey.h"
#include "Language.h"


/* Implements this interface: */
#define WINUSER_C
#include "winUserMenu.h"

#pragma CODE_SEG WINUSER_CODE
#pragma DATA_SEG WINUSER_DATA


/* private */
static byte winUserState;


/* public */
byte winUserReturnWin;


/*
** ------------------------------------------------------------------------------
**		Function: void winUserKeyHandler(byte key)
** ------------------------------------------------------------------------------
*/

void winUserKeyHandler(byte key)
{   
   switch (key)
   {
   case 1:
      winUserReturnWin = SPEEDCAL_WINDOW; 
      /* display password prompt */
      winUserState = WIN_USER_ENTER_PASSWORD;     
      /* copy parameter data to key structure */
      strcpy(NumKeyData.Name, gstr(&str->EnterPassword) );  
      NumKeyData.KeyBoardType = NUMBER;
      NumKeyData.Type = ENTERPASSWORD;     
      break;

   case 2:
      winUserReturnWin = BASIC_CONFIG_WINDOW; 
      /* display password prompt */
      winUserState = WIN_USER_ENTER_PASSWORD;     
      /* copy parameter data to key structure */
      strcpy(NumKeyData.Name, gstr(&str->EnterPassword) );  
      NumKeyData.KeyBoardType = NUMBER;
      NumKeyData.Type = ENTERPASSWORD;     
      break;
      
   case 3:
      winUserReturnWin = ENGINEERING_WINDOW; 
      /* display password prompt */
      winUserState = WIN_USER_ENTER_PASSWORD;     
      /* copy parameter data to key structure */
      strcpy(NumKeyData.Name, gstr(&str->EnterPassword) );  
      NumKeyData.KeyBoardType = NUMBER;
      NumKeyData.Type = ENTERPASSWORD;     
      break;      

   case 4:
      winUserReturnWin = HISTOGRAM_WINDOW;
      /* shut down num key window handler */
      winUserState = WIN_USER_UNLOAD;  
      break;      

   case 128:       /* EXIT */
      winUserReturnWin = MAIN_WINDOW;
      /* shut down num key window handler */
      winUserState = WIN_USER_UNLOAD;  
      break;  
     
   }
}


/*
** ------------------------------------------------------------------------------
**		Function: void ReadUserParameters(void)
** ------------------------------------------------------------------------------
*/

void ReadUserParameters(void)
{
   mbTable[enBusType].RdFlg = 0x1;

}


/*
** ------------------------------------------------------------------------------
**		Function: void UpdateUser(void)
** ------------------------------------------------------------------------------
*/

void UpdateUser(void)
{  
   /* requested update */
   if (winUpdate1==1)
   {
      /* stop counter */
      winUpdate1 = 0;
      
   }

   /* time to update? */
   if (!winTimer1)
   {
      winTimer1 = 25;

   }
}

/*
** ------------------------------------------------------------------------------
**		Function: byte winUserMenuHandler(void)
** ------------------------------------------------------------------------------
*/

byte winUserMenuHandler(void)
{
   switch (winUserState)
   {
   case WIN_USER_PREPAINT:
      /* get analog parameters from slave */
      ReadUserParameters();

      /* set delay for parameters to arrive from MCT  */
      winUpdate1 = 15;

      //slcdSubsSetOffsets();
            
      winUserState = WIN_USER_PAINT;
      break;
      
   case WIN_USER_PAINT:
      if(winUpdate1==1)
      {
         winUpdate1 = 0;

         //slcdSubsSetOffsets();

         slcd_SetColour(DarkGrey, DarkGrey);
         slcd_Send("z");

         slcd_Send("xc all");     
         /* display menu screen */
         //DisplayBmp(16, 0, 0, LEFT_ALIGN); 
         slcd_DisplayBmp(10, 0, 0); 

         //DisplayTitle("MS Instrumentos");
         DisplayTitle(gstr(&str->User_Menu));
         
         
         slcd_SetFont(24, 0);
         slcd_SetColour(LightGrey, White); 
         //slcd_SendText(gstr(&str->User_Menu), 15, 0, 0, LEFT_ALIGN);
         
         slcdDrawRectangle(100,120,180,70); //(x inicial, y inicial, comp. x, comp. y)
         slcdDrawRectangle(100,300,180,70);
         slcdDrawRectangle(390,120,180,70);
         slcdDrawRectangle(390,300,180,70);
         
         /* define back hotspot */
         //slcd_CmdQueue("x 128 560 10 630 60");
         slcd_MakeHotSpot(128, 560, 10, 50, 50);
         
         /* display buttons */   
         slcd_MakeButton(1, 1, 40,  120, 2, 3);
         slcd_MakeButton(2, 1, 40,  300, 2, 3);

         slcd_MakeButton(3, 1, 330, 120, 2, 3);
         slcd_MakeButton(4, 1, 330, 300, 2, 3);
         
         slcd_SetColour(DarkGrey, LightGrey);               

         slcd_SetFont(16, 0);
         slcd_SendText(gstr(&str->Calibration),      105, 140, 0, LEFT_ALIGN);
         
         slcd_SendText(gstr(&str->Configuration),    105, 300, 0, LEFT_ALIGN);
         slcd_SendText(gstr(&str->BasicDiagnostics), 105, 330, 0, LEFT_ALIGN); 


         slcd_SendText(gstr(&str->Engineering),      395, 140, 0, LEFT_ALIGN);
         slcd_SendText(gstr(&str->Histogram),        395, 320, 0, LEFT_ALIGN);      
         
         /* update parameters */
         winUpdate1 = 1;
         
         /* move to update state */      
         winUserState = WIN_USER_UPDATE;       
      }
      return 0;

   case WIN_USER_UPDATE:
      /* is there a key to process? */
      if (slcdKey)
      {
         /* call key handler */
         winUserKeyHandler(slcdKey);      
         /* now the key has been processed clear it */
         slcdKey = 0; 
      }

      UpdateUser();

      /* has any data been remotely changed? */
      if(mbSlave.DataUpdate)
      {
         /* clear data update flag */
         mbSlave.DataUpdate = 0;
         mbTable[enDataUp].WrFlg = 1;   
         
         /* read analog parameters */
         ReadUserParameters();  
         
         /* set update timer */                   
         winUpdate1 = 100;
      }      
      return 0;

  case WIN_USER_NUMKEYPAD:
      /* see if key pad is returning */
      if(winKeyPadHandler())
      {
         /* move to update state */      
         winUserState = WIN_USER_PREPAINT;       
      }
      break;

 case WIN_USER_ENTER_PASSWORD:
      /* see if key pad is returning */
      switch(winKeyPadHandler())
      {
      case 1:
         /* move to update state */      
         winUserState = WIN_USER_PREPAINT;       
         break;

      case 2:
         /* move to update state */      
         winUserState = WIN_USER_UNLOAD;       
         break;
      }
      break;
      
   case WIN_USER_UNLOAD:
      /* do any necessary clearing up */
      winUserState = WIN_USER_PREPAINT;  

      /* set return menu */
      winActiveWin = winUserReturnWin;
      /* clear return win */ 
      winUserReturnWin = 0; 

      /* return from key pad */
      return 1;
   }   
}



