/*
** ------------------------------------------------------------------------------
   
   File   : winKey.h 
   Aurthor: Stuart Clarke

** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

#ifndef WINKEYPAD_H
#define WINKEYPAD_H


/* public defines */


/*
** ------------------------------------------------------------------------------
**		#define : diagnostics handler states 
** ------------------------------------------------------------------------------
*/

#define WIN_KEY_PAINT        0
#define WIN_KEY_UPDATE       1
#define WIN_KEY_UNLOAD       2


/*
** ------------------------------------------------------------------------------
**		#define: Key data type defines
** ------------------------------------------------------------------------------
*/

#define BYTE            1
#define WORD            2
#define FLOAT           4
#define LONG            8
#define STRING          16
#define PASSWORD        32
#define ENTERPASSWORD   64
#define IPADR           128
#define ASCI            256 
#define NEWPASSWORD     512
#define TIME            1024
#define DATE            2048            

/*
** ------------------------------------------------------------------------------
**		#define: attribute defines
** ------------------------------------------------------------------------------
*/

#define EPROM        1
#define RAM          2
#define REMOTE       4
#define SEREE        8

/*
** ------------------------------------------------------------------------------
**		#define: Ketboard types 
** ------------------------------------------------------------------------------
*/

#define NUMBER       0
#define LETTER       1


/*
** ------------------------------------------------------------------------------
**		#typedef: Numerical key pad data type 
** ------------------------------------------------------------------------------
*/

typedef struct
{
   byte Name[20];
   word Type;
   void *DataPtr; 
   void *DataPtr1; 
   void *DataPtr2; 
   void *DataPtr3; 
   
   float fMax;
   float fMin;

   int iMax;
   int iMin;

   long lMax;
   long lMin;
   
   byte Index;
   byte Flag;
   
   byte Attributes;
   byte KeyBoardType;
   
   int  (*fp)(void);    
}NumKeyType;



#ifndef WINKEYPAD_C

/* public variables */
#pragma DATA_SEG WINKEYPAD_Data

extern NumKeyType NumKeyData;
extern word       PassWord;

#endif   /* WINKEYPAD_C */      


/* public functions */
#pragma CODE_SEG WINKEYPAD_Code

 /*
** ------------------------------------------------------------------------------
**		Function: void PaintKeyBoard(void)
** ------------------------------------------------------------------------------
*/

void PaintKeyBoard(void);

/*
** ------------------------------------------------------------------------------
**		Function: byte winKeyPadHandler(void)
** ------------------------------------------------------------------------------
*/

byte winKeyPadHandler(void);

#endif   /* WINKEYPAD_H */
