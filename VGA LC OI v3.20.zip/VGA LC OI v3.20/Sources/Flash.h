/*
** ------------------------------------------------------------------------------
   
   File   : Flash.h 
   Aurthor: Stuart Clarke
        
** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

#ifndef FLASH_H
#define FLASH_H


/* public defines */


/*
** ------------------------------------------------------------------------------
**		typedef struct : s1Type
** ------------------------------------------------------------------------------
*/

typedef struct
{
   byte Type;
   byte ByteCount;
   word Address;
   byte CheckSum;      
}s1Type;

/*
** ------------------------------------------------------------------------------
**		typedef struct : s2Type
** ------------------------------------------------------------------------------
*/

typedef struct
{
   byte ByteCount;
   byte Page;
   word Address;
   byte CheckSum;      
}s2Type;

/*
** ------------------------------------------------------------------------------
**		#define : FSTAT defines 
** ------------------------------------------------------------------------------
*/

#define FPageWsize   0x4000
#define FPageWstart  0x8000

/*
** ------------------------------------------------------------------------------
**		#define : FSTAT defines 
** ------------------------------------------------------------------------------
*/

#define CBEIF        0x80
#define CCIF         0x40
#define PVIOL        0x20
#define ACCERR       0x10
#define BLANK        0x04


/*
** ------------------------------------------------------------------------------
**		#define : flash commands
** ------------------------------------------------------------------------------
*/

#define EraseVerfCmd   0x05
#define DataCompCmd    0x06
#define ProgCmd        0x20
#define SectorEraseCmd 0x40
#define MassEraseCmd   0x41


#ifndef FLASH_C

/* public variables */
#pragma DATA_SEG   FLASH_DATA

#endif   /* FLASH_C */ 


/* public functions */

#pragma CODE_SEG   ROM_F200_SEG

/*
** ------------------------------------------------------------------------------
**		Function: void _Flash_Init(void)
** ------------------------------------------------------------------------------
*/

void _Flash_Init(void);

/*
** ------------------------------------------------------------------------------
**		Function: static void CopyCodeToRAM(void)
** ------------------------------------------------------------------------------
*/

void CopyCodeToRAM(void);


/*
** ------------------------------------------------------------------------------
**		Function: byte EraseFlash(void)
** ------------------------------------------------------------------------------
*/

byte EraseFlash(void);

/*
** ------------------------------------------------------------------------------
**		Function: byte ProgramS1(void)
** ------------------------------------------------------------------------------
*/

byte *ProgramS1(void);

/*
** ------------------------------------------------------------------------------
**		Function: byte ProgramS2(void)
** ------------------------------------------------------------------------------
*/

byte *ProgramS2(void);


#pragma CODE_SEG ROM_F000_SEG

/*
** ------------------------------------------------------------------------------
**		Function: byte EraseFlashCmd(byte Page, word Sector, byte FlashCmd)
** ------------------------------------------------------------------------------
*/

byte EraseFlashCmd(byte Page, word Sector, byte FlashCmd);

/*
** ------------------------------------------------------------------------------
**		Function: byte ProgFlashBlock(byte PPAGEVal, word *PPAGEWinAddr, word *DataBuff, word NumWords)
** ------------------------------------------------------------------------------
*/

byte ProgFlashBlock(byte Ppage, word *AdrPtr, word *DataPtr, word ByteCnt);

#endif   /* SERIAL_H */
