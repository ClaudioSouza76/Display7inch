#include <hidef.h>                           /* common defines and macros */
#include <mc9s12xd256.h>                    /* derivative information */

/*
** ------------------------------------------------------------------------------
   
   File   : Cmd.c 
   Aurthor: 
   
   Description:  
   
   Version Log          Notes                                     Changes Made by                                        
   --------------       -----                                     ---------------
   03-08-09:            Created                                   Stuart


** ------------------------------------------------------------------------------
                                    
                                    Overview
                                            
** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

/* library headers */
#include "String.h"
#include "Stdio.h"
#include "ctype.h"
#include "math.h"


/* Application headers */
#include "Main.h"
#include "Subs.h"
#include "EEPROM.h"
#include "SCI 100110.h"
#include "ADC 100118.h"
#include "Language.h"


/* Implements this interface: */
#define CMD_C
#include "Cmd.h"

#pragma DATA_SEG EEPROM_DATA


#pragma CODE_SEG CMD_Code
#pragma DATA_SEG CMD_Data


/* private */
static SCI_Type *SCIPtr;
static byte Sleep; 
static byte ComPort;
static CmdType CMD;


/* public */
byte    *RxDataPtr;
byte    *RxBufPtr;
byte    *TxBufPtr;


/*
** ------------------------------------------------------------------------------
**		Cmd Cmd Table
** ------------------------------------------------------------------------------
*/

#pragma INTO_ROM
static const CmdTabType Cmdtab[]=
{

"VER?",           1,
"BAUD=",          2,
"ID=",		      3,
"ID?",		      4,

"DEBUG=",         7,
"DEBUG?",         8,
"TEST?",          9,

"RESET",          14,
"BOOT",           15,

"",			      0
};


/*
** ------------------------------------------------------------------------------
**		Function: void CmdInit(word SCIRegPtr)
** ------------------------------------------------------------------------------
*/

void CmdInit(word SCIRegPtr)
{ 
   /* Set pointer to base address of SCI register map */
   SCIPtr = (SCI_Type *)SCIRegPtr; 
      
   /* Initialize buffer pointers */
   CMD.TxPtr = CMD.TxBuf;                 
   CMD.RxPtr = CMD.RxBuf;    
}


/*
** ------------------------------------------------------------------------------
**		Function: void CmdTx(void)
** ------------------------------------------------------------------------------
*/

void CmdTx(void)
{
   /* 
      STRA will add carriage return and then null terminate SCI buffer before  
      for transmission on related UART is initiated. 
   */           

   word i;

   i = strlen(TxBufPtr);          
   *(TxBufPtr+i++) = 0x0d;
   *(TxBufPtr+i) = 0;

   switch(ComPort)
   {
   case 0:      
      CMD.TxPtr = CMD.TxBuf;                 
      CMD.RxPtr = CMD.RxBuf;                 
      CMD.Busy  = 1;       
      SCIPtr->SCICR2 |= _TIEN;                  
      break;  
   }
}

/*
** ------------------------------------------------------------------------------
**		Function: void CmdTx(byte *Ptr)
** ------------------------------------------------------------------------------
*/

void CmdSend(byte *Ptr)
{
   if (EEPROM.cmdDebug)
   {
      /* reset tx ptr */
      CMD.TxPtr = CMD.TxBuf;                 
      /* copy string to buffer */
      strcpy(CMD.TxBuf, Ptr);
      /* terminate string */      
      strcat(CMD.TxBuf, "\r");
      
      /* set busy flag. Cleared by irq */
      CMD.Busy     = 1;       
      /* start tx irq  */   
      SCIPtr->SCICR2 |= _TIEN;                  
      /* wait till string has gone */
      while(CMD.Busy);
   }
}
/*
** ------------------------------------------------------------------------------
**		Function: void NoReply(void)
** ------------------------------------------------------------------------------
*/

void NoReply(void)
{
   /*
      No_Reply is called to reset a com channels input buffers if the com 
      channel is in multidrop address mode and the received data is either 
      a request from the master but not addressed to us or a response from 
      a slave to a request
   */
   
   switch(ComPort)
   {
   case 0:
      CMD.RxPtr = CMD.RxBuf;
      break; 
   }
}

/*
** ------------------------------------------------------------------------------
**		Function: void Reply(Resp)
** ------------------------------------------------------------------------------
*/

void Reply(byte Resp)
{
   /* 
      If the com channel is in multidrop mode an ACK is a '*' if we're not 
      an ACK is a '0'. Other wise format the error response. 
   */

   if (Resp == ACK)
   {
      if (Sleep & (0x01<<ComPort))        
         *TxBufPtr = '*';
      else
         *TxBufPtr = '0';

      *(TxBufPtr+1) = 0;   
   }
   else
   {
      sprintf(TxBufPtr, "?%1d", Resp);
   }
   CmdTx();
}

/*
** ------------------------------------------------------------------------------
**		Function: byte CmdMatch(txtplus1 *blk)
** ------------------------------------------------------------------------------
*/

byte CmdMatch(CmdTabType *blk)
{
   /*
      CmdMatch will loop though the command table comparing the command strings
      with the contents of the input buffer. If it finds a valid match it will 
      break and return the numeric ID id the command for use in the reply 
      switch case.        
   */
   
   for(;;)
   {
      if (!*(blk)->txt) 
         return 0;           /* end of table */

      if (!strncmp(RxBufPtr, blk->txt, strlen(blk->txt)))
      {
         RxDataPtr = &RxBufPtr[strlen(blk->txt)];
        	return blk->con;
      }
		blk++;
   }
}

/*
** ------------------------------------------------------------------------------
**		Function: void CmdCmdParser(void)
** ------------------------------------------------------------------------------
*/

byte CmdCmdParser(void)
{
   byte  c;
   word  i, j;
   ulong l;
      
  	switch(CmdMatch((CmdTabType *)&Cmdtab))
  	{
   case 1:        /* VER? */
   	sprintf(TxBufPtr, "%s %s", ModelString, VersionString);
   	CmdTx();
   	break;

  	case 2:        /* BAUD= */
	   i = sscanf(RxBufPtr, "%ld", &l);
      if (i<1||(l!=9600 && l!=19200 && l!=38400 && l!=57600 && l!= 115200))
      {
         Reply(DATA_ERR);
      }
      else
      {                  
	      switch (ComPort)
	      {
	      case 0:  
	         CMD.Init = 1;
	         break;
	      }
	      
	      EEWR_32(&EEPROM.cmdBaud, l);				
		   Reply(ACK);
		   /* wait for ACK to transmit before SCI can reconfigure */
		   while(CMD.Busy);
      }
  	   break;

	case 3:       	/* ID= */
		c = *RxBufPtr;
		if (!isalnum(c&0x7f)||!*RxBufPtr)  
		{
			Reply(DATA_ERR);
		}
		else
		{
			EEWR_8(&EEPROM.cmdId, c);
			CmdTx();
		}
		break;

	case 4:        /* ID? */
		sprintf(TxBufPtr, "%c", EEPROM.cmdId);
		CmdTx();
		break;
		

	case 7:       	/* DEBUG= */
		i = sscanf(RxBufPtr, "%u", &j);
		if (i!=1||j>1)  
		{
			Reply(DATA_ERR);
		}
		else
		{
			EEWR_8(&EEPROM.cmdDebug, (byte)j);
			Reply(ACK);
		}
		break;

	case 8:        /* DEBUG? */
		sprintf(TxBufPtr, "%u", EEPROM.cmdDebug);
		CmdTx();
		break;

	case 9:       	/* TEST? */
		sprintf(TxBufPtr, "%u", sizeof(HistogramArray)/8);    
		CmdTx();
		break;		

   
   
   case 14:         /* RESET */
		Reply(ACK);	
		
		/* turn LEDs on */ 
      PTP &=~ 0x70;
      /* wait for watch dog to hit */
      for(;;);
		break;		
				 
	case 15:        /* BOOT */		
      /* write to boot register in EEPROM */
      EEWR_16(&BootReg, 0xAA55);
      strcpy(TxBufPtr, "Resetting");
      CmdTx();

   	/* turn LEDs on */ 
      PTP &=~ 0x70; 
		for(;;);
		break;   		
		
  	default:
  	   return 0;
  	}
  	/* Command processed */ 
  	return 1;
}

/*
** ------------------------------------------------------------------------------
**		Function: void CmdParser(void)
** ------------------------------------------------------------------------------
*/

void CmdParser(void)
{
   /* 
      Add calls to module cmd parsers here 
   */ 
   if (CmdCmdParser())
      return;
   
   if (EECmdParser())
      return;
   
   if (SubsCmdParser())
      return;
   
   if (ADC_CmdParser())
      return;

   if (LangCmdParser())
      return;
     	   
   /* if not in multidrop reply */
   if (!(Sleep & (0x01<<ComPort)))     
      Reply(SYNTAX_ERR);
   else
      NoReply();
}

/*
** ------------------------------------------------------------------------------
**		Function: void CheckCmd(char *RxBuf, char *TxPtr, byte Com)
** ------------------------------------------------------------------------------
*/

void CheckCmd(char *RxBuf, char *TxPtr, byte Com)
{
   /* 
     CheckCmd identifies if the command addressing is being used (#ID). If so then
     it checks the command is addressed to us then conditions the receive buffer 
     by removing the # and ID and calls the command parser to process the command. 
   */
   char *Ptr = RxBuf;
   
	RxBufPtr  = RxBuf;
	TxBufPtr  = TxPtr;
	ComPort   = Com;
		
   if (*RxBufPtr=='$'||*RxBufPtr=='#')      
   {
      Sleep |= (0x01<<ComPort);                 

      if (*(RxBufPtr+1)==EEPROM.cmdId)              
      {
         do                                        
         {
            *Ptr = *(Ptr+2);
         }while(*Ptr++);
                     
         CmdParser();                              
      }
      else
      {
      	NoReply();                               
      }
   }
   else                                       
   {                                          
      if (!(Sleep & (0x01<<ComPort)))         
         CmdParser();                           
      else
         NoReply();                            
   }
}

/*
** ------------------------------------------------------------------------------
**		Function: void CheckCmdInput(void)
** ------------------------------------------------------------------------------
*/

void CheckCmdInput(void)
{
   if (CMD.Init == 1)
   {
      CMD.Init = 0;
      SCI_Init(SCI0_ADR, EEPROM.cmdBaud, (EIGHTBIT|NOPARITY), (_RE|_TE|_RIEN));      
   }
   else if (CMD.In == 1)
   {
      CMD.In = 0;
      CheckCmd(CMD.RxBuf, CMD.TxBuf, 0);   
   }
}

/*
** ------------------------------------------------------------------------------
**		Function: __interrupt void near CMD_Interrupt(void)
** ------------------------------------------------------------------------------
*/

#pragma CODE_SEG NON_BANKED 

__interrupt void near CMD_Interrupt(void)
{
   //byte SCI0SR = SCI0SR1;
   byte i;
   
   /* receive Interrupt?  */		               
   if (SCIPtr->SCICR2&_RIEN && SCIPtr->SCISR1&_RDRF)          
   {
      //i = SCI0DRL;							
      i = SCIPtr->SCIDRL;							
      
      /* ASCI only */   
      if (i>0x1F && i<0x7F)         
      {         
         /* start of a multidrop command? */      
         if (i=='$' || i=='#')      
            CMD.RxPtr = CMD.RxBuf;				      
         
         if (CMD.RxPtr < &CMD.RxBuf[RXBUF_SZ-1])	
            *(CMD.RxPtr++) = i;              
         else
            CMD.RxPtr = CMD.RxBuf;   
      }
      else
      {
         if (i == '\r')                  /* end of cmd? */                    
         {
            CMD.In         = 1;
            *(CMD.RxPtr)++ = 0;    
         }
      }
   }
   else
   {		
		/* Transmit Interrupt ? */
      if (SCIPtr->SCICR2&_TIEN && SCIPtr->SCISR1&_TDRE)	   
      {
         /* is it the end of reply? */
         if (*CMD.TxPtr)									
         {
            /* send next char (clears irq) */
            SCIPtr->SCIDRL = *CMD.TxPtr++;
         }
         else                          	
         {
            SCIPtr->SCICR2 |= _TCIE;
            SCIPtr->SCICR2 &=~ _TIEN; 
         }
      }

      /* is TCIE enabled and Tx finished */
      if (SCIPtr->SCICR2&_TCIE && SCIPtr->SCISR1&_TC)	
      {         
         CMD.Busy   = 0;       
         CMD.TxPtr  = CMD.TxBuf;						
         
         SCIPtr->SCICR2 &=~ _TCIE;
         SCIPtr->SCICR2 |= _RIEN;					       
      }
   }    
}
#pragma CODE_SEG DEFAULT


