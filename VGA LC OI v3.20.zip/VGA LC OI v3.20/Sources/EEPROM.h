/*
** ------------------------------------------------------------------------------
   
   File   : EEPROM.h 
   Aurthor: Stuart Clarke

** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

#ifndef EEPROM_H
#define EEPROM_H

#pragma CODE_SEG EEPROM_Code
#pragma DATA_SEG EEPROM_Data

/* public defines */

/*
** ------------------------------------------------------------------------------
**		define: bootloader defines
** ------------------------------------------------------------------------------
*/

#define INITIALIZE   0xA5A5
#define PROGRAMED    0x5A5A

/*
** ------------------------------------------------------------------------------
**		typedef: byte EEPROM_Type(void)
** ------------------------------------------------------------------------------
*/

#define eeComplieTime __TIME__ __DATE__    


/*
** ------------------------------------------------------------------------------
**		typedef: speed cal type 
** ------------------------------------------------------------------------------
*/

typedef struct
{
   byte Time[12];
   byte Date[12];
   float Speed;   
}SpCalType;

/*
** ------------------------------------------------------------------------------
**		typedef: mass cal type 
** ------------------------------------------------------------------------------
*/

typedef struct
{   
   byte  Time[12];
   byte  Date[12];      
   float TestWeight;   
}MassCalType;

/*
** ------------------------------------------------------------------------------
**		typedef: mass zero cal type 
** ------------------------------------------------------------------------------
*/

typedef struct
{   
   byte  Time[12];
   byte  Date[12];      
   float Zero;   
}MassZeroCalType;

/*
** ------------------------------------------------------------------------------
**		typedef: byte EEPROM_Type(void)
** ------------------------------------------------------------------------------
*/

typedef struct
{
   /* Main.c */	
	byte VerString[12];	
	byte CompileTime[21];
		
   /* cmd.c */	
	unsigned long cmdBaud;
	byte cmdId;
	byte cmdDebug;
	
	
	/* win */
	byte Language;
   byte AlarmState;
   byte AlarmPeriod;	
   word AvgTime;
   byte ProdCodeLock;
   byte BeepVolume;
   word TrendTime;
	
   /* Cal Date */
   SpCalType SpeedCal[3];
   byte  SpeedCalPtr;
   
   /* speed cal */
   float PulseRate;
   
   /* mass cal */   
   MassCalType MassCal[3];
   byte  MassCalPtr;

   /* mass zero cal */   
   MassZeroCalType MassZeroCal[3];
   byte  MassZeroCalPtr;
   
   float RefWeight;

   /* balance data */   
   float TransportCapacity;
   float SensibilityLC;             /*Insert by Souza*/
   float ApplicationCapacity;
   float BalanceCapacity;
   float TestWightAppPercentage;
   
   byte ShippingDate[11];   
   
   float MaterialDensity;
   float BeltSpeed;
   float BeltWidth;   
   float ConvayorAngle;
   float RollerAngle;
   float IdleSpacing;
   
   byte Xscale;
   byte Yscale;
   
   float ZeroMvLimit;
   
   byte MinCalTime;
   byte MaxCalTime;
   
   byte Tag[17];
   
   //word MovingAverageLC;           /*Inserted by Souza*/
   //word MovingAverageBT;           /*Inserted by Souza*/
   byte NextCalDate[12];            /*Inserted by Souza*/
   
   byte Histogram;
   float GraphLimit;
   byte SampleRate;
   
   /*  Inspe�ao Mec�nica */
   byte LocalTrans;
   byte AlinhamRoletes;
   byte DistRoletes;
   byte RigidezTrans;
   byte Comportamento;
   byte SensorVel;
   
   byte Precision;
   
   byte DateCall[3][21];
   byte TimeCall[3][21];
   float Speed[3];
   float ZeroCal[3];
   float SpanCal[3];
   byte CallPtr;
   
   byte SerNumEq[9];   /*Serial Number of the Equipament */
   
   byte ModeloScale[8];   /*Define modelo usado para a balan�a CB=Contra balan�ada e PF= Ponte Flutuante*/
   
   float MassTension;
   float MinTension;
   float MaxTension;
   	
}EEPROM_Type;



#ifndef EEPROM_C

/* public variables */
extern volatile word BootReg;
extern volatile EEPROM_Type EEPROM;

#endif   /* EEPROM_C */      

/* public functions */
#pragma CODE_SEG EEPROM_Code

/*
** ------------------------------------------------------------------------------
**		Function: byte EECmdParser(void)
** ------------------------------------------------------------------------------
*/

byte EECmdParser(void);

/*
** ------------------------------------------------------------------------------
**		Function: void SetEEProtectedDefaults(void)
** ------------------------------------------------------------------------------
*/

void SetEEProtectedDefaults(void);

/*
** ------------------------------------------------------------------------------
**		Function: void SetEEDefaults(void)
** ------------------------------------------------------------------------------
*/

void SetEEDefaults(void);

/*
** ------------------------------------------------------------------------------
**		Function: void EEPROM_Init(void)
** ------------------------------------------------------------------------------
*/

void EEPROM_Init(void);

/*
** ------------------------------------------------------------------------------
**		Function: void MassEraseEE(void)
** ------------------------------------------------------------------------------
*/

void MassEraseEE(void);

/*
** ------------------------------------------------------------------------------
**		Function: void WriteWord(word Addr, word Data)
** ------------------------------------------------------------------------------
*/

void WriteWord(word Addr, word Data);

/*
** ------------------------------------------------------------------------------
**		Function: void WriteSector(word Addr, dword Data)
** ------------------------------------------------------------------------------
*/

void WriteSector(word Addr, dword Data);

/*
** ------------------------------------------------------------------------------
**		void EEWR_X(word Addr, byte *Ptr, byte Len)
** ------------------------------------------------------------------------------
*/

void EEWR_X(word Addr, byte *Ptr, byte Len);

/*
** ------------------------------------------------------------------------------
**		byte EEWR_8(word *Addr, byte Byte)
** ------------------------------------------------------------------------------
*/

void EEWR_8(byte *Addr, byte Byte);

/*
** ------------------------------------------------------------------------------
**		byte EEWR_16(word *Addr, word Word)
** ------------------------------------------------------------------------------
*/

void EEWR_16(word *Addr, word Word);

/*
** ------------------------------------------------------------------------------
**		byte EEWR_32(word *Addr, dword Dword)
** ------------------------------------------------------------------------------
*/

void EEWR_32(dword *Addr, dword Dword);

/*
** ------------------------------------------------------------------------------
**		byte EEWR_fl(word *Addr, float Float)
** ------------------------------------------------------------------------------
*/

void EEWR_fl(float *Addr, float Float);

/*
** ------------------------------------------------------------------------------
**		byte EEWR_Str(word *Addr, byte *String, byte StrLen)
** ------------------------------------------------------------------------------
*/

void EEWR_Str(byte *Addr, byte *String, byte StrLen);

#endif   /* EEPROM_H */
