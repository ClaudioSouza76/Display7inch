/*
** ------------------------------------------------------------------------------
   
   File   : winSimulation.h 
   Aurthor: Stuart Clarke

** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

#ifndef WINSIMULATION_H
#define WINSIMULATION_H


/* public defines */


/*
** ------------------------------------------------------------------------------
**		#define : diagnostics handler states 
** ------------------------------------------------------------------------------
*/

#define WIN_SIMULATION_PREPAINT     0
#define WIN_SIMULATION_PAINT        1
#define WIN_SIMULATION_PAINT_PAGE   2
#define WIN_SIMULATION_UPDATE       3
#define WIN_SIMULATION_NUMKEYPAD    4
#define WIN_SIMULATION_UNLOAD       5




#ifndef WIN_FILTERING_C

/* public variables */
#pragma DATA_SEG WINSIMULATION_Data


#endif   /* WINSIMULATION_C */      


/* public functions */
#pragma CODE_SEG WINSIMULATION_Code

/*
** ------------------------------------------------------------------------------
**		Function: void ReadSimulationParameters(void)
** ------------------------------------------------------------------------------
*/

void ReadSimulationParameters(void);

/*
** ------------------------------------------------------------------------------
**		Function: byte winSimulationHandler(void)
** ------------------------------------------------------------------------------
*/

byte winSimulationHandler(void);

#endif   /* WINSIMULATION_H */
