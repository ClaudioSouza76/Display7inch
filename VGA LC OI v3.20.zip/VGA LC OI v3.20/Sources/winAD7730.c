#include <hidef.h>                           /* common defines and macros */
#include "derivative.h"                      /* derivative information */

/*
** ------------------------------------------------------------------------------
   
   File   : winAD7730.c 
   Aurthor: 
   
   Description:  
   
   Version Log          Notes                                     Changes Made by                                        
   --------------       -----                                     ---------------
   14-10-10:            Created                                   Stuart


** ------------------------------------------------------------------------------
                                    
                                    Overview
                                            
** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

/* library headers */
#include "stdio.h"
#include "float.h"
#include "math.h"

/* Application headers */
#include "CRG 100110.h" 
#include "Subs.h"
#include "ModBusM Int.h"
#include "ModBusM.h"
#include "EEPROM.h"
#include "SLCD 260217.h"
#include "winMain.h"
#include "winKey.h"
#include "Language.h"
#include "AD7730.h"
#include "SlcdSubs.h"

/* Implements this interface: */
#define WINAD7730_C
#include "winAD7730.h"

#pragma CODE_SEG WINAD7730_CODE
#pragma DATA_SEG WINAD7730_DATA


/* private */
static byte winAD7730State;
static byte Ad7730Page;


/* public */
byte winAD7730ReturnWin;

volatile STATUS_STR     _STATUS;
volatile ADMODE_STR     _ADMODE;
volatile ADFILTER_STR   _ADFILTER;
volatile DAC_STR        _DAC;
volatile OFFSET_STR     _OFFSET;
volatile GAIN_STR       _GAIN;

word AdSyncFilter; 

/*
** ------------------------------------------------------------------------------
**		Function: void weAD7730KeyPage1(byte key)
** ------------------------------------------------------------------------------
*/

void weAD7730KeyPage1(byte key)
{
   switch (key)
   {

   }
}

/*
** ------------------------------------------------------------------------------
**		Function: void weAD7730KeyPage2(byte key)
** ------------------------------------------------------------------------------
*/

void weAD7730KeyPage2(byte key)
{
   switch (key)
   {
   case 3: 
      /* FIR Skip bit in filter register */
      ADFILTER_SKIP = slcdKeyState;      
      /* copy register to load cell board */
      mbSlave.ADFilter = ADFILTER;
      /* set write flag */
      mbTable[enAdFilter].WrFlg = 1;   
      break;

   case 4: 
      /* Fast step bit in filter register */
      ADFILTER_FAST = slcdKeyState;      
      /* copy register to load cell board */
      mbSlave.ADFilter = ADFILTER;
      /* set write flag */
      mbTable[enAdFilter].WrFlg = 1;   
      break;      
      
   case 5: 
      /* AC Ext bit in filter register */
      ADFILTER_AC = slcdKeyState;      
      /* copy register to load cell board */
      mbSlave.ADFilter = ADFILTER;
      /* set write flag */
      mbTable[enAdFilter].WrFlg = 1;   
      break;      

   case 6: 
      /* AC Ext bit in filter register */
      ADFILTER_CHP = slcdKeyState;      
      /* copy register to load cell board */
      mbSlave.ADFilter = ADFILTER;
      /* set write flag */
      mbTable[enAdFilter].WrFlg = 1;   
      break;      
   }
}

/*
** ------------------------------------------------------------------------------
**		Function: void weAD7730KeyPage3(byte key)
** ------------------------------------------------------------------------------
*/

void winAD7730KeyHandler(byte key)
{
   switch (key)
   {
   case 1: 
      /* move to previous page */      
      if(Ad7730Page)
      {
         Ad7730Page--;
      
         /* move to repaint state */
         winAD7730State = WIN_AD7730_PAINT;      
      }
      break; 

   case 2: 
      /* move to previous page */      
      if(Ad7730Page<2)
      {
         Ad7730Page++;
      
         /* move to repaint state */
         winAD7730State = WIN_AD7730_PAINT;      
      }
      break; 

   default:
      switch(Ad7730Page)
      {
      case 0:
         /* first page key handler */
         weAD7730KeyPage1(key);
         break;

      case 1:
         /* first page key handler */
         weAD7730KeyPage2(key);
         break;    
         
      case 2:
         /* first page key handler */
         //weAD7730KeyPage3(key);
         break;            
      }      
      break;
      
      
   case 128:       /* EXIT */
      /* shut down num key window handler */
      winAD7730State = WIN_AD7730_UNLOAD;  
      break;       
   }
}

/*
** ------------------------------------------------------------------------------
**		Function: void ReadAD7730Parameters(void)
** ------------------------------------------------------------------------------
*/

void ReadAD7730Parameters(void)
{
   mbTable[enAdStatus].RdFlg  = 1;   
   mbTable[enAdMode].RdFlg    = 1;   
   mbTable[enAdFilter].RdFlg  = 1;   
   mbTable[enAdDAC].RdFlg     = 1;   
   mbTable[enAdOffset].RdFlg  = 1;   
   mbTable[enAdGain].RdFlg    = 1;   
}

/*
** ------------------------------------------------------------------------------
**		Function: void wePaintAD7730Page1(void)
** ------------------------------------------------------------------------------
*/

void wePaintAD7730Page1(void)
{  
   /* set forground and back ground colour */
   slcdSetColour(DarkGrey, White);

   /* set font */
   slcdSetFont(F24B);         

   /* display page title  */
   DisplayText(gstr(&str->AD7730), 16, 7, 'T');
         
   slcdSetFont(F16B);  
   
   /* Status register */
   DisplayText("Status Register",  27, 97, 0); 
   
   slcdSetFont(F8); 
   
   DisplayText("RDY",   x1,   145, 0);    
   DisplayText("STDY",  x2,   145, 0);    
   DisplayText("STBY",  x3,   145, 0);    
   DisplayText("NOREF", x4,   145, 0);    
   DisplayText("MS3",   x5,   145, 0);    
   DisplayText("MS2",   x6,   145, 'T');    
   DisplayText("MS1",   x7,   145, 'T');    
   DisplayText("MS0",   x8,   145, 'T'); 
   
   slcdSetFont(F16B);  
   
   /* Mode register */
   DisplayText("Mode Register",  27,  216, 0); 
   
   slcdSetFont(F8); 
   
   DisplayText("MD2",   x1,   264, 0);    
   DisplayText("MD1",   x2,   264, 0);    
   DisplayText("MD0",   x3,   264, 0);    
   DisplayText("BU",    x4,   264, 0);    
   DisplayText("DEN",   x5,   264, 0);    
   DisplayText("D1",    x6,   264, 'T');    
   DisplayText("D0",    x7,   264, 'T');    
   DisplayText("WL",    x8,   264, 'T'); 
   
   DisplayText("HIREF", x1,   327, 0);    
   DisplayText("ZERO",  x2,   327, 0);    
   DisplayText("RN1",   x3,   327, 0);    
   DisplayText("RN0",   x4,   327, 0);    
   DisplayText("CDIS",  x5,   327, 0);    
   DisplayText("BO",    x6,   327, 'T');    
   DisplayText("CH1",   x7,   327, 'T');    
   DisplayText("CH0",   x8,   327, 'T');    
    
   /* move to update state */      
   winAD7730State = WIN_AD7730_UPDATE;       
}

/*
** ------------------------------------------------------------------------------
**		Function: void wePaintAD7730Page2(void)
** ------------------------------------------------------------------------------
*/

void wePaintAD7730Page2(void)
{  
   lButtonType Button;
   byte ButtonText1[20], ButtonText2[20];
   
   /* set forground and back ground colour */
   slcdSetColour(DarkGrey, White);

   /* set font */
   slcdSetFont(F24B);         

   /* display page title  */
   DisplayText(gstr(&str->AD7730), 16, 7, 'T');
   
   slcdSetFont(F16B);  

   /* Status register */
   DisplayText("Filter Register",  27,  97, 0); 
   
   DisplayText("Sync Filter",      27, ccY1, 0); 
   
   DisplayText("FIR Skip ",        27, ccY2, 0); 
   DisplayText("Fast Step",        27, ccY3, 0);
   DisplayText("AC Ext",           27, ccY4, 0);
   
   DisplayText("Chop Mode",        327, ccY1, 'T');          
   DisplayText("Chop Delay",       327, ccY2, 'T');          
   

   /* set colours back */
   slcdSetColour(White, White);         
   
   /* copy mbSlave.filter to filter union */
   ADFILTER = mbSlave.ADFilter;
   
   slcdSetFont(F10); 
   
   /* FIR Skip button */
   Button.Id = 3;
   Button.x = 240;
   Button.y = ccY2;
   Button.type = 2;
   Button.state = ADFILTER_SKIP;
   
   Button.dx0 = 6;
   Button.dy0 = 14;
   
   Button.dx1 = 10;
   Button.dy1 = 14;
   
   strcpy(ButtonText1, gstr(&str->OFF));
   Button.text0 = ButtonText1;

   strcpy(ButtonText2, gstr(&str->ON));
   Button.text1 = ButtonText2;
         
   Button.bmp0 = 21;
   Button.bmp1 = 23;      
   
   MakeLatchingButton(&Button);

   /* Fast Step button */
   Button.Id = 4;
   Button.x = 240;
   Button.y = ccY3;
   Button.state = ADFILTER_FAST;

   MakeLatchingButton(&Button);

   /* AC EXT button */
   Button.Id = 5;
   Button.x = 240;
   Button.y = ccY4;
   Button.state = ADFILTER_AC;

   MakeLatchingButton(&Button);
          
   /* Chop mode button */
   Button.Id = 6;
   Button.x = 540;
   Button.y = ccY1;
   Button.state = ADFILTER_CHP;

   MakeLatchingButton(&Button);
          
   /* move to update state */      
   winAD7730State = WIN_AD7730_UPDATE;       
}

/*
** ------------------------------------------------------------------------------
**		Function: void wePaintAD7730Page3(void)
** ------------------------------------------------------------------------------
*/

void wePaintAD7730Page3(void)
{    
   /* set forground and back ground colour */
   slcdSetColour(DarkGrey, White);

   /* set font */
   slcdSetFont(F24B);         

   /* display page title  */
   DisplayText(gstr(&str->AD7730), 16, 7, 'T');
   
   slcdSetFont(F16B);  

   /* Status register */
   DisplayText("Calibration Registers",  27, 97,     0); 
   
   DisplayText("Data Register",          27, ccY1,   0); 
   DisplayText("Offset Register",        27, ccY3,   0);
      
   DisplayText("DAC Register",           27, ccY1,  'T');          
   DisplayText("Gain Register",          27, ccY3,  'T');          
   
   /* move to update state */      
   winAD7730State = WIN_AD7730_UPDATE;       
}


/*
** ------------------------------------------------------------------------------
**		Function: return true/false for register bits 
** ------------------------------------------------------------------------------
*/
  
byte tfb(byte b)
{
   return(b) ? 1 : 0;
}

byte tfw(word w)
{
   return(w) ? 1 : 0;
}
 
/*
** ------------------------------------------------------------------------------
**		Function: void weUpdateAD7730Page1(void)
** ------------------------------------------------------------------------------
*/

void weUpdateAD7730Page1(void)
{ 
   byte Buf[50];
   
   /* time to update? */
   if (!winTimer1)
   {
      winTimer1 = 50;

      slcdSetFont(F8); 
      
      /* status bits */              
      sprintf(Buf, "%u", tfb(mbSlave.ADStatus&0x80));
      DisplayText(Buf,   x1, 177, 0);   

      sprintf(Buf, "%u", tfb(mbSlave.ADStatus&0x40));
      DisplayText(Buf,   x2, 177, 0);   

      sprintf(Buf, "%u", tfb(mbSlave.ADStatus&0x20));
      DisplayText(Buf,   x3, 177, 0);   

      sprintf(Buf, "%u", tfb(mbSlave.ADStatus&0x10));
      DisplayText(Buf,   x4, 177, 0);   

      sprintf(Buf, "%u", tfb(mbSlave.ADStatus&0x08));
      DisplayText(Buf,   x5, 177, 0);   

      sprintf(Buf, "%u", tfb(mbSlave.ADStatus&0x04));
      DisplayText(Buf,   x6, 177, 'T');   

      sprintf(Buf, "%u", tfb(mbSlave.ADStatus&0x02));
      DisplayText(Buf,   x7, 177, 'T');   

      sprintf(Buf, "%u", tfb(mbSlave.ADStatus&0x01));
      DisplayText(Buf,   x8, 177, 'T');   
      
      /* mode bits */
      ADMODE = mbSlave.ADMode;
      //sprintf(Buf, "%u", tfw(mbSlave.ADMode&0x8000));
      sprintf(Buf, "%u", ADMODE_MD2);
      DisplayText(Buf,   x1, 296, 0);   

      //sprintf(Buf, "%u", tfw(mbSlave.ADMode&0x4000));
      sprintf(Buf, "%u", ADMODE_MD1);
      DisplayText(Buf,   x2, 296, 0);   

      //sprintf(Buf, "%u", tfw(mbSlave.ADMode&0x2000));
      sprintf(Buf, "%u", ADMODE_MD0);
      DisplayText(Buf,   x3, 296, 0);   

      sprintf(Buf, "%u", tfw(mbSlave.ADMode&0x1000));
      DisplayText(Buf,   x4, 296, 0);   

      sprintf(Buf, "%u", tfw(mbSlave.ADMode&0x0800));
      DisplayText(Buf,   x5, 296, 0);   

      sprintf(Buf, "%u", tfw(mbSlave.ADMode&0x0400));
      DisplayText(Buf,   x6, 296, 'T');   

      sprintf(Buf, "%u", tfw(mbSlave.ADMode&0x0200));
      DisplayText(Buf,   x7, 296, 'T');   

      sprintf(Buf, "%u", tfw(mbSlave.ADMode&0x0100));
      DisplayText(Buf,   x8, 296, 'T');   
      
      sprintf(Buf, "%u", tfw(mbSlave.ADMode&0x0080));
      DisplayText(Buf,   x1, 359, 0);   

      sprintf(Buf, "%u", tfw(mbSlave.ADMode&0x0040));
      DisplayText(Buf,   x2, 359, 0);   

      sprintf(Buf, "%u", tfw(mbSlave.ADMode&0x0020));
      DisplayText(Buf,   x3, 359, 0);   

      sprintf(Buf, "%u", tfw(mbSlave.ADMode&0x0010));
      DisplayText(Buf,   x4, 359, 0);   

      sprintf(Buf, "%u", tfw(mbSlave.ADMode&0x0008));
      DisplayText(Buf,   x5, 359, 0);   

      sprintf(Buf, "%u", tfw(mbSlave.ADMode&0x0004));
      DisplayText(Buf,   x6, 359, 'T');   

      sprintf(Buf, "%u", tfw(mbSlave.ADMode&0x0002));
      DisplayText(Buf,   x7, 359, 'T');   

      sprintf(Buf, "%u", tfw(mbSlave.ADMode&0x0001));
      DisplayText(Buf,   x8, 359, 'T');   
      
      slcdSetFont(F16B); 
      
      sprintf(Buf, "0x%02X    ", mbSlave.ADStatus);
      DisplayText(Buf,   x4, 97, 0);   

      sprintf(Buf, "0x%04X    ", mbSlave.ADMode);
      DisplayText(Buf,   x4, 216, 0);   
      
      mbTable[enAdStatus].RdFlg  = 1; 
      mbTable[enAdMode].RdFlg    = 1; 
   }
}

/*
** ------------------------------------------------------------------------------
**		Function: void weUpdateAD7730Page2(void)
** ------------------------------------------------------------------------------
*/

void weUpdateAD7730Page2(void)
{ 
   byte Buf[50];
   
   /* time to update? */
   if (!winTimer1)
   {
      winTimer1 = 50;

      slcdSetFont(F16B); 

      /* copy filter register to union */
      ADFILTER = mbSlave.ADFilter;
      
      slcdSetColour(DarkGrey, White);  
      
      sprintf(Buf, "0x%lX  ", mbSlave.ADFilter);
      DisplayText(Buf,   x4, 97, 0);   

      slcdSetColour(LightBlue, White);  
      
      /* */

      AdSyncFilter = (word)(((unsigned long)ADFILTER&0x00FFF000)>>12);

      sprintf(Buf, "%u  ", AdSyncFilter);
      DisplayText(Buf,  240, ccY1, 0); 
      
      /* */
      sprintf(Buf, "%u  ", ADFILTER_DL);
      DisplayText(Buf,  540, ccY2, 'T'); 
         
      mbTable[enAdFilter].RdFlg  = 1; 
   }
}

/*
** ------------------------------------------------------------------------------
**		Function: void weUpdateAD7730Page3(void)
** ------------------------------------------------------------------------------
*/

void weUpdateAD7730Page3(void)
{ 
   byte Buf[50];
   
   /* time to update? */
   if (!winTimer1)
   {
      winTimer1 = 50;

      slcdSetFont(F16B); 
      
      
      slcdSetFont(F24B); 

      /* copy filter register to union */
      ADFILTER = mbSlave.ADFilter;
      
      //slcdSetColour(DarkGrey, White);  
      slcdSetColour(LightBlue, White);  
      
      sprintf(Buf, "%lu", mbSlave.ADData);
      DisplayText(Buf, 33, ccY2, 'T');   

      sprintf(Buf, "%lu", mbSlave.ADOffset);
      DisplayText(Buf, 33, ccY4, 'T');   
      
      /* */
      sprintf(Buf, "%u", mbSlave.ADDac);
      DisplayText(Buf,  333,  ccY2, 'T'); 
      
      /* */
      sprintf(Buf, "%lu", mbSlave.ADGain);
      DisplayText(Buf,  333,  ccY4, 'T'); 
         
      //mbTable[enAdData].RdFlg  = 1; 
      mbTable[enAdOffset].RdFlg  = 1; 
      mbTable[enAdDAC].RdFlg  = 1; 
      mbTable[enAdGain].RdFlg  = 1; 
   }
}

/*
** ------------------------------------------------------------------------------
**		Function: void UpdateAD7730(void)
** ------------------------------------------------------------------------------
*/

void UpdateAD7730(void)
{ 
   switch(Ad7730Page)
   {
   case 0:
      /* paint first page */
      weUpdateAD7730Page1();
      break;

   case 1:
      /* paint second page */
      weUpdateAD7730Page2();
      break;      

   case 2:
      /* paint third page */
      weUpdateAD7730Page3();
      break;            
   }
}
/*
** ------------------------------------------------------------------------------
**		Function: byte winAD7730Handler(void)
** ------------------------------------------------------------------------------
*/

byte winAD7730Handler(void)
{
   switch (winAD7730State)
   {
   case WIN_AD7730_PREPAINT:
      /* get analog parameters from slave */
      ReadAD7730Parameters();

      /* set delay for parameters to arrive from MCT  */
      winUpdate1 = 15;
            
      winAD7730State = WIN_AD7730_PAINT;
      break;
      
   case WIN_AD7730_PAINT:
      if(winUpdate1==1)
      {
         winUpdate1 = 0;

         /* send command to execute macro 2 */
         slcdCallMacro(2);
            
         /* make page select buttons */
         MakeButton(1, 1, 483, 89, 20, 21);
         MakeButton(2, 1, 552, 89, 22, 21);
         
         switch(Ad7730Page)
         {
         case 0:
            /* paint first page */
            wePaintAD7730Page1();
            break;

         case 1:
            /* paint second page */
            wePaintAD7730Page2();
            break;    
            
         case 2:
            /* paint third page */
            wePaintAD7730Page3();
            break;            
         }         

         /* update parameters */
         winUpdate1 = 1;
         
         /* move to update state */      
         winAD7730State = WIN_AD7730_UPDATE;       
      }
      return 0;

   case WIN_AD7730_UPDATE:
      /* is there a key to process? */
      if (slcdKey)
      {
         /* call key handler */
         winAD7730KeyHandler(slcdKey);      
         /* now the key has been processed clear it */
         slcdKey = 0; 
      }

      UpdateAD7730();

      /* has any data been remotely changed? */
      if(mbSlave.DataUpdate)
      {
         /* clear data update flag */
         mbSlave.DataUpdate = 0;
         mbTable[enDataUp].WrFlg = 1;   
         
         /* read analog parameters */
         ReadAD7730Parameters();  
         
         /* set update timer */                   
         winUpdate1 = 100;
      }      
      return 0;

  case WIN_AD7730_NUMKEYPAD:
      /* see if key pad is returning */
      if(winKeyPadHandler())
      {
         /* move to update state */      
         winAD7730State = WIN_AD7730_PREPAINT;       
      }
      break;

 case WIN_AD7730_ENTER_PASSWORD:
      /* see if key pad is returning */
      switch(winKeyPadHandler())
      {
      case 1:
         /* move to update state */      
         winAD7730State = WIN_AD7730_PREPAINT;       
         break;

      case 2:
         /* move to update state */      
         winAD7730State = WIN_AD7730_UNLOAD;       
         break;
      }
      break;
      
   case WIN_AD7730_UNLOAD:
      /* do any necessary clearing up */
      winAD7730State = WIN_AD7730_PREPAINT;  

      /* start with consituent 1 */
      Ad7730Page = 0;
      
      /* set return menu */
      winActiveWin = ENGINEERING_WINDOW;

      /* return from key pad */
      return 1;
   }   
}



