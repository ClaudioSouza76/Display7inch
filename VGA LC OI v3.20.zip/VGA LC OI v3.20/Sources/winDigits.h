/*
** ------------------------------------------------------------------------------
   
   File   : winDigits.h 
   Aurthor: Stuart Clarke

** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

#ifndef WINDIGITS_H
#define WINDIGITS_H


/* public defines */


/*
** ------------------------------------------------------------------------------
**		#define : diagnostics handler states 
** ------------------------------------------------------------------------------
*/

#define WIN_DIGITS_PREPAINT     0
#define WIN_DIGITS_PAINT        1
#define WIN_DIGITS_PAINT_PAGE   2
#define WIN_DIGITS_UPDATE       3
#define WIN_DIGITS_NUMKEYPAD    4
#define WIN_DIGITS_UNLOAD       5




#ifndef WIN_DIGITS_C

/* public variables */
#pragma DATA_SEG WINDIGITS_Data


#endif   /* WINDIGITS_C */      


/* public functions */
#pragma CODE_SEG WINDIGITS_Code

/*
** ------------------------------------------------------------------------------
**		Function: void ReadFilterParameters(void)
** ------------------------------------------------------------------------------
*/

void ReadDigitsParameters(void);

/*
** ------------------------------------------------------------------------------
**		Function: byte winDigitsHandler(void)
** ------------------------------------------------------------------------------
*/

byte winDigitsHandler(void);

#endif   /* WINRANGES_H */
