#include <hidef.h>                           /* common defines and macros */
#include "derivative.h"                      /* derivative information */

/*
** ------------------------------------------------------------------------------
   
   File   : Serial.c 
   Aurthor: 
   
   Description:  
   
   Version Log          Notes                                     Changes Made by                                        
   --------------       -----                                     ---------------
   25-06-11:            Created                                   Stuart Clarke
        
** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

/* library headers */


/* Application headers */
#include "Flash.h"
#include "Boot.h"

/* Implements this interface: */
#define SERIAL_C
#include "Serial.h"

#pragma STRING_SEG   ROM_FE00_SEG
#pragma CODE_SEG     ROM_F200_SEG
#pragma DATA_SEG     SERIAL_DATA


/* private */
static byte *RxPtr;
static byte *RxDatPtr;
static byte *TxPtr;

/* public */
byte InFlag;
byte ErrFlag;


/*
** ------------------------------------------------------------------------------
**		Function: void SCI_Init(unsigned long Baud, byte C1, byte C2)
** ------------------------------------------------------------------------------
*/

void _SCI_Init(word Baud, byte C1, byte C2)
{
   /* Set Baud Rate */   
   SCI0BD = Baud;
   
   /* Set Control Resisters 1 and 2 */
   SCI0CR1 = C1;
   SCI0CR2 = C2;
   
   RxPtr     = (byte *)0x3500; 
   TxPtr     = (byte *)0x3900;	   
   RxDatPtr = (byte *)0x3500;
      
   InFlag  = 0;
   ErrFlag = 0;
}

/*
** ------------------------------------------------------------------------------
**		Function: byte *_strcpy1(byte *str_d, byte *str_s)
** ------------------------------------------------------------------------------
*/

byte *_strcpy1(byte *str_d, byte *str_s)
{
    #pragma MESSAGE DISABLE C5909 /* Assignment in condition */
    byte *sd = str_d;

    while(*str_d++ = *str_s++);
    return (sd);
}

/*
** ------------------------------------------------------------------------------
**		Function: void _Send_Serial(void)
** ------------------------------------------------------------------------------
*/

void _Send_Serial(byte *Ptr)
{
   /* copy data to tx address */   
   _strcpy1(TxPtr, Ptr);
   /* turn tx on */
   //PT1AD1_PT1AD19 = 1;
   /* start tx */
   SCI0CR2_TIE  = 1; 
   /* yellow led on */
   PTP_PTP4 = 0;       
}


/*
** ------------------------------------------------------------------------------
**		Function: void _SendMsg(byte *Ptr)
** ------------------------------------------------------------------------------
*/

void _SendMsg(byte *Ptr)
{
   _Send_Serial(Ptr); 
   while(!PTP_PTP4);  
}

/*
** ------------------------------------------------------------------------------
**		Function: void _Check_Serial(void)
** ------------------------------------------------------------------------------
*/

void _Check_Serial(void)
{
   if(InFlag)
   {
      InFlag = 0;

      /* reload boot exit timer */
      BootExitTimer = 120;
            
      /* see what command we have received */      
      switch(*RxDatPtr)
      {
      case 'B':
         /* already in boot mode */
         _SendMsg("Resetting\r");
         /* switch on the COP and wait for it to time out */         
         COPCTL = 0x47;
      	for(;;);             
         break;
      
      case 'X':
         /* inc ptr */
         RxDatPtr++;
         
         /* switch cases can share program memory with the app! */
         if(*RxDatPtr == '1')
         {
            /* version command */
            _SendMsg("bl v1.00\r");
         }
         else if(*RxDatPtr == '2')
         {
            /* erase */
            EraseFlash();
         }
         else if(*RxDatPtr == '3')
         {
            ExitBootLoader();       
         }         
         break;
         
      case 'S':
         /* inc ptr */
         RxDatPtr++;
         
         /* switch cases can share program memory with the app! */
         if(*RxDatPtr == '0')
         {
            /* S0 Record */
            _SendMsg("OK\r");
         }
         else if(*RxDatPtr == '1')
         {
             /* red led on */
            PTP_PTP5 = 0;               

            /* S1 Record */
            _SendMsg(ProgramS1());
            
             /* red led off */
            PTP_PTP5 = 1;               
         } 
         else if(*RxDatPtr == '2')
         {

             /* red led on */
            PTP_PTP5 = 0;               

            /* S2 Record */
            _SendMsg(ProgramS2());

            /* red led off */
            PTP_PTP5 = 1;   
         }
         else if(*RxDatPtr == '9')
         {
            /* S9 Record */
            _SendMsg("Programming Complete\r");
            
            ExitBootLoader();
         }
      }

      /* reset RxDatPtr */
      RxDatPtr = (byte *)0x3500; 
   }
}

/*
** ------------------------------------------------------------------------------
**		#pragma: Ram Relocation segment 
** ------------------------------------------------------------------------------
*/

#pragma CODE_SEG ROM_F000_SEG


/*
** ------------------------------------------------------------------------------
**		Function: static void _ETC1_Interrupt(void)
** ------------------------------------------------------------------------------
*/

__interrupt void near _ETC1_Interrupt(void)
{
	/* clear irq */
	TFLG1 = 0x02; 
   /* stop irq */
   TIE_C1I = 0;
   /* flag new data */
   InFlag = 1;	
   /* null terminate */
   *(RxPtr++) = 0;   
   /* reset RxPtr */
   RxPtr = (byte *)0x3500;
   /* yellow led off */
   PTP_PTP4 = 1;       
}

/*
** ------------------------------------------------------------------------------
**		Function: static void _SCI0_Interrupt(void)
** ------------------------------------------------------------------------------
*/

__interrupt void near _SCI0_Interrupt(void)
{
   byte SCI0SR = SCI0SR1;
   byte i;

   /* receive Interrupt?  */		               
   if (SCI0SR&0x20 && SCI0CR2_RIE)          
   {
      i = SCI0DRL;							

      /* yellow led on */
      PTP_PTP4 = 0;  
      
      /* Start Rx Timeout */
		TC1     = TCNT + 420;	            
   	TFLG1   = 0x02;	   	         				
   	TIE_C1I = 1;
   	
      /* ASCI only */   
      if (i>0x1F && i<0x7F)         
      {         
         if (RxPtr < (byte*)0x38FF)	
            *(RxPtr++) = i;              
         else
            RxPtr = (byte *)0x3500;   
      }
      else
      {
         ErrFlag = 1;
      }
   }
   else
   {		
		/* Transmit Interrupt ? */
      if (SCI0CR2_TIE && SCI0SR1_TDRE)	   
      {
         /* is it the end of reply? */
         if (*TxPtr)									
         {
            /* send next char (clears irq) */
            SCI0DRL = *TxPtr++;
         }
         else                          	
         {
            SCI0CR2_TCIE = 1;
            SCI0CR2_TIE  = 0; 
         }
      }

      /* is TCIE enabled and Tx finished */
      if (SCI0CR2_TCIE && SCI0SR1_TC)	
      {         
         /* reset TxPtr */
         TxPtr = (byte*)0x3900;						
         /* turn tx off */
         //PT1AD1_PT1AD19 = 0;
            
         SCI0CR2_TCIE = 0;
         SCI0CR2_RIE  = 1;	
         
         /* yellow led off */
         PTP_PTP4 = 1;  
      }
   } 
}	
