/*
** ------------------------------------------------------------------------------
   
   File   : winUser.h 
   Aurthor: Stuart Clarke

** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

#ifndef WINUSER_H
#define WINUSER_H


/* public defines */

/*
** ------------------------------------------------------------------------------
**		#define : user menu handler states 
** ------------------------------------------------------------------------------
*/

#define WIN_USER_PREPAINT     0
#define WIN_USER_PAINT        1
#define WIN_USER_UPDATE       2
#define WIN_USER_NUMKEYPAD    3
#define WIN_USER_UNLOAD       4
#define WIN_USER_ENTER_PASSWORD 5


#ifndef WINUSER_C

/* public variables */
#pragma DATA_SEG WINUSER_DATA

extern byte winUserReturnWin;

#endif   /* WINUSER_C */      


/* public functions */
#pragma CODE_SEG WINUSER_CODE

/*
** ------------------------------------------------------------------------------
**		Function: void ZeroAdjust(void)
** ------------------------------------------------------------------------------
*/

void ZeroAdjust(void);

/*
** ------------------------------------------------------------------------------
**		Function: void ReadUserParameters(void)
** ------------------------------------------------------------------------------
*/

void ReadUserParameters(void);

/*
** ------------------------------------------------------------------------------
**		Function: byte winUserMenuHandler(void)
** ------------------------------------------------------------------------------
*/

byte winUserMenuHandler(void);

#endif   /* WINUSER_H */
