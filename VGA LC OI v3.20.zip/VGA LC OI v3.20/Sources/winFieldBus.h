/*
** ------------------------------------------------------------------------------
   
   File   : winFieldBus.h 
   Aurthor: Stuart Clarke

** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

#ifndef WINFIELDBUS_H
#define WINFIELDBUS_H


/* public defines */


/*
** ------------------------------------------------------------------------------
**		#define : diagnostics handler states 
** ------------------------------------------------------------------------------
*/

#define WIN_FIELDBUS_PREPAINT     0
#define WIN_FIELDBUS_PAINT        1
#define WIN_FIELDBUS_UPDATE       2
#define WIN_FIELDBUS_NUMKEYPAD    3
#define WIN_FIELDBUS_CONFIRM      4  
#define WIN_FIELDBUS_UNLOAD       5




#ifndef WINFIELDBUS_C

/* public variables */
#pragma DATA_SEG WINFIELDBUS_Data


#endif   /* WINFIELDBUS_C */      


/* public functions */
#pragma CODE_SEG WINFIELDBUS_Code

/*
** ------------------------------------------------------------------------------
**		Function: void ReadFieldBusParameters(void)
** ------------------------------------------------------------------------------
*/

void ReadFieldParameters(void);

/*
** ------------------------------------------------------------------------------
**		Function: void winFieldBusHandler(void)
** ------------------------------------------------------------------------------
*/

void winFieldBusHandler(void);

#endif   /* WINFIELDBUS_H */
