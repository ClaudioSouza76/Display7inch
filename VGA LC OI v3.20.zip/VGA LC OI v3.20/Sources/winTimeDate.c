#include <hidef.h>                           /* common defines and macros */
#include "derivative.h"                      /* derivative information */

/*
** ------------------------------------------------------------------------------
   
   File   : winTimeDate.c 
   Aurthor: 
   
   Description:  
   
   Version Log          Notes                                     Changes Made by                                        
   --------------       -----                                     ---------------
   08-07-09:            Created                                   Stuart


** ------------------------------------------------------------------------------
                                    
                                    Overview
                                            
** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

/* library headers */
#include "stdio.h"
#include "float.h"
#include "math.h"

/* Application headers */
#include "CRG 100110.h" 
#include "Subs.h"
#include "SlcdSubs.h"
#include "ModBusM Int.h"
#include "ModBusM.h"
#include "EEPROM.h"
#include "SLCD 260217.h"
#include "winMain.h"
#include "winKey.h"
#include "Language.h"


/* Implements this interface: */
#define WINTIMEDATE_C
#include "winTimeDate.h"

#pragma CODE_SEG WINTIMEDATE_Code
#pragma DATA_SEG WINTIMEDATE_Data


/* private */
static byte winTimeDateState;


/* public */



/*
** ------------------------------------------------------------------------------
**		Function: void winTimeDateKeyHandler(byte key)
** ------------------------------------------------------------------------------
*/

void winTimeDateKeyHandler(byte key)
{   
   switch (key)
   {
 
   case 128:       /* EXIT */
      /* shut down num key window handler */
      winTimeDateState = WIN_TIMEDATE_UNLOAD;  
      break;  
      
   case 130:      /* tag hotspot */
      /* move to key pad handler sate */
      winTimeDateState = WIN_TIMEDATE_NUMKEYPAD; 
      
      /* copy parameter data to key structure */
      strcpy(NumKeyData.Name, gstr(&str->SetTime));  
      NumKeyData.KeyBoardType = NUMBER;
      NumKeyData.Type = TIME;
      NumKeyData.iMax = 9;
      NumKeyData.Flag = enTime;
      NumKeyData.DataPtr           = (void *)&mbSlave.Time;     
      break;      

   case 131:      /* Rate units hotspot */
      /* move to key pad handler sate */
      winTimeDateState = WIN_TIMEDATE_NUMKEYPAD; 
      
      /* copy parameter data to key structure */
      strcpy(NumKeyData.Name, gstr(&str->SetDate));  
      NumKeyData.KeyBoardType = NUMBER;
      NumKeyData.Type = DATE;
      NumKeyData.iMax = 9;
      NumKeyData.Flag = enDate;
      NumKeyData.DataPtr           = (void *)&mbSlave.Date;     
      break; 
   
   }
}

/*
** ------------------------------------------------------------------------------
**		Function: void ReadTimeDateParameters(void)
** ------------------------------------------------------------------------------
*/

void ReadTimeDateParameters(void)
{
   mbTable[enTime].RdFlg = 0x1;
   mbTable[enDate].RdFlg = 0x1;
}

/*
** ------------------------------------------------------------------------------
**		Function: void PaintTimeDatePage(void)
** ------------------------------------------------------------------------------
*/

void PaintTimeDatePage(void)
{   
   /* set colours back */
   slcd_SetColour(DarkGrey, White); 
   
   slcd_SetFont(16, 'B');  
   slcd_SendText(gstr(&str->SetTime),  40,   ccY0, 'T', LEFT_ALIGN);  
   slcd_SendText(gstr(&str->SetDate),  340,  ccY0, 'T', LEFT_ALIGN); 
   slcd_SendText("Next Cal Date",      340,  ccY2, 'T', LEFT_ALIGN); 
   
   slcd_SetFont(16, 0);  

   slcd_MakeHotSpot(130, 52, 164, 260, 240);
   slcd_MakeHotSpot(131, 350, 164, 460, 240);
   

   /* force update */
   winUpdate1 = 1;
}


/*
** ------------------------------------------------------------------------------
**		Function: void UpdateTimeDate(void)
** ------------------------------------------------------------------------------
*/

void UpdateTimeDate(void)
{   
   /* requested update */
   if (winUpdate1==1)
   {
      /* stop counter */
      winUpdate1 = 0;
   }

   /* time to update? */
   if (!winTimer1)
   {
      winTimer1 = 100;

      slcd_SetFont(24, 'B');  
      slcd_SetColour(LightBlue, White);  

      /* display Time */      
      slcd_SendText(&mbSlave.Time, 40, 186, 0, LEFT_ALIGN);    

      /* display Date*/      
      slcd_SendText(&mbSlave.Date, 340, 186, 'T', LEFT_ALIGN);   
      
      slcd_SetColour(DarkGrey, White);	
      /* display Next Date Calibration*/
      slcd_SendText(&EEPROM.NextCalDate, 340, 354, 'T', LEFT_ALIGN);  
      
      
      //slcdSetColour(DarkGrey, White); 
      /* display calibration Date*/      
      slcd_SendText(&EEPROM.SpeedCal[EEPROM.SpeedCalPtr].Date, 40, 354, 'T', LEFT_ALIGN);

      mbTable[enTime].RdFlg = 0x1;
      mbTable[enDate].RdFlg = 0x1;       
   }
}

/*
** ------------------------------------------------------------------------------
**		Function: byte winTimeDateHandler(void)
** ------------------------------------------------------------------------------
*/

byte winTimeDateHandler(void)
{
   switch (winTimeDateState)
   {
   case WIN_TIMEDATE_PREPAINT:
      /* get analog parameters from slave */
      ReadTimeDateParameters();
      winTimeDateState = WIN_TIMEDATE_PAINT;
      break;
      
   case WIN_TIMEDATE_PAINT:
     slcd_SetColour(DarkGrey, DarkGrey);
     slcd_Send("z");

     slcd_Send("xc all");     
     /* display menu screen */
     //DisplayBmp(16, 0, 0, LEFT_ALIGN); 
     slcd_DisplayBmp(10, 0, 0); 

     DisplayTitle("MS Instrumentos");
     
     slcd_SetFont(24, 0);
     slcd_SetColour(DarkGrey, White); 
     slcd_SendText(gstr(&str->TimeAndDate), 15, 60, 0, LEFT_ALIGN);
     
     /* define back hotspot */
     slcd_MakeHotSpot(128, 560, 10, 50, 50);
         
    
      PaintTimeDatePage();
      
      /* update parameters */
      winUpdate1 = 1;
      
      /* move to update state */      
      winTimeDateState = WIN_TIMEDATE_UPDATE;       
      return 0;

   case WIN_TIMEDATE_UPDATE:
      /* is there a key to process? */
      if (slcdKey)
      {
         /* call key handler */
         winTimeDateKeyHandler(slcdKey);      
         /* now the key has been processed clear it */
         slcdKey = 0; 
      }

      UpdateTimeDate();

      /* has any data been remotely changed? */
      if(mbSlave.DataUpdate)
      {
         /* clear data update flag */
         mbSlave.DataUpdate = 0;
         mbTable[enDataUp].WrFlg = 1;   
         
         /* read analog parameters */
         ReadTimeDateParameters();  
         
         /* set update timer */                   
         winUpdate1 = 100;
      }      
      return 0;

  case WIN_TIMEDATE_NUMKEYPAD:
      /* see if key pad is returning */
      if(winKeyPadHandler())
         /* move to update state */      
         winTimeDateState = WIN_TIMEDATE_PAINT;   
      break;

   case WIN_TIMEDATE_UNLOAD:
      /* do any necessary clearing up */
      winTimeDateState = WIN_TIMEDATE_PREPAINT;  

      /* switch to menu screen */
      winActiveWin = BASIC_CONFIG_WINDOW;  


      /* return from key pad */
      return 1;
   }   
}



