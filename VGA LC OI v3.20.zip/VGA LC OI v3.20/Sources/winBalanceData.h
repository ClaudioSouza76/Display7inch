/*
** ------------------------------------------------------------------------------
   
   File   : winBasicConfig.h 
   Aurthor: Stuart Clarke

** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

#ifndef WINBALANCEDATA_H
#define WINBALANCEDATA_H


/* public defines */

/*
** ------------------------------------------------------------------------------
**		#define : user menu handler states 
** ------------------------------------------------------------------------------
*/

#define WIN_BALANCE_DATA_PREPAINT     0
#define WIN_BALANCE_DATA_PAINT        1
#define WIN_BALANCE_DATA_UPDATE       2
#define WIN_BALANCE_DATA_NUMKEYPAD    3
#define WIN_BALANCE_DATA_UNLOAD       4
#define WIN_BALANCE_DATA_ENTER_PASSWORD 5


#ifndef WINBALANCEDATA_C

/* public variables */
#pragma DATA_SEG WINBALANCEDATA_DATA

extern byte winBalanceDataReturnWin;

extern float TestWightPercentage;

#endif   /* WINBALANCEDATA_C */      


/* public functions */
#pragma CODE_SEG WINBALANCEDATA_CODE


/*
** ------------------------------------------------------------------------------
**		Function: void ReadBalanceDataParameters(void)
** ------------------------------------------------------------------------------
*/

void ReadBalanceDataParameters(void);

/*
** ------------------------------------------------------------------------------
**		Function: byte winBalanceDataHandler(void)
** ------------------------------------------------------------------------------
*/

byte winBalanceDataHandler(void);

#endif   /* WINBALANCEDATA_H */
