/*
** ------------------------------------------------------------------------------
   
   File   : winMovingAverage.h 
   Aurthor: Stuart Clarke

** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

#ifndef WINMOVINGAVERAGE_H
#define WINMOVINGAVERAGE_H


/* public defines */


/*
** ------------------------------------------------------------------------------
**		#define : diagnostics handler states 
** ------------------------------------------------------------------------------
*/

#define WIN_MOVING_AVERAGE_PREPAINT     0
#define WIN_MOVING_AVERAGE_PAINT        1
#define WIN_MOVING_AVERAGE_PAINT_PAGE   2
#define WIN_MOVING_AVERAGE_UPDATE       3
#define WIN_MOVING_AVERAGE_NUMKEYPAD    4
#define WIN_MOVING_AVERAGE_UNLOAD       5

#ifndef WIN_MOVINGAVERAGE_C

/* public variables */
#pragma DATA_SEG WINMOVINGAVERAGE_Data


#endif   /* WINFILTERING_C */      


/* public functions */
#pragma CODE_SEG WINMOVINGAVERAGE_Code

/*
** ------------------------------------------------------------------------------
**		Function: void ReadRangeParameters(void)
** ------------------------------------------------------------------------------
*/

void ReadRangeParameters(void);

/*
** ------------------------------------------------------------------------------
**		Function: byte winFilteringHandler(void)
** ------------------------------------------------------------------------------
*/

byte winMovingAverageHandler(void);

#endif   /* WINRANGES_H */
