#include <hidef.h>                           /* common defines and macros */
#include "derivative.h"                      /* derivative information */

/*
** ------------------------------------------------------------------------------
   
   File   : winMassCal.c 
   Aurthor: 
   
   Description:  
   
   Version Log          Notes                                     Changes Made by                                        
   --------------       -----                                     ---------------
   08-07-09:            Created                                   Stuart


** ------------------------------------------------------------------------------
                                    
                                    Overview
                                            
** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

/* library headers */
#include "stdio.h"
#include "float.h"
#include "math.h"

/* Application headers */
#include "CRG 100110.h" 
#include "Subs.h"
#include "ModBusM Int.h"
#include "ModBusM.h"
#include "EEPROM.h"
#include "SLCD 260217.h"
#include "winMain.h"
#include "winKey.h"
#include "Language.h"
#include "winConfirm.h"
#include "SlcdSubs.h"


/* Implements this interface: */
#define WINMASSCAL_C
#include "winMassCal.h"

#pragma CODE_SEG WINMASSCAL_Code
#pragma DATA_SEG WINMASSCAL_Data

/* Constants to menssage box */
#define mV_MESSAGE        1
#define TIME_OUT_MESSAGE  2

/* private */
static byte winMassCalState;
static byte winMassReturnWin;

static byte LastMvLen;
static byte LastBeltLen;
//static long NewMassZero;
static float NewMassZero;
static float NewPulseRate;
static byte CalComplete;

static float UpDateRate;
static float LastDistance;

static float XscaleFactor;
static float YscaleFactor;

static byte MessageBox;

/* public */
float MassZeroError;
float OldMassZero;


/*
** ------------------------------------------------------------------------------
**		Function: void winMassCalKeyHandler(byte key)
** ------------------------------------------------------------------------------
*/

void DisplayMessageBox(byte TypeMessage)
{
  switch (TypeMessage)
  {
    case mV_MESSAGE:
      
       /* switch to msg box state */
       winMassCalState = WIN_MASSCAL_MSGBOX;      
       
       /* set pointer to msg box message */
       strcpy(MsgBoxData.TitleBarTxt, gstr(&str->Warning));

       /* set pointer to msg box message */
       MsgBoxData.MsgTxt = gstr(&str->mVVeryHigh); 
       
       /* display OK box */
       MsgBoxData.Attribute = 1;
       
       /* load return function */
       //MsgBoxData.fp = SaveFieldBusParameters;
     break;
     
    case TIME_OUT_MESSAGE:
      
      slcdSetButtonSate(2,1);      
      /* switch to msg box state */
       winMassCalState = WIN_MASSCAL_MSGBOX;      
       
       /* set pointer to msg box message */
       strcpy(MsgBoxData.TitleBarTxt, gstr(&str->Warning));

       /* set pointer to msg box message */
       MsgBoxData.MsgTxt = gstr(&str->TimeOutCal); 
       
       /* display OK box */
       MsgBoxData.Attribute = 1;
       
       /* load return function */
       //MsgBoxData.fp = SaveFieldBusParameters;
       
     break;
   }
}

/*
** ------------------------------------------------------------------------------
**		Function: void winMassCalKeyHandler(byte key)
** ------------------------------------------------------------------------------
*/

void winMassCalKeyHandler(byte key)
{   
   switch (key)
   {
   case 1:  /* Zero cal + Belt length*/
      /* dont start cal with zero belt length */
      if(mbSlave.BeltLength<1.0)
      {
         /* error beep */
         slcd_CmdQueue("beep 500");    
         /* reset button state */
         slcdSetButtonSate(1, 0);
      }
      else
      {
         /* has cal been started or stopped */
         if(!mbSlave.MZeroCalStartStop)
         {
            /* clear chart area */
            MakeChart (CHART_X+1, CHART_Y, CHART_X+440, CHART_Y+140, 140);
            
            /* change accept button to abort */
            slcd_SetColour(White, Black);   
            //slcdMakeButtonCT(3, gstr(&str->ABORT), 1, 484, 230, 5, 4);
            MakeButtonCT(3, gstr(&str->ABORT), 1, 484, 230, 5, 4);
            
            /* start cal */
            mbSlave.MZeroCalStartStop = 1;
            
            mbSlave.MCalFlag = 2;
            /* set write flag */
            mbTable[enMZeroCalStop].WrFlg = 1;

            /* clear cal complete flag */
            CalComplete = 0;        
            
            /* calculate chart update rate */
            //UpDateRate = (mbSlave.BeltLength*3)/220; 
            UpDateRate = (mbSlave.BeltLength*3)/440; 
            
            mbSlave.BeltTravel = 0;
            LastDistance = 0;  
         }
         else
         {
            /* only stop cal here if its the right cal */
            if(mbSlave.MZeroCalStartStop==1)
            {           
               /* clear Coleta de dados concluida message */
               slcd_SetColour(DarkGrey, White);   
               slcd_SendText("                                                  ", 20, 135, 0, LEFT_ALIGN);
               
               /* change abort button to accept */
               slcd_SetColour(White, White);   
               //slcdMakeButtonCT(3, gstr(&str->ACCEPT), 1, 484, 230, 5, 4);
               MakeButtonCT(3, gstr(&str->ACCEPT), 1, 484, 230, 5, 4);
                  
               /* stop mass zero cal */   
               mbSlave.MZeroCalStartStop = 0;
               
               mbSlave.MCalFlag = 0;
               /* set write flag */
               mbTable[enMZeroCalStop].WrFlg = 1;

               /* clear cal complete flag */
               CalComplete = 0;                           
            }
            else
            {
               /* error beep */
               slcd_CmdQueue("beep 500");    
               /* reset button state */
               slcdSetButtonSate(1, 0);               
            }
         }
      }
      break;       
      
   case 2:  /* Zero Cal No belt Length */
      /* set write flag */

      /* has cal been started or stopped */
      if(!mbSlave.MZeroCalStartStop)
      {
         /* clear chart area */
         MakeChart (CHART_X+1, CHART_Y, CHART_X+440, CHART_Y+140, 140);
         
         /* change accept button to abort */
         slcd_SetColour(White, White);   
         //slcdMakeButtonCT(3, gstr(&str->ABORT), 1, 484, 230, 5, 4);
         MakeButtonCT(3, gstr(&str->ABORT), 1, 484, 230, 5, 4);
         
         /* start cal */
         mbSlave.MZeroCalStartStop = 2;
         
         /* set write flag */
         mbTable[enMZeroCalStop].WrFlg = 1;

         /* clear cal complete flag */
         CalComplete = 0;    
         
         /* start cal timer */
         CalTimer = (unsigned long)(EEPROM.MinCalTime*100)*60;  
         
         MessageBox = 1;                   
      }
      else
      {
         if(!CalTimer)
         {
            /* only stop cal here if its the right cal */
            if(mbSlave.MZeroCalStartStop==2)
            {
               /* change abort button to accept */
               slcd_SetColour(White, White);   
               //slcdMakeButtonCT(3, gstr(&str->ACCEPT), 1, 484, 230, 5, 4);
               MakeButtonCT(3, gstr(&str->ACCEPT), 1, 484, 230, 5, 4);

               /* clear Coleta de dados concluida message */
               slcd_SetColour(DarkGrey, White);   
               slcd_SendText("                                                  ", 20, 135, 0, LEFT_ALIGN);
               
               /* Stop cal */
               mbSlave.MZeroCalStartStop = 0;
               
               /* set write flag */
               mbTable[enMZeroCalStop].WrFlg = 1;
               
               /* get new zero */
               NewMassZero = mbSlave.MassAverage; 
               DisplayNewZero();  
               
               /* get new pulse rate */
               //NewPulseRate = mbSlave.MassAverage/mbSlave.BeltTravel;
               //DisplayPulseRate(NewPulseRate);
               
               /* claculate error */
               MassZeroError = (mbSlave.MassAverage-mbSlave.Zero[2])/(mbSlave.Zero[2]/100);
               DisplayMassZeroError();
                        
               /* set cal complete flag */
               CalComplete = 1;         
               
               /* clear wait msg if it has been displayed */
               slcd_CmdQueue("xic 10 0 0 435 15 550 60");    
               
               /* dont save zero if its > 3 mV */
               if(NewMassZero>EEPROM.ZeroMvLimit)
               {
                  /* beepa ! */
                  slcd_CmdQueue("beep 500"); 
                  DisplayMessageBox(mV_MESSAGE);                     
               }                
            }
            else
            {
               /* error beep */
               slcd_CmdQueue("beep 500");    
               /* reset button state */
               slcdSetButtonSate(2, 0);
            }
         }
         else
         {
            /* display wait meassage */   
            slcd_SetFont(16, 'B');
            slcd_SetColour(Red, White);

            /* display new Speed */
            slcd_SendText(gstr(&str->Wait), 435, 15, 0, LEFT_ALIGN); 
            
            slcdSetButtonSate(2, 1);  
            
            /* error beep */
            slcd_CmdQueue("beep 500");                                                  
         }
      }
      break;       
            
 case 3:
      /* save */
      if(!mbSlave.MZeroCalStartStop && CalComplete)
      {
         /* dont save zero if its > 3 mV */
         if(NewMassZero<EEPROM.ZeroMvLimit)
         {
            /* save the offset */

            /* clear Coleta de dados concluida message */
            slcd_SetColour(DarkGrey, White);   
            slcd_SendText("                                                  ", 20, 135, 0, LEFT_ALIGN);
            
            /* save old zero for span adjust */
            OldMassZero = mbSlave.Zero[2];
                                    
            //mbSlave.MassOffset = NewMassZero;
            mbSlave.Zero[2] = NewMassZero;
            
            /* record the zero shift */
            if(mbSlave.CalibrationFlag&0x02)
               mbSlave.ZeroShift += NewMassZero-OldMassZero; 
            else
               mbSlave.ZeroShift = 0;
               
            mbTable[enZeroShift].WrFlg = 1;
             
            /* write to sensor */
            //mbTable[enMassOffset].WrFlg = 1;
            mbTable[enMassZero].WrFlg = 1;
            
            /* display new offset */         
            DisplayCurrentZero();

            /* save cal data and new zero  */      
            SetMassZeroCalDate(NewMassZero);
            /* display mass zero cal date */
            DisplayMassZeroCalDate();
                        
            /* clear new zero */         
            NewMassZero = 0.0;
            DisplayNewZero();
            
            /* save new pulse rate */
            //EEWR_fl(&EEPROM.PulseRate, NewPulseRate); 
            
            /* clear cal complete flag */
            CalComplete = 0;  
            
            /* write to calibration flag */
            mbSlave.CalibrationFlag = mbSlave.CalibrationFlag|0x02;
            mbTable[enCalibrationFlag].WrFlg = 1;
            
            /* save beep */
            slcd_CmdQueue("beep 1000");  
            
            /* is belt tension enabled? */
            if(mbSlave.AnInFunc[0]==1)
            {
               mbTable[enTensionLo].WrFlg = 0x1;  
               mbSlave.TensionLo = mbSlave.TensionAverage/2;       
            }
         
         }
         else
         {
            /* error beep */
            slcd_CmdQueue("beep 500");     
            /* display warning pop up */
            DisplayMessageBox(mV_MESSAGE);
         }
      }
      else
      {
         /* if the cal is running we use this button to abort */
         if(mbSlave.MZeroCalStartStop)
         {
            /* abort calibration */  
            
            /* reset button state */
            if(mbSlave.MZeroCalStartStop==1)
               slcdSetButtonSate(1, 0);
            else
               slcdSetButtonSate(2, 0);
         
            /* stop mass zero cal */   
            mbSlave.MZeroCalStartStop = 0;
            
            mbSlave.MCalFlag = 0;
            /* set write flag */
            mbTable[enMZeroCalStop].WrFlg = 1;  
            
            slcd_SetColour(White, White);   
            /* change abort button to accept */
            //slcdMakeButtonCT(3, gstr(&str->ACCEPT), 1, 484, 230, 5, 4);                      
            MakeButtonCT(3, gstr(&str->ACCEPT), 1, 484, 150, 5, 4);                      
            
            /* clear wait msg if it has been displayed */
            slcd_CmdQueue("xic 10 0 0 435 15 550 60");    
         }
         else
         {
            /* error beep */
            slcd_CmdQueue("beep 500");     
         }
      }
      break;            
      
  case 128:       /* EXIT to run window */
      /* shut down num key window handler */
      
      /* dont leave if cal is in process */
      if(!mbSlave.MZeroCalStartStop)
      {
         winMassCalState = WIN_MASSCAL_UNLOAD;  
         winMassReturnWin = MAIN_WINDOW;
      }
      else
      {
         /* error beep */
         slcd_CmdQueue("beep 500");     
      }
      break;  

   case 129:       /* EXIT to menu */
      /* shut down num key window handler */
      
      /* dont leave if cal is in process */
      if(!mbSlave.MZeroCalStartStop)
      {
         winMassCalState = WIN_MASSCAL_UNLOAD;  
         winMassReturnWin = SPEEDCAL_WINDOW;
      }
      else
      {
         /* error beep */
         slcd_CmdQueue("beep 500");     
      }
      break; 
      
   case 130:       /* jump to Zero Mass Cal */
      /* shut down num key window handler */
      
      /* dont leave if cal is in process */
      if(!mbSlave.MZeroCalStartStop)
      {
         winMassCalState = WIN_MASSCAL_UNLOAD;
         winMassReturnWin = MASSSPANCAL_WINDOW;  
      }
      else
      {
         /* error beep */
         slcd_CmdQueue("beep 500");     
      }
      break; 
      
 case 131:      /* Belt Length hotspot */
      /* move to key pad handler sate */
      
      /* dont leave if cal is in process */
      if(!mbSlave.MZeroCalStartStop)
      {
         winMassCalState = WIN_MASSCAL_NUMKEYPAD; 
         
         /* copy parameter data to key structure */
         strcpy(NumKeyData.Name, gstr(&str->BeltLength) );  
         NumKeyData.Type = FLOAT;
         NumKeyData.KeyBoardType = NUMBER;
         NumKeyData.fMax = 3000.0;
         NumKeyData.fMin = 0.0;
         NumKeyData.Index = 0;
         NumKeyData.Flag  = enBeltLength;
         
         NumKeyData.DataPtr = (void *)&mbSlave.BeltLength;
      }
      else
      {
         /* error beep */
         slcd_CmdQueue("beep 500");           
      }
      break; 
      
 case 132:      /* Y Scale hotspot */
      /* move to key pad handler sate */

      /* dont leave if cal is in process */
      if(!mbSlave.MZeroCalStartStop)
      {
         winMassCalState = WIN_MASSCAL_NUMKEYPAD; 
         
         /* copy parameter data to key structure */
         strcpy(NumKeyData.Name, "Y Scale" );  
         NumKeyData.Type = BYTE;
         NumKeyData.Attributes = EPROM;
         NumKeyData.KeyBoardType = NUMBER;
         NumKeyData.iMax = 10;
         NumKeyData.iMin = 1;
         NumKeyData.Index = 0;
         
         /* "EEPROM.Xscale" is actually y scale */
         NumKeyData.DataPtr = (void *)&EEPROM.Xscale;
      }
      else
      {
         /* error beep */
         slcd_CmdQueue("beep 500");           
      }
      break;                                                  
   
 case 133:      /* X Scale hotspot */
      /* move to key pad handler sate */
      
      /* dont leave if cal is in process */
      if(!mbSlave.MZeroCalStartStop)
      {
         winMassCalState = WIN_MASSCAL_NUMKEYPAD; 
         
         /* copy parameter data to key structure */
         strcpy(NumKeyData.Name, "X Scale" );  
         NumKeyData.Type = BYTE;
         NumKeyData.Attributes = EPROM;
         NumKeyData.KeyBoardType = NUMBER;
         NumKeyData.iMax = 20;
         NumKeyData.iMin = 1;
         NumKeyData.Index = 0;
         
         /* "EEPROM.Yscale" is actually x scale */
         NumKeyData.DataPtr = (void *)&EEPROM.Yscale;
      }
      else
      {
         /* error beep */
         slcd_CmdQueue("beep 500");           
      }
      break;                                                  
   
   }
}

/*
** ------------------------------------------------------------------------------
**		Function: void ReadMassCalParameters(void)
** ------------------------------------------------------------------------------
*/

void ReadMassCalParameters(void)
{
   mbTable[enMassAvg].RdFlg = 0x1;
   mbTable[enMassZero].RdFlg = 0x1;
   //mbTable[enMassOffset].RdFlg = 0x1;
   
   mbTable[enMassAdj].RdFlg = 0x1;
   mbTable[enMassSpan].RdFlg = 0x1;
   mbTable[enMassMv].RdFlg = 0x1;
   
   mbTable[enBeltLength].RdFlg = 0x1;
}



/*
** ------------------------------------------------------------------------------
**		Function: void DrawMvGraph(void)
** ------------------------------------------------------------------------------
*/

void DrawMvGraph(word x, word y)
{
   byte Buf[50];

   /* set forground and back ground colour */
   slcd_SetColour(Blue, White);   

   /* draw graph axis */
   /* Draw Y Axis */
   DrawLine(x, y, x, y+140);   
   /* Draw X Axis */
   DrawLine(x, y+141, x+440, y+141);  
   
   /* set font */
   slcd_SetFont(14, 0);
   /* set forground and back ground colour */
   slcd_SetColour(LightBlue, White);   

   //sprintf(Buf, "%3u", 10);
   //slcdslcd_SendText(&Buf, x-20, y, 'T'); 

   /* Display upper scale digit */
   sprintf(Buf, "%3u", EEPROM.Xscale);
   slcd_SendText(&Buf, x-30, y, 0, LEFT_ALIGN); 
   
   /* Display lower scale digit */
   sprintf(Buf, "%3u", 0);
   slcd_SendText(&Buf, x-30, y+140, 0, LEFT_ALIGN);   
   
   /* Optional X axis unit indicator */
   //slcdslcd_SendText("X Axis Scale:",x+330,y+148,'T');
   
   /* Display Time scale unit (minutes) */
   sprintf(Buf, "%3u min", EEPROM.Yscale);
   slcd_SendText(&Buf, x+455, y+148, 0, LEFT_ALIGN); 

   //sprintf(Buf, "%u hr %u m", (word)EEPROM.TrendTime/60, (word)EEPROM.TrendTime%60 );
   //slcdslcd_SendText(Buf, x+298, y+83, 'T'); 
   
   MakeChart (x+1, y, x+440, y+140, 140);
}

/*
** ------------------------------------------------------------------------------
**		Function: void DisplayNewZero(void)
** ------------------------------------------------------------------------------
*/

void DisplayNewZero(void)
{   
   byte Buf[20];
   
   slcd_SetFont(16, 0);
   slcd_SetColour(DarkGrey, White);
   
   /* clear old zero */
   slcd_SendText("         ", 404, 200, 0, LEFT_ALIGN); 
      
   /* format Belt Length  */       
   //sprintf(Buf, "%lu ", NewMassZero);
   sprintf(Buf, "%.3f ", NewMassZero);
   
   /* display belt length */
   slcd_SendText(&Buf, 400, 200, 0, LEFT_ALIGN); 
} 

/*
** ------------------------------------------------------------------------------
**		Function: void DisplayBeltTravel(void)
** ------------------------------------------------------------------------------
*/

void DisplayCurrentZero(void)
{   
   byte Buf[20];
   
   slcd_SetFont(16, 0);
   slcd_SetColour(DarkGrey, White);

   /* clear old zero */
   slcd_SendText("         ", 140, 200, 0, LEFT_ALIGN); 
      
   /* format Belt Length  */       
   //sprintf(Buf, "%lu ", mbSlave.MassOffset);
   sprintf(Buf, "%.3f ", mbSlave.Zero[2]);
   
   /* display belt length */
   slcd_SendText(&Buf, 140, 200, 0, LEFT_ALIGN); 
} 


/*
** ------------------------------------------------------------------------------
**		Function: void DisplayBeltTravel(void)
** ------------------------------------------------------------------------------
*/

void DisplayBeltTravel(void)
{   
   byte i, Buf[20];
   
   slcd_SetFont(16, 'B');
   slcd_SetColour(DarkGrey, White);
      
   /* format Belt Length  */       
   sprintf(Buf, "%.1f ", mbSlave.BeltTravel);

   /* get string length  */
   i = strlen(Buf);
   
   /* has string length changed? */
   if(i!=LastBeltLen)
   {
      LastBeltLen = i;
      /* clear display */
      slcd_SendText("            ", 364, 150, 0, LEFT_ALIGN);      
   }

   
   /* display belt length */
   slcd_SendText(&Buf, 364, 150, 0, LEFT_ALIGN); 
   
   mbTable[enBeltTravel].RdFlg = 1; 
} 


/*
** ------------------------------------------------------------------------------
**		Function: void DisplayMilliVolts(void)
** ------------------------------------------------------------------------------
*/

void DisplayBeltLength(void)
{   
   byte Buf[20];
   
   slcd_SetFont(16, 'B');
   slcd_SetColour(LightBlue, White);
      
   /* clear old zero */
   slcd_SendText("         ", 130, 224, 0, LEFT_ALIGN); 
         
   /* format Belt Length  */       
   sprintf(Buf, "%.1f  ", mbSlave.BeltLength);
   
   /* display belt length */
   slcd_SendText(&Buf, 364, 99, 0, LEFT_ALIGN);  
} 

/*
** ------------------------------------------------------------------------------
**		Function: void DisplayMilliVolts(void)
** ------------------------------------------------------------------------------
*/

void DisplayMilliVolts(void)
{   
   byte Buf[20];
   
   slcd_SetFont(16, 'B');
   slcd_SetColour(DarkGrey, White);
      
   /* format mV  */       
   sprintf(Buf, "%.2f  ", mbSlave.MassMv);
   
   /* display new mV */
   slcd_SendText(&Buf, 540, 305, 0, LEFT_ALIGN);  
   
   mbTable[enMassMv].RdFlg = 1;      
} 


/*
** ------------------------------------------------------------------------------
**		Function: void DisplayPulseRate(float PulseRate)
** ------------------------------------------------------------------------------
*/

void DisplayPulseRate(float PulseRate)
{   
   byte Buf[20];
   
   slcd_SetFont(16, 'B');
   slcd_SetColour(DarkGrey, White);
      
   /* clear old zero */
   slcd_SendText("            ", 170, 266, 0, LEFT_ALIGN); 
         
   /* format Belt Length  */       
   sprintf(Buf, "%f ", PulseRate);
   
   /* display belt length */
   slcd_SendText(&Buf, 170, 266, 0, LEFT_ALIGN); 
} 


/*
** ------------------------------------------------------------------------------
**		Function: void DisplayMassZeroCalDate(void)
** ------------------------------------------------------------------------------
*/

void DisplayMassZeroCalDate(void)
{   
   slcd_SetFont(16, 0);
   slcd_SetColour(DarkGrey, White);
      
   /* clear display */
   slcd_SendText("          ", 176, 260, 0, LEFT_ALIGN);      
   
   /* display new Speed */
   slcd_SendText(&EEPROM.MassZeroCal[EEPROM.MassZeroCalPtr].Date, 176, 260, 0, LEFT_ALIGN);  
}

/*
** ------------------------------------------------------------------------------
**		Function: void DisplayMassZeroError(void)
** ------------------------------------------------------------------------------
*/

void DisplayMassZeroError(void)
{   
   byte Buf[20];
   
   slcd_SetFont(16, 0);
   slcd_SetColour(DarkGrey, White);
      
   /* format Belt Length  */       
   sprintf(Buf, "%.2f %%", MassZeroError);

   /* clear display */
   slcd_SendText("              ", 350, 260, 0, LEFT_ALIGN);      
          
   /* display zero error */
   slcd_SendText(&Buf, 350, 260, 0, LEFT_ALIGN); 
} 


/*
** ------------------------------------------------------------------------------
**		Function: void UpdateZeroMassCal(void)
** ------------------------------------------------------------------------------
*/

void UpdateZeroMassCal(void)
{      
   /* requested update */
   if (winUpdate1==1)
   {
      /* stop counter */
      winUpdate1 = 0;
   }                                                                                                    

   /* time to update? */
   if (!winTimer1)
   {
      winTimer1 = (word)YscaleFactor;

      /* only if we're calibrating */
      if(mbSlave.MZeroCalStartStop==2)                     
         UpDateChart(0, (word)(mbSlave.MassMv*XscaleFactor));      
   }

   /* time to update? */
   if (!winTimer2)
   {
      winTimer2 = 25;

      /* update milli volts */      
      DisplayMilliVolts();     

      /* show distance travelled  */
      if(mbSlave.MZeroCalStartStop)        
         DisplayBeltTravel();  
      
      /* if we're clibrating get mass average */
      if(mbSlave.MZeroCalStartStop)   
      {
         mbTable[enMassAvg].RdFlg = 0x1;   
         
         /* is belt tension enabled? */
         if(mbSlave.AnInFunc[0]==1)
            mbTable[enTensionAvg].RdFlg = 0x1;      
         
         /* if its a belt length cal */
         if(mbSlave.MZeroCalStartStop==1)
         {
            /* check cal flag */
            if(!mbSlave.MCalFlag)
            {
               /* cal has finished */                  
               mbSlave.MZeroCalStartStop = 0;
                              
               /* get new zero */
               NewMassZero = mbSlave.MassAverage; 

               /* dont save zero if its > 3 mV */
               if(NewMassZero<EEPROM.ZeroMvLimit)
               {               
                  DisplayNewZero();  
                  
                  /* get new pulse rate */
                  //NewPulseRate = mbSlave.MassAverage/mbSlave.BeltLength;
                  //DisplayPulseRate(NewPulseRate);

                  /* claculate error */
                  MassZeroError = (mbSlave.MassAverage-mbSlave.Zero[2])/(mbSlave.Zero[2]/100);
                  DisplayMassZeroError();
               
                  /* reset button state */
                  slcdSetButtonSate(1, 0);
               }
               else
               {
                  /* beepa ! */
                  slcd_CmdQueue("beep 500"); 
                  
                  DisplayMessageBox(mV_MESSAGE);                     
               }
               
               /* flag cal stop */
               mbSlave.MZeroCalStartStop = 0 ;
               /* set complete flag */
               CalComplete = 1;                                         
            }
            else
            {
               /* read again */   
               mbTable[enMCalFlag].RdFlg = 0x1;   
            }
         }
         if(!CalTimer && mbSlave.MZeroCalStartStop > 1)
         {
            if (MessageBox == 1) 
            {
              //DisplayMessageBox(TIME_OUT_MESSAGE);
              slcd_SetFont(16, 'B');
              slcd_SetColour(Red, White);
              slcd_SendText("Coleta de dados concluida", 20, 135, 0, LEFT_ALIGN);
              MessageBox = 2; 
            }
         }         
      }
   }


   if(mbSlave.MZeroCalStartStop==1)                     
   {

      /* time to update? */
      if (!winTimer3)
      {
         winTimer3 = 5;
         mbTable[enBeltTravel].RdFlg = 1; 
      }   

      if(mbSlave.BeltTravel>(LastDistance+UpDateRate))
      {
         /* update mV graph (scale up *7 for 70 pixels )*/
         UpDateChart(0, (word)(mbSlave.MassMv*XscaleFactor));      
         //LastDistance = mbSlave.BeltTravel;
         LastDistance += UpDateRate;
         
         //PTP_PTP5 ^= 1;
      }
      
      if(mbSlave.BeltTravel > ((3 * mbSlave.BeltLength))- 0.2)
      {
        slcd_SetFont(16, 'B');
        slcd_SetColour(Red, White);
        slcd_SendText("Coleta de dados concluida", 20, 135, 0, LEFT_ALIGN);

         slcd_SetColour(White, Black);   
         /* change abort button to accept */
         //slcdMakeButtonCT(3, gstr(&str->ACCEPT), 1, 484, 230, 5, 4);                  
         slcd_MakeButtonCT(3, gstr(&str->ACCEPT), 1, 484, 200, 5, 4);                  
      }       
   }
}

/*
** ------------------------------------------------------------------------------
**		Function: void winPaintZeroMassCal(void)
** ------------------------------------------------------------------------------
*/

void winPaintZeroMassCal(void)
{  
   //lButtonType Button;   
   byte ButtonText1[20], ButtonText2[20];
    
   /* make back hotspot */
   slcd_MakeHotSpot(129, 50, 440, 100, 480);
   
   /* make next hotspot */
   slcd_MakeHotSpot(130, 220, 440, 280, 480); 
   
   /* make belt length hotspot */
   slcd_MakeHotSpot(131, 350, 100, 450, 130);

   /* make graph scale hotspot */
   slcd_MakeHotSpot(132, 10, 300, 30, 320);
   slcd_MakeHotSpot(133, 460, 450, 560, 480);
      
   slcd_SetFont(16, 'B');   
   slcd_SetColour(White, White);
   
   /* zero cal start button */
   //Button.Id = 1;
   //Button.x = 484;
   //Button.y = 90;
   //Button.type = 2;
   //Button.state = 0;
   //strcpy(ButtonText1, "Iniciar");      
   strcpy(ButtonText1, gstr(&str->START));      
   //strcpy(ButtonText2, "Parar");      
   strcpy(ButtonText2, gstr(&str->STOP));      
   //Button.text0 = ButtonText1;
   //Button.text1 = ButtonText2;
   //Button.dx0 = 20;
   //Button.dy0 = 6;
   //Button.dx1 = 24;
   //Button.dy1 = 6;
   //Button.bmp0 = 5;
   //Button.bmp1 = 4;  
       
   /* define start/stop button */
   //slcdMakeLatchingButtonCT(&Button);  
   slcd_MakeLatchingButtonCT(1, ButtonText1, ButtonText2, 484, 90, 5, 4);
  
  
   /* make span cal button */
   //Button.Id = 2;
   //Button.x = 484;
   //Button.y = 160;
   //Button.type = 2;
   //Button.state = 0;
   //strcpy(ButtonText1, "Iniciar");      
   //strcpy(ButtonText2, "Parar");      

   //strcpy(ButtonText1, "Iniciar");      
   strcpy(ButtonText1, gstr(&str->START));      
   //strcpy(ButtonText2, "Parar");      
   strcpy(ButtonText2, gstr(&str->STOP));      
       
   /* define start/stop button */
   //slcdMakeLatchingButtonCT(&Button); 
   slcd_MakeLatchingButtonCT(2, ButtonText1, ButtonText2, 484, 150, 5, 4);

   /* make save button */
   //slcdMakeButtonCT(3, gstr(&str->ACCEPT), 1, 484, 230, 5, 4);
   slcd_MakeButtonCT(3, gstr(&str->ACCEPT), 1, 484, 210, 5, 4);
   
   slcd_SetColour(LightBlue, White);
   slcd_SendText(gstr(&str->Back),50,455, 0, LEFT_ALIGN);
   slcd_SendText(gstr(&str->Next),220,455,0, LEFT_ALIGN);
   

   /* display belt length */
   DisplayBeltLength();
   /* */
   DisplayCurrentZero();
   /* */
   DisplayNewZero();
   /* */
   //DisplayPulseRate(EEPROM.PulseRate);
   
   /* mass zero cal date */
   DisplayMassZeroCalDate();
   
   DisplayMassZeroError();
   
   /* calculate scale factor */
   XscaleFactor = 140/EEPROM.Xscale;
   
   /* calculate Y scale factor */
   YscaleFactor = ((EEPROM.Yscale*60)/440.0)*100;
   
   /* display milli volt graph */
   DrawMvGraph(CHART_X, CHART_Y);
}

/*
** ------------------------------------------------------------------------------
**		Function: byte winMassCalHandler(void)
** ------------------------------------------------------------------------------
*/

byte winMassCalHandler(void)
{
   switch (winMassCalState)
   {
   case WIN_MASSCAL_PREPAINT:
      /* get analog parameters from slave */
      ReadMassCalParameters();
      winMassCalState = WIN_MASSCAL_PAINT;
      
      /* LastMvLen */
      LastMvLen = 0;
      LastBeltLen = 0;
      NewMassZero = 0.0;
      NewPulseRate = 0.0;      
      CalComplete = 0;
      mbSlave.MZeroCalStartStop = 0;
      break;
      
   case WIN_MASSCAL_PAINT:
      /* send command to execute macro 2 */
      //slcdCallMacro(2);
      /* display zero mas cal page */      
      ////slcd_CmdQueue("xi 19 0 0");
      //slcd_CmdQueue("xi 36 0 0");

      slcd_SetColour(DarkGrey, DarkGrey);
      slcd_Send("z");

      slcd_Send("xc all");     
      /* display menu screen */
      //DisplayBmp(16, 0, 0); 
      slcd_DisplayBmp(10, 0, 0); 

      DisplayTitle(gstr(&str->ZeroCal));
      
      slcd_SetColour(DarkGrey, White);
      
      slcd_SetFont(16,0);
      slcd_SendText("Movimente a correia vazia e selecione a opc\303\243o", 15, 60, 0, LEFT_ALIGN);
      slcd_SendText(gstr(&str->ActualZero),15,200,0, LEFT_ALIGN);
      slcd_SendText(gstr(&str->NewZero),280,200,0, LEFT_ALIGN);
      slcd_SendText(gstr(&str->ActualZeroDate),15,260,0, LEFT_ALIGN);
      slcd_SendText(gstr(&str->ErrorColon),300,260,0, LEFT_ALIGN);
      slcd_SendText(gstr(&str->miliVolts),500,305,0, LEFT_ALIGN);
      
   
      
      //slcd_SetFont(24, 0);
      slcd_SetColour(Blue, White);
      slcd_SendText("1 - Informe o comprimento da correia:", 15, 93, 0, LEFT_ALIGN);
      slcd_SendText("2 - Marque a correia e inicialize", 15, 153, 0, LEFT_ALIGN);
      slcd_SendText("m", 450,93,0, LEFT_ALIGN);
      slcd_SendText("m", 450,153,0, LEFT_ALIGN);
       

      /* define back hotspot */
      slcd_MakeHotSpot(128, 560, 10, 50, 50);
            
      winPaintZeroMassCal();
      
      /* update parameters */
      winUpdate1 = 1;
      
      /* move to update state */      
      winMassCalState = WIN_MASSCAL_UPDATE;       
      return 0;

   case WIN_MASSCAL_UPDATE:
      /* is there a key to process? */
      if (slcdKey)
      {
         /* call key handler */
         winMassCalKeyHandler(slcdKey);      
         /* now the key has been processed clear it */
         slcdKey = 0; 
      }

      UpdateZeroMassCal();
      
      /* has any data been remotely changed? */
      if(mbSlave.DataUpdate)
      {
         /* clear data update flag */
         mbSlave.DataUpdate = 0;
         mbTable[enDataUp].WrFlg = 1;   
         
         /* read analog parameters */
         ReadMassCalParameters();  
         
         /* set update timer */                   
         winUpdate1 = 100;
      }      
      return 0;

  case WIN_MASSCAL_NUMKEYPAD:
      /* see if key pad is returning */
      if(winKeyPadHandler())
         /* move to update state */      
         winMassCalState = WIN_MASSCAL_PAINT;   
      break;

   case WIN_MASSCAL_MSGBOX:
      /* see if confirmation win is returning */
      switch(winConfirmHandler()) 
      {
      case 2:
         /* move to paint state */      
         winMassCalState = WIN_MASSCAL_PAINT;      
         break;
      }
      break; 

   case WIN_MASSCAL_UNLOAD:
      /* do any necessary clearing up */
      winMassCalState = WIN_MASSCAL_PREPAINT;  
      
      /* switch to next screen */
      winActiveWin = winMassReturnWin;  


      /* return from key pad */
      return 1;
   }   
}



