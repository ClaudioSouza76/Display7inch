/*
** ------------------------------------------------------------------------------
   
   File   : winBasicConfig.h 
   Aurthor: Stuart Clarke

** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

#ifndef WINANALOGUEIN_H
#define WINANALOGUEIN_H


/* public defines */

/*
** ------------------------------------------------------------------------------
**		#define : user menu handler states 
** ------------------------------------------------------------------------------
*/

#define WIN_ANALOGUE_IN_PREPAINT     0
#define WIN_ANALOGUE_IN_PAINT        1
#define WIN_ANALOGUE_IN_PAINTPAGE    2
#define WIN_ANALOGUE_IN_UPDATE       3
#define WIN_ANALOGUE_IN_NUMKEYPAD    4
#define WIN_ANALOGUE_IN_UNLOAD       5
#define WIN_ANALOGUE_IN_ENTER_PASSWORD 6


#ifndef WINANALOGUEIN_C

/* public variables */
#pragma DATA_SEG WINANALOGUEIN_DATA

extern byte winAnalogueInReturnWin;

#endif   /* WINANALOGUEIN_C */      


/* public functions */
#pragma CODE_SEG WINANALOGUEIN_CODE


/*
** ------------------------------------------------------------------------------
**		Function: void ReadAnalogueInParameters(void)
** ------------------------------------------------------------------------------
*/

void ReadAnalogueInParameters(void);

/*
** ------------------------------------------------------------------------------
**		Function: byte winAnalogueInHandler(void)
** ------------------------------------------------------------------------------
*/

byte winAnalogueInHandler(void);

#endif   /* WINANALOGUEIN_H */
