/*
** ------------------------------------------------------------------------------
   
   File   : ModBusM.h 
   Aurthor: 
        
** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

#ifndef ModBusM_H
#define ModBusM_H

#pragma CODE_SEG MODBUSM_Code
#pragma DATA_SEG MODBUSM_Data

/* public defines */

/*
** ------------------------------------------------------------------------------
**		define: Error responses 
** ------------------------------------------------------------------------------
*/

#define mbOk            0x00
#define mbFunctionErr   0x01
#define mbAddressErr    0x02
#define mbDataErr       0x03

#define mbTimeoutErr    0x0E
#define mbCRCErr        0x0F

/*
** ------------------------------------------------------------------------------
**		#define: table defines 
** ------------------------------------------------------------------------------
*/

//#define mbMBSW          0
//#define mbMBSWTIMEOUT   1
#define mbCONNECT       0
#define mbIDLE          1
#define mbBUSY          2

/*
** ------------------------------------------------------------------------------
**		#define : modbus status bits
** ------------------------------------------------------------------------------
*/

#define mbOFFLINE       1
#define mbONLINE        2

 /*
** ------------------------------------------------------------------------------
**		DataType: mbtype
** ------------------------------------------------------------------------------
*/

#define mbRXBUF_SZ      100
#define mbTXBUF_SZ      50

typedef struct
{
   byte RxBuf[mbRXBUF_SZ]; 
   byte *RxPtr;
     
   byte TxBuf[mbTXBUF_SZ];   
   byte *TxPtr;
   
   byte In;
   byte Busy;
   byte Init;
   byte TimeOut;
}mbtype;


#ifndef MODBUSM_C

/* public variables */
extern mbtype  mb;
extern byte    mbMsgLength;
extern byte    mbStatus;
extern byte    mbTableIndex;

extern word    BusComErrCnt;
extern word    ExceptionErrCnt;



#endif   /* FileName_C */ 


/* public functions */
#pragma CODE_SEG MODBUSM_Code


/*
** ------------------------------------------------------------------------------
**		Function: void ModBus_Init(word SCIRegPtr)
** ------------------------------------------------------------------------------
*/

void ModBusM_Init(word SCIRegPtr);

/*
** ------------------------------------------------------------------------------
**		void mbT3Timeout(void)
** ------------------------------------------------------------------------------
*/

void mbT3Timeout(void);

/*
** ------------------------------------------------------------------------------
**		interrupt void mbMsgTimer(void)
** ------------------------------------------------------------------------------
*/

void mbMsgTimer(void);

/*
** ------------------------------------------------------------------------------
**		Function: void mbModBusDriver(void)
** ------------------------------------------------------------------------------
*/

void mbModBusDriver(void);

/*
** ------------------------------------------------------------------------------
**		Function: __interrupt void near ModBus_Interrupt(void)
** ------------------------------------------------------------------------------
*/

#pragma CODE_SEG NON_BANKED 

__interrupt void near ModBus_Interrupt(void);

     
#endif   /* FileName_H */
