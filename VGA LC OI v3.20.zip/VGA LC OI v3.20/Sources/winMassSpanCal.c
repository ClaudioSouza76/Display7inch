#include <hidef.h>                           /* common defines and macros */
#include "derivative.h"                      /* derivative information */

/*
** ------------------------------------------------------------------------------
   
   File   : winMassSpanCal.c 
   Aurthor: 
   
   Description:  
   
   Version Log          Notes                                     Changes Made by                                        
   --------------       -----                                     ---------------
   12-10-10:            Created                                   Stuart


** ------------------------------------------------------------------------------
                                    
                                    Overview
                                            
** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

/* library headers */
#include "stdio.h"
#include "float.h"
#include "math.h"
#include "stdlib.h"

/* Application headers */
#include "CRG 100110.h" 
#include "Subs.h"
#include "ModBusM Int.h"
#include "ModBusM.h"
#include "EEPROM.h"
#include "SLCD 260217.h"
#include "winMain.h"
#include "winKey.h"
#include "Language.h"
#include "winBalanceData.h"
#include "winMassCal.h"
#include "winConfirm.h"
#include "SlcdSubs.h"
#include "winDigitalOut.h"


/* Implements this interface: */
#define WINMASSSPANCAL_C
#include "winMassSpanCal.h"

#pragma CODE_SEG WINMASSSPANCAL_Code
#pragma DATA_SEG WINMASSSPANCAL_Data


/* private */
static byte winMassSpanCalState;
static byte winMassSpanReturnWin;

static byte MassCalComplete;
static byte LastAvgMassLen;
static byte LastRefWeightLen;
static byte LastRefLen;
static byte LastBeltDisLen;

static float NewMassSpan;
static float MassError; 
static float FlowRate;
static float RefWeight;

static byte MassCalCalcFlag;

static byte MassCalTypeFlag;

word ValueCal;


/* public */


/*
** ------------------------------------------------------------------------------
**		Function: void winMassSpanCalKeyHandler(byte key)
** ------------------------------------------------------------------------------
*/

void winMassSpanCalKeyHandler(byte key)
{   
   float f;
   
   switch (key)
   {
   case 1:  /* test weight */
      winMassSpanCalState = WIN_MASSSPANCAL_PAINT;      
      MassCalTypeFlag = MASS_TEST_WEIGHT_CAL;
      break;

   case 2:  /* test weight */
      winMassSpanCalState = WIN_MASSSPANCAL_PAINT;      
      MassCalTypeFlag = MASS_MATERIAL_CAL;
      break;
   
   case 3:  /* belt cut */
      winMassSpanCalState = WIN_MASSSPANCAL_PAINT;      
      MassCalTypeFlag = MASS_BELT_CUT_CAL;
      break;
         
   case 4:  /* start/stop tests weight cal */
              /* has cal been started or stopped */
      if(MassCalTypeFlag == MASS_TEST_WEIGHT_CAL)
      {
         if(!mbSlave.MSpanCalStartStop)
         {
            /* start cal */
            mbSlave.MSpanCalStartStop = MASS_TEST_WEIGHT_CAL;
            /* set write flag */
            mbTable[enMSpanCalStop].WrFlg = 1;

            mbSlave.MCalFlag = MASS_TEST_WEIGHT_CAL;
                     
            /* clear cal complete flag */
            MassCalComplete = 0;    
            
            /* start cal timer */
            ValueCal =  EEPROM.MinCalTime*100;
           // CalTimer = (EEPROM.MinCalTime*100)*60;  
           CalTimer = ValueCal * 60;
            /* start time out timer */
            CalTimeOut = (EEPROM.MaxCalTime*100)*60;
            
            /* adjust span if error is > 1.0 % */
            if(MassZeroError>1.0)
            {
               /* get test weight percentage 10mV*(80.0%/100) */  
               f = 10.0*(TestWightPercentage/100.0);
               
               /* calculate new span */                  
               NewMassSpan = mbSlave.Span[2]/((f-mbSlave.Zero[2])/(f-OldMassZero));
               DisplayNewSpan();   
               
               /* save the span */
               if(NewMassSpan>0.0)
               {
                    mbSlave.Span[2] = NewMassSpan;                 
                    /* write to sensor */
                    mbTable[enMassSpan].WrFlg = 1; 
               }
            }                                                     
         }
         else
         {
            /* only stop cal here if its the right cal */
            if(mbSlave.MSpanCalStartStop==MASS_TEST_WEIGHT_CAL)
            {
               if(!CalTimer)
               {               
                  /* Stop cal */
                  mbSlave.MSpanCalStartStop = 0;
                  /* set write flag */
                  mbTable[enMSpanCalStop].WrFlg = 1;

                  /* set cal complete flag */
                  MassCalComplete = MASS_TEST_WEIGHT_CAL;  
                  
                  /* update */
                  mbTable[enMassAvg].RdFlg = 1;  
                  mbTable[enBeltTravel].RdFlg = 1; 
                  
                  /* clear wait msg if it has been displayed */
                  slcd_CmdQueue("xic 17 0 0 400 8 540 60");                        
               }
               else
               {
                  /* display wait meassage */   
                  slcdSetFont(F16B);
                  slcdSetColour(Red, White);

                  /* display new Speed */
                  slcdDisplayText("AGUARDE", 400, 8, 'T'); 
                  
                  slcdSetButtonSate(4, 1);  
                  
                  /* error beep */
                  slcd_CmdQueue("beep 500");                                                  
               }
            }
            else
            {
               /* error beep */
               slcd_CmdQueue("beep 500");    
               /* reset button state */
               slcdSetButtonSate(4, 0);
            }         
         }  
      }
      else
      {
         if(MassCalTypeFlag == MASS_MATERIAL_CAL)
         {
            /*
            if(!mbSlave.MSpanCalStartStop)
            {
               /* start cal 
               mbSlave.MSpanCalStartStop = MASS_MATERIAL_CAL;
               /* set write flag/
               mbTable[enMSpanCalStop].WrFlg = 1;

               //mbSlave.MCalFlag = MASS_MATERIAL_CAL;
               mbSlave.MCalFlag = MASS_BELT_CUT_CAL;
                        
               /* clear cal complete flag 
               MassCalComplete = 0;           
            }
            else
            {
               /* only stop cal here if its the right cal 
               //if(mbSlave.MSpanCalStartStop==MASS_MATERIAL_CAL)
               if(mbSlave.MSpanCalStartStop==MASS_BELT_CUT_CAL)
               {
                  /* Stop cal
                  mbSlave.MSpanCalStartStop = 0;
                  /* set write flag */
                  mbTable[enMSpanCalStop].WrFlg = 1;
                  
                  /* update 
                  mbTable[enMassAvg].RdFlg = 1;  
                  mbTable[enBeltTravel].RdFlg = 1;  
                  
                  //MassCalCalcFlag = 1;                    
               }
               else
               {
                  /* error beep 
                  slcd_CmdQueue("beep 500");    
                  /* reset button state 
                  slcdSetButtonSate(4, 0);
               }   */
               
               if(!mbSlave.MSpanCalStartStop)
               {
                  /* start cal */
                  mbSlave.MSpanCalStartStop = MASS_BELT_CUT_CAL;
                  /* set write flag */
                  mbTable[enMSpanCalStop].WrFlg = 1;

                  mbSlave.MCalFlag = MASS_BELT_CUT_CAL;
                           
                  /* clear cal complete flag */
                  MassCalComplete = 0;           
               }
               else
               {
                  /* only stop cal here if its the right cal */
                  if(mbSlave.MSpanCalStartStop==MASS_BELT_CUT_CAL)
                  {
                     /* Stop cal */
                     mbSlave.MSpanCalStartStop = 0;
                     /* set write flag */
                     mbTable[enMSpanCalStop].WrFlg = 1;
                     
                     /* move to key pad handler sate */
                     winMassSpanCalState = WIN_MASSSPANCAL_NUMKEYPAD; 
                     
                     /* copy parameter data to key structure */
                     strcpy(NumKeyData.Name, gstr(&str->CalWeight) );  
                     NumKeyData.Type = FLOAT;
                     NumKeyData.KeyBoardType = NUMBER;
                     NumKeyData.Attributes = EPROM;
                     NumKeyData.fMax = 100000.0;
                     NumKeyData.fMin = 1.0;      
                     
                     NumKeyData.DataPtr = (void *)&EEPROM.RefWeight;  
                     
                     MassCalComplete=MASS_BELT_CUT_CAL;
                     
                     /* update */
                     mbTable[enMassAvg].RdFlg = 1;  
                     mbTable[enBeltTravel].RdFlg = 1;  
                                    
                  }
                  else
                  {
                     /* error beep */
                     slcd_CmdQueue("beep 500");    
                     /* reset button state */
                     slcdSetButtonSate(4, 0);
                  }      
            }  
         } 
         else
         {
            if(MassCalTypeFlag == MASS_BELT_CUT_CAL)
            {
               if(!mbSlave.MSpanCalStartStop)
               {
                  /* start cal */
                  mbSlave.MSpanCalStartStop = MASS_BELT_CUT_CAL;
                  /* set write flag */
                  mbTable[enMSpanCalStop].WrFlg = 1;

                  mbSlave.MCalFlag = MASS_BELT_CUT_CAL;
                           
                  /* clear cal complete flag */
                  MassCalComplete = 0;           
               }
               else
               {
                  /* only stop cal here if its the right cal */
                  if(mbSlave.MSpanCalStartStop==MASS_BELT_CUT_CAL)
                  {
                     /* Stop cal */
                     mbSlave.MSpanCalStartStop = 0;
                     /* set write flag */
                     mbTable[enMSpanCalStop].WrFlg = 1;
                     
                     /* move to key pad handler sate */
                     winMassSpanCalState = WIN_MASSSPANCAL_NUMKEYPAD; 
                     
                     /* copy parameter data to key structure */
                     strcpy(NumKeyData.Name, gstr(&str->CalWeight) );  
                     NumKeyData.Type = FLOAT;
                     NumKeyData.KeyBoardType = NUMBER;
                     NumKeyData.Attributes = EPROM;
                     NumKeyData.fMax = 100000.0;
                     NumKeyData.fMin = 1.0;      
                     
                     NumKeyData.DataPtr = (void *)&EEPROM.RefWeight;  
                     
                     MassCalComplete=MASS_BELT_CUT_CAL;
                     
                     /* update */
                     mbTable[enMassAvg].RdFlg = 1;  
                     mbTable[enBeltTravel].RdFlg = 1;  
                                    
                  }
                  else
                  {
                     /* error beep */
                     slcd_CmdQueue("beep 500");    
                     /* reset button state */
                     slcdSetButtonSate(4, 0);
                  }         
               }  
            }             
         }
      }
      break;

   case 7:    /* Calculate */
      if(MassCalComplete==MASS_TEST_WEIGHT_CAL)  
      {         
         MassCalComplete = 0;
         
         /* claculate new span */
         //NewMassSpan = mbSlave.Span[2]/(mbSlave.MassAverage/EEPROM.RefWeight);
         NewMassSpan = mbSlave.Span[2]/(mbSlave.MassAverage/TestWightPercentage);
         DisplayNewSpan();
         
         /* copy ref weight for storage */
         RefWeight = TestWightPercentage;
         
         /* claculate error */
         //MassError = (mbSlave.MassAverage-EEPROM.RefWeight)/(mbSlave.MassAverage/100);
         MassError = (mbSlave.MassAverage-TestWightPercentage)/(mbSlave.MassAverage/100);
         
         DisplayMassError();   
         
         /* record the span shift */
         if(mbSlave.CalibrationFlag&0x04)
            mbSlave.SpanShift += NewMassSpan-mbSlave.Span[2]; 
         else
            mbSlave.SpanShift = 0;
         
         MassCalCalcFlag = 1;    
      }
      else
      {
         if(MassCalComplete==MASS_MATERIAL_CAL || MassCalComplete==MASS_BELT_CUT_CAL)  
         {         
            MassCalComplete = 0;
            
            /* get mass in kg's */
            f = mbSlave.MassAverage*1000;            

            /* copy ref weight for storage */
            RefWeight = EEPROM.RefWeight;
            
            /* claculate new span */
            NewMassSpan = mbSlave.Span[2]*(EEPROM.RefWeight/f);
            
            DisplayNewSpan();
            
            /* claculate error */
            MassError = (f-EEPROM.RefWeight)/(f/100);
            
            DisplayMassError();   

            /* record the span shift */
            if(mbSlave.CalibrationFlag&0x04)
               mbSlave.SpanShift += NewMassSpan-mbSlave.Span[2]; 
            else
               mbSlave.SpanShift = 0;
            
            MassCalCalcFlag = 1;           
         }
         else
         {
            /* save beep */
            slcd_CmdQueue("beep 500");  
         }      
      }
      break;            

   case 8:     /* Save */
      if(MassCalCalcFlag)      
      {
         MassCalCalcFlag = 0;
            
         /* save the span */
         mbSlave.Span[2] = NewMassSpan;      
         /* write to sensor */
         mbTable[enMassSpan].WrFlg = 1;
         
         /* display new offset */         
         DisplayMassSpan();
                  
         /* clear new zero */         
         NewMassSpan = 0.0;
         DisplayNewSpan();   
         
         /* Grava a data da pr�xima calibra��o */
         RecordNextDateCal();
         
         RecordLastCall();
         
         /* save cal data and weight */      
         SetMassCalDate(RefWeight);
         
         /* update date and ref weight */
         DisplayLastRefWeight();       
         DisplayMassCalDate();
         
         /* write to calibration flag */
         mbSlave.CalibrationFlag = mbSlave.CalibrationFlag|0x04;
         mbTable[enCalibrationFlag].WrFlg = 1;
         
         /* record the span shift */
         mbTable[enSpanShift].WrFlg = 1;
         
         /* is belt tension enabled? */
         if(mbSlave.AnInFunc[0]==1)
         {
            mbTable[enTensionHi].WrFlg = 0x1;  
            mbSlave.TensionHi = mbSlave.TensionAverage;       
         }  
                        
         /* save beep */
         slcd_CmdQueue("beep 1000");  
      }
      else
      {
         /* save beep */
         slcd_CmdQueue("beep 500");  
      }
      break;
      
   case 9:    /* Action P.E.R.A digital output */
       
       mbSlave.ActionPERA ^= 1;
       mbTable[enActionPera].WrFlg = 1;
       	
       if(mbSlave.ActionPERA == 1)
       {
         DisplayBmp(29, 580, 420);
       } 
       else if(mbSlave.ActionPERA == 0)
       {
         DisplayBmp(28, 580, 420);
       }
   
   break;
      
   case 128:       /* EXIT to run window */
      /* shut down num key window handler */
      
      /* dont leave if cal is in process */
      if(!mbSlave.MZeroCalStartStop)
      {      
         winMassSpanCalState = WIN_MASSSPANCAL_UNLOAD;  
         winMassSpanReturnWin = MAIN_WINDOW;
      }
      else
      {
         /* error beep */
         slcd_CmdQueue("beep 500");     
      }
      break;  

   case 129:       /* EXIT select cal type menu  */
      /* shut down num key window handler */
      /* dont leave if cal is in process */
      if(!mbSlave.MZeroCalStartStop)
      {      
         winMassSpanCalState = WIN_MASSSPANCAL_PREPAINT; 
      }
      else
      {
         /* error beep */
         slcd_CmdQueue("beep 500");     
      }
      break; 
      
   case 130:       /* menu principal */
      /* shut down num key window handler */
      /* dont leave if cal is in process */
      if(!mbSlave.MZeroCalStartStop)
      {      
         winMassSpanCalState = WIN_MASSSPANCAL_UNLOAD;
         winMassSpanReturnWin = USER_WINDOW;  
      }
      else
      {
         /* error beep */
         slcd_CmdQueue("beep 500");     
      }
      break; 
          
   case 132:      /* cal weight hotspot */
      /* move to key pad handler sate */

      /* dont leave if cal is in process */
      if(!mbSlave.MSpanCalStartStop)
      {
         winMassSpanCalState = WIN_MASSSPANCAL_NUMKEYPAD; 
         
         /* copy parameter data to key structure */
         strcpy(NumKeyData.Name, gstr(&str->CalWeight) );  
         NumKeyData.Type = FLOAT;
         NumKeyData.Attributes = EPROM;
         NumKeyData.KeyBoardType = NUMBER;
         NumKeyData.fMax = 10000;
         NumKeyData.fMin = 1;
         NumKeyData.Index = 0;
         
         NumKeyData.DataPtr = (void *)&EEPROM.RefWeight;
         
         /* allow recalculation */
         if(MassCalTypeFlag == MASS_TEST_WEIGHT_CAL)
         {
            MassCalComplete = MASS_TEST_WEIGHT_CAL;
         }
         else
         {
            if(MassCalTypeFlag == MASS_MATERIAL_CAL)
               MassCalComplete = MASS_MATERIAL_CAL;
            else
               MassCalComplete = MASS_BELT_CUT_CAL;
         }
      }
      else
      {
         /* error beep */
         slcd_CmdQueue("beep 500");           
      }
      break; 
                   
   case 133:       /* zero cal window */
      /* shut down num key window handler */
      winMassSpanCalState = WIN_MASSSPANCAL_UNLOAD;
      winMassSpanReturnWin = MASSCAL_WINDOW;  
      break;                                                                                       
   }
}

/*
** ------------------------------------------------------------------------------
**		Function: void ReadMassCalParameters(void)
** ------------------------------------------------------------------------------
*/

void ReadMassSpanCalParameters(void)
{
   mbTable[enMassAvg].RdFlg = 0x1;
   mbTable[enMassZero].RdFlg = 0x1;
   mbTable[enMassOffset].RdFlg = 0x1;
   
   mbTable[enMassAdj].RdFlg = 0x1;
   mbTable[enMassSpan].RdFlg = 0x1;
   mbTable[enMassMv].RdFlg = 0x1;
   
   mbTable[enBeltLength].RdFlg = 0x1;
   
   mbTable[enRate].RdFlg = 1;
   
   mbTable[enActionPera].RdFlg = 0x1;
}

/*
** ------------------------------------------------------------------------------
**		Function: void RecordNextDateCal(void)
** ------------------------------------------------------------------------------
*/
void RecordNextDateCal(void)
{
     byte Day[3];
     byte Month[3];
     byte Year[3];
     byte Buf[28];
     byte Tst[50];

     word Mes;
     int Ano;
     word Dia;    

     Day[0] = mbSlave.Date[0];
     Day[1] = mbSlave.Date[1];
     Month[0] = mbSlave.Date[3];
     Month[1] = mbSlave.Date[4];
     Year[0] = mbSlave.Date[6];
     Year[1] = mbSlave.Date[7];

     Dia = atoi(Day);        

     Mes = atoi(Month);
     Mes = Mes + 3;    

     Ano = atoi(Year);   

     if(Mes>12)
     {
          Mes = Mes - 12;
          Ano = Ano + 1;
     }

     sprintf(Day, "%02i",Dia);     
     sprintf(Month, "%02i",Mes);
     sprintf(Year, "%02i",Ano);
     
     strcat(Tst, Day);
     strcat(Tst, "/");
     strcat(Tst, Month);
     strcat(Tst, "/");
     strcat(Tst, Year);
     
     EEWR_Str((byte*)&EEPROM.NextCalDate, Tst, strlen("00/00/00"));
                                
    return;
}


/*
** ------------------------------------------------------------------------------
**		Function: void RecordLastCall(void)
** ------------------------------------------------------------------------------
*/

void RecordLastCall(void)
{
  
  byte DataTime[50];
  
  strcat(DataTime, mbSlave.Date);
  strcat(DataTime, " ");
  strcat(DataTime, mbSlave.Time);
  
  //Desloca posi��o 1 da mem�ria para a posi��o 2
  EEWR_fl(&EEPROM.Speed[2], EEPROM.Speed[1]);
  EEWR_fl(&EEPROM.ZeroCal[2], EEPROM.ZeroCal[1]);
  EEWR_fl(&EEPROM.SpanCal[2], EEPROM.SpanCal[1]);
  EEWR_Str((byte*)&EEPROM.DateCall[2], (byte*)&EEPROM.DateCall[1], strlen("00/00/00")) ;
  EEWR_Str((byte*)&EEPROM.TimeCall[2], (byte*)&EEPROM.TimeCall[1], strlen("00:00")) ;
  
  //Desloca posi��o 0 da mem�ria para a posi��o 1
  EEWR_fl(&EEPROM.Speed[1], EEPROM.Speed[0]);
  EEWR_fl(&EEPROM.ZeroCal[1], EEPROM.ZeroCal[0]);
  EEWR_fl(&EEPROM.SpanCal[1], EEPROM.SpanCal[0]);
  EEWR_Str((byte*)&EEPROM.DateCall[1], (byte*)&EEPROM.DateCall[0], strlen("00/00/00")) ;
  EEWR_Str((byte*)&EEPROM.TimeCall[1], (byte*)&EEPROM.TimeCall[0], strlen("00:00")) ;
  
  //Grava nova calibra��o na posi��o 0
  EEWR_fl(&EEPROM.Speed[0], mbSlave.Span[3]);
  EEWR_fl(&EEPROM.ZeroCal[0], mbSlave.Zero[2]);
  EEWR_fl(&EEPROM.SpanCal[0], mbSlave.Span[2]);
  EEWR_Str((byte*)&EEPROM.DateCall[0], mbSlave.Date, strlen("00/00/00"));
  EEWR_Str((byte*)&EEPROM.TimeCall[0], mbSlave.Time, strlen("00:00"));
}
/*
** ------------------------------------------------------------------------------
**		Function: void DisplayMassError(void)
** ------------------------------------------------------------------------------
*/

void DisplayMassError(void)
{   
   byte Buf[20];
   
   slcdSetFont(F16);
   slcdSetColour(DarkGrey, White);
      
   /* format Belt Length  */       
   sprintf(Buf, "%.1f%%  ", MassError);

   /* clear display */
   slcdDisplayText("              ", 510, 308, 0);      
          
   /* display avg mass */
   slcdDisplayText(&Buf, 510, 308, 0); 
   
   mbTable[enMassSpan].RdFlg = 1;  
} 

/*
** ------------------------------------------------------------------------------
**		Function: void DisplayNewSpan(void)
** ------------------------------------------------------------------------------
*/

void DisplayNewSpan(void)
{   
   byte Buf[20];
   
   slcdSetFont(F16);
   slcdSetColour(DarkGrey, White);
      
   /* format Belt Length  */       
   sprintf(Buf, "%.2f", NewMassSpan);

   /* clear display */
   slcdDisplayText("         ", 548, 263, 0);      
          
   /* display avg mass */
   slcdDisplayText(&Buf, 548, 263, 0); 
   
   mbTable[enMassSpan].RdFlg = 1;  
} 
 

/*
** ------------------------------------------------------------------------------
**		Function: void DisplayMassSpan(void)
** ------------------------------------------------------------------------------
*/

void DisplayMassSpan(void)
{   
   byte Buf[20];
   
   slcdSetFont(F16);
   slcdSetColour(DarkGrey, White);
      
   /* format Belt Length  */       
   sprintf(Buf, "%.2f", mbSlave.Span[2]);

   /* clear display */
   slcdDisplayText("         ", 548, 217, 0);      
          
   /* display avg mass */
   DisplayText(&Buf, 548, 217, 0); 
   
   mbTable[enMassSpan].RdFlg = 1;  
} 

 /*
** ------------------------------------------------------------------------------
**		Function: void DisplayScaleCapacity(void)
** ------------------------------------------------------------------------------
*/

void DisplayScaleCapacity(void)
{   
   byte Buf[20];
   
   slcdSetFont(F16);
   slcdSetColour(DarkGrey, White);
      
   /* format Belt Length  */       
   sprintf(Buf, "%.2f t/h", EEPROM.ApplicationCapacity);
          
   /* display avg mass */
   DisplayText(&Buf, 270, 70, 0); 

} 

/*
** ------------------------------------------------------------------------------
**		Function: void DisplayRefWeight(void)
** ------------------------------------------------------------------------------
*/

void DisplayRefWeight(void)
{   
   byte i, Buf[20];
   
   slcdSetFont(F16);
      
   switch (MassCalTypeFlag) 
   {
   case MASS_TEST_WEIGHT_CAL:
      slcdSetColour(DarkGrey, White);

      /* calculate test weight max appilcation percentage */
      TestWightPercentage = ((EEPROM.ApplicationCapacity/3.6)*(EEPROM.TestWightAppPercentage/100.0))/EEPROM.BeltSpeed;
      
      sprintf(Buf, "%.1f ", TestWightPercentage);
      break;

   case MASS_MATERIAL_CAL:
   case MASS_BELT_CUT_CAL:
      
      slcdSetColour(LightBlue, White);
      /* format Belt Length  */       
      sprintf(Buf, "%.1f ", EEPROM.RefWeight);
      break;
   }
         
   /* get string length  */
   i = strlen(Buf);
   
   /* has string length changed? */
   if(i!=LastRefLen)
      /* clear display */
      DisplayText("         ", 540, 108, 0);      
       
   /* display avg mass */
   DisplayText(&Buf, 540, 108, 0); 

   
   /* do we need to repaint the units? */
   if(i!=LastRefLen)
   {
      /* copy last length */
      LastRefLen = i;
      
      if(MassCalTypeFlag==MASS_TEST_WEIGHT_CAL) 
         strcpy(Buf, "");
      else
         strcpy(Buf, "kg");
      
      /* set font and clour */
      slcdSetFont(F16);
      slcdSetColour(DarkGrey, White);
      
      /* display new units */         
      DisplayText(&Buf, 540+((4*i)*2)+12, 108, 0);   
   }    
} 

/*
** ------------------------------------------------------------------------------
**		Function: void DisplayLastRefWeight(void)
** ------------------------------------------------------------------------------
*/

void DisplayLastRefWeight(void)
{   
   byte i, Buf[20];
   
   slcdSetFont(F16);
   slcdSetColour(DarkGrey, White);
      
   /* format Belt Length  */       
   sprintf(Buf, "%.1f ", EEPROM.MassCal[EEPROM.MassCalPtr].TestWeight);

   /* get string length  */
   i = strlen(Buf);
   
   /* has string length changed? */
   if(i!=LastRefWeightLen)
      /* clear display */
      DisplayText("             ", 150, 356, 0);      
   
   /* display last ref weight */
   DisplayText(&Buf, 150, 356, 0); 
   
   
   /* do we need to repaint the units? */
   if(i!=LastRefWeightLen)
   {
      /* copy last length */
      LastRefWeightLen = i;
      
      if(MassCalTypeFlag==MASS_TEST_WEIGHT_CAL) 
         strcpy(Buf, "kg/s");
      else
         strcpy(Buf, "kg");
      
      /* set font and clour */
      slcdSetFont(F16);
      slcdSetColour(DarkGrey, White);
      
      /* display new units */         
      DisplayText(&Buf, 150+((4*i)*2)+12, 358, 0);   
   }    
} 

/*
** ------------------------------------------------------------------------------
**		Function: void DisplayMassCalDate(void)
** ------------------------------------------------------------------------------
*/

void DisplayMassCalDate(void)
{   
   slcdSetFont(F16);
   slcdSetColour(DarkGrey, White);
      
   /* clear display */
   DisplayText("          ", 150, 316, 0);      
   
   /* display new Speed */
   DisplayText(&EEPROM.MassCal[EEPROM.MassCalPtr].Date, 150, 314, 0);  
}

/*
** ------------------------------------------------------------------------------
**		Function: void DisplayFlowPercent(void)
** ------------------------------------------------------------------------------
*/

void DisplayFlowPercent(void)
{   
   byte i, Buf[20];
   
   slcdSetFont(F16);
   slcdSetColour(DarkGrey, White);
    
   FlowRate = (mbSlave.MassMv-mbSlave.Zero[2])*10.0;
      
   /* format Belt Length  */       
   sprintf(Buf, "%.1f ", FlowRate);

   /* get string length  */
   i = strlen(Buf);
   
   /* has string length changed? */
   if(i!=LastFlowLen)
      /* clear display */
      DisplayText("                  ", 280, 200, 0);      
   
   /* display avg mass */
   DisplayText(&Buf, 280, 200, 0); 
   
   mbTable[enMassMv].RdFlg = 1;
   
   /* do we need to repaint the units? */
   if(i!=LastFlowLen)
   {
      /* copy last length */
      LastFlowLen = i;
      
      strcpy(Buf, "%");
      
      /* set font and clour */
      slcdSetFont(F16);
      slcdSetColour(DarkGrey, White);
      
      /* display new units */         
      DisplayText(&Buf, 280+((6*i)*2)+12, 200, 0);   
   }    
} 
/*
** ------------------------------------------------------------------------------
**		Function: void DisplayAvgMass(void)
** ------------------------------------------------------------------------------
*/

void DisplayAvgMass(void)
{   
   byte i, Buf[20];
   
   slcdSetFont(F16);
   slcdSetColour(DarkGrey, White);
      
   /* format Belt Length  */       
   if(MassCalTypeFlag == MASS_MATERIAL_CAL || MassCalTypeFlag == MASS_BELT_CUT_CAL)
      sprintf(Buf, "%.2f ", mbSlave.MassAverage*1000);
   else
      sprintf(Buf, "%.2f ", mbSlave.MassAverage);

   /* get string length  */
   i = strlen(Buf);
   
   /* has string length changed? */
   if(i!=LastAvgMassLen)
      /* clear display */
      DisplayText("                ", 280, 140, 0);      
   
   /* display avg mass */
   DisplayText(&Buf, 280, 140, 0); 
   
   mbTable[enMassAvg].RdFlg = 1;
   
   /* do we need to repaint the units? */
   if(i!=LastAvgMassLen)
   {
      /* copy last length */
      LastAvgMassLen = i;
      
      if(MassCalTypeFlag == MASS_MATERIAL_CAL || MassCalTypeFlag == MASS_BELT_CUT_CAL)
      {
         strcpy(Buf, "kg");
      }
      else
      {
         strcpy(Buf, "kg/m");
      
         /* set font and clour */
         slcdSetFont(F16);
         slcdSetColour(DarkGrey, White);
         
         /* display new units */         
         DisplayText(&Buf, 280+((6*i)*2)+12, 154, 0);   
      }
   }    
} 

/*
** ------------------------------------------------------------------------------
**		Function: void DisplayBeltDistance(void)
** ------------------------------------------------------------------------------
*/

void DisplayBeltDistance(void)
{   
   byte i, Buf[20];
   
   slcdSetFont(F16);
   slcdSetColour(DarkGrey, White);
      
   /* format Belt Length  */       
   sprintf(Buf, "%.2f ", mbSlave.BeltTravel);

   /* get string length  */
   i = strlen(Buf);
   
   /* has string length changed? */
   if(i!=LastBeltDisLen)
      /* clear display */
      DisplayText("                  ", 280, 260, 0);      
   
   /* display avg mass */
   DisplayText(&Buf, 280, 260, 0); 
   
   mbTable[enBeltTravel].RdFlg = 1; 
   
   /* do we need to repaint the units? */
   if(i!=LastBeltDisLen)
   {
      /* copy last length */
      LastBeltDisLen = i;
      
      strcpy(Buf, "m");
      
      /* set font and clour */
      slcdSetFont(F16);
      slcdSetColour(DarkGrey, White);
      
      /* display new units */         
      DisplayText(&Buf, 280+((6*i)*2)+12, 260, 0);   
   }    
}

/*
** ------------------------------------------------------------------------------
**		Function: void DisplayCalTotal(void)
** ------------------------------------------------------------------------------
*/

void DisplayCalTotal(void)
{   
   byte i, Buf[20];
   
   slcdSetFont(F16);
   slcdSetColour(DarkGrey, White);
      
   /* format Belt Length  */       
   sprintf(Buf, "%.2f ", mbSlave.BeltTravel);

   /* get string length  */
   i = strlen(Buf);
   
   /* has string length changed? */
   if(i!=LastBeltDisLen)
      /* clear display */
      DisplayText("                ", 280, 222, 0);      
   
   /* display avg mass */
   DisplayText(&Buf, 280, 222, 0); 
   
   mbTable[enBeltTravel].RdFlg = 1; 
   
   /* do we need to repaint the units? */
   if(i!=LastBeltDisLen)
   {
      /* copy last length */
      LastBeltDisLen = i;
      
      strcpy(Buf, "m");
      
      /* set font and clour */
      slcdSetFont(F16);
      slcdSetColour(DarkGrey, White);
      
      /* display new units */         
      //slcdDisplayText(&Buf, 280+((6*i)*2)+12, 222, 0);   
   }    
}

/*
** ------------------------------------------------------------------------------
**		Function: void UpdateMassSpanCal(void)
** ------------------------------------------------------------------------------
*/

void UpdateMassSpanCal(void)
{      
   /* requested update */
   if (winUpdate1==1)
   {
      /* stop counter */
      winUpdate1 = 0;
   }

   /* time to update? */
   if (!winTimer1)
   {
      winTimer1 = 100;
      
      /* check for cal timeout */
      if(mbSlave.MSpanCalStartStop && !mbSlave.MCalFlag)
      {
         /* cal has timed out */   
         if(mbSlave.MSpanCalStartStop==MASS_TEST_WEIGHT_CAL)  
         {
            MassCalComplete = 0;
            
            mbSlave.MSpanCalStartStop = 0;
            
            /* claculate new span */
            NewMassSpan = mbSlave.Span[2]/(mbSlave.MassAverage/EEPROM.RefWeight);
            
            DisplayNewSpan();
            
            /* claculate error */
            MassError = (mbSlave.MassAverage-EEPROM.RefWeight)/(mbSlave.MassAverage/100);
            
            DisplayMassError(); 

            /* reset button state */
            slcdSetButtonSate(4, 0);
            
            /* save beep */
            slcd_CmdQueue("beep 1000");  
                        
            MassCalCalcFlag = 1;  
         }
         else
         {
            if(mbSlave.MSpanCalStartStop==MASS_MATERIAL_CAL || mbSlave.MSpanCalStartStop==MASS_BELT_CUT_CAL)  
            {
               MassCalComplete = MASS_MATERIAL_CAL;
               
               mbSlave.MSpanCalStartStop = 0;

               /* reset button state */
               slcdSetButtonSate(4, 0);
               
               /* prompt user for actual total */
               
               /* move to key pad handler sate */
               winMassSpanCalState = WIN_MASSSPANCAL_NUMKEYPAD; 
               
               /* copy parameter data to key structure */
               strcpy(NumKeyData.Name, gstr(&str->CalWeight) );  
               NumKeyData.Type = FLOAT;
               NumKeyData.KeyBoardType = NUMBER;
               NumKeyData.Attributes = EPROM;
               NumKeyData.fMax = 10000.0;
               NumKeyData.fMin = 1.0;      
               
               NumKeyData.DataPtr = (void *)&EEPROM.RefWeight;                          
            
               /* save beep */
               slcd_CmdQueue("beep 1000");  
               
               MassCalCalcFlag = 1;   
            }
         }
      }
      mbTable[enMCalFlag].RdFlg = 1;
      
      /* is belt tension enabled? */
      if(mbSlave.AnInFunc[0]==1)
         mbTable[enTensionAvg].RdFlg = 0x1;       
   }
   
   /* time to update? */
   if (!winTimer2)
   {
      winTimer2 = 20;

      if (MassCalTypeFlag == MASS_TEST_WEIGHT_CAL)
      {
          if(!CalTimer && mbSlave.MSpanCalStartStop > 1 )
          {
              slcdSetFont(F16B);
              slcdSetColour(Red, White);
              DisplayText("Coleta de dados concluida", 20, 80, 'T');
          }
      }
      
      /* display flow % */
      DisplayFlowPercent();
         
      /* is cal running */
      //if(mbSlave.MSpanCalStartStop)
      {
         /* update rate for test wight cal */
         DisplayAvgMass();  
      }
      
      /* display belt distance */
      if(mbSlave.MSpanCalStartStop)
      {
         DisplayBeltDistance();
      }
   }
}

/*
** ------------------------------------------------------------------------------
**		Function: void winPaintMassSpanCal(void)
** ------------------------------------------------------------------------------
*/

void winPaintMassSpanCal(void)
{  
   ButtonType Button;   
   byte ButtonText1[20], ButtonText2[20];
   
   slcdSetFont(F24B); 
   slcdSetColour(DarkGrey, White);
   
   switch (MassCalTypeFlag) 
   {
   case MASS_TEST_WEIGHT_CAL:
      /* display page title  */
      DisplayText(gstr(&str->TestWeightCal), 16,  7, 'T');      
      
      slcdSetFont(F16B);
      slcdSetColour(LightBlue, White);
      DisplayText(gstr(&str->AverageKgm), 16,  140, 'T'); 
      
      if((mbSlave.OutputFunction[0]==10)||(mbSlave.OutputFunction[1]==10)||(mbSlave.OutputFunction[2]==10)||(mbSlave.OutputFunction[3]==10))
      {
        slcdSetColour(White, White);
        //slcdMakeButtonCT(9, "P.E.R.A",1,460, 420, 5, 4);
        MakeButtonCT(9, "P.E.R.A",1,460, 420, 5, 4);
        if(mbSlave.ActionPERA==0) DisplayBmp(28, 580, 420);
        if(mbSlave.ActionPERA==1) DisplayBmp(29, 580, 420);
      }
      
   break;

   case MASS_MATERIAL_CAL:
      /* display page title  */
      DisplayText(gstr(&str->MaterialCal), 16,  7, 'T');      
      
      slcdSetFont(F16B);
      slcdSetColour(LightBlue, White);
      DisplayText(gstr(&str->CalTotal), 16,  140, 'T');       
      break;

   case MASS_BELT_CUT_CAL:
      /* display page title  */
      DisplayText(gstr(&str->BeltCutCal), 16,  7, 'T');      

      slcdSetFont(F16B);
      slcdSetColour(LightBlue, White);
      DisplayText(gstr(&str->CalTotal), 16,  140, 'T');       
      break;
   }
   
   DisplayText(gstr(&str->FlowRatePcnt), 16,  200, 'T');       
   DisplayText("Correia percorrida:", 16,  260, 'T');             
  
   /* make back hotspot */
   MakeHotSpot(129, 50, 440, 110, 480);
   
   /* make next hotspot */
   MakeHotSpot(130, 220, 440, 280, 480); 

   /* make Cal weighthotspot */
   MakeHotSpot(132, 544, 100, 620, 132);

   /* make back hotspot */
   MakeHotSpot(129, 50, 440, 110, 480);   
   
   slcdSetFont(F16);   
   slcdSetColour(White, White);
   
   /* zero cal start button */
   Button.Id = 4;
   Button.x = 272;
   Button.y = 320;
   Button.type = 2;
   
   if(mbSlave.MSpanCalStartStop)
      Button.state = 1;
   else
      Button.state = 0;
   
   strcpy(ButtonText1, gstr(&str->START));      
   strcpy(ButtonText2, gstr(&str->STOP));      
   strcpy(ButtonText1, "Iniciar");      
   strcpy(ButtonText2, "Parar");      

   Button.text0 = ButtonText1;
   Button.text1 = ButtonText2;
   Button.dx0 = 20;
   Button.dy0 = 6;
   Button.dx1 = 24;
   Button.dy1 = 6;
   Button.bmp0 = 5;
   Button.bmp1 = 4;  
       
   /* define start/stop button */
   MakeLatchingButton(&Button);  

   /* make cacular button */
   MakeButtonTextXY(7, 460, 154, "Calcular", 6, 6, 5, 4);
   
   /* make save button */
   MakeButtonTextXY(8, 460, 344, "Aceitar", 12, 6, 5, 4);
   
   
   /* display scale capacity */
   DisplayScaleCapacity();
   
   /* display last cal weight */
   DisplayLastRefWeight();

   /* display last cal date */
   DisplayMassCalDate();
   
   /* display current reference weight */
   DisplayRefWeight();
   
   /* display average mass */
   DisplayAvgMass();
   
   /* display flow % */
   DisplayFlowPercent();
   
   /* display mass span */
   DisplayMassSpan();

   /* display new span */
   DisplayNewSpan();

   /* display span err */
   DisplayMassError();
   
   /* display belt distance */
   DisplayBeltDistance();
   
}

/*
** ------------------------------------------------------------------------------
**		Function: byte winMassSpanCalHandler(void)
** ------------------------------------------------------------------------------
*/

byte winMassSpanCalHandler(void)
{
   switch (winMassSpanCalState)
   {
   case WIN_MASSSPANCAL_PREPAINT:
      /* get analog parameters from slave */
      ReadMassSpanCalParameters();
      winMassSpanCalState = WIN_MASSSPANCAL_MENU;
      
      /* zero these */
      MassCalCalcFlag = 0;
      MassCalTypeFlag = 0;

      FlowRate = 0.0;
      
      mbSlave.MSpanCalStartStop = 0;

      /* display span method menu  */      
      slcd_CmdQueue("xc all");
      DisplayBmp(10, 0, 0);
      
      //slcd_SetFont(24,0);
      
      //DisplayTitle("Span Dinamico");
      
      //slcd_SetFont(16,0);
      
      //slcd_SendText("Peso Teste", 115, 120, 0 ,LEFT_ALIGN);
      //slcd_SendText("Peso Conhecido", 115, 300,0, LEFT_ALIGN);
      
    
      //slcd_SendText("Escolha o metodo para calibrar span", 15,60,0, LEFT_ALIGN);      
      
      
      /* make back hotspot */
      MakeHotSpot(128, 560, 10, 630, 60);
      MakeHotSpot(133, 50, 440, 110, 480);
         
      /* make selection buttons */
      slcd_MakeButton(1, 1, 30, 120, 2, 3);
      slcd_MakeButton(2, 1, 30, 300, 2, 3); 
         
      break;
   
   case WIN_MASSSPANCAL_MENU:
      /* wait for user to pick span method */
      
      /* is there a key to process? */
      if (slcdKey)
      {
         /* call key handler */
         winMassSpanCalKeyHandler(slcdKey);      
         /* now the key has been processed clear it */
         slcdKey = 0; 
      }      
      break;
      
   case WIN_MASSSPANCAL_PAINT:
      /* send command to execute macro 2 */
      slcdCallMacro(2);
      /* display zero mas cal page */      
      //slcd_CmdQueue("xi 17 0 0");
      DisplayBmp(10, 0, 0);
      
      /* zero these */
      LastAvgMassLen = 0;
      LastRefWeightLen = 0;
      LastRefLen = 0;
      LastBeltDisLen = 0;
      LastFlowLen = 0;
      
      mbSlave.BeltTravel = 0;
      
      winPaintMassSpanCal();
      
      /* update parameters */
      winUpdate1 = 1;
      
      /* move to update state */      
      winMassSpanCalState = WIN_MASSSPANCAL_UPDATE;       
      return 0;

   case WIN_MASSSPANCAL_UPDATE:
      /* is there a key to process? */
      if (slcdKey)
      {
         /* call key handler */
         winMassSpanCalKeyHandler(slcdKey);      
         /* now the key has been processed clear it */
         slcdKey = 0; 
      }

      UpdateMassSpanCal();
      
      /* has any data been remotely changed? */
      if(mbSlave.DataUpdate)
      {
         /* clear data update flag */
         mbSlave.DataUpdate = 0;
         mbTable[enDataUp].WrFlg = 1;   
         
         /* read analog parameters */
         ReadMassSpanCalParameters();  
         
         /* set update timer */                   
         winUpdate1 = 100;
      }      
      return 0;

   case WIN_MASSSPANCAL_MSGBOX:
      /* see if confirmation win is returning */
      switch(winConfirmHandler()) 
      {
      case 2:
         /* move to paint state */      
         winMassSpanCalState = WIN_MASSSPANCAL_PAINT;      
         break;
      }
      break; 
      
  case WIN_MASSSPANCAL_NUMKEYPAD:
      /* see if key pad is returning */
      if(winKeyPadHandler())
         /* move to update state */      
         winMassSpanCalState = WIN_MASSSPANCAL_PAINT;   
      break;

   case WIN_MASSSPANCAL_UNLOAD:
      /* do any necessary clearing up */
      winMassSpanCalState = WIN_MASSSPANCAL_PREPAINT;  
      
      /* switch to next screen */
      winActiveWin = winMassSpanReturnWin;  


      /* return from key pad */
      return 1;
   }   
}



