/*
** ------------------------------------------------------------------------------
   
   File   : winTotalizer.h 
   Aurthor: Stuart Clarke

** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

#ifndef WINTOTALIZER_H
#define WINTOTALIZER_H


/* public defines */


/*
** ------------------------------------------------------------------------------
**		#define : diagnostics handler states 
** ------------------------------------------------------------------------------
*/

#define WIN_TOTALIZER_PREPAINT     0
#define WIN_TOTALIZER_PAINT        1
#define WIN_TOTALIZER_PAINT_PAGE   2
#define WIN_TOTALIZER_UPDATE       3
#define WIN_TOTALIZER_NUMKEYPAD    4
#define WIN_TOTALIZER_UNLOAD       5




#ifndef WIN_TOTALIZER_C

/* public variables */
#pragma DATA_SEG WINTOTALIZER_Data


#endif   /* WINTOTALIZER_C */      


/* public functions */
#pragma CODE_SEG WINTOTALIZER_Code

/*
** ------------------------------------------------------------------------------
**		Function: void ReadTotalizerParameters(void)
** ------------------------------------------------------------------------------
*/

void ReadTotalizerParameters(void);

/*
** ------------------------------------------------------------------------------
**		Function: byte winTotalizerHandler(void)
** ------------------------------------------------------------------------------
*/

byte winTotalizerHandler(void);

#endif   /* WINRANGES_H */
