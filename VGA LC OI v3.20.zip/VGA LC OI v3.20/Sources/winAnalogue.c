#include <hidef.h>                           /* common defines and macros */
#include "derivative.h"                      /* derivative information */

/*
** ------------------------------------------------------------------------------
   
   File   : winCalRoutine.c 
   Aurthor: 
   
   Description:  
   
   Version Log          Notes                                     Changes Made by                                        
   --------------       -----                                     ---------------
   08-07-09:            Created                                   Stuart


** ------------------------------------------------------------------------------
                                    
                                    Overview
                                            
** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

/* library headers */
#include "stdio.h"
#include "float.h"
#include "math.h"

/* Application headers */
#include "CRG 100110.h" 
#include "Subs.h"
#include "ModBusM Int.h"
#include "ModBusM.h"
#include "EEPROM.h"
#include "SLCD 100721.h"
#include "winMain.h"
#include "winKey.h"
#include "Language.h"


/* Implements this interface: */
#define WINANALOG_C
#include "winAnalogue.h"

#pragma CODE_SEG WINANALOG_Code
#pragma DATA_SEG WINANALOG_Data


/* private */
static byte winAnalogState;
static byte AnalogIndex;
static byte AnalogFixFlg;


/* public */



/*
** ------------------------------------------------------------------------------
**		Function: void winAnalogKeyHandler(byte key)
** ------------------------------------------------------------------------------
*/

void winAnalogKeyHandler(byte key)
{   
   byte Buf[25];
   switch (key)
   {
   case 1:
     
      /* increment analogue select register */      
      if(++AnalogIndex>1)
         AnalogIndex = 0;
      
      /* set font */
      #ifdef FIVEPOINTSEVEN
      slcdSetFont(F24B);  
      #else
      slcdSetFont(F32B);  
      #endif 
      
      /* set colours back */
      slcdSetColour(DarkGrey, White);  
      
      /* display selected analog channel */
      sprintf(Buf, "%s %u ", gstr(&str->Analog), AnalogIndex+1);
      slcdDisplayText(Buf, getX(80), getY(50), 0); 

      //slcd_CmdQueue("xic 2 0 0 405 230 460 255");  
      
      /* update analogue parameters */
      ReadAnalogParameters();
      /* update parameters */
      winUpdate1 = 100;
      break;

   case 2:     /* fix Analog at 2 mA */      
      /* set fix flag */
      AnalogFixFlg = 1;
      
      /* set write flag for select channel */
      if(!AnalogIndex)
      {
         mbTable[enAnOut1].WrFlg = 0x1;
         /* force mb table index An Wr flag */
         mbTableIndex = enAnOut1;         
      }
      else if (AnalogIndex==1)
      {
         mbTable[enAnOut2].WrFlg = 0x1;
         /* force mb table index An Wr flag */
         mbTableIndex = enAnOut2;         
      }

      /* set output value */
      mbSlave.AnOutput[AnalogIndex] = 2.0;
      break;      

   case 3:     /* fix Analog at 18 mA */      
      /* set fix flag */
      AnalogFixFlg = 2;

      /* set write flag for select channel */
      if(!AnalogIndex)
      {
         mbTable[enAnOut1].WrFlg = 0x1;
         /* force mb table index An Wr flag */
         mbTableIndex = enAnOut1;         
      }
      else if (AnalogIndex==1)
      {
         mbTable[enAnOut2].WrFlg = 0x1;
         /* force mb table index An Wr flag */
         mbTableIndex = enAnOut2;         
      }

      
      /* set output value */
      mbSlave.AnOutput[AnalogIndex] = 18.0;
      break;      
      
   case 128:       /* EXIT */
      /* shut down num key window handler */
      winAnalogState = WIN_ANALOG_UNLOAD;  
      break;  
      
   case 130:      /* AnHi hotspot */
      /* move to key pad handler sate */
      winAnalogState = WIN_ANALOG_NUMKEYPAD; 
      
      /* copy parameter data to key structure */
      strcpy(NumKeyData.Name, gstr(&str->Analog_Hi) );  
      NumKeyData.KeyBoardType = NUMBER;
      NumKeyData.Type = FLOAT;
      NumKeyData.fMax = 999.0;
      NumKeyData.fMin = -100.0;
      NumKeyData.Index = 0;
     
      if(!AnalogIndex)
         NumKeyData.Flag  = enAnHi1;
      else if(AnalogIndex==1) 
         NumKeyData.Flag  = enAnHi2;
      
      NumKeyData.DataPtr = (void *)&mbSlave.AnHi[AnalogIndex];
      break;      

   case 131:      /* AnLo hotspot */
      /* move to key pad handler sate */
      winAnalogState = WIN_ANALOG_NUMKEYPAD; 
      
      /* copy parameter data to key structure */
      strcpy(NumKeyData.Name, gstr(&str->Analog_Lo) );  
      NumKeyData.Type = FLOAT;
      NumKeyData.KeyBoardType = NUMBER;
      NumKeyData.fMax = 999.0;
      NumKeyData.fMin = -100.0;
      NumKeyData.Index = 0;
      if(!AnalogIndex)
         NumKeyData.Flag  = enAnLo1;
      else if(AnalogIndex==1) 
         NumKeyData.Flag  = enAnLo2;
      
      NumKeyData.DataPtr = (void *)&mbSlave.AnLo[AnalogIndex];
      break; 


   case 132:
      if(mbSlave.AnMode & (0x01<<AnalogIndex))
         mbSlave.AnMode &=~ (0x01<<AnalogIndex);
      else
         mbSlave.AnMode |= (0x01<<AnalogIndex);

      /* set write flag */
      mbTable[enAnMode].WrFlg = 1;
      /* call for an update */
      winUpdate1 = 1;
      break;
      
   
   case 133:      /* An Allocation */
      /* fist channel has fixed allocation */
      //if(AnalogIndex)
      {
         /* move to key pad handler sate */
         winAnalogState = WIN_ANALOG_NUMKEYPAD; 
         
         /* copy parameter data to key structure */
         strcpy(NumKeyData.Name, gstr(&str->Analog_Allocation) );  
         NumKeyData.KeyBoardType = NUMBER;
         NumKeyData.Type = BYTE;
         NumKeyData.iMax = 2;
         NumKeyData.iMin = 1;
         NumKeyData.Index = 0;
         
         if(!AnalogIndex)
            NumKeyData.Flag  = enAnAlloc1;
         else if(AnalogIndex==1)
            NumKeyData.Flag  = enAnAlloc2;
         
         NumKeyData.DataPtr = (void *)&mbSlave.AnAlloc[AnalogIndex];
      }
      break;             

   case 134:      /* An Adjust */
      /* only adjust if analogue chaneel is fixed */
      if(AnalogFixFlg)
      {
         /* move to key pad handler sate */
         winAnalogState = WIN_ANALOG_NUMKEYPAD; 
         
         /* copy parameter data to key structure */
         strcpy(NumKeyData.Name, gstr(&str->Analog_Adjust) );  
         NumKeyData.KeyBoardType = NUMBER;
         NumKeyData.Type = FLOAT;
         
         if(AnalogFixFlg==1)
         {
            NumKeyData.fMax = 3.0;
            NumKeyData.fMin = 1.0;
         }
         else
         {
            NumKeyData.fMax = 21.0;
            NumKeyData.fMin = 17.0;
         }
         NumKeyData.Index = 0;
         
         if(!AnalogIndex)
            NumKeyData.Flag  = enAnAdjust1;
         else if(AnalogIndex==1) 
            NumKeyData.Flag  = enAnAdjust2;

         
         NumKeyData.DataPtr = (void *)&mbSlave.AnAdjust[AnalogIndex];
      }
      break;       
   }
}

/*
** ------------------------------------------------------------------------------
**		Function: void ReadAnalogParameters(void)
** ------------------------------------------------------------------------------
*/

void ReadAnalogParameters(void)
{
   mbTable[enAnMode].RdFlg = 0x1;
   
   switch(AnalogIndex)
   {
   case 0:
      mbTable[enAnHi1].RdFlg = 0x1;
      mbTable[enAnLo1].RdFlg = 0x1;
      mbTable[enAnAlloc1].RdFlg = 0x1;
      break;

   case 1:
      mbTable[enAnHi2].RdFlg = 0x1;
      mbTable[enAnLo2].RdFlg = 0x1;
      mbTable[enAnAlloc2].RdFlg = 0x1;
      break;
   }
}

/*
** ------------------------------------------------------------------------------
**		Function: void PaintAnalog(void)
** ------------------------------------------------------------------------------
*/

void PaintAnalog(void)
{
   byte Buf[25];
   
   /* send command to execute macro  */
   //slcdCallMacro(19);
      
   slcdSetFont(F24B);  
   
   /* set colours back */
   slcdSetColour(DarkGrey, White);         
   
   /* display selected analog channel */
   sprintf(Buf, "%s %u", gstr(&str->Analog), AnalogIndex+1);
   slcdDisplayText(Buf, getX(80), getY(50), 0);  
   /* make analog select button */      
   slcdMakeButton(1, getX(20), getY(50), "", 22, 21);

   /* make fix mA buttons  */
   slcdMakeButton(2, getX(405), getY(ccY2), "", 23, 21);
   slcdMakeButton(3, getX(405), getY(ccY3), "", 23, 21);

   slcdSetFont(F16B);  
   
   /* set colours back */
   slcdSetColour(DarkGrey, White);         

   /* display headings */
   slcdDisplayText(gstr(&str->Analog_Hi),   getX(20),   getY(ccY1), 'T');  
   slcdDisplayText(gstr(&str->Analog_Lo),   getX(20),   getY(ccY2), 'T');  
   slcdDisplayText(gstr(&str->Output_mA),   getX(20),   getY(ccY3), 'T');     
   //slcdDisplayText(gstr(&str->Output_Mode), getX(20),   getY(ccY4), 'T');     
   
   slcdDisplayText("Canal", getX(245),  getY(ccY1), 'T');  
   slcdDisplayText(gstr(&str->Fix_2mA),     getX(245),  getY(ccY2), 'T');         
   slcdDisplayText(gstr(&str->Fix_18mA),    getX(245),  getY(ccY3), 'T');         
   slcdDisplayText(gstr(&str->Adjust),      getX(245),  getY(ccY4), 'T');         

   slcd_CmdQueue("xs 130 114 97 153 110");
   slcd_CmdQueue("xs 131 114 132 153 154");
   slcd_CmdQueue("xs 132 114 203 153 225");
   
   slcd_CmdQueue("xs 133 270 97 303 110");
   slcd_CmdQueue("xs 134 270 203 303 225");
      
   /* set font */
   slcdSetFont(F16B);  

   /* force update */
   winUpdate1 = 1;
}

/*
** ------------------------------------------------------------------------------
**		Function: void UpdateAnalog(void)
** ------------------------------------------------------------------------------
*/

void UpdateAnalog(void)
{
   byte Buf[25];
   
   /* requested update */
   if (winUpdate1==1)
   {
      /* stop counter */
      winUpdate1 = 0;
      
      slcdSetFont(F16B);  
      
      /* set colours back */
      slcdSetColour(LightBlue, White);         
         
      sprintf(Buf, "%.1f  ", mbSlave.AnHi[AnalogIndex]);  
      Buf[7] = 0;
      slcdDisplayText(Buf, getX(170), getY(ccY1), 0);  
      
      sprintf(Buf, "%.1f  ", mbSlave.AnLo[AnalogIndex]);  
      Buf[7] = 0;
      slcdDisplayText(Buf, getX(170), getY(ccY2), 0);  

      /* first channel has fixed allocation */
      if(AnalogIndex)
         slcdSetColour(LightBlue, White);         

      sprintf(Buf, "%u", mbSlave.AnAlloc[AnalogIndex]);  
      Buf[7] = 0;
      slcdDisplayText(Buf, getX(405), getY(ccY1), 0);  

      slcdSetColour(LightBlue, White);         
      
      
      //slcd_CmdQueue("xic 2 0 0 405 230 450 255"); 
      sprintf(Buf, "%.2f ", mbSlave.AnAdjust[AnalogIndex]);  
      Buf[7] = 0;
      slcdDisplayText(Buf, getX(405),getY(ccY4), 'T');  

      //if(mbSlave.AnMode&(0x01<<AnalogIndex))
         //slcdDisplayText(" mA  ", getX(170), getY(ccY4), 0);  
      //else
         //slcdDisplayText("Volts", getX(170), getY(ccY4), 0);   
   }

   /* time to update? */
   if (!winTimer1)
   {
      winTimer1 = 25;

      slcdSetFont(F24B);  
      
      /* set colours back */
      slcdSetColour(DarkGrey, White);         
      sprintf(Buf, "%.1f  ", mbSlave.AnOutput[AnalogIndex]);  
      Buf[7] = 0;
      slcdDisplayText(Buf, getX(170), getY(ccY3), 0);  

      switch(AnalogIndex)
      {
      case 0:
         mbTable[enAnOut1].RdFlg = 0x1;
         break;

      case 1:
         mbTable[enAnOut2].RdFlg = 0x1;
         break;
      }
   }
}

/*
** ------------------------------------------------------------------------------
**		Function: byte winAnalogHandler(void)
** ------------------------------------------------------------------------------
*/

byte winAnalogHandler(void)
{
   switch (winAnalogState)
   {
   case WIN_ANALOG_PREPAINT:
      /* get analog parameters from slave */
      ReadAnalogParameters();
      
      /* zero adjust registers */
      mbSlave.AnAdjust[0] = 0; 
      mbSlave.AnAdjust[1] = 0; 
      
      winAnalogState = WIN_ANALOG_PAINT;
      break;
      
   case WIN_ANALOG_PAINT:
      /* send command to execute macro 2 */
      slcdCallMacro(2);
      /* set forground and back ground colour */
      slcdSetColour(DarkGrey, DarkGrey);
      /* set font */
      slcdSetFont(F16B);         
      
      /* display page title  */
      slcdDisplayText(gstr(&str->Analogs), getX(12),  getY(4), 'T');
      
      /* paint key pad */
      PaintAnalog();

      /* update parameters */
      winUpdate1 = 1;
      
      /* move to update state */      
      winAnalogState = WIN_ANALOG_UPDATE;       
      return 0;

   case WIN_ANALOG_UPDATE:
      /* is there a key to process? */
      if (slcdKey)
      {
         /* call key handler */
         winAnalogKeyHandler(slcdKey);      
         /* now the key has been processed clear it */
         slcdKey = 0; 
      }

      UpdateAnalog();

      /* has any data been remotely changed? */
      if(mbSlave.DataUpdate)
      {
         /* clear data update flag */
         mbSlave.DataUpdate = 0;
         mbTable[enDataUp].WrFlg = 1;   
         
         /* read analog parameters */
         ReadAnalogParameters();  
         
         /* set update timer */                   
         winUpdate1 = 100;
      }      
      return 0;

  case WIN_ANALOG_NUMKEYPAD:
      /* see if key pad is returning */
      if(winKeyPadHandler())
         /* move to update state */      
         winAnalogState = WIN_ANALOG_PAINT;   
      break;

   case WIN_ANALOG_UNLOAD:
      /* do any necessary clearing up */
      winAnalogState = WIN_ANALOG_PREPAINT;  

      /* switch to menu screen */
      winActiveWin = BASIC_CONFIG_WINDOW;  

      AnalogIndex = 0;
      
      /* check to see if any analogues are fixed */
      if(AnalogFixFlg)
      {
         /* make sure all analogues are unfixed */         
         AnalogFixFlg = 0;
         /* set non valid adjust value to unfix */
         mbSlave.AnAdjust[0] = 21.0;      
         mbTable[enAnAdjust1].WrFlg = 0x1;
         mbSlave.AnAdjust[1] = 21.0;      
         mbTable[enAnAdjust2].WrFlg = 0x1;
         /* force mb table index An Wr flag */
         mbTableIndex = enAnOut1;         
      }

      /* return from key pad */
      return 1;
   }   
}



