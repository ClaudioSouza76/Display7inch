/*
** ------------------------------------------------------------------------------
   
   File   : winTimeDate.h 
   Aurthor: Stuart Clarke

** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

#ifndef WINTIMEDATE_H
#define WINTIMEDATE_H


/* public defines */


/*
** ------------------------------------------------------------------------------
**		#define : diagnostics handler states 
** ------------------------------------------------------------------------------
*/

#define WIN_TIMEDATE_PREPAINT     0
#define WIN_TIMEDATE_PAINT        1
#define WIN_TIMEDATE_PAINT_PAGE   2
#define WIN_TIMEDATE_UPDATE       3
#define WIN_TIMEDATE_NUMKEYPAD    4
#define WIN_TIMEDATE_UNLOAD       5




#ifndef WIN_TIMEDATE_C

/* public variables */
#pragma DATA_SEG WINTIMEDATE_Data


#endif   /* WINTIMEDATE_C */      


/* public functions */
#pragma CODE_SEG WINTIMEDATE_Code

/*
** ------------------------------------------------------------------------------
**		Function: void ReadTimeDateParameters(void)
** ------------------------------------------------------------------------------
*/

void ReadTimeDateParameters(void);

/*
** ------------------------------------------------------------------------------
**		Function: byte winTimeDateHandler(void)
** ------------------------------------------------------------------------------
*/

byte winTimeDateHandler(void);

#endif   /* WINTIMEDATE_H */
