#include <hidef.h>                           /* common defines and macros */
#include <mc9s12xdt512.h>                    /* derivative information */

/*
** ------------------------------------------------------------------------------
   
   File   : winConfirm.c 
   Aurthor: 
   
   Description:  
   
   Version Log          Notes                                     Changes Made by                                        
   --------------       -----                                     ---------------
   01-05-09:            Created                                   Stuart


** ------------------------------------------------------------------------------
                                    
                                    Overview
                                            
** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

/* library headers */
#include "stdio.h"

/* Application headers */
#include "Subs.h"
#include "SlcdSubs.h"
#include "EEPROM.h"
#include "SLCD 260217.h"
#include "winMain.h"
#include "language.h"
#include "CRG 100110.h"


/* Implements this interface: */
#define WINCONFIRM_C
#include "winConfirm.h"

#pragma CODE_SEG WINCONFIRM_Code
#pragma DATA_SEG WINCONFIRM_Data


/* private */
static byte winConfirmState;
static byte winConfirReturnValue;



/* public */

MsgBoxType MsgBoxData;


/*
** ------------------------------------------------------------------------------
**		Function: void winConfirmKeyHandler(byte key)
** ------------------------------------------------------------------------------
*/

void winConfirmKeyHandler(byte key)
{
   
   switch (key)
   {
   case 1:
      /* return from key pad */
      winConfirmState = WIN_CONFIRM_UNLOAD;  
      
      /* is the funtion pointer loaded ? */
      if(MsgBoxData.fp)
      {
         /* call */
         (MsgBoxData.fp)();
         /* clear function ptr */ 
         MsgBoxData.fp = 0;  
      }
      /* yes please */         
      winConfirReturnValue = 1;      
      break;
      
 
   case 2:
   case 128:       /* EXIT */
      /* shut down num key window handler */
      winConfirmState = WIN_CONFIRM_UNLOAD;  
      /* no thanks */      
      winConfirReturnValue = 2;
      break;      
   }
}

/*
** ------------------------------------------------------------------------------
**		Function: void PaintConfirmBox(void)
** ------------------------------------------------------------------------------
*/

void PaintConfirmBox(void)
{
   /* send command to execute macro 21 */
   slcdCallMacro(21);
         
   /* set forground and back ground colour */
   slcdSetColour(DarkGrey, White);
   
   /* set font */
   //#ifdef FIVEPOINTSEVEN 
   slcdSetFont(F16B);         
   //#else
   //slcdSetFont(F24B);         
   //#endif
   
   /* display page title  */
   DisplayText(MsgBoxData.TitleBarTxt, 120, 135, 'T');
   
   /* display page title  */
   DisplayText(MsgBoxData.MsgTxt, 133, 177, 'T');
   
   #ifdef FIVEPOINTSEVEN 
   //slcd_CmdQueue("bd 1 78 155 1 \"YES\" 14 4 5 4");     
   //slcd_CmdQueue("bd 2 168 155 1 \"NO\" 17 4 5 4");  
   #else
   //slcd_CmdQueue("bd 1 118 175 1 \"YES\" 28 8 5 4");  
   //slcd_CmdQueue("bd 2 253 175 1 \"NO\" 35 8 5 4");  
   #endif

   if(!MsgBoxData.Attribute)
   {
      MakeButtonTextXY(1, 157, 310, gstr(&str->Yes), 30, 8, 5, 4);   
      MakeButtonTextXY(2, 337, 310, gstr(&str->No), 30, 8, 5, 4);   
   }
   else
   {
      MakeButtonTextXY(2, 280, 310, gstr(&str->OK), 30, 8, 5, 4);   
   }
         
   //slcdMakeButton(4, 285, 85, "", 9, 8);
            
   /* update parameters */
   winUpdate1 = 5;  
   
}

/*
** ------------------------------------------------------------------------------
**		Function: void UpdateConfirmBox(void)
** ------------------------------------------------------------------------------
*/

void UpdateConfirmBox(void)
{
   /* time to update? */
   if (winUpdate1==1)
   {
      winUpdate1 = 0;
      
   }
}

/*
** ------------------------------------------------------------------------------
**		Function: byte winConfirmHandler(void)
** ------------------------------------------------------------------------------
*/

byte winConfirmHandler(void)
{
   switch (winConfirmState)
   {
   case WIN_CONFIRM_PAINT:
      /* paint key pad */
      PaintConfirmBox();
      /* clear return flag */
      winConfirReturnValue = 0;
      /* move to update state */      
      winConfirmState = WIN_CONFIRM_UPDATE;       
      return 0;

   case WIN_CONFIRM_UPDATE:
      /* is there a key to process? */
      if (slcdKey)
      {
         /* call key handler */
         winConfirmKeyHandler(slcdKey);      
         /* now the key has been processed clear it */
         slcdKey = 0; 
      }
   
      UpdateConfirmBox();
      return 0;

   case WIN_CONFIRM_UNLOAD:
      /* do any necessary clearing up */
      MsgBoxData.Attribute = 0;

      winConfirmState = WIN_CONFIRM_PAINT;  
      /* return from key pad */
      return winConfirReturnValue;
   }   
}



