#include <hidef.h>                           /* common defines and macros */
#include "derivative.h"                      /* derivative information */

/*
** ------------------------------------------------------------------------------
   
   File   : winSpeedCal.c 
   Aurthor: 
   
   Description:  
   
   Version Log          Notes                                     Changes Made by                                        
   --------------       -----                                     ---------------
   08-07-09:            Created                                   Stuart


** ------------------------------------------------------------------------------
                                    
                                    Overview
                                            
** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

/* library headers */
#include "stdio.h"
#include "float.h"
#include "math.h"

/* Application headers */
#include "CRG 100110.h" 
#include "Subs.h"
#include "SlcdSubs.h"
#include "ModBusM Int.h"
#include "ModBusM.h"
#include "EEPROM.h"
#include "SLCD 260217.h"
#include "winMain.h"
#include "winKey.h"
#include "Language.h"


/* Implements this interface: */
#define WINSPEEDCAL_C
#include "winSpeedCal.h"

#pragma CODE_SEG WINSPEEDCAL_Code
#pragma DATA_SEG WINSPEEDCAL_Data


/* private */
static byte winSpeedCalState;
static byte winSpeedCalReturnWin;

static byte SpeedCalType;

static byte LastFreqLen;
static byte LastCalErrLen;

static float CalError;
static float TachoAverage;
static float SpeedAverage;

static byte  SpanCalcFlag;

static float NewSpan;

static byte SpeedCalComplete;

/* Speed Calibration screen layout (640x480 logical, scaled by slcd_SendText) */
#define SC_BOX_L_X        10
#define SC_BOX_L_W        300
#define SC_BOX_R_X        334
#define SC_BOX_R_W        296
#define SC_ZERO_BOX_Y     105
#define SC_ZERO_BOX_H     130
#define SC_SPAN_BOX_Y     258
#define SC_SPAN_BOX_H     130
#define SC_DATA_BOX_Y     105
#define SC_DATA_BOX_H     315
#define SC_BOX_INSET_X    (SC_BOX_L_X + 10)
#define SC_DATA_INSET_X   (SC_BOX_R_X + 24)
#define SC_BTN_W          100
#define SC_BTN_X(box_x, box_w)  ((box_x) + ((box_w) / 2) - (SC_BTN_W / 2))
#define SC_TITLE_Y_OFF    6
#define SC_BODY_Y_OFF     26
#define SC_BTN_Y_OFF      58
#define SC_ZERO_TITLE_Y   (SC_ZERO_BOX_Y + SC_TITLE_Y_OFF)
#define SC_SPAN_TITLE_Y   (SC_SPAN_BOX_Y + SC_TITLE_Y_OFF)
#define SC_DATA_TITLE_Y   (SC_DATA_BOX_Y + SC_TITLE_Y_OFF)
#define SC_ZERO_TEXT_Y    (SC_ZERO_BOX_Y + SC_BODY_Y_OFF)
#define SC_SPAN_TEXT_Y    (SC_SPAN_BOX_Y + SC_BODY_Y_OFF)
#define SC_ZERO_BTN_X     SC_BTN_X(SC_BOX_L_X, SC_BOX_L_W)
#define SC_ZERO_BTN_Y     (SC_ZERO_BOX_Y + SC_BTN_Y_OFF)
#define SC_SPAN_BTN_X     SC_BTN_X(SC_BOX_L_X, SC_BOX_L_W)
#define SC_SPAN_BTN_Y     (SC_SPAN_BOX_Y + SC_BTN_Y_OFF)
#define SC_ACCEPT_BTN_X   SC_BTN_X(SC_BOX_R_X, SC_BOX_R_W)
#define SC_ACCEPT_BTN_Y   265
#define SC_DATA_ROW1_Y    (SC_DATA_BOX_Y + SC_BODY_Y_OFF)
#define SC_DATA_ROW_DY    45
#define SC_PULSES_LBL_Y   SC_DATA_ROW1_Y
#define SC_PULSES_VAL_Y   SC_DATA_ROW1_Y
#define SC_FLOW_LBL_Y     (SC_DATA_ROW1_Y + SC_DATA_ROW_DY)
#define SC_FLOW_VAL_Y     (SC_DATA_ROW1_Y + SC_DATA_ROW_DY)
#define SC_ERROR_LBL_Y    (SC_DATA_ROW1_Y + (2 * SC_DATA_ROW_DY))
#define SC_ERROR_VAL_Y    (SC_DATA_ROW1_Y + (2 * SC_DATA_ROW_DY))
#define SC_VAL_X          420
#define SC_VAL_R          555
#define SC_UNIT_R         (SC_BOX_R_X + SC_BOX_R_W - 8)
#define SC_IN_LBL_Y       345
#define SC_DATE_Y         345
#define SC_VEQ_LBL_Y      375
#define SC_CALSP_Y        395
#define SC_M3H_X          (SC_BOX_R_X + SC_BOX_R_W - 8)
#define SC_M3H_Y          375
#define SC_FOOTER_Y       455
#define SC_BACK_X         50
#define SC_NEXT_X         220


/* public */



/*
** ------------------------------------------------------------------------------
**		Function: void winSpeedCalKeyHandler(byte key)
** ------------------------------------------------------------------------------
*/

void winSpeedCalKeyHandler(byte key)
{  
   switch (key)
   {
   case 1:  /* Zero cal */
      /* dont use key if span cal is in progress */
      if(mbSlave.SpanCalStartStop)
      {
         /* error beep */
         slcd_Send("beep 500");   
         /* reset button state */
         slcd_SetButtonState(1, 0);                  
      }
      else
      {
         if(!mbSlave.ZeroCalStartStop)
         {
            /* start flag */
            mbSlave.ZeroCalStartStop = 1;
            /* set write flag */
            mbTable[enZeroCalStop].WrFlg = 1;

            /* its zero cal */
            SpeedCalType = 1;

            CalError = 0.0;
            
            /* update the display */
            scDisplayCalError();   
            /* flag not complete for save */
            SpeedCalComplete = 0;    
         }
         else
         {
            /* stop flag */
            mbSlave.ZeroCalStartStop = 0;
            
            /* set write flag */
            mbTable[enZeroCalStop].WrFlg = 1;

            /* save new average */
            TachoAverage = mbSlave.Frequency;
               
            /* calculate error */
            if(!mbSlave.TachoOffset && !TachoAverage)
            {
               /* zero offset and zero frequency */
               CalError = 0.0;
            }
            else
            {
               if(!mbSlave.TachoOffset && TachoAverage)   
               {
                  /* zero offset */
                  CalError = 100.0;
               }
               else
               {
                  if(mbSlave.TachoOffset && TachoAverage)   
                  {
                     /* normal error */
                     CalError = ((mbSlave.Frequency-mbSlave.TachoOffset)/(mbSlave.TachoOffset/100.0));
                  }
                  else
                  {
                     if(mbSlave.TachoOffset && !TachoAverage)
                        /* previous offset no frequency */
                        CalError = 100.0;   
                  }
               }
            }
            /* update the display */
            scDisplayCalError();  
            
            /* flag complete for save */
            SpeedCalComplete = 1;    
         }
      }
      break;

   case 2:  /* Span cal */
      /* span page */   

      /* dont use key if span cal is in progress */
      if(mbSlave.ZeroCalStartStop)
      {
         /* error beep */
         slcd_Send("beep 500");   
         /* reset button state */
         slcd_SetButtonState(2, 0);                  
      }
      else
      {   
         if(!mbSlave.SpanCalStartStop)
         {
            /* set start flag */
            mbSlave.SpanCalStartStop = 1;
            /* set write flag */
            mbTable[enSpanCalStop].WrFlg = 1;         
            
            /* its span cal */
            SpeedCalType = 2;
            /* flag not complete for save */
            SpeedCalComplete = 0; 
            
            /* start cal timer */
            CalTimer = (unsigned long)(EEPROM.MinCalTime*100)*60;   
         }
         else
         {
            if(!CalTimer)
            {
               slcd_SendText("       ", 400, 8, 'T', LEFT_ALIGN); 
               /* set stop flag */
               mbSlave.SpanCalStartStop = 0;
               /* set write flag */
               mbTable[enSpanCalStop].WrFlg = 1;         
               
               /* save new average */
               SpeedAverage = mbSlave.AvgSpeed;
               
               /* launch Enter speed window */
               
               /* move to key pad handler state */
               winSpeedCalState = WIN_SPEEDCAL_NUMKEYPAD; 
               
               /* copy parameter data to key structure */
               strcpy(NumKeyData.Name, gstr(&str->EnterMeasuredSpeed) );  
               NumKeyData.Type = FLOAT;
               NumKeyData.KeyBoardType = NUMBER;
               NumKeyData.fMax = 5.0;
               NumKeyData.fMin = 0.1;
               NumKeyData.Index = 0;
               NumKeyData.Flag  = enBeltSpeed;
               NumKeyData.DataPtr = (void *)&mbSlave.BeltSpeed;   
               
               /* set span calc flag */
               SpanCalcFlag = 1;        
            }
            else
            {
               /* display wait meassage */   
               slcd_SetFont(16, 'B');
               slcd_SetColour(Red, White);

               /* display new Speed */
               slcd_SendText(gstr(&str->Wait), 400, 8, 'T', LEFT_ALIGN); 
               
               slcd_SetButtonState(2, 1);  
               
               /* error beep */
               slcd_Send("beep 500");                                                  
            }
         }
      }
      break;
      
   case 3:
      /* save */
      if(!SpeedCalComplete)
      {
         slcd_Send("beep 500");            
      }
      else
      {
         if(SpeedCalType==1)
         {
            /* zero cal */   
            
            /* save the offset */
            mbSlave.TachoOffset = (word)TachoAverage;
            /* */
            mbTable[enSpeedZero].WrFlg = 1;
            
            /* clear the flag */
            SpeedCalType = 0;   

            /* save beep */
            slcd_Send("beep 1000");  
            
         }
         else
         {
            if(SpeedCalType==2)
            {
               /* speed cal */

               if(NewSpan!=0.0)
               {
                  /* save the offset */
                  mbSlave.Span[3] = NewSpan;
                  /* */
                  mbTable[enSpeedSpan].WrFlg = 1;
                  
                  /* clear the flag */
                  SpeedCalType = 0;   

                  /* save speed cal date */
                  SetSpeedCalDate(mbSlave.BeltSpeed);
      
                  /* display last cal date */
                  scDisplayCalDate();
                  /* display last cal speed */
                  scDisplayCalSpeed();                                    

                  /* save beep */
                  slcd_Send("beep 1000");  

                  /* write to calibration flag */
                  mbSlave.CalibrationFlag = mbSlave.CalibrationFlag|0x01;
                  mbTable[enCalibrationFlag].WrFlg = 1;
               }
               else
               {
                  slcd_Send("beep 500");       
               }
            }
            else
            {
               slcd_Send("beep 500");    
            }
         }
      }
      break;
       
   case 128:       /* EXIT to run window */
      /* shut down num key window handler */
      if(!mbSlave.ZeroCalStartStop && !mbSlave.SpanCalStartStop)
      {
         winSpeedCalState = WIN_SPEEDCAL_UNLOAD;  
         winSpeedCalReturnWin = MAIN_WINDOW;
      }
      else
      {
         /* error beep */
         slcd_Send("beep 500");     
      }
      break;  

   case 129:       /* EXIT to menu */
      /* shut down num key window handler */
      if(!mbSlave.ZeroCalStartStop && !mbSlave.SpanCalStartStop)
      {
         winSpeedCalState = WIN_SPEEDCAL_UNLOAD;  
         winSpeedCalReturnWin = USER_WINDOW;
      }
      else
      {
         /* error beep */
         slcd_Send("beep 500");     
      }
      break; 
      
   case 130:       /* jump to Zero Mass Cal */
      /* shut down num key window handler */
      if(!mbSlave.ZeroCalStartStop && !mbSlave.SpanCalStartStop)
      {
         winSpeedCalState = WIN_SPEEDCAL_UNLOAD;
         winSpeedCalReturnWin = MASSCAL_WINDOW;  
      }
      else
      {
         /* error beep */
         slcd_Send("beep 500");     
      }
      break;                       
   }
}

/*
** ------------------------------------------------------------------------------
**		Function: void ReadSpeedCalParameters(void)
** ------------------------------------------------------------------------------
*/

void ReadSpeedCalParameters(void)
{
   mbTable[enFreq].RdFlg = 0x1;
   mbTable[enSpeedZero].RdFlg = 0x1;
   mbTable[enSpeedSpan].RdFlg = 0x1;   
   mbTable[enBeltSpeed].RdFlg = 0x1;
}

/*
** ------------------------------------------------------------------------------
**		Function: void scDisplayFrequency(void)
** ------------------------------------------------------------------------------
*/

void scDisplayFrequency(void)
{ 
   byte i, Buf[20];
   
   slcd_SetFont(16, 'B');
   slcd_SetColour(DarkGrey, LightGrey);
   
   /* format Speed  */       
   sprintf(Buf, "%0.1f ", mbSlave.Frequency);

   /* get string length  */
   i = strlen(Buf);
   
   /* has string length changed? */
   if(i!=LastFreqLen)
      /* clear display */
      slcd_SendText("                  ", SC_VAL_R, SC_PULSES_VAL_Y, 0, RIGHT_ALIGN);      
   
   /* display new Speed */
   slcd_SendText(&Buf, SC_VAL_R, SC_PULSES_VAL_Y, 0, RIGHT_ALIGN);  
   mbTable[enFreq].RdFlg = 0x1;    
   
   /* do we need to repaint the units? */
   if(i!=LastFreqLen)
   {
      /* copy last length */
      LastFreqLen = i;
      
      /* format string */
      strcpy(Buf, "Hz");
      
      /* set font and clour */
      slcd_SetFont(16, 0);
      slcd_SetColour(DarkGrey, LightGrey);
      
      /* display new units */         
      slcd_SendText(&Buf, SC_UNIT_R, SC_PULSES_VAL_Y, 0, RIGHT_ALIGN);   
   }    
}

/*
** ------------------------------------------------------------------------------
**		Function: void scDisplaySpeed(void)
** ------------------------------------------------------------------------------
*/

void scDisplaySpeed(void)
{   
   byte i, Buf[20];
   
   slcd_SetFont(16, 'B');
   slcd_SetColour(DarkGrey, LightGrey);
      
   /* format Speed  */       
   sprintf(Buf, "%.*f ", mbSlave.Digit, mbSlave.AvgSpeed);

   /* get string length  */
   i = strlen(Buf);
   
   /* has string length changed? */
   if(i!=LastSpeedLen)
      /* clear display */
      slcd_SendText("                  ", SC_VAL_R, SC_FLOW_VAL_Y, 0, RIGHT_ALIGN);      
   
   /* display new Speed */
   slcd_SendText(&Buf, SC_VAL_R, SC_FLOW_VAL_Y, 0, RIGHT_ALIGN);  
   mbTable[enAvgSpeed].RdFlg = 1;   
   
   /* do we need to repaint the units? */
   if(i!=LastSpeedLen)
   {
      /* copy last length */
      LastSpeedLen = i;
      
      /* format string */
      if(!mbSlave.Units[3])
         strcpy(Buf, "m/s");
      else
         strcpy(Buf, "m/m");
      
      /* set font and clour */
      slcd_SetFont(16, 0);
      slcd_SetColour(DarkGrey, LightGrey);
      
      /* display new units */         
      slcd_SendText(&Buf, SC_UNIT_R, SC_FLOW_VAL_Y, 0, RIGHT_ALIGN);   
   } 
}
 
/*
** ------------------------------------------------------------------------------
**		Function: void scDisplayCalError(void)
** ------------------------------------------------------------------------------
*/

void scDisplayCalError(void)
{   
   byte i, Buf[20];
   
   slcd_SetFont(16, 'B');
   slcd_SetColour(DarkGrey, LightGrey);
      
   /* format Speed  */       
   sprintf(Buf, "%.1f ", CalError);

   /* get string length  */
   i = strlen(Buf);
   
   /* has string length changed? */
   if(i!=LastCalErrLen)
      /* clear display */
      slcd_SendText("                  ", SC_VAL_R, SC_ERROR_VAL_Y, 0, RIGHT_ALIGN);      
   
   /* display new Speed */
   slcd_SendText(&Buf, SC_VAL_R, SC_ERROR_VAL_Y, 0, RIGHT_ALIGN);  
   mbTable[enSpeed].RdFlg = 1;   
   
   /* do we need to repaint the units? */
   if(i!=LastCalErrLen)
   {
      /* copy last length */
      LastCalErrLen = i;
      
      strcpy(Buf, "%");
      
      /* set font and clour */
      slcd_SetFont(16, 0);
      slcd_SetColour(DarkGrey, LightGrey);
      
      /* display new units */         
      slcd_SendText(&Buf, SC_UNIT_R, SC_ERROR_VAL_Y, 0, RIGHT_ALIGN);   
   } 
} 

/*
** ------------------------------------------------------------------------------
**		Function: void scDisplayCalDate(void)
** ------------------------------------------------------------------------------
*/

void scDisplayCalDate(void)
{   
   slcd_SetFont(16, 0);
   slcd_SetColour(DarkGrey, LightGrey);
      
   /* clear display */
   slcd_SendText("          ", 400, SC_DATE_Y, 0, LEFT_ALIGN);      
   
   /* display new Speed */
   slcd_SendText(&EEPROM.SpeedCal[EEPROM.SpeedCalPtr].Date, 400, SC_DATE_Y, 0, LEFT_ALIGN);  
} 

/*
** ------------------------------------------------------------------------------
**		Function: void scDisplayCalSpeed(void)
** ------------------------------------------------------------------------------
*/

void scDisplayCalSpeed(void)
{   
   byte Buf[20];
   
   slcd_SetFont(16, 0);
   slcd_SetColour(DarkGrey, LightGrey);

   /* format Speed  */       
   sprintf(Buf, "%.1f", EEPROM.SpeedCal[EEPROM.SpeedCalPtr].Speed);
  
   /* clear display */
   slcd_SendText("       ", 400, SC_VEQ_LBL_Y, 0, LEFT_ALIGN);      
   
   /* display new Speed */
   slcd_SendText(&Buf, 400, SC_VEQ_LBL_Y, 0, LEFT_ALIGN);     
} 

/*
** ------------------------------------------------------------------------------
**		Function: void PaintSpeedCalBoxes(void)
** ------------------------------------------------------------------------------
*/

void PaintSpeedCalBoxes(void)
{
   slcdDrawRectangle(SC_BOX_L_X, SC_ZERO_BOX_Y, SC_BOX_L_W, SC_ZERO_BOX_H);
   slcdDrawRectangle(SC_BOX_L_X, SC_SPAN_BOX_Y, SC_BOX_L_W, SC_SPAN_BOX_H);
   slcdDrawRectangle(SC_BOX_R_X, SC_DATA_BOX_Y, SC_BOX_R_W, SC_DATA_BOX_H);
}

/*
** ------------------------------------------------------------------------------
**		Function: void PaintSpeedCalLabels(void)
** ------------------------------------------------------------------------------
*/

void PaintSpeedCalLabels(void)
{
   slcd_SetColour(DarkGrey, LightGrey);

   slcd_SetFont(16, 'B');
   slcd_SendText(gstr(&str->Zero),                 SC_BOX_INSET_X,  SC_ZERO_TITLE_Y, 0, LEFT_ALIGN);
   slcd_SendText(gstr(&str->Span),                 SC_BOX_INSET_X,  SC_SPAN_TITLE_Y, 0, LEFT_ALIGN);
   slcd_SendText(gstr(&str->CalData),              SC_DATA_INSET_X, SC_DATA_TITLE_Y, 0, LEFT_ALIGN);

   slcd_SetFont(16, 0);
   slcd_SendText(gstr(&str->NeglectedFlow),        SC_BOX_INSET_X,  SC_ZERO_TEXT_Y,  0, LEFT_ALIGN);
   slcd_SendText(gstr(&str->ProcessFlow),          SC_BOX_INSET_X,  SC_SPAN_TEXT_Y,  0, LEFT_ALIGN);

   slcd_SendText(gstr(&str->Pulses),               SC_DATA_INSET_X, SC_PULSES_LBL_Y, 0, LEFT_ALIGN);
   slcd_SendText(gstr(&str->FlowColon),            SC_DATA_INSET_X, SC_FLOW_LBL_Y,   0, LEFT_ALIGN);
   slcd_SendText(gstr(&str->ErrorColon),           SC_DATA_INSET_X, SC_ERROR_LBL_Y,  0, LEFT_ALIGN);
   slcd_SendText(gstr(&str->InDate),               SC_DATA_INSET_X, SC_IN_LBL_Y,     0, LEFT_ALIGN);
   slcd_SendText(gstr(&str->vEquals),              SC_DATA_INSET_X, SC_VEQ_LBL_Y,    0, LEFT_ALIGN);
   slcd_SendText(gstr(&str->m3perHour),            SC_M3H_X,        SC_M3H_Y,        0, RIGHT_ALIGN);

   slcd_SetColour(LightBlue, White);
   slcd_SendText(gstr(&str->Back),                 SC_BACK_X,       SC_FOOTER_Y,     0, LEFT_ALIGN);
   slcd_SendText(gstr(&str->Next),                 SC_NEXT_X,       SC_FOOTER_Y,     0, LEFT_ALIGN);
}

/*
** ------------------------------------------------------------------------------
**		Function: void winPaintSpeedCalPage(void)
** ------------------------------------------------------------------------------
*/

void winPaintSpeedCalPage(void)
{   
   //lButtonType Button;   
   byte ButtonText1[20], ButtonText2[20];

   PaintSpeedCalBoxes();
   PaintSpeedCalLabels();
      
   /* make back hotspot */
   slcd_MakeHotSpot(129, 50, 440, 110, 480);
   
   /* make next hotspot */
   slcd_MakeHotSpot(130, 220, 440, 280, 480);

   
   slcd_SetFont(16, 0);   
   slcd_SetColour(White, DarkGrey);
   
   /* zero cal start button */
   //Button.Id = 1;
   //Button.x = 64;
   //Button.y = 138;
   //Button.type = 2;
   //Button.state = 0;
   
   strcpy(ButtonText1, gstr(&str->START));      
   strcpy(ButtonText2, gstr(&str->STOP));      


   //Button.text0 = ButtonText1;
   //Button.text1 = ButtonText2;
   //Button.dx0 = 20;
   //Button.dy0 = 6;
   //Button.dx1 = 24;
   //Button.dy1 = 6;
   //Button.bmp0 = 5;
   //Button.bmp1 = 4;  
       
   /* define start/stop button */
   //slcdMakeLatchingButtonCT(&Button);  
   slcd_MakeLatchingButtonCT(1, ButtonText1, ButtonText2, SC_ZERO_BTN_X, SC_ZERO_BTN_Y, 5, 4);
  
  
   /* make span cal button */
   //Button.Id = 2;
   //Button.x = 64;
   //Button.y = 302;
   //Button.type = 2;
   //Button.state = 0;
   //strcpy(ButtonText1, "Iniciar");      
   //strcpy(ButtonText2, "Parar");      
   //Button.text0 = ButtonText1;
   //Button.text1 = ButtonText2;
       
   /* define start/stop button */
   //slcdMakeLatchingButtonCT(&Button);    
   slcd_MakeLatchingButtonCT(2, ButtonText1, ButtonText2, SC_SPAN_BTN_X, SC_SPAN_BTN_Y, 5, 4);

   /* make save button */
   slcd_MakeButtonCT(3, gstr(&str->ACCEPT), 1, SC_ACCEPT_BTN_X, SC_ACCEPT_BTN_Y, 5, 4);
   
     
   /* display cal error parameter */
   scDisplayCalError();
   /* */   
   scDisplayFrequency();
   /* display last cal date */
   scDisplayCalDate();
   /* display last cal speed */
   scDisplayCalSpeed();
   
           
   /* force update */
   winUpdate1 = 1;
}

 
/*
** ------------------------------------------------------------------------------
**		Function: void UpdateSpeedCal(void)
** ------------------------------------------------------------------------------
*/

void UpdateSpeedCal(void)
{      
   /* requested update */
   if (winUpdate1==1)
   {
      /* stop counter */
      winUpdate1 = 0;
   }

   /* time to update? */
   if (!winTimer1)
   {
      winTimer1 = 100;

   }
   
   /* time to update? */
   if (!winTimer2)
   {
      winTimer2 = 20;
      
      slcd_SetFont(16, 'B');
      slcd_SetColour(DarkGrey, LightGrey);       

      /* if cal is in progress */
      //if(mbSlave.TCalFlag)
      /* update displayed frequency */
      scDisplayFrequency();
      
      /* update displayed belt speed */
      scDisplaySpeed();
      
      mbTable[enFreq].RdFlg = 0x1; 
      
      if(!CalTimer && mbSlave.SpanCalStartStop > 0)
      {
            slcd_SetFont(16, 'B');
            slcd_SetColour(Red, White);
            //slcd_SendText("Coleta de dados concluida", 10, 190, 'T');
            slcd_SendText("Coleta de dados concluida", 20, 380, 'T', LEFT_ALIGN);
      }
            
      /* do we need to caculate a new span */
      if(SpanCalcFlag)  
      {
         SpanCalcFlag = 0;
         
         /* calculate new span */
         NewSpan = mbSlave.Span[3] * (mbSlave.BeltSpeed/SpeedAverage);
         /* calculate error */
         CalError = (mbSlave.Span[3]-NewSpan)/(mbSlave.Span[3]/100.0);
         /* update display */         
         scDisplayCalError(); 

         /* flag complete for save */
         SpeedCalComplete = 1;    
      }
   }
}

/*
** ------------------------------------------------------------------------------
**		Function: byte winSpeedCalHandler(void)
** ------------------------------------------------------------------------------
*/

byte winSpeedCalHandler(void)
{
   switch (winSpeedCalState)
   {
   case WIN_SPEEDCAL_PREPAINT:
      /* get analog parameters from slave */
      ReadSpeedCalParameters();
      winSpeedCalState = WIN_SPEEDCAL_PAINT;
      
      /* clear this to force units update */
      LastSpeedLen = 0;
      LastFreqLen = 0;
      LastCalErrLen = 0;
      CalError = 0.0;
      SpeedCalComplete = 0;
      
      mbSlave.ZeroCalStartStop = 0;
      
      break;
      
   case WIN_SPEEDCAL_PAINT:
      slcd_SetColour(DarkGrey, DarkGrey);
      slcd_Send("z");

      slcd_Send("xc all");     
      /* display menu screen */
      //DisplayBmp(16, 0, 0); 
      slcd_DisplayBmp(10, 0, 0); 

      DisplayTitle("MS Instrumentos");
      
      slcd_SetFont(24, 0);
      slcd_SetColour(DarkGrey, White); 
      slcd_SendText(gstr(&str->FlowRate), 15, 60, 0, LEFT_ALIGN);

      /* define back hotspot */
      slcd_MakeHotSpot(128, 560, 10, 50, 50);

      
      
      winPaintSpeedCalPage();
               
      /* update parameters */
      winUpdate1 = 1;
      
      /* move to update state */      
      winSpeedCalState = WIN_SPEEDCAL_UPDATE;       
      return 0;
      
   case WIN_SPEEDCAL_UPDATE:
      /* is there a key to process? */
      if (slcdKey)
      {
         /* call key handler */
         winSpeedCalKeyHandler(slcdKey);      
         /* now the key has been processed clear it */
         slcdKey = 0; 
      }
      UpdateSpeedCal();


      /* has any data been remotely changed? */
      if(mbSlave.DataUpdate)
      {
         /* clear data update flag */
         mbSlave.DataUpdate = 0;
         mbTable[enDataUp].WrFlg = 1;   
         
         /* read analog parameters */
         ReadSpeedCalParameters();  
         
         /* set update timer */                   
         winUpdate1 = 100;
      }      
      return 0;

  case WIN_SPEEDCAL_NUMKEYPAD:
      /* see if key pad is returning */
      if(winKeyPadHandler())
         /* move to update state */      
         winSpeedCalState = WIN_SPEEDCAL_PAINT;   
      break;

   case WIN_SPEEDCAL_UNLOAD:
      /* do any necessary clearing up */
      winSpeedCalState = WIN_SPEEDCAL_PREPAINT;  

      /* switch to menu screen */
      winActiveWin = winSpeedCalReturnWin;  
      /* return from key pad */
      return 1;
   }   
}



