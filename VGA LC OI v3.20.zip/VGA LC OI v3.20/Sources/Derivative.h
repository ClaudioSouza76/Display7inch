#include <mc9s12xd256.h>                    /* derivative information */
#define MC9S12XD
#define MC9S12XD256