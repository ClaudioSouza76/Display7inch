/*
** ------------------------------------------------------------------------------
   
   File   : Lang.h 
   Aurthor: Stuart Clarke

** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

#ifndef LANG_H
#define LANG_H


/* public defines */

#define ENGLISH     0
#define PORTUGUESE  1

/*
** ------------------------------------------------------------------------------
**		define language structure type
** ------------------------------------------------------------------------------
*/

typedef struct 
{
   /* main screen */
   byte Status;   
     
   /* menu */
   byte StatusConnected;
   byte StatusConnecting;
   byte EnterPassword;
   byte SelectMenu;
   
   /* cal parameters */
   byte Zero;
   byte Span;
   byte Damp;
   byte AvgTime;
   byte AlarmHi;
   byte AlarmLo;
   byte AnalogHi;
   byte AnalogLo;
   byte Cal;
      
   /* misc */
   byte ChangePassword;
   byte Digits;
   byte DigitsPrecision;
   byte InstrumentID;
   byte OI_Version;
   byte NIR_Version;
   byte Serial_No;
       
   /* engineering */
   byte Engineering;
   byte ON;
   byte OFF;
   
   byte Warning;
   byte AreYouSureFactory;
   byte AreYouSureProductCalibrations;            
   byte EE_CLEAR;
   byte Restore_Factory_Defaults;
   byte Reset_Product_Calibrations;
   byte Languages;
   byte Select_Language;
   
   /* analogue */
   byte Analog;
   byte Analog_Allocation;
   byte Analog_Adjust;
   byte Analog_Hi;
   byte Analog_Lo;
   byte Output_mA;
   byte Constituent;
   byte Fix_2mA;
   byte Fix_18mA;
   byte Adjust;   
      
   /* KeyPad */
   byte Min;
   byte Max;  
   
   /* fieldbus */
   byte IP_Address;
   byte SubNet;
   byte DHCP;
       
   /* */    
   byte User_Menu;    
   byte Setup_Menu;
   byte Save;
   byte Page1;
   byte Page2;
   byte Page3;
   byte Restore_Instrument;
   byte Settings;
   byte Backup_Instrument;
   byte Restore_Factory;
   byte Defaults;
   byte Erase;
   byte Yes;
   byte No;
         
   /* New strings for LC IO */
   
   /* Setup */   
   byte Setup;
   byte FullCalibration;
   byte ResolutionAnd;
   byte Ranges;
   byte Speed;   
   byte Mass;
   byte Calibration;
   
   byte TimeAnd;
   byte Date;
   byte Analogs;
   byte FieldBus;
   
   /* Ranges */
   byte RatesAndRanges;
   byte ScaleTag;
   byte RateUnits;
   byte Resolution;
   byte PulseTotalizer;
   
   byte RateRanges;
   byte SpeedRanges;
   byte MassRanges;
   byte HighEnd;
   byte LowEnd;
   
   /* Engineering menu */
   byte Tacho;
   byte Input;
   byte AD7730;
   byte Converter;
   byte EEPROM;
   
   byte SetTimeandDate;
   byte SetTime;
   byte SetDate;

   byte ZeroCal;
   byte SpanCal;
   
   byte SpeedCalibration;
   byte MassCalibration;
   byte STOP_BELT;
   byte RUN_BELT;
   byte CalDuration;
   byte Frequency; 
   byte Offset;
   byte BeltSpeed;
   byte EnterMeasuredSpeed;  
   
   byte START;
   byte STOP;
   byte ABORT;
   byte ACCEPT;
   byte CALIBRATING;
   byte COMPLETE;
   byte CALCULATE;   
   byte STOP_CONVAYOR_EMPTY; 
   
   byte Counts;
   byte MassOffset;
   byte EnterMass;   
   byte MassSpan;   
   byte MassAdj;
   byte LOAD_TEST_WEIGHT;
   
   byte SpecialFunc;
   byte Simulation;
   byte Filtering;
   byte AlarmSettings;
   byte Totalizer;
   byte Compensation;
   
   byte RateFilter;
   byte MassFilter;
   byte SpeedFilter;
   
   byte TC;
   
   byte MassAlarms;
   byte RateAlarms;
   byte SpeedAlarms;
   byte DeviationAlarms;
   
   byte HighAlarm;
   byte LowAlarm;
   byte Hysteresis;
   
   byte PulseWidth;
   byte PulseRate;
   byte CutOff;
   byte TotalReset;
   byte Total;
   byte PulseTest;
   
   byte Flow;
   byte Total1;
   byte Weight;
   byte LastCalCheck;
   byte NextCal;
   
   byte BeltLength;
   
   byte MaxScaleCapacity;
   byte CalWeight;
   
   byte TestWeightCal;
   byte MaterialCal;
   byte BeltCutCal;
   
   byte AverageKgm;
   byte CalTotal;
   byte FlowRatePcnt;
   byte BeltDistance;
   
   byte TransportCapacity;
   byte ApplicationCapacity;
   byte BalanceCapacity;
   byte TestWightAppPercentage;
   
   byte SensibilityLC;              //Inserted by Souza
   
   byte MaterialDensity;
   byte BeltWidth;
   byte ConvayorAngle;
   byte RollerAngle;  
   byte IdleSpacing;
   
   byte SerialNo;
   byte ShippingDate;   
   byte TestWeight;
   
   byte AreYouSure;
   
   byte Restoring;
   byte BackingUp;
   byte Complete;
   
   byte CalFunctions;
   byte MinCalTime;
   byte Time;
   
   byte SpeedSimulator;
   byte MassSimulator;
   
   byte mVVeryHigh;
   byte OK;

   byte CalZeroLimit;
   byte MaxCalTime;
   
   byte Inputs;
   byte Outputs;
   byte InputsAndOutputs;
   
   byte Analogue;
   byte Digital;
   
   byte DigitalInputs;
   byte DigitalOutputs;
   byte AnalogueInputs;
   byte AnalogueOutputs;
      
   byte InputDelay;
   byte Polarity;
   byte Function;
   
   byte Positive;
   byte Negative;
   
   byte Output;
   byte TriggerHi;
   byte TriggerLo;
   byte OutputDelay;
   
   byte AnalogueIn1;
   byte AnalogueIn2;
   
   byte Tension;
   byte InputType;
   
   byte TensionHi;
   byte TensionLo;
   
   byte MovingAverageLC;            //Inserted by Souza
   byte MovingAverageBT;            //Inserted by Souza
   
   byte SampleCount;
   byte AverageCount;
   
   byte TimeOutCal;   
   
   byte Precision;
   
   byte SerNumMS;
   
   byte ModelScale;

   byte Configuration;
   byte BasicDiagnostics;
   byte Histogram;
   byte ConfigurationBasicDiagnostics;
   byte TimeAndDate;
   byte BalanceData;
   byte CalibrationConstants;

   /* Balance Data screen labels */
   byte BalanceScreenTitle;
   byte BalanceLbl_Tag;
   byte BalanceLbl_Model;
   byte BalanceLbl_SerialNo;
   byte BalanceLbl_CC;
   byte BalanceLbl_mVperV;
   byte BalanceLbl_ProjFlow;
   byte BalanceLbl_ScaleCap;
   byte BalanceLbl_TestWtEquiv;
   byte BalanceLbl_TestWtPct;
   byte BalanceLbl_TestWtKg;
   byte BalanceLbl_FactoryDate;
   byte BalanceLbl_Version;
   byte BalanceLbl_Density;
   byte BalanceLbl_BeltLength;
   byte BalanceLbl_BeltWidth;
   byte BalanceLbl_DesignSpeed;
   byte BalanceLbl_ConvIncline;
   byte BalanceLbl_RollerIncline;
   byte BalanceLbl_RollerSpacing;
   byte BalanceLbl_ManufacturedBy;
   byte BalanceLbl_MSCompany;
   byte BalanceLbl_MSLocation;
   byte BalanceLbl_MSWebsite;

   /* Speed Calibration screen labels */
   byte FlowRate;
   byte NeglectedFlow;
   byte ProcessFlow;
   byte CalData;
   byte Pulses;
   byte FlowColon;
   byte ErrorColon;
   byte InDate;
   byte vEquals;
   byte m3perHour;
   byte Back;
   byte Next;
   byte Wait;

   /* Engineering menu labels */
   byte CalFunctionsLine1;
   byte CalFunctionsLine2;
   byte MechAssemblyLine1;
   byte MechAssemblyLine2;
   byte SpeedSensor;
   byte SpecialFunctions;
   byte MovingAverage;
   byte TensionScreenTitle;
   byte InspecMecTitle;
   
   byte ActualZero;
   byte NewZero;
   byte ActualZeroDate;
   byte miliVolts;
   
}LangStrucType;


#ifndef LANG_C

/* public variables */
#pragma DATA_SEG LANG_Data

extern byte  strBuffer[25]; 
extern const LangStrucType  *str;


#endif   /* LANG_C */ 


/* public functions */
#pragma CODE_SEG LANG_Code


/*
** ------------------------------------------------------------------------------
**		Function: byte *gstr(byte *str)
** ------------------------------------------------------------------------------
**  str points at a LangStrucType member; str is null so the pointer value
**  equals the string table index (0..n-1).  Must use word, not byte, index.
** ------------------------------------------------------------------------------
*/

#pragma CODE_SEG STRING_CODE

byte *gstr(byte *str);
     
#pragma CODE_SEG LANG_Code

/*
** ------------------------------------------------------------------------------
**		Function: byte LangCmdParser(void)
** ------------------------------------------------------------------------------
*/

byte LangCmdParser(void);

/*
** ------------------------------------------------------------------------------
**		Function: void LangInit(void)
** ------------------------------------------------------------------------------
*/

void LangInit(void);


#endif   /* LANG_H */
