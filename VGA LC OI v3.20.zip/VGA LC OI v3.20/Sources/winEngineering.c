#include <hidef.h>                           /* common defines and macros */
#include "derivative.h"                      /* derivative information */

/*
** ------------------------------------------------------------------------------
   
   File   : winEngineering.c 
   Aurthor: 
   
   Description:  
   
   Version Log          Notes                                     Changes Made by                                        
   --------------       -----                                     ---------------
   14-10-10:            Created                                   Stuart


** ------------------------------------------------------------------------------
                                    
                                    Overview
                                            
** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

/* library headers */
#include "stdio.h"
#include "float.h"
#include "math.h"

/* Application headers */
#include "CRG 100110.h" 
#include "Subs.h"
#include "SlcdSubs.h"
#include "ModBusM Int.h"
#include "ModBusM.h"
#include "EEPROM.h"
#include "SLCD 260217.h"
#include "winMain.h"
#include "winKey.h"
#include "Language.h"


/* Implements this interface: */
#define WINENGINEERING_C
#include "winEngineering.h"

#pragma CODE_SEG WINENGINEERING_CODE
#pragma DATA_SEG WINENGINEERING_DATA


/* private */
static byte winEngineeringState;


/* public */
byte winEngineeringReturnWin;


/*
** ------------------------------------------------------------------------------
**		Function: void winEngineeringKeyHandler(byte key)
** ------------------------------------------------------------------------------
*/

void winEngineeringKeyHandler(byte key)
{   
   switch (key)
   {

    
   case 2:      /* AD7730 */     
      //winEngineeringReturnWin = AD7730_WINDOW; 
      /* send command to execute macro 2 */
      //winEngineeringState = WIN_ENGINEERING_UNLOAD;  
      break; 

   case 3:      /* Special Functions */     
      winEngineeringReturnWin = SPECIALFUNC_WINDOW; 
      /* send command to execute macro 2 */
      winEngineeringState = WIN_ENGINEERING_UNLOAD;  
      break; 

   case 4:      /* Calibartion Functions */     
      winEngineeringReturnWin = CALFUNC_WINDOW; 
      /* send command to execute macro 2 */
      winEngineeringState = WIN_ENGINEERING_UNLOAD;  
      break; 
      
   case 5: /* Inspector hardware  */
       winEngineeringReturnWin = INSPECMEC_WINDOW; 
      /* send command to execute macro 2 */
      winEngineeringState = WIN_ENGINEERING_UNLOAD;  
      break;       
            
   case 128:       /* EXIT */
      winEngineeringReturnWin = USER_WINDOW;
      /* shut down num key window handler */
      winEngineeringState = WIN_ENGINEERING_UNLOAD;  
      break;  
     
   }
}


/*
** ------------------------------------------------------------------------------
**		Function: void ReadEngineeringParameters(void)
** ------------------------------------------------------------------------------
*/

void ReadEngineeringParameters(void)
{


}


/*
** ------------------------------------------------------------------------------
**		Function: void UpdateEngineering(void)
** ------------------------------------------------------------------------------
*/

void UpdateEngineering(void)
{
   /* requested update */
   if (winUpdate1==1)
   {
      /* stop counter */
      winUpdate1 = 0;
      
   }

   /* time to update? */
   if (!winTimer1)
   {
      winTimer1 = 25;

   }
}

/*
** ------------------------------------------------------------------------------
**		Function: byte winEngineeringHandler(void)
** ------------------------------------------------------------------------------
*/

byte winEngineeringHandler(void)
{
   switch (winEngineeringState)
   {
   case WIN_ENGINEERING_PREPAINT:
      /* get analog parameters from slave */
      ReadEngineeringParameters();

      /* set delay for parameters to arrive from MCT  */
      winUpdate1 = 15;
            
      winEngineeringState = WIN_ENGINEERING_PAINT;
      break;
      
   case WIN_ENGINEERING_PAINT:
      if(winUpdate1==1)
      {
         winUpdate1 = 0;

         slcd_SetColour(DarkGrey, DarkGrey);
         slcd_Send("z");

         slcd_Send("xc all");     
         /* display menu screen */
         //DisplayBmp(16, 0, 0, LEFT_ALIGN); 
         slcd_DisplayBmp(10, 0, 0); 

         DisplayTitle("MS Instrumentos");
         
         slcd_SetFont(24, 0);
         slcd_SetColour(DarkGrey, White); 
         slcd_SendText(gstr(&str->Engineering), 15, 60, 0, LEFT_ALIGN);
         
         /* define back hotspot */
         //slcd_CmdQueue("x 128 560 10 630 60");
         slcd_MakeHotSpot(128, 560, 10, 50, 50);
         
         /* display buttons */   
         slcd_MakeButton(3, 1, 30,  120,  2, 3);
         slcd_MakeButton(5, 1, 30,  200,  2, 3);
         slcd_MakeButton(4, 1, 320, 120,  2, 3);              

         slcd_SetFont(16, 0);
         slcd_SetColour(DarkGrey, White);
         slcd_SendText(gstr(&str->SpecialFunc),        115, 120, 0, LEFT_ALIGN);

         slcd_SendText(gstr(&str->CalFunctionsLine1), 405, 120, 0, LEFT_ALIGN);
         slcd_SendText(gstr(&str->CalFunctionsLine2), 405, 150, 0, LEFT_ALIGN);

         slcd_SendText(gstr(&str->MechAssemblyLine1), 115, 200, 0, LEFT_ALIGN);
         slcd_SendText(gstr(&str->MechAssemblyLine2), 115, 230, 0, LEFT_ALIGN);

         /* update parameters */
         winUpdate1 = 1;
         
         /* move to update state */      
         winEngineeringState = WIN_ENGINEERING_UPDATE;       
      }
      return 0;

   case WIN_ENGINEERING_UPDATE:
      /* is there a key to process? */
      if (slcdKey)
      {
         /* call key handler */
         winEngineeringKeyHandler(slcdKey);      
         /* now the key has been processed clear it */
         slcdKey = 0; 
      }

      UpdateEngineering();

      /* has any data been remotely changed? */
      if(mbSlave.DataUpdate)
      {
         /* clear data update flag */
         mbSlave.DataUpdate = 0;
         mbTable[enDataUp].WrFlg = 1;   
         
         /* read analog parameters */
         ReadEngineeringParameters();  
         
         /* set update timer */                   
         winUpdate1 = 100;
      }      
      return 0;

  case WIN_ENGINEERING_NUMKEYPAD:
      /* see if key pad is returning */
      if(winKeyPadHandler())
      {
         /* move to update state */      
         winEngineeringState = WIN_ENGINEERING_PREPAINT;       
      }
      break;

 case WIN_ENGINEERING_ENTER_PASSWORD:
      /* see if key pad is returning */
      switch(winKeyPadHandler())
      {
      case 1:
         /* move to update state */      
         winEngineeringState = WIN_ENGINEERING_PREPAINT;       
         break;

      case 2:
         /* move to update state */      
         winEngineeringState = WIN_ENGINEERING_UNLOAD;       
         break;       
      }
      break;
      
   case WIN_ENGINEERING_UNLOAD:
      /* do any necessary clearing up */
      winEngineeringState = WIN_ENGINEERING_PREPAINT;  

      /* set return menu */
      winActiveWin = winEngineeringReturnWin;

      /* return from key pad */
      return 1;
   }   
}



