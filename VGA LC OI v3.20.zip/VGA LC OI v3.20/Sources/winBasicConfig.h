/*
** ------------------------------------------------------------------------------
   
   File   : winBasicConfig.h 
   Aurthor: Stuart Clarke

** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

#ifndef WINBASICCONFIG_H
#define WINBASICCONFIG_H


/* public defines */

/*
** ------------------------------------------------------------------------------
**		#define : user menu handler states 
** ------------------------------------------------------------------------------
*/

#define WIN_BASIC_CONFIG_PREPAINT     0
#define WIN_BASIC_CONFIG_PAINT        1
#define WIN_BASIC_CONFIG_UPDATE       2
#define WIN_BASIC_CONFIG_NUMKEYPAD    3
#define WIN_BASIC_CONFIG_UNLOAD       4
#define WIN_BASIC_CONFIG_ENTER_PASSWORD 5


#ifndef WINBASICCONFIG_C

/* public variables */
#pragma DATA_SEG WINUSER_DATA

extern byte winBasicConfigReturnWin;

#endif   /* WINUSER_C */      


/* public functions */
#pragma CODE_SEG WINBASICCONFIG_CODE


/*
** ------------------------------------------------------------------------------
**		Function: void ReadBasicConfigParameters(void)
** ------------------------------------------------------------------------------
*/

void ReadBasicConfigParameters(void);

/*
** ------------------------------------------------------------------------------
**		Function: byte winBasicConfigHandler(void)
** ------------------------------------------------------------------------------
*/

byte winBasicConfigHandler(void);

#endif   /* WINUSER_H */
