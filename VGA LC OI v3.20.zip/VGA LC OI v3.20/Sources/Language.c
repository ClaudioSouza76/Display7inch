#include <hidef.h>                           /* common defines and macros */
#include <mc9s12xd256.h>                    /* derivative information */

/*
** ------------------------------------------------------------------------------
   
   File   : Language.c 
   Aurthor: 
   
   Description:  
   
   Version Log          Notes                                     Changes Made by                                        
   --------------       -----                                     ---------------
   30-04-08:            Created                                   Stuart


** ------------------------------------------------------------------------------
                                    
                                    Overview
                                            
** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

/* library headers */
#include "string.h"
#include "stdio.h"

/* Application headers */
#include "Main.h"
#include "Cmd.h"
#include "EEPROM.h"

#include "SLCD 260217.h"
#include "English.h"
//#include "Deutsch.h"
#include "Portugal.h"
//#include "Chinese.h"
//#include "Polish.h"
//#include "Spanish.h"

/* Implements this interface: */
#define LANG_C
#include "Language.h"

#pragma CODE_SEG LANG_Code
#pragma DATA_SEG LANG_Data


/* private */
                                      

/* public */

byte  strBuffer[100];
const LangStrucType  *str;


/*
** ------------------------------------------------------------------------------
**		EEPROM Cmd Table
** ------------------------------------------------------------------------------
*/

#pragma INTO_ROM
static const CmdTabType LanguageCmdTab[]=
{
"LANG=",         1,
"LANG?",         2,

"",			   0
};

/*
** ------------------------------------------------------------------------------
**		Function: byte LangCmdParser(void)
** ------------------------------------------------------------------------------
*/

byte LangCmdParser(void)
{
   word i, j;
   
   switch(CmdMatch((CmdTabType *)&LanguageCmdTab))
   {
	case 1:       	/* LANG= */
		i = sscanf(RxDataPtr, "%u", &j);
		if (i!=1||j>2)  
		{
			Reply(DATA_ERR);
		}
		else
		{
			EEWR_8(&EEPROM.Language, (byte)j);
			LangInit();
			Reply(ACK);
		}
		break;
		
	case 2:         /* LANG? */
	   sprintf(TxBufPtr, "%u", EEPROM.Language);
	   LangInit();
	   CmdTx();
		break;  	


   default:
      return 0;
   }
   
   /* Command processed */   
   return 1;
}

/*
** ------------------------------------------------------------------------------
**		Function: void LangInit(void)
** ------------------------------------------------------------------------------
*/

void LangInit(void)
{
   switch (EEPROM.Language)
   {
   case ENGLISH:
   default:   
      slcd_Send("utf8 off");
      break;
      
   case PORTUGUESE:
      slcd_Send("utf8 on");
      break;
   }
}

/*
** ------------------------------------------------------------------------------
**		Function: byte *__strcpy(byte *str_d, byte *str_s)
** ------------------------------------------------------------------------------
*/

#pragma CODE_SEG STRING_CODE

byte *__strcpy(byte *str_d, byte *str_s)
{
    byte *sd = str_d;

    while(*str_d++ = *str_s++);
    return (sd);
}

/*
** ------------------------------------------------------------------------------
**		Function: byte *gstr(byte *str)
** ------------------------------------------------------------------------------
**  Pointer value is the string table index (LangStrucType offset via &str->field).
**  Index must be word — byte cast wraps at 256 strings.
** ------------------------------------------------------------------------------
*/

byte *gstr(byte * str)
{
   word index;
   
   index = (word)str;
   
   switch (EEPROM.Language)
   {
   case 0:     /* English */
   default:   
       __strcpy(strBuffer, English[index]);
       break;

   case 1:     /* Portuguese */
       __strcpy(strBuffer, Portuguese[index]);
       break;

   //case 1:     /* Deutsch */
       //__strcpy(strBuffer, Deutsch[index]);
       //break;

   //case 3:     /* Polish */
       //__strcpy(strBuffer, Polish[index]);
       //break;

   //case 4:     /* Chinese */
       //__strcpy(strBuffer, Chinese[index]);
       //break;

   //case 5:     /* Spanish */
       //__strcpy(strBuffer, Spanish[index]);
       //break;
   }
   
   return strBuffer; 
}

#pragma CODE_SEG DEFAULT