#include <hidef.h>                           /* common defines and macros */
#include "derivative.h"                      /* derivative information */

/*
** ------------------------------------------------------------------------------
   
   File   : winMovingAverage.c 
   Aurthor: Souza - MS Instrumentos
   
   Description:  
   
   Version Log          Notes                                     Changes Made by                                        
   --------------       -----                                     ---------------
   25-07-10:            Created                                   Stuart


** ------------------------------------------------------------------------------
                                    
                                    Overview
                                            
** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

/* library headers */
#include "stdio.h"
#include "float.h"
#include "math.h"

/* Application headers */
#include "CRG 100110.h" 
#include "Subs.h"
#include "ModBusM Int.h"
#include "ModBusM.h"
#include "EEPROM.h"
#include "SLCD 260217.h"
#include "winMain.h"
#include "winKey.h"
#include "Language.h"
#include "SlcdSubs.h"

/* Implements this interface: */
#define WINMOVINGAVERAGE_C
#include "winMovingAverage.h"

#pragma CODE_SEG WINMOVINGAVERAGE_Code
#pragma DATA_SEG WINMOVINGAVERAGE_Data


/* private */
static byte winMovingAverageState;
static byte winMovingAveragePage;


/* public */

/*
** ------------------------------------------------------------------------------
**		Function: void winMovingAverageKeyHandler(byte key)
** ------------------------------------------------------------------------------
*/

void winMovingAverageKeyHandler(byte key) {
  
  switch (key) {
  
    case 1:
      /* change state */
      mbSlave.MovingAverageLCen ^= 1;
      /* set write flag */
      mbTable[enMovingAverageLC].WrFlg = 1;       
      break;
      
    case 2:
      /* change state */
      mbSlave.MovingAverageBTen ^= 1;
      /* set write flag */
      mbTable[enMovingAverageBT].WrFlg = 1;       
      break;
      
    case 128:       /*EXIT*/
      winMovingAverageState =  WIN_MOVING_AVERAGE_UNLOAD;
      break;
      
    case 130:      /*Moving Average LC*/
      winMovingAverageState = WIN_MOVING_AVERAGE_NUMKEYPAD;
      /* Config the screen of the Key Pad*/
      strcpy(NumKeyData.Name, gstr(&str->MovingAverageLC));
      NumKeyData.KeyBoardType = NUMBER;
      NumKeyData.Type = WORD;
      NumKeyData.Attributes = EPROM;
      NumKeyData.iMax = 99;
      NumKeyData.iMin = 1;
      NumKeyData.Flag = enMovingAverageLC;
      NumKeyData.DataPtr = (void *)&mbSlave.MovingAverageLC;
      break;
      
    case 131:     /*Moving Average BT*/
      winMovingAverageState = WIN_MOVING_AVERAGE_NUMKEYPAD;
      /* Config the screen of the Key Pad*/
      strcpy(NumKeyData.Name, gstr(&str->MovingAverageBT));
      NumKeyData.KeyBoardType = NUMBER;
      NumKeyData.Type = WORD;
      NumKeyData.Attributes = EPROM;
      NumKeyData.iMax = 99;
      NumKeyData.iMin = 1;
      NumKeyData.Flag = enMovingAverageBT;
      NumKeyData.DataPtr = (void *)&mbSlave.MovingAverageBT	;
      break;
  }
}

/*
** ------------------------------------------------------------------------------
**		Function: void ReadMovingAverageParameters(void)
** ------------------------------------------------------------------------------
*/

void ReadMovingAverageParameters(void) 
{

  mbTable[enMovingAverageLC].RdFlg = 0x1;
  mbTable[enMovingAverageBT].RdFlg = 0x1;

  mbTable[enMovingAverageLCen].RdFlg = 0x1;
  mbTable[enMovingAverageBTen].RdFlg = 0x1;
  
}

/*
** ------------------------------------------------------------------------------
**		Function: void PaintMovingAveragePage(void)
** ------------------------------------------------------------------------------
*/

void PaintMovingAveragePage(void){

  byte Buf[35];                           //Vector to converter the variable of the EEPROM to string.
  lButtonType Button;                     //Config of the slcd to creat a button.
  byte ButtonText1[20], ButtonText2[20];
  
  slcdSetFont(F16B);                      //Set the font of the text in the screen
  
  slcdSetColour(DarkGrey, White);         //Set the colours of the text in the screen
  
  slcdDisplayText("Load Cell", 27, ccY0, 'T');
  DisplayText("Tensao Correia", 327, ccY0, 'T');
  
  DisplayText(gstr(&str->TC), 27, 230, 'T');
  DisplayText(gstr(&str->TC), 327, 230, 'T');
  
  sprintf(Buf, "%u s ", mbSlave.MovingAverageLC);
  DisplayText(&Buf, 227, 230, 0);

  sprintf(Buf, "%u s ", mbSlave.MovingAverageBT);
  DisplayText(&Buf, 540, 230, 0);

  
  MakeHotSpot(130, 220, 240, 298, 284);  //Config of the position of action user on write of value time constant.
  MakeHotSpot(131, 540, 240, 600, 284);
  
  
  slcdSetColour(Red, White);

  Button.Id = 1;
  Button.x = 227;
  Button.y = ccY0;
  Button.type = 2;
  Button.state = mbSlave.MovingAverageLCen;	
  strcpy(ButtonText1, gstr(&str->OFF));                                                                   
  strcpy(ButtonText2, gstr(&str->ON));
  Button.text0 = ButtonText1;
  Button.text1 = ButtonText2;
  Button.dx0 = 12;
  Button.dy0 = 10;
  Button.dx1 = 18;
  Button.dy1 = 10;
  Button.bmp0 = 27;
  Button.bmp1 = 26; 
  
  MakeLatchingButton(&Button);
  
  Button.Id = 2;
  Button.x = 540;
  Button.y = ccY0;
  Button.state = mbSlave.MovingAverageBTen;
  
  MakeLatchingButton(&Button); 
  
  winUpdate1 = 1;
  
}

/*
** ------------------------------------------------------------------------------
**		Function: void UpdateMovingAverage(void)
** ------------------------------------------------------------------------------
*/

void UpdateMovingAverage(void){

  //byte Buf[35];

  if (winUpdate1==1)
  {
    winUpdate1 = 0;
    
    slcdSetColour(LightBlue, White);
    slcdSetFont(F16B);

    //sprintf(Buf, "%u s ", mbSlave.MovingAverageLC);
    //slcdDisplayText(&Buf, getX(170), getY(130), 0);

    //sprintf(Buf, "%u s ", mbSlave.MovingAverageBT);
    //slcdDisplayText(&Buf, getX(405), getY(130), 0);     
  }
  
}

/*
** ------------------------------------------------------------------------------
**		Function: byte winMovingAverageHandler(void)
** ------------------------------------------------------------------------------
*/

byte winMovingAverageHandler(void){

  switch (winMovingAverageState) 
   {
    case WIN_MOVING_AVERAGE_PREPAINT:
    
      ReadMovingAverageParameters();
      winMovingAverageState = WIN_MOVING_AVERAGE_PAINT;
      
      /* set delay time for parameter exchange */
      winTimer1 = 25;
      
      break;
      
    case WIN_MOVING_AVERAGE_PAINT:
      
      /* has parameter exchange delay expired? */
      if(!winTimer1)
      {
         slcdCallMacro(2);
         
         slcdSetColour(DarkGrey, DarkGrey);
         
         slcdSetFont(F24B);
         
         DisplayText("Media Movel", 16, 7,'T');
         
         winUpdate1 = 1;
         
         winMovingAverageState = WIN_MOVING_AVERAGE_PAINT_PAGE;
      }
      break;
      
    case WIN_MOVING_AVERAGE_PAINT_PAGE:
    
      slcd_CmdQueue("xic 10 0 0 2 112 640 480");      
      
      slcd_CmdQueue("xc all");      
      
      /* remake back button */
      slcd_CmdQueue("x 128 560 10 630 60");
      
      PaintMovingAveragePage();
      
      winMovingAverageState = WIN_MOVING_AVERAGE_UPDATE;
      break;
      
    case WIN_MOVING_AVERAGE_UPDATE:
    
      if (slcdKey) {
        winMovingAverageKeyHandler(slcdKey);
        slcdKey = 0;

      }
      UpdateMovingAverage();
      
      winUpdate1 = 100;
      break;
      
    case WIN_MOVING_AVERAGE_NUMKEYPAD:
    
      if (winKeyPadHandler())
        winMovingAverageState = WIN_MOVING_AVERAGE_PAINT;
      
      break;
      
    case WIN_MOVING_AVERAGE_UNLOAD:
      
      winMovingAverageState = WIN_MOVING_AVERAGE_PREPAINT;
      
      winMovingAveragePage = 0; 
      
      winActiveWin = SPECIALFUNC_WINDOW;
      
      return 1;
  
  }
}