#include <hidef.h>                           /* common defines and macros */
#include <mc9s12xd256.h>    
#include "derivative.h"                 /* derivative information */

#pragma LINK_INFO DERIVATIVE "mc9s12xd256"

#pragma CODE_SEG Main_Code
#pragma DATA_SEG Main_Data

/*
** ------------------------------------------------------------------------------------------
   
   File   : Main.c 
   Aurthor: Stuart Clarke
   
** ------------------------------------------------------------------------------------------ */

   #pragma INTO_ROM
   const char ModelString[14] = "7.1 LC OI";
   #pragma INTO_ROM
   const char VersionString[12] = "v3.20";

      
/* ------------------------------------------------------------------------------------------
   
   Version Log          Notes                                                    Changes Made by                                        
   ----------------     -----                                                    ---------------
   23-10-08: v1.00      Created from NIR OI v 2.01                               Stuart Clarke
   
   28-09-10: v1.02      Next Stage of development                                Stuart Clarke
   
   04-10-10: v1.03      Moved to 5.7 in display                                  Stuart Clarke
   
   10-11-10: v1.04      Moved serial no to ser eeprom                            Stuart Clarke
   
   
   11-01-11: v1.04a     Souzas version                                           Souza
   
   24-01-11: v1.04b     Added further modifications per Julio's request see 
                        revision record                                          Stuart Clarke 
   
   07-02-11: v1.05     Added OI configuration menus 
                                                                                 Stuart Clarke    

   03-02-11: v1.06     Fixed loadcell modbus parameter transfer problems for Souza
   
                                                                                 Stuart Clarke    

   26-07-11: v1.08     Added distribution 
   
                                                                                 Stuart Clarke    

   17-08-11: v1.09     Changed Distribution calcs  
   
                                                                                 Stuart Clarke    


   11-10-11: v1.10     Added fieldbus menu 
   
                                                                                 Stuart Clarke    

   01-11-12: v2.02     Changed analogue input zero range
                                                                                 Stuart Clarke    

   28-06-13: v2.03     Increased precision in dados balancia 
                                                                                 Stuart Clarke    

   11-07-13: v2.04     Updated Fieldbus menu for ethernet 
                                                                                 Stuart Clarke    
   

   06-08-13: v2.05     Fix version issues 
                                                                                 Stuart Clarke    
   
   16-09-13: v2.06     Compiled for souza
                                                                                 Stuart Clarke    
                                                                                 
   24-09-20: v2.07     Added station Name to Fieldbus page
                                                                                 Stuart Clarke 
   03-11-23: v2.09     Added PERA option in output Rele                          Souza
   
   06-11-24: v2.10     Correct page winTension                                   Souza
   
   
   06-11-24: v3.20     Updated for new display                                   Stuart
   
                                                                                                                                                                     

** ------------------------------------------------------------------------------------------
                                    
                                    Overview
                                    
                                            
** ------------------------------------------------------------------------------------------

   COPYRIGHT NOTIFICATION (c)2010 MS INSTRUMENTOS INDUSTRIAIS LTDA
   This program is the property of MS INSTRUMENTOS INDUSTRIAIS LTDA.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   MS INSTRUMENTOS INDUSTRIAIS LTDA
   Industriais Ltda 
   Estrada do Bigu�� 43 - Alto da Boa Vista 
   Rio de Janeiro RJ/Brasil
   
** ------------------------------------------------------------------------------------------
*/

/* library headers */


/* Application headers */
#include "Irq.h"
#include "Cmd.h"
#include "ModBusM Int.h"
#include "Subs.h"
#include "EEPROM.h"
#include "IRQ 100110.h"
#include "CRG 100110.h"
#include "PIM 100110.h"
#include "PIT 100110.h"
#include "ECT 100114.h"
#include "SCI 100110.h"
#include "Flash 080906.h"
#include "Boot 080919.h"
#include "LED 100118.h"
#include "SLCD 260217.h"
#include "ADC 100118.h"
#include "ModBusM.h"

#include "winMain.h"



#pragma CODE_SEG DEFAULT


/* Implements this interface: */
#define MAIN_C
#include "Main.h"


void main(void) 
{
   DisableInterrupts;
   
   /* what board are we running in ? */
   BoardType = _900_125;
   
   /* DataDirection, Data, PullUp */
   PortAInit(0x03, 0x00, 1);
   PortBInit(0x00, 0x00, 1);
   PortEInit(0x00, 0x00, 1);
   
   //if (BoardType == _1162)
      //PortKInit(0x30, 0x00, 1);
   //else
      PortKInit(0x10, 0x00, 1);
   
   /* DataDirection, Data, PullUps */   
   PortHInit(0x00, 0x00, 0xFF);
   PortJInit(0x00, 0x00, 0xFF);
   
   //if (BoardType == _1162)
      //PortMInit(0x40, 0x00, 0xFF);
   //else
      PortMInit(0xC0, 0x40, 0xFF);
   
   //if (BoardType == _1162)
      //PortPInit(0x00, 0x00, 0xFF);
   //else
      PortPInit(0x70, 0x70, 0x8F);   
   
   PortSInit(0x00, 0x00, 0xFF);   
   
   //if (BoardType == _1162)
      //PortTInit(0xE0, 0xE0, 0xFF);
   //else
      PortTInit(0x00, 0x00, 0xFF);
      
   /* DigitalEnable, DataDirection, Data, PullUps */
   //if (BoardType == _1162)
      //PortPAD0Init(0xFF, 0x00, 0x00, 0xFF);
   //else
      PortPAD0Init(0x00, 0x00, 0x00, 0xFF);
   
   PortPAD1Init(0x00, 0x00, 0x00, 0xFF);


   /* Initialize the EEPROM burning clock */
   EEPROM_Init();
   
   /* Shift interrupt vector base address for the bootloader */
   Irq_Init();   
   /* Disable the external IRQ if not in use */
   IRQ_Init(IRQ_DISABLE);
   /* Initialize PLL for 40MHz bus clock */
   PLL_Init();

   /* Initialize the internal ADC */
   ADC_Init(RES10, 0x03);

   
   /* Initilaze Cmd for ASCI coms on SCI0 */
   CmdInit(SCI0_ADR);  
   /* Initialze SCI0 for cmd interface and bootloader */
   SCI_Init(SCI0_ADR, 115200, (EIGHTBIT|NOPARITY), (_RE|_TE|_RIEN));   

   /* initialize slcd driver on SCI1 */
   slcd_Init(SCI1_ADR);
   /* initialze SCI1 for coms to slcd board*/
   SCI_Init(SCI1_ADR, 115200, (EIGHTBIT|NOPARITY), (_RE|_TE|_RIEN));   
   
   /* initialize ECT channel 1 10 mS output compare  */
   ECT_ChannelInit(ECT0, OUTPUT_COMP, 10000, IRQ_ON, 0);

   /* initialize modbus driver on SCI2 */
   ModBusM_Init(SCI2_ADR);   
   ModBusIntInit();
   
   /* Initialze SCI2 for 485 Modbus to host */
   SCI_Init(SCI2_ADR, 38400, (EIGHTBIT|NOPARITY), (_RE|_TE));   
   
   /* initialize ECT channel 2 for modbus T3 timeout  */
   ECT_ChannelInit(ECT1, OUTPUT_COMP, 0, IRQ_OFF, 0);
   /* initialize timer for modbus reply timeout */
   ECT_ChannelInit(ECT2, OUTPUT_COMP, 10000, IRQ_ON, 0);


   /* start up ECT */
   ECT_TimerInit(ECT_DIV_8, ON);
   
   /* Initialize COP */
   COP_Init();
   /* Initialize the Periodical Interrupt Timer */
   PIT_Init();

   /* start leds */
   //if (BoardType == _1162)
   //{
      /* set LED port */
      //led_Init(&PTT);
      /* set LED pins */
      //led_DefineLEDPins(0x20, 0x80, 0x40);
   //}
   //else
   //{
      /* set LED port */
      led_Init(&PTP);
      /* set LED pins */
      led_DefineLEDPins(0x20, 0x10, 0x40);
   //}
   
   /* start subs */
   SubsInit();
                    
   EnableInterrupts;

   /* Initialize code execution timers */
   Timer100mS  = 10;
   Timer200mS  = 2;
   Timer1S     = 5;

   /* load timer for 200 mS statup delay */
   StartUpDelay = 80;
   while(StartUpDelay);
   
   for(;;) 
   {
      __RESET_COP();
      
      /* PIT code execution scheduler */
      if (pitTimer10mS)
      {
         pitTimer10mS--;

         /* run led timers at 10mS */
         //led_Driver();
         
         /* manage hystogram sample timer */
         if(winActiveWin>SPLASH_TIMEOUT && EEPROM.SampleRate<=1)
            subsSampleTimer();
            
         /* Do 100 mS jobs */
         if (Timer100mS && !--Timer100mS)
         {
            Timer100mS = 10;   

            /* read switch inputs */
            subsReadSwitches();
            
            if (BoardType == _900_125)
               /* check reset switch */ 
               subsCheckResetSwitch();

            /* Do 200 mS jobs */
            if (Timer200mS && !--Timer200mS)
            {
               Timer200mS = 2;           

               if (BoardType == _900_125)
                  /* read psu voltages */
                  subsMeasurePSU();
             
            
               /* Do 1 sec jobs */
               if (Timer1S && !--Timer1S)
               {
                  Timer1S = 5; 
                  
                  PTP_PTP6 ^= 1;
                  
                  /* dont ask if repainting in progress */
                  if(!winRePaint)
                    mbTable[enDataUp].RdFlg = 1;  
                  
                  /* manage hystogram sample timer */
                  if(winActiveWin>SPLASH_TIMEOUT && EEPROM.SampleRate>=2)
                     subsSampleTimer();
               }
            }
         }
      }
      
      /* Check for ASCI commands on SCI0 */
      CheckCmdInput();      

      /* call modbus driver */
      mbModBusDriver();

      /* call slcd driver */
      slcd_Driver();
      
      /* call fault handlder */
      subsErrorHandler();
   } 
}
