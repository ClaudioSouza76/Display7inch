#include <hidef.h>                           /* common defines and macros */
#include "derivative.h"                      /* derivative information */

/*
** ------------------------------------------------------------------------------
   
   File   : winInputsOutputs.c 
   Aurthor: 
   
   Description:  
   
   Version Log          Notes                                     Changes Made by                                        
   --------------       -----                                     ---------------
   14-10-10:            Created                                   Stuart


** ------------------------------------------------------------------------------
                                    
                                    Overview
                                            
** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

/* library headers */
#include "stdio.h"
#include "float.h"
#include "math.h"

/* Application headers */
#include "CRG 100110.h" 
#include "Subs.h"
#include "SlcdSubs.h"
#include "ModBusM Int.h"
#include "ModBusM.h"
#include "EEPROM.h"
#include "SLCD 260217.h"
#include "winMain.h"
#include "winKey.h"
#include "Language.h"


/* Implements this interface: */
#define WININPUTSOUTPUTS_C
#include "winInputsOutputs.h"

#pragma CODE_SEG WININPUTSOUTPUTS_CODE
#pragma DATA_SEG WININPUTSOUTPUTS_DATA


/* private */
static byte winInputsOutputsState;



/* public */
byte winInputsOutputsReturnWin;


/*
** ------------------------------------------------------------------------------
**		Function: void winInputsOutputsKeyHandler(byte key)
** ------------------------------------------------------------------------------
*/

void winInputsOutputsKeyHandler(byte key)
{   
   switch (key)
   {
   case 128:       /* EXIT */
      winInputsOutputsReturnWin = BASIC_CONFIG_WINDOW;
      /* shut down num key window handler */
      winInputsOutputsState = WIN_INPUTS_OUTPUTS_UNLOAD;  
      break;  
      
   case 1:       /* Digital Inputs */
      /* switch page */
      winInputsOutputsReturnWin = DIGITALIN_WINDOW;
      /* shut down num key window handler */
      winInputsOutputsState = WIN_INPUTS_OUTPUTS_UNLOAD;       
      break;  
      
   case 2:       /* Digital Outputs */
      /* switch page */
      winInputsOutputsReturnWin = DIGITALOUT_WINDOW;
      /* shut down num key window handler */
      winInputsOutputsState = WIN_INPUTS_OUTPUTS_UNLOAD;       
      break; 
      
   case 3:       /* Analogue Inputs */
      /* switch page */
      winInputsOutputsReturnWin = ANALOGUEIN_WINDOW;
      /* shut down num key window handler */
      winInputsOutputsState = WIN_INPUTS_OUTPUTS_UNLOAD;       
      break;  
      
   case 4:       /* Analogue Outputs */
      /* switch page */
      winInputsOutputsReturnWin = ANALOGUEOUT_WINDOW;
      /* shut down num key window handler */
      winInputsOutputsState = WIN_INPUTS_OUTPUTS_UNLOAD;       
      break; 
      
   case 5:
      winInputsOutputsReturnWin = FIELDBUS_WINDOW;
      /* shut down num key window handler */
      winInputsOutputsState = WIN_INPUTS_OUTPUTS_UNLOAD;  
      break;      
             
   }
}


/*
** ------------------------------------------------------------------------------
**		Function: void ReadInputsOutputsParameters(void)
** ------------------------------------------------------------------------------
*/

void ReadInputsOutputsParameters(void)
{


}


/*
** ------------------------------------------------------------------------------
**		Function: void UpdateInputsOutputs(void)
** ------------------------------------------------------------------------------
*/

void UpdateInputsOutputs(void)
{
   /* requested update */
   if (winUpdate1==1)
   {
      /* stop counter */
      winUpdate1 = 0;
      
   }

   /* time to update? */
   if (!winTimer1)
   {
      winTimer1 = 25;

   }
}

/*
** ------------------------------------------------------------------------------
**		Function: byte winInputsOutputsHandler(void)
** ------------------------------------------------------------------------------
*/

byte winInputsOutputsHandler(void)
{
   switch (winInputsOutputsState)
   {
   case WIN_INPUTS_OUTPUTS_PREPAINT:
      /* get analog parameters from slave */
      ReadInputsOutputsParameters();

      /* set delay for parameters to arrive from MCT  */
      winUpdate1 = 15;
            
      winInputsOutputsState = WIN_INPUTS_OUTPUTS_PAINT;
      break;
      
   case WIN_INPUTS_OUTPUTS_PAINT:
      if(winUpdate1==1)
      {
         winUpdate1 = 0;   

         slcd_SetColour(DarkGrey, DarkGrey);
         slcd_Send("z");

         slcd_Send("xc all");     
         /* display menu screen */
         //DisplayBmp(16, 0, 0, LEFT_ALIGN); 
         slcd_DisplayBmp(10, 0, 0); 

         DisplayTitle("MS Instrumentos");
         
         slcd_SetFont(24, 0);
         slcd_SetColour(DarkGrey, White); 
         slcd_SendText(gstr(&str->InputsAndOutputs), 15, 60, 0, LEFT_ALIGN);
         
         /* define back hotspot */
         slcd_MakeHotSpot(128, 560, 10, 50, 50);

         /* display buttons */   
         slcd_MakeButton(1, 1, 30,  120,  2, 3);
         slcd_MakeButton(2, 1, 30,  200,  2, 3);
         slcd_MakeButton(5, 1, 30,  280,  2, 3);
         
         slcd_MakeButton(3, 1, 320, 120,  2, 3);
         slcd_MakeButton(4, 1, 320, 200,  2, 3);   
         
         slcd_SetColour(DarkGrey, White);
         slcd_SetFont(16, 0);
         
         slcd_SendText(gstr(&str->DigitalInputs),     115, 120, 0, LEFT_ALIGN);
         slcd_SendText(gstr(&str->DigitalOutputs),    115, 200, 0, LEFT_ALIGN);
         slcd_SendText(gstr(&str->FieldBus),          115, 280, 0, LEFT_ALIGN);
         
         slcd_SendText(gstr(&str->AnalogueInputs),    405, 120, 0, LEFT_ALIGN);
         slcd_SendText(gstr(&str->AnalogueOutputs),   405, 200, 0, LEFT_ALIGN);

         /* update parameters */
         winUpdate1 = 1;
         
         /* move to update state */      
         winInputsOutputsState = WIN_INPUTS_OUTPUTS_UPDATE;       
      }
      break;

   
   case WIN_INPUTS_OUTPUTS_UPDATE:
      /* is there a key to process? */
      if (slcdKey)
      {
         /* call key handler */
         winInputsOutputsKeyHandler(slcdKey);      
         /* now the key has been processed clear it */
         slcdKey = 0; 
      }

      UpdateInputsOutputs();

      /* has any data been remotely changed? */
      if(mbSlave.DataUpdate)
      {
         /* clear data update flag */
         mbSlave.DataUpdate = 0;
         mbTable[enDataUp].WrFlg = 1;   
         
         /* read analog parameters */
         ReadInputsOutputsParameters();  
         
         /* set update timer */                   
         winUpdate1 = 100;
      }      
      return 0;

      
   case WIN_INPUTS_OUTPUTS_UNLOAD:
      /* do any necessary clearing up */
      winInputsOutputsState = WIN_INPUTS_OUTPUTS_PREPAINT;  

      /* set return menu */
      winActiveWin = winInputsOutputsReturnWin;

      /* return from key pad */
      return 1;
   }   
}



