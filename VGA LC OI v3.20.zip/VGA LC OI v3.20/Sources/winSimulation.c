#include <hidef.h>                           /* common defines and macros */
#include "derivative.h"                      /* derivative information */

/*
** ------------------------------------------------------------------------------
   
   File   : winSimulation.c 
   Aurthor: 
   
   Description:  
   
   Version Log          Notes                                     Changes Made by                                        
   --------------       -----                                     ---------------
   25-07-10:            Created                                   Stuart


** ------------------------------------------------------------------------------
                                    
                                    Overview
                                            
** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

/* library headers */
#include "stdio.h"
#include "float.h"
#include "math.h"

/* Application headers */
#include "CRG 100110.h" 
#include "Subs.h"
#include "ModBusM Int.h"
#include "ModBusM.h"
#include "EEPROM.h"
#include "SLCD 260217.h"
#include "winMain.h"
#include "winKey.h"
#include "Language.h"
#include "SlcdSubs.h"

/* Implements this interface: */
#define WINSIMULATION_C
#include "winSimulation.h"

#pragma CODE_SEG WINSIMULATION_Code
#pragma DATA_SEG WINSIMULATION_Data


/* private */
static byte winSimulationState;
static byte winSimulationPage;


/* public */



/*
** ------------------------------------------------------------------------------
**		Function: void winSimulationKeyHandler(byte key)
** ------------------------------------------------------------------------------
*/

void winSimulationKeyHandler(byte key)
{   
   switch (key)
   {
   case 1:
      /* change state */
      mbSlave.SpeedSimEn ^= 1;
      /* set write flag */
      mbTable[enSpeedSimEn].WrFlg = 1;       
      break;

   case 3:
      /* change state */
      mbSlave.MassSimEn ^= 1;
      /* set write flag */
      mbTable[enMassSimEn].WrFlg = 1;       
      break;
            
   case 128:       /* EXIT */
      /* shut down num key window handler */
      winSimulationState = WIN_SIMULATION_UNLOAD;  
      break;  
      
   case 130:      /* Speed Simulator */
      /* move to key pad handler sate */
      winSimulationState = WIN_SIMULATION_NUMKEYPAD; 
      
      /* copy parameter data to key structure */
      strcpy(NumKeyData.Name, gstr(&str->SpeedSimulator));  
      NumKeyData.KeyBoardType = NUMBER;
      NumKeyData.Type = FLOAT;
      NumKeyData.fMax = 10.0;
      NumKeyData.fMin = 1.0;
      NumKeyData.Flag = enSpeedSim;
      NumKeyData.DataPtr = (void *)&mbSlave.SpeedSim;     
      break;      

   case 132:      /* Mass Simulator */
      /* move to key pad handler sate */
      winSimulationState = WIN_SIMULATION_NUMKEYPAD; 
      
      /* copy parameter data to key structure */
      strcpy(NumKeyData.Name, gstr(&str->MassSimulator));  
      NumKeyData.KeyBoardType = NUMBER;
      NumKeyData.Type = FLOAT;
      NumKeyData.fMax = 20.0;
      NumKeyData.fMin = 1.0;
      NumKeyData.Flag = enMassSim;
      NumKeyData.DataPtr = (void *)&mbSlave.MassSim;     
      break;
         
   }
}

/*
** ------------------------------------------------------------------------------
**		Function: void ReadSimulationParameters(void)
** ------------------------------------------------------------------------------
*/

void ReadSimulationParameters(void)
{
   mbTable[enMassSim].RdFlg = 0x1;
   mbTable[enMassSimEn].RdFlg = 0x1;
   mbTable[enSpeedSim].RdFlg = 0x1;
   mbTable[enSpeedSimEn].RdFlg = 0x1;
}

/*
** ------------------------------------------------------------------------------
**		Function: void PaintFilteringPage(void)
** ------------------------------------------------------------------------------
*/

void PaintSimulationPage(void)
{   
   byte Buf[25];
   lButtonType Button;   
   byte ButtonText1[20], ButtonText2[20];   
   
   if(PanelSize == PSZ_1024_600)
      slcd_SetFont(14, 0);  
   else   
      slcd_SetFont(16, 'B');  
   
   /* set colours back */
   slcd_SetColour(DarkGrey, White);         

   /* display headings */
   slcd_SendText(gstr(&str->SpeedSimulator), 27,  ccY0, 0, LEFT_ALIGN);     
   slcd_SendText(gstr(&str->MassSimulator),  327, ccY0, 0, LEFT_ALIGN);  

   if(PanelSize == PSZ_1024_600)
      slcd_SetFont(14, 0);  
   else
      slcd_SetFont(16, 'B');  
   
   slcd_SendText(gstr(&str->Speed), 27,  ccY1, 0, LEFT_ALIGN);
   slcd_SendText(gstr(&str->Mass),  400, ccY1, 0, LEFT_ALIGN);

   /* set colours back */
   slcd_SetColour(LightBlue, White);         

   /* Speed Sim */
   sprintf(Buf, "%.1f m/s", mbSlave.SpeedSim);
   slcd_SendText(&Buf, 227, ccY1, 0, LEFT_ALIGN);
   
   /* Mass Sim */
   sprintf(Buf, "%.1f kg/m", mbSlave.MassSim);
   slcd_SendText(&Buf, 530, ccY1, 0, LEFT_ALIGN);
  
   //
   /*Como funciona: 
   xs ->comando do slcd;<n>-> n? de index; x0,y0 s?o posi??o do v?rtice superior e x1,y1 s?o posi??o do v?rtice inferior.
   Assim, faz-se x1-x0 para o tamanho do comprimento e y1-y0 para o tamanho da altura    
   */
   slcd_MakeHotSpot(130, 227, ccY1, 32, 128);
   slcd_MakeHotSpot(132, 530, ccY1, 32, 128);

   if(PanelSize == PSZ_1024_600)
      slcd_SetFont(14, 0);  
   
   /* set colours back */
   slcd_SetColour(Red, Blue); 
   
   Button.Id = 1;
   Button.x = 227;
   Button.y = ccY0;
   Button.type = 2;
   Button.state = mbSlave.SpeedSimEn;
   strcpy(ButtonText1, gstr(&str->OFF));      
   strcpy(ButtonText2, gstr(&str->ON));      
   Button.text0 = ButtonText1;
   Button.text1 = ButtonText2;
   Button.dx0 = 16;
   Button.dy0 = 8;
   Button.dx1 = 22;
   Button.dy1 = 8;
   Button.bmp0 = 27;
   Button.bmp1 = 26;  
       
   /* define start/stop button */
   slcd_MakeLatchingButton(&Button);  


   Button.Id = 3;
   Button.x = 540;
   Button.y = ccY0;
   Button.state = mbSlave.MassSimEn;
       
   /* define start/stop button */
   slcd_MakeLatchingButton(&Button);  
   
   /* force update */
   winUpdate1 = 1;
}


/*
** ------------------------------------------------------------------------------
**		Function: void UpdateSimulation(void)
** ------------------------------------------------------------------------------
*/

void UpdateSimulation(void)
{   
   byte Buf[25];
   
   /* requested update */
   if (winUpdate1==1)
   {
      /* stop counter */
      winUpdate1 = 0;

      /* set colours back */
      slcd_SetColour(LightBlue, White);       

      if(PanelSize == PSZ_1024_600)
         slcd_SetFont(14, 0);  
      else
         slcd_SetFont(16, 'B');  
      
      /* Speed Sim */
      sprintf(Buf, "%.1f m/s", mbSlave.SpeedSim);
      slcd_SendText(&Buf, 227, ccY1, 0, LEFT_ALIGN);
      
      /* Mass Sim */
      sprintf(Buf, "%.1f kg/m", mbSlave.MassSim);
      slcd_SendText(&Buf, 530, ccY1, 0, LEFT_ALIGN);
   
   }

   /* time to update? */
   if (!winTimer1)
   {
      //winTimer1 = 25;

     
   }
}

/*
** ------------------------------------------------------------------------------
**		Function: byte winSimulationHandler(void)
** ------------------------------------------------------------------------------
*/

byte winSimulationHandler(void)
{
   switch (winSimulationState)
   {
   case WIN_SIMULATION_PREPAINT:
      /* get analog parameters from slave */
      ReadSimulationParameters();
      winSimulationState = WIN_SIMULATION_PAINT;
      break;
      
   case WIN_SIMULATION_PAINT:
      slcd_SetColour(DarkGrey, DarkGrey);
      slcd_Send("z");

      slcd_Send("xc all");     
      /* display menu screen */
      //DisplayBmp(16, 0, 0, LEFT_ALIGN); 
      slcd_DisplayBmp(10, 0, 0); 

      DisplayTitle("MS Instrumentos");
      
      slcd_SetFont(24, 0);
      slcd_SetColour(DarkGrey, White); 
      slcd_SendText(gstr(&str->Simulation), 15, 60, 0, LEFT_ALIGN);
      
      /* define back hotspot */
      //slcd_CmdQueue("x 128 560 10 630 60");
      slcd_MakeHotSpot(128, 560, 10, 50, 50);
      
      /* update parameters */
      winUpdate1 = 1;
      
      /* move to update state */      
      winSimulationState = WIN_SIMULATION_PAINT_PAGE;       
      break;

   case WIN_SIMULATION_PAINT_PAGE:
   
               
      PaintSimulationPage();
      
      /* move to update state */      
      winSimulationState = WIN_SIMULATION_UPDATE;       
      break;

   case WIN_SIMULATION_UPDATE:
      /* is there a key to process? */
      if (slcdKey)
      {
         /* call key handler */
         winSimulationKeyHandler(slcdKey);      
         /* now the key has been processed clear it */
         slcdKey = 0; 
      }

      UpdateSimulation();

      /* has any data been remotely changed? */
      if(mbSlave.DataUpdate)
      {
         /* clear data update flag */
         mbSlave.DataUpdate = 0;
         mbTable[enDataUp].WrFlg = 1;   
         
         /* read analog parameters */
         ReadSimulationParameters();  
         
         /* set update timer */                   
         winUpdate1 = 100;
      }      
      break;

  case WIN_SIMULATION_NUMKEYPAD:
      /* see if key pad is returning */
      if(winKeyPadHandler())
         /* move to update state */      
         winSimulationState = WIN_SIMULATION_PAINT;   
      break;

   case WIN_SIMULATION_UNLOAD:
      /* do any necessary clearing up */
      winSimulationState = WIN_SIMULATION_PREPAINT;  

      /* clear page */
      winSimulationPage = 0;
      
      /* switch to menu screen */
      winActiveWin = SPECIALFUNC_WINDOW;  


      /* return from key pad */
      return 1;
   }   
}



