#include <hidef.h>                           /* common defines and macros */
#include "derivative.h"       /* derivative information */

/*
** ------------------------------------------------------------------------------
   
   File   : Timer.c 
   Aurthor: 
   
   Description:  
   
   Version Log          Notes                                     Changes Made by                                        
   --------------       -----                                     ---------------
   25-06-11:            Created                                   Stuart Clarke
        
** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

/* library headers */


/* Application headers */



/* Implements this interface: */
#define TIMER_C
#include "Timer.h"

#pragma CODE_SEG   ROM_F200_SEG
#pragma DATA_SEG   TIMER_DATA

/* private */



/* public */

word _Timer1S;

/*
** ------------------------------------------------------------------------------
**		Function: void _Timer_Init(void)
** ------------------------------------------------------------------------------
*/

void _Timer_Init(void)
{
	/* Timer Input Capture/Output Compare Select Register (TIOS) */
   TIOS |= 0x03;	
  	/* set Timer Input Capture/Output Compare Register (TC0) */
   TC0 = 12500;					     	
  	/* clear Main Timer Interrupt Flag 1 (TFLG1)  */
  	TFLG1 = 0x01;                         	
  	/* Timer Interrupt Enable Register (TIE) */
   TIE  |= 0x01; 
   
  	/* set Timer System Control Register 2 (TSCR2)  /32 */
  	TSCR2_PR  = 5;        			      
  	/* set timer enable bit in Timer System Control Register 1 (TSCR1) */
  	TSCR1_TEN = 1;                          
}

/*
** ------------------------------------------------------------------------------
**		#pragma: Ram Relocation segment 
** ------------------------------------------------------------------------------
*/

#pragma CODE_SEG ROM_F000_SEG

/*
** ------------------------------------------------------------------------------
**		Function: static void _ETC0_Interrupt(void)
** ------------------------------------------------------------------------------
*/

__interrupt void near _ETC0_Interrupt(void)
{
	#pragma MESSAGE DISABLE C2705 /* Possible loss of data */
	
	/* 10 mS @ 40 MHz */
	TC0 += 12500;			
	TFLG1 = 0x01; 
	
	if(_Timer1S)
	   _Timer1S--;
}
