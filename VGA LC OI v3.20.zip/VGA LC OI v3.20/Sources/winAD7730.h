/*
** ------------------------------------------------------------------------------
   
   File   : winAD7730.h 
   Aurthor: Stuart Clarke

** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

#ifndef WINAD7730_H
#define WINAD7730_H


/* public defines */

/*
** ------------------------------------------------------------------------------
**		#define : user menu handler states 
** ------------------------------------------------------------------------------
*/

#define WIN_AD7730_PREPAINT     0
#define WIN_AD7730_PAINT        1
#define WIN_AD7730_UPDATE       2
#define WIN_AD7730_NUMKEYPAD    3
#define WIN_AD7730_UNLOAD       4
#define WIN_AD7730_ENTER_PASSWORD 5


/*
** ------------------------------------------------------------------------------
**		#define : AD7730 register bit coordinate defines  
** ------------------------------------------------------------------------------
*/

#define x1     40     
#define x2     x1+76     
#define x3     x2+76     
#define x4     x3+76     
#define x5     x4+76     
#define x6     x5+76     
#define x7     x6+76     
#define x8     x7+76 

#ifndef WINAD7730_C

/* public variables */
#pragma DATA_SEG WINAD7730_DATA

extern byte winAD7730ReturnWin;

#endif   /* WINAD7730_C */      


/* public functions */
#pragma CODE_SEG WINAD7730_CODE


/*
** ------------------------------------------------------------------------------
**		Function: void ReadAD7730Parameters(void)
** ------------------------------------------------------------------------------
*/

void ReadAD7730Parameters(void);

/*
** ------------------------------------------------------------------------------
**		Function: byte winAD7730Handler(void)
** ------------------------------------------------------------------------------
*/

byte winAD7730Handler(void);

#endif   /* WINAD7730_H */
