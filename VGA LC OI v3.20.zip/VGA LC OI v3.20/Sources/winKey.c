#include <hidef.h>                           /* common defines and macros */
#include "derivative.h"                      /* derivative information */

/*
** ------------------------------------------------------------------------------
   
   File   : winKey.c 
   Aurthor: 
   
   Description:  
   
   Version Log          Notes                                     Changes Made by                                        
   --------------       -----                                     ---------------
   03-04-09:            Created                                   Stuart


** ------------------------------------------------------------------------------
                                    
                                    Overview
                                            
** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

/* library headers */
#include "stdio.h"

/* Application headers */
#include "Subs.h"
#include "SlcdSubs.h"
#include "ModBusM Int.h"
#include "EEPROM.h"
#include "SLCD 260217.h"
#include "winMain.h"
#include "Language.h"
#include "winUserMenu.h"


/* Implements this interface: */
#define WINKEYPAD_C
#include "winKey.h"

#pragma CODE_SEG WINKEYPAD_Code
#pragma DATA_SEG WINKEYPAD_Data


/* private */
static byte winKeyState;
static byte NumEditBuf[30];
static byte EditIndex;
static byte CursorState;
static byte keyReturnVal;
static byte AutoClear;
static byte AltKeyPad;

/* public */
NumKeyType NumKeyData;

word PassWord;
 
/*
** ------------------------------------------------------------------------------
**		Function: void winKeyPadKeyHandler(byte key)
** ------------------------------------------------------------------------------
*/

void winKeyPadKeyHandler(byte key)
{
   byte i;
   float f;
   word w, j,k,m,n;
   long l;
   
   if(!AutoClear && key !=61)
   {
      AutoClear = 1;   

      /* clear edit buffer */      
      memset(NumEditBuf, 0, 20);
      strcpy(NumEditBuf, " ");
      slcd_Send("f 14x24"); 


      /* clear edit buffer area */
      if(NumKeyData.KeyBoardType == NUMBER)
      {
         #ifdef FIVEPOINTSEVEN
         slcd_SendText("           ", 129, 159, 0, LEFT_ALIGN); 
         #else                   
         slcd_SendText("                ", 129, 159, 0, LEFT_ALIGN);                     
         #endif
         
         /* display new buffer */      
         slcd_SendText(NumEditBuf, 129, 159, 0, LEFT_ALIGN);
      }
      else
      {
         #ifdef FIVEPOINTSEVEN
         slcd_SendText("           ", 147, 89, 0, LEFT_ALIGN); 
         #else      
         slcd_SendText("                ", 147, 89, 0, LEFT_ALIGN);                     
         #endif
         
         /* display new buffer */      
         slcd_SendText(NumEditBuf, 147, 89, 0, LEFT_ALIGN);      
      }
   }
    
   switch (key)
   {
   case 128:       /* EXIT */
      /* shut down num key window handler */
      winKeyState = WIN_KEY_UNLOAD;  
      /* set key return value */
      keyReturnVal = 1;         
      break;
      
   case 31:       /* ALT */
      /* switch key pad */
      AltKeyPad ^= 0x80;

      PaintKeyBoard();
      
      /* move to paint state */      
      //KeyPadState = PAINT;      
      break;
            
   case 46:       /* . */
      if(NumKeyData.Type==FLOAT||NumKeyData.Type==IPADR||NumKeyData.Type==TIME)
      {
         if(EditIndex<15)
         {
            /* place new number in buffer */
            //NumEditBuf[EditIndex++] = key;         
            NumEditBuf[EditIndex++] = '.';         

            if(!NumEditBuf[EditIndex])
            {
               NumEditBuf[EditIndex] = ' ';
               NumEditBuf[EditIndex+1] = 0;         
            }
            
            /* force update */
            winTimer1   = 1;
            CursorState = 1;
         }         
      }
      else
      {
         /* send beep command */
         slcd_CmdQueue("beep 500");             
      }
      break;
      
   case 58:       /* : */
      if(NumKeyData.Type==TIME)
      {
         if(EditIndex<15)
         {
            /* place new number in buffer */
            NumEditBuf[EditIndex++] = key;         

            if(!NumEditBuf[EditIndex])
            {
               NumEditBuf[EditIndex] = ' ';
               NumEditBuf[EditIndex+1] = 0;         
            }
            
            /* force update */
            winTimer1   = 1;
            CursorState = 1;
         }         
      }
      else
      {
         /* send beep command */
         slcd_CmdQueue("beep 500");             
      }
      break;

   case 47:       /* / */
      if(NumKeyData.Type==DATE)
      {
         if(EditIndex<15)
         {
            /* place new number in buffer */
            NumEditBuf[EditIndex++] = key;         

            if(!NumEditBuf[EditIndex])
            {
               NumEditBuf[EditIndex] = ' ';
               NumEditBuf[EditIndex+1] = 0;         
            }
            
            /* force update */
            winTimer1   = 1;
            CursorState = 1;
         }         
      }
      else
      {
         /* send beep command */
         slcd_CmdQueue("beep 500");             
      }
      break;
            
   case '-':       /* - */
      if(!EditIndex)
      {
         /* place new number in buffer */
         NumEditBuf[EditIndex++] = '-';         

         if(!NumEditBuf[EditIndex])
         {
            NumEditBuf[EditIndex] = ' ';
            NumEditBuf[EditIndex+1] = 0;         
         }
         /* force update */
         winTimer1   = 1;
         CursorState = 1;
      }
      break;
      
   case '<':
      if(EditIndex)
      {
         /* place new number in buffer */
         NumEditBuf[EditIndex--] = ' ';  
         /* force update */
         winTimer1   = 1;
         CursorState = 1;
      }                
      break;

   case 63:       /* CE */
      /* clear edit buffer area */
      #ifdef FIVEPOINTSEVEN
      DisplayText("        ", 129, 159, 0);                     
      #else                   
      DisplayText("           ", 129, 159, 0);                     
      #endif
      
      /* clear edit buffer */      
      memset(NumEditBuf, 0, 20);
      strcpy(NumEditBuf, " ");
      /* reset index and cursor state */      
      EditIndex   = 0;   
      CursorState = 0;
      /* display new buffer */      
      DisplayText(NumEditBuf, 129, 159, 0);
      /* force update */
      winTimer1   = 1;                     
      break;
      
   case 61:       /* Enter */

    switch (NumKeyData.Type)
      {
      case FLOAT:
         /* scan edit buffer */
         sscanf(NumEditBuf, "%f ", &f);
         
         /* check its within limits */         
         if(f>=NumKeyData.fMin && f<=NumKeyData.fMax)
         {
            /* is data in EEPROM */
            if(NumKeyData.Attributes==EPROM)
            {
               EEWR_fl((float *)NumKeyData.DataPtr, f);                 
            }
            else
            {
               /* must be in RAM */
               
               /* copy new value */
               *(float *)NumKeyData.DataPtr = f;

               /* if flag is zero data is not remote */
               if(NumKeyData.Flag)
               {
                  if(NumKeyData.Attributes==SEREE)
                     /* get com to send new value */            
                     mbTable[NumKeyData.Flag].WrFlg = 0x64;                        
                  else                                    
                     /* get com to send new value */            
                     mbTable[NumKeyData.Flag].WrFlg = 0x01;                        
               }
            }

            /* is the funtion pointer loaded ? */
            if(NumKeyData.fp)
            {
               /* call */
               (NumKeyData.fp)();
            }
                  
            /* shut down num key window handler */
            winKeyState = WIN_KEY_UNLOAD;     
            /* set key return value */
            keyReturnVal = 1;
         }
         else
         {
            /* display error */   
            /* send beep command */
            slcd_CmdQueue("beep 500");             
         }
         break;   
            
      case BYTE:         
      case WORD:
      case PASSWORD:
         /* scan edit buffer */
         sscanf(NumEditBuf, "%u ", &w);
         
         /* check its within limits */         
         if(w>=NumKeyData.iMin && w<=NumKeyData.iMax)
         {
            /* is data in EEPROM */
            if(NumKeyData.Attributes==EPROM)
            {
               if(NumKeyData.Type==BYTE)
                  EEWR_8((byte *)NumKeyData.DataPtr, (byte)w);                 
               else
                  EEWR_16((word *)NumKeyData.DataPtr, w);                 
            }
            else
            {
               /* must be in RAM */
               if(NumKeyData.Type==BYTE)
                  *(byte *)NumKeyData.DataPtr = (byte)w;
               else
                  *(word *)NumKeyData.DataPtr = w;
               
               /* if flag is zero data is not remote */
               if(NumKeyData.Flag)
                  /* get com to send new value */            
                  mbTable[NumKeyData.Flag].WrFlg = (0x1<<NumKeyData.Index);                        
            }
            
            /* is the funtion pointer loaded ? */
            if(NumKeyData.fp)
            {
               /* call */
               (NumKeyData.fp)();
            }
            
            /* shut down num key window handler */
            winKeyState = WIN_KEY_UNLOAD;   
            /* set key return value */
            keyReturnVal = 1;
         }
         else
         {
            /* display error */   
            /* send beep command */
            slcd_CmdQueue("beep 500");             
         }
         break;    

      case LONG:
         /* scan edit buffer */
         sscanf(NumEditBuf, "%ld ", &l);
         
         /* check its within limits */         
         if(l>=NumKeyData.lMin && l<=NumKeyData.lMax)
         {
            /* is data in EEPROM */
            if(NumKeyData.Attributes==EPROM)
            {
               EEWR_32((long *)NumKeyData.DataPtr, l);                 
            }
            else
            {
               *(long *)NumKeyData.DataPtr = l;
               
               /* if flag is zero data is not remote */
               if(NumKeyData.Flag)
                  /* get com to send new value */            
                  mbTable[NumKeyData.Flag].WrFlg = (0x1<<NumKeyData.Index);                        
            }
            
            /* is the funtion pointer loaded ? */
            if(NumKeyData.fp)
            {
               /* call */
               (NumKeyData.fp)();
            }
            
            /* shut down num key window handler */
            winKeyState = WIN_KEY_UNLOAD;   
            /* set key return value */
            keyReturnVal = 1;
         }
         else
         {
            /* display error */   
            /* send beep command */
            slcd_CmdQueue("beep 500");             
         }
         break;    
         
      case ENTERPASSWORD:
         /* scan edit buffer */
         sscanf(NumEditBuf, "%u ", &PassWord);
         
         switch (winUserReturnWin)
         {
         case SPEEDCAL_WINDOW:
         case BASIC_CONFIG_WINDOW:
            /* check its within limits */         
            if(PassWord==2020)
            {
               /* shut down num key window handler */
               winKeyState = WIN_KEY_UNLOAD;
               /* set key return value */
               keyReturnVal = 2;
            }
            else
            {
               /* send beep command */
               slcd_CmdQueue("beep 500");                  
            }
            break;                      

         case BALANCE_DATA_WINDOW:
            if(PassWord==6811)
            {
               /* shut down num key window handler */
               winKeyState = WIN_KEY_UNLOAD;
                           
               /* is the funtion pointer loaded ? */
               if(NumKeyData.fp)
               {
                  /* call */
                  (NumKeyData.fp)();
               } 
               keyReturnVal = 1;              
            }
            break;
            
         case ENGINEERING_WINDOW:
            /* check its within limits */         
            if(PassWord==2882)
            {
               /* shut down num key window handler */
               winKeyState = WIN_KEY_UNLOAD;
               /* set key return value */
               keyReturnVal = 2;
            }
            else
            {
               /* send beep command */
               slcd_CmdQueue("beep 500");                  
            }
            break;             
         }
         break; 

      case IPADR:
         /* scan edit buffer */
         w = sscanf(NumEditBuf, "%u.%u.%u.%u", &j, &k, &m, &n);
		   
		   if(w!=4||j>255||k>255||m>255||n>255)         
         {
            /* display error */   
            /* send beep command */
            slcd_CmdQueue("beep 500");             
         }
         else         
         {
            *(word *)NumKeyData.DataPtr = j;
            *(word *)NumKeyData.DataPtr1 = k;
            *(word *)NumKeyData.DataPtr2 = m;
            *(word *)NumKeyData.DataPtr3 = n;
            
            /* if flag is zero data is not remote */
            if(NumKeyData.Flag)
               /* get com to send new value */            
               mbTable[NumKeyData.Flag].WrFlg = (0x1<<NumKeyData.Index);                        

            /* shut down num key window handler */
            winKeyState = WIN_KEY_UNLOAD;   
            /* set key return value */
            keyReturnVal = 1;

         }
         break;  

      case ASCI:         
         /* scan edit buffer */
         sscanf(NumEditBuf, "%d ", &w);
         
         /* check its within limits */         
         if(w>=NumKeyData.iMin && w<=NumKeyData.iMax)
         {
            /* is data in EEPROM */
            if(NumKeyData.Attributes==EPROM)
            {
               EEWR_8((byte *)NumKeyData.DataPtr, (byte)w+0x30);                 
            }
            else
            {
               /* must be in RAM */
               *(byte *)NumKeyData.DataPtr = (byte)w+0x30;
               
               /* if flag is zero data is not remote */
               if(NumKeyData.Flag)
                  /* get com to send new value */            
                  mbTable[NumKeyData.Flag].WrFlg = (0x1<<NumKeyData.Index);                        
            }
            
            /* shut down num key window handler */
            winKeyState = WIN_KEY_UNLOAD;   
            /* set key return value */
            keyReturnVal = 1;
         }
         else
         {
            /* display error */   
            /* send beep command */
            slcd_CmdQueue("beep 500");             
         }
         break;     
      
      case STRING:         
         /* remove trailing spaces */
         
         i = strlen(NumEditBuf)-1;
         
         while(NumEditBuf[i]==' ')
         {
            NumEditBuf[i--]=0;                 
         };
         
         /* scan edit buffer */
         w = strlen(NumEditBuf);
         
         /* check its within limits */         
         if(w<=NumKeyData.iMax)
         {
            /* is data in EEPROM */
            if(NumKeyData.Attributes==EPROM)
            {
               EEWR_Str((byte *)NumKeyData.DataPtr, NumEditBuf, strlen(NumEditBuf));                 
            }
            else
            {
               /* must be in RAM */
               strcpy((byte *)NumKeyData.DataPtr, NumEditBuf);
               
               /* if flag is zero data is not remote */
               if(NumKeyData.Flag)
               {
                  if(NumKeyData.Attributes==SEREE)
                     /* get com to send new value */            
                     mbTable[NumKeyData.Flag].WrFlg = 0x64;                        
                  else                                    
                     /* get com to send new value */            
                     mbTable[NumKeyData.Flag].WrFlg = 0x01;                        
               }
            }

            /* is the funtion pointer loaded ? */
            if(NumKeyData.fp)
            {
               /* call */
               (NumKeyData.fp)();
            }
            
            /* shut down num key window handler */
            winKeyState = WIN_KEY_UNLOAD;   
            /* set key return value */
            keyReturnVal = 1;
         }
         else
         {
            /* display error */   
            /* send beep command */
            slcd_CmdQueue("beep 500");             
         }
         break;                         

      case TIME:         
         /* remove trailing spaces */
         
         i = strlen(NumEditBuf)-1;
         
         while(NumEditBuf[i]==' ')
         {
            NumEditBuf[i--]=0;                 
         };
         
         i = sscanf(NumEditBuf, "%X:%X:%X", &w, &j, &k);
         //i = sscanf(NumEditBuf, "%X:%X", &w, &j);
         if(i!=3 || ((w&0xF0)>>4)>2 || (w&0x0F)>11 || ((j&0xF0)>>4)>5 || (j&0x0F)>9 || ((k&0xF0)>>4)>5 || (k&0x0F)>9 )
         //if(i!=2 || ((w&0xF0)>>4)>2 || (w&0x0F)>11 || ((j&0xF0)>>4)>5 || (j&0x0F)>9)
         {
            /* erorr */
            slcd_CmdQueue("beep 500"); 
         }
         else
         {                     
            /* must be in RAM */
            strcpy((byte *)NumKeyData.DataPtr, NumEditBuf);
               
            /* get com to send new value */            
            mbTable[NumKeyData.Flag].WrFlg = 0x01;                        

            /* shut down num key window handler */
            winKeyState = WIN_KEY_UNLOAD;   
            /* set key return value */
            keyReturnVal = 1;
         }
         break;                         
         
      case DATE:         
         /* remove trailing spaces */
         
         i = strlen(NumEditBuf)-1;
         
         while(NumEditBuf[i]==' ')
         {
            NumEditBuf[i--]=0;                 
         };
         
         i = sscanf(NumEditBuf, "%X/%X/%X", &w, &j, &k);
         if(i!=3 || ((w&0xF0)>>4)>3 || (w&0x0F)>9 || ((j&0xF0)>>4)>1 || (j&0x0F)>9 || ((k&0xF0)>>4)>9 || (k&0x0F)>9 )
         {
            /* erorr */
            slcd_CmdQueue("beep 500"); 
         }
         else
         {                     
            
            /* is data in EEPROM */
            if(NumKeyData.Attributes==EPROM)
            {
               EEWR_Str((byte *)NumKeyData.DataPtr, NumEditBuf, strlen(NumEditBuf));                 
            }
            else
            {
               /* must be in RAM */
               strcpy((byte *)NumKeyData.DataPtr, NumEditBuf);
               
               /* if flag is zero data is not remote */
               if(NumKeyData.Flag)
               {
                  /* get com to send new value */            
                  mbTable[NumKeyData.Flag].WrFlg = 0x01;                        
               }
            }

            /* is the funtion pointer loaded ? */
            if(NumKeyData.fp)
            {
               /* call */
               (NumKeyData.fp)();
            }            

            /* shut down num key window handler */
            winKeyState = WIN_KEY_UNLOAD;   
            /* set key return value */
            keyReturnVal = 1;
         }
         break;           
                  
      case NEWPASSWORD:
         /* scan edit buffer */
         sscanf(NumEditBuf, "%u ", &w);
         
         /* check its within limits */         
         if(w>=NumKeyData.iMin && w<=NumKeyData.iMax && w != 9999 && w != 2882 && w != 8228 && w != 6811)
         {
               *(word *)NumKeyData.DataPtr = w;
               
               /* if flag is zero data is not remote */
               if(NumKeyData.Flag)
                  /* get com to send new value */            
                  mbTable[NumKeyData.Flag].WrFlg = (0x1<<NumKeyData.Index);                        

            /* shut down num key window handler */
            winKeyState = WIN_KEY_UNLOAD;   
            /* set key return value */
            keyReturnVal = 1;
         }
         else
         {
            /* display error */   
            /* send beep command */
            slcd_CmdQueue("beep 500");             
         }
         break;    
      }
      break;     


   default:      
      if(NumKeyData.KeyBoardType == LETTER)
      {
         if(EditIndex<15)
         {
            /* place new number in buffer */
            NumEditBuf[EditIndex++] = key;         
            
            if(!NumEditBuf[EditIndex])
            {
               NumEditBuf[EditIndex] = ' ';
               NumEditBuf[EditIndex+1] = 0;         
            }
            
            /* force update */
            winTimer1   = 1;
            CursorState = 1;
         }
      }
      else
      {
         if(EditIndex<10)
         {
            /* place new number in buffer */
            NumEditBuf[EditIndex++] = key;         
            
            if(!NumEditBuf[EditIndex])
            {
               NumEditBuf[EditIndex] = ' ';
               NumEditBuf[EditIndex+1] = 0;         
            }
            
            /* force update */
            winTimer1   = 1;
            CursorState = 1;
         }         
      }
      break;     
   }
}

/*
** ------------------------------------------------------------------------------
**		Function: void PaintKeyPad(void)
** ------------------------------------------------------------------------------
*/

void PaintKeyPad(void)
{
   byte Buf[25];

   
   switch (NumKeyData.Type)
   {
   case TIME:
      slcd_MakeButtonTextXY(58, 434, 330, ":", 40, 25, 2, 3);
      break;
      
   case DATE:
      slcd_MakeButtonTextXY(47, 434, 330, "/", 40, 25, 2, 3);
      break;

   default:
      slcd_MakeButtonTextXY(46, 434, 330, ".", 40, 25, 2, 3);
      break;
   }
   
   slcd_SetFont(24, 0);
   slcd_SetColour(White, DarkGrey);    
   
   /* display parameter name */ 
   slcd_SendText(NumKeyData.Name, 12, 7, 'T', LEFT_ALIGN);  

   /* set colour for edit text */
   slcd_SetColour(DarkGrey, White);  
   
   /* set font F16x32 */
   slcd_Send("f 14x24");   
   
   switch (NumKeyData.Type)
   {
   case FLOAT:
      /* format edit buffer */
      sprintf(NumEditBuf, "%.3f ", *(float *)NumKeyData.DataPtr);
      break;   
   
   case NEWPASSWORD:
   case WORD:
      /* format edit buffer */
      sprintf(NumEditBuf, "%u ", *(word *)NumKeyData.DataPtr);
      break;   

   case LONG:
      /* format edit buffer */
      sprintf(NumEditBuf, "%ld ", *(long *)NumKeyData.DataPtr);
      break;   

   case BYTE:
      /* format edit buffer */
      sprintf(NumEditBuf, "%u ", *(byte *)NumKeyData.DataPtr);
      break;   

   case PASSWORD:
      /* format edit buffer */
      sprintf(NumEditBuf, "%04u ", *(word *)NumKeyData.DataPtr);
      break;   

   case ENTERPASSWORD:
      /* format edit buffer */
      sprintf(NumEditBuf, "%04u ", 0);
      break;   

   case IPADR:
      sprintf(NumEditBuf, "%u.%u.%u.%u  ", *(byte *)NumKeyData.DataPtr, *(byte *)NumKeyData.DataPtr1, *(byte *)NumKeyData.DataPtr2, *(byte *)NumKeyData.DataPtr3);  
      break;

   case ASCI:
      /* format edit buffer */
      sprintf(NumEditBuf, "%c ", *(byte *)NumKeyData.DataPtr);
      break;   
      

   case TIME:
   case DATE:
      /* format edit buffer */
      strcpy(NumEditBuf, NumKeyData.DataPtr);
      break;
   }

   /* reset edit index */
   //EditIndex = (strlen(NumEditBuf)-2);
   EditIndex   = 0;   
   CursorState = 0;
   
   slcd_SendText(NumEditBuf, 129, 159, 0, LEFT_ALIGN);  

   /* set colour for edit text */
   slcdSetColour(Black, White);  
   
   /* set font */
   slcdSetFont(F16);  
   
   /* display min text */
   switch (NumKeyData.Type)
   {
   case FLOAT:
      /* format edit buffer */
      sprintf(Buf, "%s %.2f", gstr(&str->Min), NumKeyData.fMin);
      /* display min text */
      slcd_SendText(Buf, 121, 221, 'T', LEFT_ALIGN);  
      break;   

   case BYTE:
   case WORD:
   case PASSWORD:
      /* format edit buffer */
      sprintf(Buf, "%s %u", gstr(&str->Min), NumKeyData.iMin);
      /* display min text */
      slcd_SendText(Buf, 121, 221, 'T', LEFT_ALIGN);  
      break;   

   case LONG:
      /* format edit buffer */
      sprintf(Buf, "%s %ld", gstr(&str->Min), NumKeyData.lMin);
      /* display min text */
      slcd_SendText(Buf, 121, 221, 'T', LEFT_ALIGN);  
      break;   

   case ASCI:
      /* format edit buffer */
      sprintf(Buf, "%s %u", gstr(&str->Min), NumKeyData.iMin);
      /* display min text */
      slcd_SendText(Buf, 121, 221, 'T', LEFT_ALIGN);  
      break;   

   }

   /* display min text */
   switch (NumKeyData.Type)
   {
   case FLOAT:
      /* format edit buffer */
      sprintf(Buf, "%s %.2f", gstr(&str->Max), NumKeyData.fMax);
      /* display min text */
      slcd_SendText(Buf, 121, 250, 'T', LEFT_ALIGN);  
      break;   

   case BYTE:
   case WORD:
   case PASSWORD:
      /* format edit buffer */
      sprintf(Buf, "%s %u", gstr(&str->Max), NumKeyData.iMax);
      /* display min text */
      slcd_SendText(Buf, 121, 250, 'T', LEFT_ALIGN);  
      break;   

   case LONG:
      /* format edit buffer */
      sprintf(Buf, "%s %ld", gstr(&str->Max), NumKeyData.lMax);
      /* display min text */
      slcd_SendText(Buf, 121, 250, 'T', LEFT_ALIGN);  
      break;   

   case ASCI:
      /* format edit buffer */
      sprintf(Buf, "%s %u", gstr(&str->Max), NumKeyData.iMax);
      /* display min text */
      slcd_SendText(Buf, 121, 250, 'T', LEFT_ALIGN);  
      break;   
   }
}

/*
** ------------------------------------------------------------------------------
**		Function: void PaintKeyBoard(void)
** ------------------------------------------------------------------------------
*/

void PaintKeyBoard(void)
{
   /* send command to display Key pad */
   if(!AltKeyPad)
      slcd_CallMacro(7);
   else
      slcd_CallMacro(8);
         

   slcd_SetFont(24, 0);
   slcd_SetColour(White, DarkGrey);    
   
   /* display parameter name */ 
   slcd_SendText(NumKeyData.Name, 12, 7, 'T', LEFT_ALIGN);  

   /* set colour for edit text */
   slcd_SetColour(DarkGrey, White);  
   
   /* set font F16x32 */
   slcd_Send("f 14x24");   
   
   /* format edit buffer */
   strcpy(NumEditBuf, NumKeyData.DataPtr);

   /* reset edit index */
   //EditIndex = (strlen(NumEditBuf)-2);
   EditIndex   = 0;   
   CursorState = 0;
   
   slcd_SendText(NumEditBuf, 147, 89, 0, LEFT_ALIGN);  

}

/*
** ------------------------------------------------------------------------------
**		Function: void UpdateKeyPad(void)
** ------------------------------------------------------------------------------
*/

void UpdateKeyPad(void)
{
   byte Buf[30];
   
   /* time to update? */
   if (!winTimer1)
   {
      winTimer1 = 50;

      memset(Buf, 0, 20);
      
      /* restore edit box font and colour */
      /* set colour for edit text */
      slcd_SetColour(DarkGrey, White);  
      
      /* set font */       
      slcd_Send("f 14x24"); 
     
         
      /* copy edit buffer */
      strcpy(Buf, NumEditBuf);
      /* is it time to show cursor? */
      if(CursorState^=1)
         Buf[EditIndex] = '_';   
      
      /* update display */      
      slcd_SendText(Buf, 129, 159, 0, LEFT_ALIGN);  
   }
}

/*
** ------------------------------------------------------------------------------
**		Function: void UpdateKeyBoard(void)
** ------------------------------------------------------------------------------
*/

void UpdateKeyBoard(void)
{
   byte Buf[30];
   /* time to update? */
   if (!winTimer1)
   {
      winTimer1 = 50;

      /* copy edit buffer */
      strcpy(Buf, NumEditBuf);

      /* is it time to show cursor? */
      if(CursorState^=1)
         Buf[EditIndex] = '_'; 
      
      /* update display */      
      slcd_SendText(Buf, 147, 89, 0, LEFT_ALIGN);  
   }
}

/*
** ------------------------------------------------------------------------------
**		Function: byte winKeyPadHandler(void)
** ------------------------------------------------------------------------------
*/

byte winKeyPadHandler(void)
{
   
   /* is there a key to process? */
   if (slcdKey)
   {
      /* call key handler */
      winKeyPadKeyHandler(slcdKey);      
      /* now the key has been processed clear it */
      slcdKey = 0; 
   }
   
   switch (winKeyState)
   {
   case WIN_KEY_PAINT:

      /* clear the screen */
      slcd_Send("z");
            
      if(NumKeyData.KeyBoardType == NUMBER)
      {
         /* send command to display Key pad */
         slcd_CallMacro(9);
         /* paint key pad */
         PaintKeyPad();
      }
      else
      {
         /* paint keyboard */
         PaintKeyBoard();
      }
      /* move to update state */      
      winKeyState = WIN_KEY_UPDATE;       
      return 0;

   case WIN_KEY_UPDATE:
      if(NumKeyData.KeyBoardType == NUMBER)
         UpdateKeyPad();
      else
         UpdateKeyBoard();
      return 0;

   case WIN_KEY_UNLOAD:
      /* do any necessary clearing up */
      NumKeyData.Attributes = 0;

      /* clear NumKeyData */
      memset((byte *)&NumKeyData, 0, sizeof(NumKeyData));
      /* clear edit buffer */
      memset((byte *)&NumEditBuf, 0, 20);
      /*clea auto clear flag */
      AutoClear = 0;
      
      winKeyState = WIN_KEY_PAINT;  

      /* clear function ptr */ 
      NumKeyData.fp = 0;  

      /* return from key pad */
      return keyReturnVal;
   }   
}



