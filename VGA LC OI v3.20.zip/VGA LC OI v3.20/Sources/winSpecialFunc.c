#include <hidef.h>                           /* common defines and macros */
#include "derivative.h"                      /* derivative information */

/*
** ------------------------------------------------------------------------------
   
   File   : winSpecialFunc.c 
   Aurthor: 
   
   Description:  
   
   Version Log          Notes                                     Changes Made by                                        
   --------------       -----                                     ---------------
   25-07-10:            Created                                   Stuart


** ------------------------------------------------------------------------------
                                    
                                    Overview
                                            
** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

/* library headers */
#include "string.h"

/* Application headers */
#include "SLCD 260217.h"
#include "winMain.h"
#include "winKey.h"
#include "Language.h"
#include "ModBusM Int.h"
#include "EEPROM.h"
#include "SlcdSubs.h"

/* Implements this interface: */
#define WINSPECIALFUNC_C
#include "winSpecialFunc.h"

#pragma CODE_SEG WINSPECIALFUNC_Code
#pragma DATA_SEG WINSPECIALFUNC_Data


/* private */
static byte winSpecialFuncState;
static byte winReturnWin;

/* public */


/*
** ------------------------------------------------------------------------------
**		Function: void winSpecialFuncKeyHandler(byte key)
** ------------------------------------------------------------------------------
*/

void winSpecialFuncKeyHandler(byte key)
{
   switch (key)
   {
   case 1:      /* simulation */     
      /* switch to menu screen */
      winReturnWin = SIMULATION_WINDOW;
      /* shut down main window handler */
      winSpecialFuncState = WIN_SPECIALFUNC_UNLOAD;     
      break;

   case 2:      /* filtering  */     
      /* switch to menu screen */
      winReturnWin = FILTERING_WINDOW;
      /* shut down main window handler */
      winSpecialFuncState = WIN_SPECIALFUNC_UNLOAD;     
      break;
      
   case 3:      /* Alarm settings */     
      /* switch to menu screen */
      winReturnWin = TENSION_WINDOW;
      /* shut down main window handler */
      winSpecialFuncState = WIN_SPECIALFUNC_UNLOAD;     
      break;

   case 4:      /* Totalizer  */     
      /* switch to menu screen */
      winReturnWin = TOTALIZER_WINDOW;
      /* shut down main window handler */
      winSpecialFuncState = WIN_SPECIALFUNC_UNLOAD;     
      break;

   case 5:      /* Compensation */     
      /* switch to menu screen */
      winReturnWin = DIGITS_WINDOW;
      /* shut down main window handler */
      winSpecialFuncState = WIN_SPECIALFUNC_UNLOAD;     
      break;

    case 6:      /* Moving Average */     
      /* switch to menu screen */
      winReturnWin = MOVING_AVERAGE_WINDOW;
      /* shut down main window handler */
      winSpecialFuncState = WIN_SPECIALFUNC_UNLOAD;     
      break;
      
   case 128:       /* EXIT */
      /* switch to menu screen */
      //winReturnWin = USER_WINDOW;
      winReturnWin = ENGINEERING_WINDOW;
      /* shut down main window handler */
      winSpecialFuncState = WIN_SPECIALFUNC_UNLOAD;     
      break;
   }
}

/*
** ------------------------------------------------------------------------------
**		Function: void winSpecialFuncHandler(void)
** ------------------------------------------------------------------------------
*/

void winSpecialFuncHandler(void)
{
   switch (winSpecialFuncState)
   {
   case WIN_SPECIALFUNC_PAINT:
      slcd_SetColour(DarkGrey, DarkGrey);
      slcd_Send("z");

      slcd_Send("xc all");     
      /* display menu screen */
      //DisplayBmp(16, 0, 0, LEFT_ALIGN); 
      slcd_DisplayBmp(10, 0, 0); 

      DisplayTitle("MS Instrumentos");
      
      slcd_SetFont(24, 0);
      slcd_SetColour(DarkGrey, White); 
      slcd_SendText(gstr(&str->SpecialFunctions), 15, 60, 0, LEFT_ALIGN);
      
      /* define back hotspot */
      //slcd_CmdQueue("x 128 560 10 630 60");
      slcd_MakeHotSpot(128, 560, 10, 50, 50);
      
      /* display buttons */   
      slcd_MakeButton(1, 1, 30,  120,  2, 3);
      slcd_MakeButton(2, 1, 30,  200,  2, 3);
      slcd_MakeButton(3, 1, 30,  280,  2, 3);
      
      slcd_MakeButton(4, 1, 320, 120,  2, 3);             
      slcd_MakeButton(5, 1, 320, 200,  2, 3);             
      //slcd_MakeButton(6, 1, 320, 280,  2, 3);             
      
      slcd_SetFont(16, 0);
      slcd_SetColour(DarkGrey, White);
      slcd_SendText(gstr(&str->Simulation),       115, 120, 0, LEFT_ALIGN);
      slcd_SendText(gstr(&str->Filtering),        115, 200, 0, LEFT_ALIGN);
      slcd_SendText(gstr(&str->Tension),          115, 280, 0, LEFT_ALIGN);
      slcd_SendText(gstr(&str->Totalizer),        405, 120, 0, LEFT_ALIGN);
      slcd_SendText(gstr(&str->DigitsPrecision),  405, 200, 0, LEFT_ALIGN);
      //slcd_SendText(gstr(&str->MovingAverage),    405, 280, 0, LEFT_ALIGN);
      
      /* move to update state */      
      winSpecialFuncState = WIN_SPECIALFUNC_UPDATE;       
      break;
      
   case WIN_SPECIALFUNC_UPDATE:
      /* is there a key to process? */
      if (slcdKey)
      {
         /* call key handler */
         winSpecialFuncKeyHandler(slcdKey);      
         /* now the key has been processed clear it */
         slcdKey = 0; 
      }
      break;

   case WIN_SPECIALFUNC_ENTER_PASSWORD:
      /* see if key pad is returning */
      switch(winKeyPadHandler())
      {
      case 1:
         /* move to update state */      
         winSpecialFuncState = WIN_SPECIALFUNC_PAINT;       
         break;

      case 2:
         /* move to update state */      
         winSpecialFuncState = WIN_SPECIALFUNC_UNLOAD;       
         break;

      case 3:
         /* move to update state */      
         winSpecialFuncState = WIN_SPECIALFUNC_UNLOAD;       
         /* Open engineering */
         winReturnWin = ENGINEERING_WINDOW; 
         break;
      }
      break;
      
   case WIN_SPECIALFUNC_UNLOAD:
      /* do any necessary clearing up */
      winSpecialFuncState = WIN_SPECIALFUNC_PAINT;  
      /* set return menu */
      winActiveWin = winReturnWin;
      /* clear return win */ 
      winReturnWin = MAIN_WINDOW;
      break;
   }   
}



