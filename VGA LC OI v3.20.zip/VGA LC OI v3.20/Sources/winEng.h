/*
** ------------------------------------------------------------------------------
   
   File   : winMisc.h 
   Aurthor: Stuart Clarke

** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

#ifndef WINENG_H
#define WINENG_H


/* public defines */


/*
** ------------------------------------------------------------------------------
**		#define : diagnostics handler states 
** ------------------------------------------------------------------------------
*/

#define WIN_ENG_PAINT_MENU   0
#define WIN_ENG_SELECT_MENU  1
#define WIN_ENG_PAINT        2
#define WIN_ENG_UPDATE       3
#define WIN_ENG_NUMKEYPAD    4
#define WIN_ENG_CONFIRM      5
#define WIN_ENG_UNLOAD       6






#ifndef WINENG_C

/* public variables */
#pragma DATA_SEG WINENG_Data


#endif   /* WINENG_C */      


/* public functions */
#pragma CODE_SEG WINENG_Code

/*
** ------------------------------------------------------------------------------
**		Function: void DisplayOnOFF(void)
** ------------------------------------------------------------------------------
*/

void DisplayOnOFF(byte State, word Y, byte Separator);

/*
** ------------------------------------------------------------------------------
**		Function: void winEngHandler(void)
** ------------------------------------------------------------------------------
*/

void winEngHandler(void);

#endif   /* WINENG_H */
