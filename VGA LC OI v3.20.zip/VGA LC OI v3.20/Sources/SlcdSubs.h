/* SlcdSubs.h interface */
/*
** ------------------------------------------------------------------------------
   
   File   : SlcdSubs.h 
   Aurthor: Stuart Clarke
        
** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2007 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp.
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
   
** ------------------------------------------------------------------------------
*/

#ifndef SLCDSUBS_H
#define SLCDSUBS_H

#pragma CODE_SEG SLCDSUBS_Code
#pragma DATA_SEG SLCDSUBS_Data


/* public defines */

#define PSZ_640_480        0
#define PSZ_800_600        1
#define PSZ_1280_800       2
#define PSZ_1024_600       3

#define LEFT_ALIGN           0
#define CENTER_ALIGN         1
#define RIGHT_ALIGN          2
#define LEFT_BOTTOM_ALIGN    3
#define CENTER_BOTTOM_ALIGN  4
#define RIGHT_BOTTOM_ALIGN   5

/*
** ------------------------------------------------------------------------------
**		DataType: lButtonType
** ------------------------------------------------------------------------------
*/


typedef struct
{
   byte Id;
   word x;
   word y;
   byte type;
   byte state;
   byte *text0;
   byte *text1;
   byte dx0;
   byte dy0;
   byte dx1;
   byte dy1;
   byte bmp0;
   byte bmp1;
}ButtonType;

#ifndef SLCDSUBS_C


/* public variables */


extern byte slcdVer[64];
extern byte PanelSize;

extern word xoff;
extern word yoff;

extern float xratio; 
extern float yratio;


#endif   /* SLCDSUBS_C */ 


/* public functions */

/*
** ------------------------------------------------------------------------------
**		Function: void slcdSubsSetOffsets(void)
** ------------------------------------------------------------------------------
*/

void slcdSubsSetOffsets(void);

/*
** ------------------------------------------------------------------------------
**		Function: void DisplayTitle(byte *Title)
** ------------------------------------------------------------------------------
*/

void DisplayTitle(byte *Title);

/*
** ------------------------------------------------------------------------------
**		Function: void OffsetOff(void)
** ------------------------------------------------------------------------------
*/

void OffsetOff(void);

/*
** ------------------------------------------------------------------------------
**		Function: void DisplayBmp(byte BmpId, word x, word y)
** ------------------------------------------------------------------------------
*/

void DisplayBmp(byte BmpId, word x, word y);

/*
** ------------------------------------------------------------------------------
**		Function: void ClearButton(byte id)
** ------------------------------------------------------------------------------
*/

void ClearButton(byte id);

/*
** ------------------------------------------------------------------------------
**		Function: void MakeButton(byte id, byte type, word x, word y, word BmpUp, word BmpDn)
** ------------------------------------------------------------------------------
*/

void MakeButton(byte id, byte Type, word x, word y, word BmpUp, word BmpDn);


/*
** ------------------------------------------------------------------------------
**		Function: void MakeLatchingButtonCT(byte id, byte *Str1, byte *Str2, word x, word y, word BmpUp, word BmpDn)
** ------------------------------------------------------------------------------
*/

void MakeLatchingButtonCT(byte id, byte *Str1, byte *Str2, word x, word y, word BmpUp, word BmpDn);

/*
** ------------------------------------------------------------------------------
**		Function: void slcdMakeLatchingButton(lButtonType * button)
** ------------------------------------------------------------------------------
*/

void MakeLatchingButton(ButtonType * button);

/*
** ------------------------------------------------------------------------------
**		Function: void MakeButtonCT(byte id, byte *Str, byte Type, word x, word y, word BmpUp, word BmpDn);
** ------------------------------------------------------------------------------
*/

void MakeButtonCT(byte id, byte *Str, byte Type, word x, word y, word BmpUp, word BmpDn);


/*
** ------------------------------------------------------------------------------
**		Function: void MakeHotSpot(byte id, word x, word y, word xsz, word ysz)
** ------------------------------------------------------------------------------
*/

void MakeHotSpot(byte id, word x, word y, word xsz, word ysz);

/*
** ------------------------------------------------------------------------------
**		Function: void slcdMakeButtonTextXY(byte Id, word x, word y, byte *Ptr, word x1, word y1, word BmpUp, word BmpDn)
** ------------------------------------------------------------------------------
*/

void MakeButtonTextXY(byte Id, word x, word y, byte *Ptr, word x1, word y1, word BmpUp, word BmpDn);

/*
** ------------------------------------------------------------------------------
**		Function: void DisplayText(byte *Ptr, word x, word y)
** ------------------------------------------------------------------------------
*/

void DisplayText(byte *Ptr, word x, word y, byte Argument);

/*
** ------------------------------------------------------------------------------
**		Function: void slcd_AppendText(byte *Ptr)
** ------------------------------------------------------------------------------
*/

void slcd_AppendText(byte *Ptr);

/*
** ------------------------------------------------------------------------------
**		Function: void slcdSendText(byte *Ptr, word x, word y, byte Type)
** ------------------------------------------------------------------------------
*/

void slcd_SendText(byte *Ptr, word x, word y, byte Type, byte Align);

/*
** ------------------------------------------------------------------------------
**		Function: void slcd_SetColour(byte f, byte b)
** ------------------------------------------------------------------------------
*/

void slcd_SetColour(byte f, byte b);

/*
** ------------------------------------------------------------------------------
**		Function: void slcd_SetFont(byte Size, byte Type)
** ------------------------------------------------------------------------------
*/

void slcd_SetFont(byte Size, byte Type);

/*
** ------------------------------------------------------------------------------
**		Function: void slcd_DisplayBmp(byte BmpId, word x, word y)
** ------------------------------------------------------------------------------
*/

void slcd_DisplayBmp(byte BmpId, word x, word y);

/*
** ------------------------------------------------------------------------------
**		Function: void slcd_MakeHotSpot(byte id, word x, word y, word xsz, word ysz)
** ------------------------------------------------------------------------------
*/

void slcd_MakeHotSpot(byte id, word x, word y, word xsz, word ysz);

/*
** ------------------------------------------------------------------------------
**		Function: void slcd_MakeButton(byte id, byte type, word x, word y, word BmpUp, word BmpDn)
** ------------------------------------------------------------------------------
*/

void slcd_MakeButton(byte id, byte Type, word x, word y, word BmpUp, word BmpDn);

/*
** ------------------------------------------------------------------------------
**		Function: void slcd_CallMacro(byte No)
** ------------------------------------------------------------------------------
*/

void slcd_CallMacro(byte No);

/*
** ------------------------------------------------------------------------------
**		Function: void slcd_MakeLatchingButtonCT(byte id, byte *Str1, byte *Str2, word x, word y, word BmpUp, word BmpDn)
** ------------------------------------------------------------------------------
*/

void slcd_MakeLatchingButtonCT(byte id, byte *Str1, byte *Str2, word x, word y, word BmpUp, word BmpDn);

/*
** ------------------------------------------------------------------------------
**		Function: void slcd_MakeButtonCT(byte id, byte *Str, byte Type, word x, word y, word BmpUp, word BmpDn)
** ------------------------------------------------------------------------------
*/

void slcd_MakeButtonCT(byte id, byte *Str, byte Type, word x, word y, word BmpUp, word BmpDn);

/*
** ------------------------------------------------------------------------------
**		Function: void slcd_MakeButtonTextXY(byte Id, word x, word y, byte *Ptr, word x1, word y1, word BmpUp, word BmpDn)
** ------------------------------------------------------------------------------
*/

void slcd_MakeButtonTextXY(byte Id, word x, word y, byte *Ptr, word x1, word y1, word BmpUp, word BmpDn);

/*
** ------------------------------------------------------------------------------
**		Function: void slcd_MakeLatchingButton(ButtonType * button)
** ------------------------------------------------------------------------------
*/

void slcd_MakeLatchingButton(ButtonType * button);

/*
** ------------------------------------------------------------------------------
**		Function: void slcdTextAlign(byte Align)
** ------------------------------------------------------------------------------
*/

void slcd_TextAlign(byte Align);

/*
** ------------------------------------------------------------------------------
**		Function: void slcdDrawRectangle2(word x1, word y1, word xSz, word ySz)
** ------------------------------------------------------------------------------
*/

void slcdDrawRectangle2(word x1, word y1, word xSz, word ySz);

/*
** ------------------------------------------------------------------------------
**		Function: void slcdDrawRectangle(word x1, word y1, word xSz, word ySz)
** ------------------------------------------------------------------------------
*/

void slcdDrawRectangle(word x1, word y1, word xSz, word ySz);

/*
** ------------------------------------------------------------------------------
**		Function: void slcd_SetButtonSate(byte Id, byte State)
** ------------------------------------------------------------------------------
*/

void slcd_SetButtonState(byte Id, byte State);

#endif   /* SLCDSUBS_H */


