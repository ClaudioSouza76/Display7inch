/*
** ------------------------------------------------------------------------------
   
   File   : winBasicConfig.h 
   Aurthor: Stuart Clarke

** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

#ifndef WININPUTSOUTPUTS_H
#define WININPUTSOUTPUTS_H


/* public defines */

/*
** ------------------------------------------------------------------------------
**		#define : user menu handler states 
** ------------------------------------------------------------------------------
*/

#define WIN_INPUTS_OUTPUTS_PREPAINT     0
#define WIN_INPUTS_OUTPUTS_PAINT        1
#define WIN_INPUTS_OUTPUTS_PAINTPAGE    2
#define WIN_INPUTS_OUTPUTS_UPDATE       3
#define WIN_INPUTS_OUTPUTS_NUMKEYPAD    4
#define WIN_INPUTS_OUTPUTS_UNLOAD       5
#define WIN_INPUTS_OUTPUTS_ENTER_PASSWORD 6


#ifndef WININPUTSOUTPUTS_C

/* public variables */
#pragma DATA_SEG WININPUTSOUTPUTS_DATA

extern byte winInputsOutputsReturnWin;

#endif   /* WININPUTSOUTPUTS_C */      


/* public functions */
#pragma CODE_SEG WININPUTSOUTPUTS_CODE


/*
** ------------------------------------------------------------------------------
**		Function: void ReadInputsOutputsParameters(void)
** ------------------------------------------------------------------------------
*/

void ReadInputsOutputsParameters(void);

/*
** ------------------------------------------------------------------------------
**		Function: byte winInputsOutputsHandler(void)
** ------------------------------------------------------------------------------
*/

byte winInputsOutputsHandler(void);

#endif   /* WININPUTSOUTPUTS_H */
