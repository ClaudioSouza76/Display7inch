#include <hidef.h>                           /* common defines and macros */
#include "derivative.h"                      /* derivative information */

/*
** ------------------------------------------------------------------------------
   
   File   : winCalRoutine.c 
   Aurthor: 
   
   Description:  
   
   Version Log          Notes                                     Changes Made by                                        
   --------------       -----                                     ---------------
   08-07-09:            Created                                   Stuart


** ------------------------------------------------------------------------------
                                    
                                    Overview
                                            
** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

/* library headers */
#include "stdio.h"
#include "float.h"
#include "math.h"

/* Application headers */
#include "CRG 100110.h" 
#include "Subs.h"
#include "ModBusM Int.h"
#include "ModBusM.h"
#include "EEPROM.h"
#include "SLCD 100721.h"
#include "winMain.h"
#include "winKey.h"
#include "Language.h"


/* Implements this interface: */
#define WINRANGES_C
#include "winRanges.h"

#pragma CODE_SEG WINRANGES_Code
#pragma DATA_SEG WINRANGES_Data


/* private */
static byte winRangesState;
static byte winRangesPage;


/* public */



/*
** ------------------------------------------------------------------------------
**		Function: void winRangesKeyHandler(byte key)
** ------------------------------------------------------------------------------
*/

void winRangesKeyHandler(byte key)
{   
   byte Buf[25];
   switch (key)
   {
   case 1:
      if(winRangesPage)
         winRangesPage--;
      
      /* move to update state */      
      winRangesState = WIN_RANGES_PAINT_PAGE;         
      break;
      

   case 2:
      if(winRangesPage<1)
         winRangesPage++;
      
      /* move to update state */      
      winRangesState = WIN_RANGES_PAINT_PAGE;         
      break;
      
   case 128:       /* EXIT */
      /* shut down num key window handler */
      winRangesState = WIN_RANGES_UNLOAD;  
      break;  
      
   case 130:      /* tag hotspot */
      /* move to key pad handler sate */
      winRangesState = WIN_RANGES_NUMKEYPAD; 
      
      /* copy parameter data to key structure */
      strcpy(NumKeyData.Name, "Tag");  
      NumKeyData.KeyBoardType = LETTER;
      NumKeyData.Type = STRING;
      NumKeyData.iMax = 16;
      NumKeyData.Flag = enTag;
      NumKeyData.DataPtr           = (void *)&mbSlave.Tag;     
      break;      

   case 131:      /* Rate units hotspot */
      mbSlave.Units[0]^=1;
      mbTable[enUnits1].WrFlg = 1;
      
      /* set write flag */
      slcdSetFont(F24B);  
      slcdSetColour(LightBlue, White);  
            
      /* display instrument tag */
      slcdDisplayText(&mbSlave.Tag, getX(170), getY(ccY0), 0);  
      
      /* display rate units */
      if(!mbSlave.Units[0])
         slcdDisplayText("t/h   ", getX(170), getY(ccY1), 0);  
      else
         slcdDisplayText("kg/h ", getX(170), getY(ccY1), 0);  
      
      break; 


   case 132:      /* Decimal precision */
      if(mbSlave.Digit<3)
         mbSlave.Digit++;
      else
         mbSlave.Digit = 0;
      
      mbTable[enDigits].WrFlg = 1;
      
      /* set write flag */
      slcdSetFont(F24B);  
      slcdSetColour(LightBlue, White); 
      
      /* display deciaml precision */      
      sprintf(Buf, "%u", mbSlave.Digit);
      slcdDisplayText(&Buf, getX(170), getY(ccY2), 0);              
      break;
         
   case 133:      /* Pulse total */
           /* move to key pad handler sate */
      winRangesState = WIN_RANGES_NUMKEYPAD; 
      
      /* copy parameter data to key structure */
      strcpy(NumKeyData.Name, gstr(&str->PulseRate));  
      NumKeyData.KeyBoardType = NUMBER;
      NumKeyData.Type = FLOAT;
      NumKeyData.fMax = 100.0;
      NumKeyData.fMin = 0.001;
      NumKeyData.Flag = enPulseRate;
      NumKeyData.DataPtr = (void *)&mbSlave.PulseRate;     
      break;             

   case 134:      /* Rate Range Hi */
      /* move to key pad handler sate */
      winRangesState = WIN_RANGES_NUMKEYPAD; 
      
      /* copy parameter data to key structure */
      strcpy(NumKeyData.Name, gstr(&str->HighEnd) );  
      NumKeyData.Type = FLOAT;
      NumKeyData.KeyBoardType = NUMBER;
      NumKeyData.fMax = 999.999;
      NumKeyData.fMin = 1.0;
      NumKeyData.Index = 0;
      NumKeyData.Flag  = enRangeHi1;
      
      NumKeyData.DataPtr = (void *)&mbSlave.RangeHi[0];         
      break;       

   case 135:      /* Rate Range lo */
      /* move to key pad handler sate */
      winRangesState = WIN_RANGES_NUMKEYPAD; 
      
      /* copy parameter data to key structure */
      strcpy(NumKeyData.Name, gstr(&str->HighEnd) );  
      NumKeyData.Type = FLOAT;
      NumKeyData.KeyBoardType = NUMBER;
      NumKeyData.fMax = 999.999;
      NumKeyData.fMin = 1.0;
      NumKeyData.Index = 0;
      NumKeyData.Flag  = enRangeLo1;
      
      NumKeyData.DataPtr = (void *)&mbSlave.RangeLo[0];        
      break;    
      
   case 136:      /* Speed Range Hi */
      /* move to key pad handler sate */
      winRangesState = WIN_RANGES_NUMKEYPAD; 
      
      /* copy parameter data to key structure */
      strcpy(NumKeyData.Name, gstr(&str->HighEnd) );  
      NumKeyData.Type = FLOAT;
      NumKeyData.KeyBoardType = NUMBER;
      NumKeyData.fMax = 999.999;
      NumKeyData.fMin = 1.0;
      NumKeyData.Index = 0;
      NumKeyData.Flag  = enRangeHi4;
      
      NumKeyData.DataPtr = (void *)&mbSlave.RangeHi[3];         
      break;       

   case 137:      /* Speed Range lo */
      /* move to key pad handler sate */
      winRangesState = WIN_RANGES_NUMKEYPAD; 
      
      /* copy parameter data to key structure */
      strcpy(NumKeyData.Name, gstr(&str->HighEnd) );  
      NumKeyData.Type = FLOAT;
      NumKeyData.KeyBoardType = NUMBER;
      NumKeyData.fMax = 999.999;
      NumKeyData.fMin = 1.0;
      NumKeyData.Index = 0;
      NumKeyData.Flag  = enRangeLo4;
      
      NumKeyData.DataPtr = (void *)&mbSlave.RangeLo[3];        
      break;     
      
   case 138:      /* Mass Range Hi */
      /* move to key pad handler sate */
      winRangesState = WIN_RANGES_NUMKEYPAD; 
      
      /* copy parameter data to key structure */
      strcpy(NumKeyData.Name, gstr(&str->HighEnd) );  
      NumKeyData.Type = FLOAT;
      NumKeyData.KeyBoardType = NUMBER;
      NumKeyData.fMax = 999.999;
      NumKeyData.fMin = 1.0;
      NumKeyData.Index = 0;
      NumKeyData.Flag  = enRangeHi3;
      
      NumKeyData.DataPtr = (void *)&mbSlave.RangeHi[2];         
      break;       

   case 139:      /* Mass Range lo */
      /* move to key pad handler sate */
      winRangesState = WIN_RANGES_NUMKEYPAD; 
      
      /* copy parameter data to key structure */
      strcpy(NumKeyData.Name, gstr(&str->HighEnd) );  
      NumKeyData.Type = FLOAT;
      NumKeyData.KeyBoardType = NUMBER;
      NumKeyData.fMax = 999.999;
      NumKeyData.fMin = 1.0;
      NumKeyData.Index = 0;
      NumKeyData.Flag  = enRangeLo3;
      
      NumKeyData.DataPtr = (void *)&mbSlave.RangeLo[2];        
      break;             

   }
}

/*
** ------------------------------------------------------------------------------
**		Function: void ReadRangeParameters(void)
** ------------------------------------------------------------------------------
*/

void ReadRangeParameters(void)
{
   mbTable[enTag].RdFlg = 0x1;
   mbTable[enUnits1].RdFlg = 0x1;
   mbTable[enDigits].RdFlg = 0x1;  
   mbTable[enPulseTotal].RdFlg = 0x1;  

   mbTable[enRangeLo1].RdFlg = 1; 
   mbTable[enRangeLo2].RdFlg = 1; 
   mbTable[enRangeLo3].RdFlg = 1; 
   mbTable[enRangeLo4].RdFlg = 1; 
   
   mbTable[enRangeHi1].RdFlg = 1; 
   mbTable[enRangeHi2].RdFlg = 1; 
   mbTable[enRangeHi3].RdFlg = 1; 
   mbTable[enRangeHi4].RdFlg = 1;   
}

/*
** ------------------------------------------------------------------------------
**		Function: void PaintRangesPage(void)
** ------------------------------------------------------------------------------
*/

void PaintRangesPage(void)
{   
   switch (winRangesPage)
   {
   case 0:

      slcdSetFont(F24);  
      
      /* set colours back */
      slcdSetColour(DarkGrey, White);         

      /* display headings */
      
      slcdDisplayText(gstr(&str->ScaleTag),   getX(20),   getY(ccY0), 'T');     
      slcdDisplayText(gstr(&str->RateUnits),  getX(20),   getY(ccY1), 'T');  
      slcdDisplayText(gstr(&str->Resolution), getX(20),   getY(ccY2), 'T');  
      
      slcdSetFont(F24B);  
      slcdDisplayText(gstr(&str->PulseTotalizer), getX(20),   getY(ccY3), 'T');  
      slcdSetFont(F24);  
      
      slcdDisplayText("1 Pulse = ", getX(20),   getY(ccY4), 'T');     
      
      
      slcdSetFont(F24B);  
      slcdDisplayText(gstr(&str->RateRanges), getX(245),  getY(ccY1), 'T');  
      slcdSetFont(F24);  
      slcdDisplayText(gstr(&str->HighEnd),         getX(245),  getY(ccY2), 'T');         
      slcdDisplayText(gstr(&str->LowEnd),          getX(245),  getY(ccY3), 'T');         

      slcd_CmdQueue("xs 130 170 70 300 95");
      slcd_CmdQueue("xs 131 170 110 230 135");
      slcd_CmdQueue("xs 132 170 150 230 175");
      slcd_CmdQueue("xs 133 170 230 230 255");
      
      slcd_CmdQueue("xs 134 405 150 455 175");
      slcd_CmdQueue("xs 135 405 190 455 215");

      /* force update */
      winUpdate1 = 1;
      break;
      
   case 1:

      /* set colours back */
      slcdSetColour(DarkGrey, White); 
      
      slcdSetFont(F24B);  
      slcdDisplayText(gstr(&str->SpeedRanges),  getX(20),   getY(ccY1), 'T');  
      slcdDisplayText(gstr(&str->MassRanges), getX(245),  getY(ccY1), 'T');  
      slcdSetFont(F24);  

      slcdDisplayText(gstr(&str->HighEnd), getX(20),   getY(ccY2), 'T');     
      slcdDisplayText(gstr(&str->LowEnd), getX(20),   getY(ccY3), 'T');     

      slcdDisplayText(gstr(&str->HighEnd), getX(245),   getY(ccY2), 'T');     
      slcdDisplayText(gstr(&str->LowEnd), getX(245),   getY(ccY3), 'T');     

      slcd_CmdQueue("xs 136 170 110 230 135");
      slcd_CmdQueue("xs 137 170 150 230 175");

      slcd_CmdQueue("xs 138 405 150 455 175");
      slcd_CmdQueue("xs 139 405 190 455 215");

      /* force update */
      winUpdate1 = 1;
      break;
   }
}


/*
** ------------------------------------------------------------------------------
**		Function: void UpdateRanges(void)
** ------------------------------------------------------------------------------
*/

void UpdateRanges(void)
{
   byte Buf[25];
   
   /* requested update */
   if (winUpdate1==1)
   {
      /* stop counter */
      winUpdate1 = 0;

      slcdSetFont(F24B);  
      slcdSetColour(LightBlue, White);  

      switch (winRangesPage)
      {
      case 0:
            
         /* display instrument tag */
         slcdDisplayText(&mbSlave.Tag, getX(170), getY(ccY0), 0);  
         
         /* display rate units */
         if(!mbSlave.Units[0])
            slcdDisplayText("t/h  ", getX(170), getY(ccY1), 0);  
         else
            slcdDisplayText("kg/h ", getX(170), getY(ccY1), 0);         
         
         sprintf(Buf, "%u", mbSlave.Digit);
         slcdDisplayText(&Buf, getX(170), getY(ccY2), 0);     

         /* totalizer Rate */
         sprintf(Buf, "%.3f t ", mbSlave.PulseRate);
         slcdDisplayText(&Buf, getX(170), getY(ccY4), 0);  
               
         /* diaplay Rate ranges */      
         sprintf(Buf, "%.1f", mbSlave.RangeHi[0]);
         slcdDisplayText(&Buf, getX(405), getY(ccY2), 'T');    

         sprintf(Buf, "%.1f", mbSlave.RangeLo[0]);
         slcdDisplayText(&Buf, getX(405), getY(ccY3), 'T');    
         break;
         
      case 1:

         /* diaplay Speed ranges */      
         sprintf(Buf, "%.1f", mbSlave.RangeHi[3]);
         slcdDisplayText(&Buf, getX(170), getY(ccY2), 'T');    

         sprintf(Buf, "%.1f", mbSlave.RangeLo[3]);
         slcdDisplayText(&Buf, getX(170), getY(ccY3), 'T');    
         
         /* diaplay Mass ranges */      
         sprintf(Buf, "%.1f", mbSlave.RangeHi[2]);
         slcdDisplayText(&Buf, getX(405), getY(ccY2), 'T');    

         sprintf(Buf, "%.1f", mbSlave.RangeLo[2]);
         slcdDisplayText(&Buf, getX(405), getY(ccY3), 'T');    
         break;
      }
   }

   /* time to update? */
   if (!winTimer1)
   {
      winTimer1 = 25;

     
   }
}

/*
** ------------------------------------------------------------------------------
**		Function: byte winRangesHandler(void)
** ------------------------------------------------------------------------------
*/

byte winRangesHandler(void)
{
   switch (winRangesState)
   {
   case WIN_RANGES_PREPAINT:
      /* get analog parameters from slave */
      ReadRangeParameters();
      winRangesState = WIN_RANGES_PAINT;
      break;
      
   case WIN_RANGES_PAINT:
      /* send command to execute macro 2 */
      slcdCallMacro(2);
      /* set forground and back ground colour */
      slcdSetColour(DarkGrey, DarkGrey);
      /* set font */
      slcdSetFont(F32B);         
      
      /* display page title  */
      slcdDisplayText(gstr(&str->RatesAndRanges), getX(12),  getY(4), 'T');
      
      /* update parameters */
      winUpdate1 = 1;
      
      /* move to update state */      
      winRangesState = WIN_RANGES_PAINT_PAGE;       
      return 0;

   case WIN_RANGES_PAINT_PAGE:
   
      #ifdef FIVEPOINTSEVEN
      /* clear previous page */
      slcd_CmdQueue("xic 10 0 0 1 56 320 240");
      #else
      slcd_CmdQueue("xic 10 0 0 1 64 480 272");
      #endif

      /* clear previous hotspots */      
      slcd_CmdQueue("xc all");      
      /* remake back button */
      slcd_CmdQueue("x 128 280 5 315 30");      
      /* make page select buttons */
      slcdMakeButton(1, getX(362), getY(50), "", 25, 8);
      slcdMakeButton(2, getX(414), getY(50), "", 26, 8);
      
               
      PaintRangesPage();
      
      /* move to update state */      
      winRangesState = WIN_RANGES_UPDATE;       
      break;

   case WIN_RANGES_UPDATE:
      /* is there a key to process? */
      if (slcdKey)
      {
         /* call key handler */
         winRangesKeyHandler(slcdKey);      
         /* now the key has been processed clear it */
         slcdKey = 0; 
      }

      UpdateRanges();

      /* has any data been remotely changed? */
      if(mbSlave.DataUpdate)
      {
         /* clear data update flag */
         mbSlave.DataUpdate = 0;
         mbTable[enDataUp].WrFlg = 1;   
         
         /* read analog parameters */
         ReadRangeParameters();  
         
         /* set update timer */                   
         winUpdate1 = 100;
      }      
      return 0;

  case WIN_RANGES_NUMKEYPAD:
      /* see if key pad is returning */
      if(winKeyPadHandler())
         /* move to update state */      
         winRangesState = WIN_RANGES_PAINT;   
      break;

   case WIN_RANGES_UNLOAD:
      /* do any necessary clearing up */
      winRangesState = WIN_RANGES_PREPAINT;  

      /* clear page */
      winRangesPage = 0;
      
      /* switch to menu screen */
      winActiveWin = SETUP_WINDOW;  


      /* return from key pad */
      return 1;
   }   
}



