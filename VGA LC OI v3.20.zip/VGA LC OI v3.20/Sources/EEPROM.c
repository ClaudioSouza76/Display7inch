#include <hidef.h>                           /* common defines and macros */
#include <mc9s12xd256.h>                    /* derivative information */

/*
** ------------------------------------------------------------------------------
   
   File   : EEPROM.c 
   Aurthor: 
   
   Description:  
   
   Version Log          Notes                                     Changes Made by                                        
   --------------       -----                                     ---------------
   02-09-08:            Created                                   Stuart


** ------------------------------------------------------------------------------
                                    
                                    Overview
   The EEPROMmemory may be read as either bytes, aligned words, or misaligned words. 
   Read access time is one bus cycle for bytes and aligned words, and two bus cycles 
   for misaligned words. The EEPROM memory is ideal for data storage for 
   single-supply applications allowing for field reprogramming without requiring 
   external voltage sources for program or erase. Program and erase functions are 
   controlled by a command driven interface.
                                            
** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

/* library headers */
#include "stdio.h"

/* Application headers */
#include "Main.h"
#include "Cmd.h"

/* Implements this interface: */
#define EEPROM_C
#include "EEPROM.h"


#pragma DATA_SEG EEPROM_DATA
volatile word BootReg;
volatile EEPROM_Type EEPROM;


#pragma CODE_SEG EEPROM_Code
#pragma DATA_SEG EEPROM_Data

/* private */


/* public */

/*
** ------------------------------------------------------------------------------
**		EEPROM Cmd Table
** ------------------------------------------------------------------------------
*/

#pragma INTO_ROM
static const CmdTabType EEtab[]=
{
"EEWR=",       1,
"EERD?",       2,
"EEPROM=",     3,
"EERASE",      4,
"COMPILETIME?",5,

"AVGTIME=",    6,
"AVGTIME?",    7,

"PLOCK=",      8,
"PLOCK?",      9,

"MINCALT=",    10,
"MINCALT?",    11,
"MAXCALT=",    12,
"MAXCALT?",    13,
"HIST=",       14,
"HIST?",       15,


"",			   0
};

/*
** ------------------------------------------------------------------------------
**		Function: byte EECmdParser(void)
** ------------------------------------------------------------------------------
*/

byte EECmdParser(void)
{
   word i,j,k;
   
   switch(CmdMatch((CmdTabType *)&EEtab))
   {
	case 1:         /* EEWR= */
	   i = sscanf(RxDataPtr, "%X %X", &j, &k);
      if (i<2||j<0x0C00||j>0x0FFF)
      {
         Reply(DATA_ERR);
      }
      else
      {         
		   EEWR_8((byte *)j, (byte)k);   
		   Reply(ACK);
      }
		break;  	
  	
	case 2:         /* EERD? */
	   i = sscanf(RxDataPtr, "%X", &j);
      if (!i||j<0x0C00||j>0x0FFF)
      {
         Reply(DATA_ERR);
      }
      else
      {         
		   sprintf(TxBufPtr, "%X", *(byte *)j);
		   CmdTx();
      }
		break;
  	   
   case 3:         /* EEPROM= */
	   i = sscanf(RxDataPtr, "%u", &j);
      if (!i||j>1)
      {
         Reply(DATA_ERR);
      }
      else
      {         
   		if (j)
   		{
            /* erase eeprom */
            MassEraseEE();   		   
            /* Initialize protected data */
            SetEEProtectedDefaults();      
   		}

		   /* normal ee clear */
		   SetEEDefaults();

   		Reply(ACK);
      }
		break;

   case 4:         /* EERASE */
		MassEraseEE();
		Reply(ACK);
		break;

	case 5:			/* COMPILETIME? */
		sprintf(TxBufPtr, "%s", eeComplieTime);
		CmdTx();
		break;
		
  	case 6:         /* AVGTIME= */
	   i = sscanf(RxDataPtr, "%u", &j);
      if (i!=1||j>300)      
      {
         Reply(DATA_ERR);
      }
      else
      {                  
	      EEWR_16(&EEPROM.AvgTime, j);	
	      Reply(ACK);
      }
  	   break;					

   case 7:         /* AVGTIME? */
	   sprintf(TxBufPtr, "%u", EEPROM.AvgTime);		   
	   CmdTx();
  	   break;   
  	   
  	case 8:         /* PLOCK= */
	   i = sscanf(RxDataPtr, "%u", &j);
      if (i!=1||j>300)      
      {
         Reply(DATA_ERR);
      }
      else
      {                  
	      EEWR_8(&EEPROM.ProdCodeLock, (byte)j);	
	      Reply(ACK);
      }
  	   break;					

   case 9:         /* PLOCK? */
	   sprintf(TxBufPtr, "%u", EEPROM.ProdCodeLock);		   
	   CmdTx();
  	   break;  	     	   

  	case 10:         /* MINCALT= */
	   i = sscanf(RxDataPtr, "%u", &j);
      if (i!=1||j>60)      
      {
         Reply(DATA_ERR);
      }
      else
      {                  
	      EEWR_8(&EEPROM.MinCalTime, (byte)j);	
	      Reply(ACK);
      }
  	   break;					

   case 11:         /* MINCALT? */
	   sprintf(TxBufPtr, "%u", EEPROM.MinCalTime);		   
	   CmdTx();
  	   break;  

  	case 12:         /* MAXCALT= */
	   i = sscanf(RxDataPtr, "%u", &j);
      if (i!=1||j>60)      
      {
         Reply(DATA_ERR);
      }
      else
      {                  
	      EEWR_8(&EEPROM.MaxCalTime, (byte)j);	
	      Reply(ACK);
      }
  	   break;					

   case 13:         /* MAXCALT? */
	   sprintf(TxBufPtr, "%u", EEPROM.MaxCalTime);		   
	   CmdTx();
  	   break;  

  	case 14:         /* HIST= */
	   i = sscanf(RxDataPtr, "%u", &j);
      if (i!=1||j>1)      
      {
         Reply(DATA_ERR);
      }
      else
      {                  
	      EEWR_8(&EEPROM.Histogram, (byte)j);	
	      Reply(ACK);
      }
  	   break;					

   case 15:         /* HIST? */
	   sprintf(TxBufPtr, "%u", EEPROM.Histogram);		   
	   CmdTx();
  	   break;  	     	   


   default:
      return 0;
   }
   
   /* Command processed */   
   return 1;
}

/*
** ------------------------------------------------------------------------------
**		Function: void SetEEProtectedDefaults(void)
** ------------------------------------------------------------------------------
*/

void SetEEProtectedDefaults(void)
{

    
}

/*
** ------------------------------------------------------------------------------
**		Function: void SetEEDefaults(void)
** ------------------------------------------------------------------------------
*/

void SetEEDefaults(void)
{
	byte i;
	
	/* cmd.c */
	 EEWR_32((dword *)&EEPROM.cmdBaud, 9600);  
   EEWR_8(&EEPROM.cmdId, '9');  
   EEWR_8(&EEPROM.cmdDebug, 0);  
   
   EEWR_8(&EEPROM.Language, 1);  
   
   EEWR_8(&EEPROM.AlarmState, 0);  
   EEWR_8(&EEPROM.AlarmPeriod, 2);  
   
   EEWR_16(&EEPROM.AvgTime, 10);  
   
   EEWR_8(&EEPROM.ProdCodeLock, 0); 
   EEWR_8(&EEPROM.BeepVolume , 255); 
   
   EEWR_16(&EEPROM.TrendTime, 60);  
   
   /* Speed cal date, time and speed */
   for(i=0;i<3;i++)
   {
      EEWR_Str((byte *)&EEPROM.SpeedCal[i].Date, " ", strlen(" ")); 
      EEWR_Str((byte *)&EEPROM.SpeedCal[i].Time, " ", strlen(" ")); 
      EEWR_fl(&EEPROM.SpeedCal[i].Speed, 0.0);  
   }   
   EEWR_8(&EEPROM.SpeedCalPtr, 0);  
   
   EEWR_fl(&EEPROM.PulseRate, 0.0); 
   
   /* Mass cal date, time and weight */
   for(i=0;i<3;i++)
   {
      EEWR_Str((byte *)&EEPROM.MassCal[i].Date, " ", strlen(" ")); 
      EEWR_Str((byte *)&EEPROM.MassCal[i].Time, " ", strlen(" ")); 
      EEWR_fl(&EEPROM.MassCal[i].TestWeight, 0.0);  
   }   
   EEWR_8(&EEPROM.MassCalPtr, 0);  

   /* Mass zero cal date, time and weight */
   for(i=0;i<3;i++)
   {
      EEWR_Str((byte *)&EEPROM.MassZeroCal[i].Date, " ", strlen(" ")); 
      EEWR_Str((byte *)&EEPROM.MassZeroCal[i].Time, " ", strlen(" ")); 
      EEWR_fl(&EEPROM.MassZeroCal[i].Zero, 0.0);  
   }   
   EEWR_8(&EEPROM.MassZeroCalPtr, 0);  
      
   EEWR_fl(&EEPROM.RefWeight, 0.0);      
   
   EEWR_fl(&EEPROM.TransportCapacity, 0.0); 
   EEWR_fl(&EEPROM.SensibilityLC, 0.0);           //Inserted by Souza    
   EEWR_fl(&EEPROM.ApplicationCapacity, 0.0);     
   EEWR_fl(&EEPROM.BalanceCapacity, 0.0);     
   EEWR_fl(&EEPROM.TestWightAppPercentage, 0.0);
    
   EEWR_Str((byte *)&EEPROM.ShippingDate, "01/01/2010", strlen("00/00/2010")); 
   
   EEWR_fl(&EEPROM.MaterialDensity, 0.0);  
   EEWR_fl(&EEPROM.BeltSpeed,       0.0);  
   EEWR_fl(&EEPROM.BeltWidth,       0.0);  
   EEWR_fl(&EEPROM.ConvayorAngle,   0.0);  
   EEWR_fl(&EEPROM.RollerAngle,     0.0);  
   EEWR_fl(&EEPROM.IdleSpacing,     0.0);  
     
   EEWR_8(&EEPROM.Xscale, 1);      
   EEWR_8(&EEPROM.Yscale, 10);   
   
   EEWR_fl(&EEPROM.ZeroMvLimit, 3.0); 
   
   EEWR_8(&EEPROM.MinCalTime, 6);   
   EEWR_8(&EEPROM.MaxCalTime, 15);   
   
   EEWR_Str((byte *)&EEPROM.Tag, "Tag", strlen("Tag"));      
   
   //EEWR_16(&EEPROM.MovingAverageBT, 1.0);                          /*Inserted by Souza*/
   //EEWR_16(&EEPROM.MovingAverageLC, 1.0);
   
   EEWR_8(&EEPROM.Histogram, 0);  
   EEWR_fl(&EEPROM.GraphLimit, 3.0);  
   EEWR_8(&EEPROM.SampleRate, 0);   
   
   /* Inspe�ao Mec�nica */
   EEWR_8(&EEPROM.LocalTrans,0);
   EEWR_8(&EEPROM.AlinhamRoletes,0);
   EEWR_8(&EEPROM.DistRoletes,0);
   EEWR_8(&EEPROM.RigidezTrans,0);
   EEWR_8(&EEPROM.Comportamento,0);
   EEWR_8(&EEPROM.SensorVel,0);
   
   EEWR_8(&EEPROM.Precision, 1);
   
    for(i=0;i<3;i++)
   {
      EEWR_fl(&EEPROM.Speed[i], 1.0);
      EEWR_fl(&EEPROM.ZeroCal[i], 1.0);
      EEWR_fl(&EEPROM.SpanCal[i], 1.0);
   }
   
   EEWR_Str((byte*)&EEPROM.DateCall[0], "26/10/15", strlen("00/00/00"));
   EEWR_Str((byte*)&EEPROM.DateCall[1], "26/10/15", strlen("00/00/00"));
   EEWR_Str((byte*)&EEPROM.DateCall[2], "26/10/15", strlen("00/00/00"));
   
   EEWR_Str((byte*)&EEPROM.TimeCall[0], "10:00", strlen("00:00"));
   EEWR_Str((byte*)&EEPROM.TimeCall[1], "10:01", strlen("00:00"));
   EEWR_Str((byte*)&EEPROM.TimeCall[2], "10:02", strlen("00:00"));
   
   EEWR_Str((byte*)&EEPROM.NextCalDate, "03/11/15", strlen("00/00/00"));
   
   EEWR_Str((byte *)&EEPROM.SerNumEq, "00000000", strlen("00000000"));
   
   EEWR_Str((byte *)&EEPROM.ModeloScale, "XX0000", strlen("000000"));
   
   EEWR_fl(&EEPROM.MassTension,0.0);
   EEWR_fl(&EEPROM.MinTension, 0.0);
   EEWR_fl(&EEPROM.MaxTension, 0.0);	
}

/*
** ------------------------------------------------------------------------------
**		Function: void EEPROM_Init(void)
** ------------------------------------------------------------------------------
*/

void EEPROM_Init(void)
{
   /* set the EEPROM burning clock  (OSC/20=200 KHz) */
   ECLKDIV = 20;

   /* See if the EEPROM needs programming */
   if(strncmp(EEPROM.VerString, VersionString, strlen(VersionString)) != 0 || strncmp(EEPROM.CompileTime, eeComplieTime, strlen(eeComplieTime)) != 0)
   {
      /* erase eeprom */
      MassEraseEE();
      
      /* Initialize protected data */
      SetEEProtectedDefaults();      

      /* initialize eeprom data */   	
   	SetEEDefaults();
   	
   	/* save new firmware version to eeprom  */
   	EEWR_Str(&EEPROM.VerString, VersionString, sizeof(VersionString));
   	/* save new compile time to eeprom  */
   	EEWR_Str(&EEPROM.CompileTime, eeComplieTime, sizeof(eeComplieTime));
   }   
}


/*
** ------------------------------------------------------------------------------
**		Function: void MassEraseEE(void)
** ------------------------------------------------------------------------------
*/

void MassEraseEE(void)
{
  	ESTAT |= 0x30;                               /* clear error flags */
  	*(volatile word *) 0x0C00 = 0xFF;            /* write data to addres to load ee data and adress registers */
  	
  	ECMD = 0x41;                                 /* word program command */
  	ESTAT_CBEIF = 1;                     	      /* clear command buffer empty flag */
 
 	while (!ESTAT_CCIF);            	         /* wait to buffer empty */
}

/*
** ------------------------------------------------------------------------------
**		Function: void WriteWord(word Addr, word Data)
** ------------------------------------------------------------------------------
*/

void WriteWord(word Addr, word Data)
{
  	if (ESTAT & 0x30)                               /* clear error flags */
  	   ESTAT |= 0x30;

   while (!ESTAT_CBEIF);

  	*(volatile word *) Addr = Data; 	            /* write data to addres to load ee data and adress registers */
  	
  	ECMD = 0x20;                                 /* word program command */
  	ESTAT_CBEIF = 1;                     	      /* clear command buffer empty flag */
 
 	while (!ESTAT_CCIF);            	         /* wait to buffer empty */
}

/*
** ------------------------------------------------------------------------------
**		Function: void WriteSector(word Addr, dword Data)
** ------------------------------------------------------------------------------
*/

void WriteSector(word Addr, dword Data)
{
  	if (ESTAT & 0x30)                               /* clear error flags */
  	   ESTAT |= 0x30;

   while (!ESTAT_CBEIF);

  	*(volatile word *) Addr = (word)(Data>>16);  /* array address and program data - higher part */
  
  	ECMD = 0x60;                          			/* sector modify command */
  	ESTAT_CBEIF = 1;                     			/* clear flag command buffer empty */
  
  	while (!ESTAT_CCIF);            			   /* wait to buffer empty */
  
  	WriteWord(Addr + 2,(word)Data); 	            /* write lower part */
}

/*
** ------------------------------------------------------------------------------
**		void EEWR_X(word Addr, byte *Ptr, byte Len)
** ------------------------------------------------------------------------------
*/

void EEWR_X(word Addr, byte *Ptr, byte Len)
{	
   union
	{
		byte b[4];
 		word w[2];
 		long l;
	} backup;
   	
   byte i, SecIndex;
   
   backup.l = 0x00000000;
   
  	//if((Addr < 0x0C00)||(Addr > 0x0FFF))		      /* is address in range? */
	   	//return 1;                  				
 
 	backup.l = *(volatile long *)(Addr & 0xFFFC);	/* load 4 byte sector to backup */
 	
 	SecIndex = Addr&0x0003;								   /* get sector offset */
 	
 	for(i=0;i<Len;i++) 										/* Loop untill > len */
 	{
 		backup.b[SecIndex++] = *(Ptr+i);		   			/* write data to backup */

 		if (SecIndex>3)  											/* have we crossed sector boundary? */
 		{
 			WriteSector(Addr & 0xFFFC, backup.l);				/* yes write modified sector */
 			SecIndex = 0;												/* Reset sector index */		
 			Addr += 4;													/* Get start of next sector */
 			backup.l = *(volatile long *)(Addr & 0xFFFC); 	/* Load 4 byte sector to backup */
 		} 			 		
 	}	
 	
 	if (SecIndex)												/* Has last sector been written */
 		WriteSector(Addr & 0xFFFC, backup.l);				/* no write modified sector */
 	
 	//return 0;	
}

/*
** ------------------------------------------------------------------------------
**		byte EEWR_8(word *Addr, byte Byte)
** ------------------------------------------------------------------------------
*/

void EEWR_8(byte *Addr, byte Byte)
{
	EEWR_X((word)Addr, (byte *) &Byte, sizeof(byte));

}

/*
** ------------------------------------------------------------------------------
**		byte EEWR_16(word *Addr, word Word)
** ------------------------------------------------------------------------------
*/

void EEWR_16(word *Addr, word Word)
{
	EEWR_X((word)Addr, (byte *) &Word, sizeof(word));
}

/*
** ------------------------------------------------------------------------------
**		byte EEWR_32(word *Addr, dword Dword)
** ------------------------------------------------------------------------------
*/

void EEWR_32(dword *Addr, dword Dword)
{
	EEWR_X((word)Addr, (byte *) &Dword, sizeof(dword));
}

/*
** ------------------------------------------------------------------------------
**		byte EEWR_fl(word *Addr, float Float)
** ------------------------------------------------------------------------------
*/

void EEWR_fl(float *Addr, float Float)
{
	EEWR_X((word)Addr, (byte *) &Float, sizeof(float));
}

/*
** ------------------------------------------------------------------------------
**		byte EEWR_Str(word *Addr, byte *String, byte StrLen)
** ------------------------------------------------------------------------------
*/

void EEWR_Str(byte *Addr, byte *String, byte StrLen)
{
	EEWR_X((word)Addr, String, StrLen);
	EEWR_8((byte *)(Addr+StrLen), 0);
}
