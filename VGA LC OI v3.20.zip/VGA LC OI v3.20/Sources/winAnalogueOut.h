/*
** ------------------------------------------------------------------------------
   
   File   : winBasicConfig.h 
   Aurthor: Stuart Clarke

** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

#ifndef WINANALOGUEOUT_H
#define WINANALOGUEOUT_H


/* public defines */

/*
** ------------------------------------------------------------------------------
**		#define : user menu handler states 
** ------------------------------------------------------------------------------
*/

#define WIN_ANALOGUE_OUT_PREPAINT     0
#define WIN_ANALOGUE_OUT_PAINT        1
#define WIN_ANALOGUE_OUT_PAINTPAGE    2
#define WIN_ANALOGUE_OUT_UPDATE       3
#define WIN_ANALOGUE_OUT_NUMKEYPAD    4
#define WIN_ANALOGUE_OUT_UNLOAD       5
#define WIN_ANALOGUE_OUT_ENTER_PASSWORD 6


#ifndef WINANALOGUEOUT_C

/* public variables */
#pragma DATA_SEG WINANALOGUEOUT_DATA

extern byte winAnalogueOutReturnWin;

#endif   /* WINANALOGUEOUT_C */      


/* public functions */
#pragma CODE_SEG WINANALOGUEOUT_CODE


/*
** ------------------------------------------------------------------------------
**		Function: void ReadAnalogueOutParameters(void)
** ------------------------------------------------------------------------------
*/

void ReadAnalogueOutParameters(void);

/*
** ------------------------------------------------------------------------------
**		Function: byte winAnalogueOutHandler(void)
** ------------------------------------------------------------------------------
*/

byte winAnalogueOutHandler(void);

#endif   /* WINANALOGUEOUT_H */
