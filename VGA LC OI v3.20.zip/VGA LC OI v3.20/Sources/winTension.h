/*
** ------------------------------------------------------------------------------
   
   File   : winTensions.h 
   Aurthor: Stuart Clarke

** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

#ifndef WINCAL_TENSION_H
#define WINCAL_TENSION_H


/* public defines */


/*
** ------------------------------------------------------------------------------
**		#define : diagnostics handler states 
** ------------------------------------------------------------------------------
*/

#define WIN_TENSION_PREPAINT     0
#define WIN_TENSION_PAINT        1
#define WIN_TENSION_PAINT_PAGE   2
#define WIN_TENSION_UPDATE       3
#define WIN_TENSION_NUMKEYPAD    4
#define WIN_TENSION_UNLOAD       5




#ifndef WIN_TENSION_C

/* public variables */
#pragma DATA_SEG WINTENSION_DATA


#endif   /* WINCAL_TENSION_C */      


/* public functions */
#pragma CODE_SEG WINTENSION_CODE

/*
** ------------------------------------------------------------------------------
**		Function: void ReadTensionParameters(void)
** ------------------------------------------------------------------------------
*/

void ReadTensionParameters(void);

/*
** ------------------------------------------------------------------------------
**		Function: byte winTensionHandler(void)
** ------------------------------------------------------------------------------
*/

byte winTensionHandler(void);

#endif   /* WINRANGES_H */
