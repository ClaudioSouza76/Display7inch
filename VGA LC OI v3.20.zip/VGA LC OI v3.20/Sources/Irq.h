/*
** ------------------------------------------------------------------------------
   
   File   : Vectors.h 
   Aurthor: Stuart Clarke
        
** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

#ifndef Vectors_H
#define Vectors_H


/* public defines */

#ifndef IRQ_C


/* public variables */
#pragma DATA_SEG EEPROM

#pragma DATA_SEG SLCD_Data


#endif   /* IRQ_C */ 


/* public functions */
#pragma CODE_SEG IRQ_Code

/*
** ------------------------------------------------------------------------------
**		Function: void Irq_Init(void)
** ------------------------------------------------------------------------------
*/

void Irq_Init(void);


#endif   /* IRQ_H */
