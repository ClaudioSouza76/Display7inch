/*
** ------------------------------------------------------------------------------
   
   File   : Subs.h 
   Aurthor: Stuart Clarke

** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

#ifndef SUBS_H
#define SUBS_H


/* public defines */

/*
** ------------------------------------------------------------------------------
**		#define: PSU error bits
** ------------------------------------------------------------------------------
*/

#define VS_LOW    0x01
#define VS_HI     0x02
#define VCC_LOW   0x04
#define VCC_HI    0x08


/*
** ------------------------------------------------------------------------------
**		#define 
** ------------------------------------------------------------------------------
*/

//#define szArray   290
#define szArray   512


#ifndef SUBS_C

/* public variables */
#pragma DATA_SEG SUBS_Data

extern byte subsStatusWord;

extern float psuVS;
extern float psuVCC2;

extern byte subsResetFlag;
extern word subsResetTimer;

extern byte subsBootFlag;
extern word subsBootTimer;

extern float SampleMean;
extern float StdDev;





#pragma DATA_SEG RAM_PAGE2
extern float far HistogramArray[szArray];

#pragma DATA_SEG SUBS_Data



#endif   /* SUBS_C */ 


/* public functions */
#pragma CODE_SEG SUBS_Code

/*
** ------------------------------------------------------------------------------
**		Function: byte SubsCmdParser(void)
** ------------------------------------------------------------------------------
*/

byte SubsCmdParser(void);

/*
** ------------------------------------------------------------------------------
**		Function: void SubsInit(void)
** ------------------------------------------------------------------------------
*/

void SubsInit(void);

/*
** ------------------------------------------------------------------------------
**		Function: byte *subsGetStatusString(byte Error)
** ------------------------------------------------------------------------------
*/

byte *subsGetStatusString(byte Error);

/*
** ------------------------------------------------------------------------------
**		Function: void subsErrorHandler(void)
** ------------------------------------------------------------------------------
*/

void subsErrorHandler(void);

/*
** ------------------------------------------------------------------------------
**		Function: void subsReadSwitches(void)
** ------------------------------------------------------------------------------
*/

void subsReadSwitches(void);

/*
** ------------------------------------------------------------------------------
**		Function: void subsCheckResetSwitch(void)
** ------------------------------------------------------------------------------
*/

void subsCheckResetSwitch(void);

/*
** ------------------------------------------------------------------------------
**		Function: void subsMeasurePSU(void)
** ------------------------------------------------------------------------------
*/

void subsMeasurePSU(void);


/*
** ------------------------------------------------------------------------------
**		Function: byte* GetSpeedCalDate(byte Inx)
** ------------------------------------------------------------------------------
*/

byte* GetSpeedCalDate(byte Inx);

/*
** ------------------------------------------------------------------------------
**		Function: void GetSpeedPtr(byte Inx)
** ------------------------------------------------------------------------------
*/

byte GetSpeedPtr(byte Inx);

/*
** ------------------------------------------------------------------------------
**		Function: void SetSpeedCalDate(float Speed)
** ------------------------------------------------------------------------------
*/

void SetSpeedCalDate(float Speed);

/*
** ------------------------------------------------------------------------------
**		Function: void GetMassPtr(byte Inx)
** ------------------------------------------------------------------------------
*/

byte GetMassPtr(byte Inx);

/*
** ------------------------------------------------------------------------------
**		Function: void SetMassCalDate(float Ref)
** ------------------------------------------------------------------------------
*/

void SetMassCalDate(float Ref);

/*
** ------------------------------------------------------------------------------
**		Function: void GetMassZeroPtr(byte Inx)
** ------------------------------------------------------------------------------
*/

byte GetMassZeroPtr(byte Inx);

/*
** ------------------------------------------------------------------------------
**		Function: void SetMassZeroCalDate(float Ref)
** ------------------------------------------------------------------------------
*/

void SetMassZeroCalDate(float Zero);

/*
** ------------------------------------------------------------------------------
**		Function: void subsSetHistogramRate(void)
** ------------------------------------------------------------------------------
*/

void subsSetHistogramRate(void);


/*
** ------------------------------------------------------------------------------
**		Function: void subsSampleTimer(void)
** ------------------------------------------------------------------------------
*/

void subsSampleTimer(void);
     
#endif   /* SUBS_H */
