#include <hidef.h>                           /* common defines and macros */
#include "derivative.h"                      /* derivative information */

/*
** ------------------------------------------------------------------------------
   
   File   : winDigitalOut.c 
   Aurthor: 
   
   Description:  
   
   Version Log          Notes                                     Changes Made by                                        
   --------------       -----                                     ---------------
   08-10-11:            Created                                   Stuart


** ------------------------------------------------------------------------------
                                    
                                    Overview
                                            
** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

/* library headers */
#include "stdio.h"
#include "float.h"
#include "math.h"

/* Application headers */
#include "CRG 100110.h" 
#include "Subs.h"
#include "SlcdSubs.h"
#include "ModBusM Int.h"
#include "ModBusM.h"
#include "EEPROM.h"
#include "SLCD 260217.h"
#include "winMain.h"
#include "winKey.h"
#include "Language.h"


/* Implements this interface: */
#define WINDIGITALOUT_C
#include "winDigitalOut.h"

#pragma CODE_SEG WINDIGITALOUT_CODE
#pragma DATA_SEG WINDIGITALOUT_DATA


/* private */
static byte winDigitalOutState;

static byte OutPutImg;
static byte OutputIndex;
static word OutputDelayReg;

/* public */
byte winDigitalOutReturnWin;

/* Digital Outputs screen layout (640x480 logical, scaled by slcd_SendText) */
#define DOUT_Y_OFF      53    /* page title now at y=60 (was y=7) */
#define DOUT_LED_Y      (90  + DOUT_Y_OFF)
#define DOUT_BTN_Y      (89  + DOUT_Y_OFF)
#define DOUT_OUTPUT_Y   (150 + DOUT_Y_OFF)
#define DOUT_ROW1_Y     200   /* first field row */
#define DOUT_ROW_DY     36    /* standard row spacing */
#define DOUT_ROW(n)     (DOUT_ROW1_Y + (((n) - 1) * DOUT_ROW_DY))
#define DOUT_LBL2_Y     DOUT_ROW(1)
#define DOUT_VAL2_Y     DOUT_ROW(2)
#define DOUT_LBL3_Y     DOUT_ROW(3)
#define DOUT_VAL3_Y     DOUT_ROW(4)
#define DOUT_VAL2R_X    390
#define DOUT_HS_H       40

/*
** ------------------------------------------------------------------------------
**		Function: void SetOutputDelay(void)
** ------------------------------------------------------------------------------
*/

void SetOutputDelay(void)
{
   /* */
   OutputDelayReg = OutputDelayReg/100;
   mbSlave.OutputDelay[OutputIndex] = OutputDelayReg;
}


/*
** ------------------------------------------------------------------------------
**		Function: void winDigitalOutKeyHandler(byte key)
** ------------------------------------------------------------------------------
*/

void winDigitalOutKeyHandler(byte key)
{   
   switch (key)
   {
   case 128:       /* EXIT */
      winDigitalOutReturnWin = USER_WINDOW;
      /* shut down num key window handler */
      winDigitalOutState = WIN_DIGITAL_OUT_UNLOAD;  
      break;  
      
 case 1:       /* Digital Inputs */
      /* switch page */
      if(OutputIndex)
         OutputIndex--;
      
      PaintDigitalOut();
      break;  
      
   case 2:       /* Digital Outputs */
      /* switch page */
      if(OutputIndex<3)
         OutputIndex++;
      
      PaintDigitalOut();
      break;  
      
   case 129:      /* Alarm Hi hotspot */
      /* move to key pad handler sate */
      winDigitalOutState = WIN_DIGITAL_OUT_NUMKEYPAD; 
      
      /* copy parameter data to key structure */
      strcpy(NumKeyData.Name, gstr(&str->TriggerHi) );  
      NumKeyData.Type = FLOAT;
      NumKeyData.KeyBoardType = NUMBER;
      NumKeyData.fMax = 10000.0;
      NumKeyData.fMin = 0.0;
      NumKeyData.DataPtr = (void *)&mbSlave.AlarmHi[OutputIndex];      
      
      /* set func ptr */
      //NumKeyData.fp = SetInputDelay;
               
      switch (OutputIndex)
      {
      case 0:
         NumKeyData.Flag  = enAlrHi1;
         break;

      case 1:
         NumKeyData.Flag  = enAlrHi2;
         break;

      case 2:
         NumKeyData.Flag  = enAlrHi3;
         break;

      case 3:
         NumKeyData.Flag  = enAlrHi4;
         break;
      }      
      break; 
      
   case 130:      /* Alarm Lo hotspot */
      /* move to key pad handler sate */
      winDigitalOutState = WIN_DIGITAL_OUT_NUMKEYPAD; 
      
      /* copy parameter data to key structure */
      strcpy(NumKeyData.Name, gstr(&str->TriggerLo) );  
      NumKeyData.Type = FLOAT;
      NumKeyData.KeyBoardType = NUMBER;
      NumKeyData.fMax = 10000.0;
      NumKeyData.fMin = 0.0;
      NumKeyData.DataPtr = (void *)&mbSlave.AlarmLo[OutputIndex];      
      
      /* set func ptr */
      //NumKeyData.fp = SetInputDelay;
               
      switch (OutputIndex)
      {
      case 0:
         NumKeyData.Flag  = enAlrLo1;
         break;

      case 1:
         NumKeyData.Flag  = enAlrLo2;
         break;

      case 2:
         NumKeyData.Flag  = enAlrLo3;
         break;

      case 3:
         NumKeyData.Flag  = enAlrLo4;
         break;
      }      
      break; 
      
   case 131:      /* Output delay hotspot */
      /* move to key pad handler sate */
      winDigitalOutState = WIN_DIGITAL_OUT_NUMKEYPAD; 
      
      /* copy parameter data to key structure */
      strcpy(NumKeyData.Name, gstr(&str->OutputDelay) );  
      NumKeyData.Type = WORD;
      NumKeyData.KeyBoardType = NUMBER;
      NumKeyData.iMax = 10000;
      NumKeyData.iMin = 0;
      NumKeyData.DataPtr = (void *)&OutputDelayReg;      
      
      /* set func ptr */
      NumKeyData.fp = SetOutputDelay;
               
      switch (OutputIndex)
      {
      case 0:
         NumKeyData.Flag  = enOutDelay1;
         break;

      case 1:
         NumKeyData.Flag  = enOutDelay2;
         break;

      case 2:
         NumKeyData.Flag  = enOutDelay3;
         break;

      case 3:
         NumKeyData.Flag  = enOutDelay4;
         break;
      }      
      break;

   case 132:      /* Output function hotspot */
      /* switch to next function */
      if(mbSlave.OutputFunction[OutputIndex]<10)
         mbSlave.OutputFunction[OutputIndex]++;
      else
         mbSlave.OutputFunction[OutputIndex] = 0;
      
      /* */
      switch (OutputIndex)
      {
      case 0:
         mbTable[enOutFunction1].WrFlg = 0x1; 
         break;

      case 1:
         mbTable[enOutFunction2].WrFlg = 0x1; 
         break;

      case 2:
         mbTable[enOutFunction3].WrFlg = 0x1; 
         break;

      case 3:
         mbTable[enOutFunction4].WrFlg = 0x1; 
         break;
      }
      
      DisplayOutputFunction();
      break;
   }
}


/*
** ------------------------------------------------------------------------------
**		Function: void ReadDigitalOutParameters(void)
** ------------------------------------------------------------------------------
*/

void ReadDigitalOutParameters(void)
{
   mbTable[enOutputs].RdFlg = 0x1;
   
   mbTable[enAlrLo1].RdFlg = 1; 
   mbTable[enAlrLo2].RdFlg = 1; 
   mbTable[enAlrLo3].RdFlg = 1; 
   mbTable[enAlrLo4].RdFlg = 1; 
   
   mbTable[enAlrHi1].RdFlg = 1; 
   mbTable[enAlrHi2].RdFlg = 1; 
   mbTable[enAlrHi3].RdFlg = 1; 
   mbTable[enAlrHi4].RdFlg = 1; 
   
   mbTable[enOutDelay1].RdFlg = 1; 
   mbTable[enOutDelay2].RdFlg = 1; 
   mbTable[enOutDelay3].RdFlg = 1; 
   mbTable[enOutDelay4].RdFlg = 1; 
      
   mbTable[enOutFunction1].RdFlg = 1; 
   mbTable[enOutFunction2].RdFlg = 1; 
   mbTable[enOutFunction3].RdFlg = 1; 
   mbTable[enOutFunction4].RdFlg = 1; 

}

/*
** ------------------------------------------------------------------------------
**		Function: DisplayOutputFunction(void)
** ------------------------------------------------------------------------------
*/

void DisplayOutputFunction(void)
{   
   /* set colours back */
   slcd_SetColour(LightBlue, White);       

   if(PanelSize == PSZ_1024_600)
      slcd_SetFont(14, 0);
   else
      slcd_SetFont(16, 'B');  

      
   /* clear previous string */
   slcd_SendText("            ", DOUT_VAL2R_X, DOUT_VAL3_Y, 0, LEFT_ALIGN);      
   
   switch (mbSlave.OutputFunction[OutputIndex])
   {
   default:
   case 0:
      /* function delay */   
      slcd_SendText("NA", DOUT_VAL2R_X, DOUT_VAL3_Y, 0, LEFT_ALIGN);      
      break;

   case 1:
      /* flow Rate */   
      slcd_SendText(gstr(&str->Flow), DOUT_VAL2R_X, DOUT_VAL3_Y, 0, LEFT_ALIGN);      
      break;

   case 2:
      /* Total */   
      slcd_SendText(gstr(&str->Total), DOUT_VAL2R_X, DOUT_VAL3_Y, 0, LEFT_ALIGN);      
      break;

   case 3:
      /* Mass */   
      slcd_SendText(gstr(&str->Mass), DOUT_VAL2R_X, DOUT_VAL3_Y, 0, LEFT_ALIGN);      
      break;

   case 4:
      /* Speed */   
      slcd_SendText(gstr(&str->Speed), DOUT_VAL2R_X, DOUT_VAL3_Y, 0, LEFT_ALIGN);      
      break;

   case 5:
      /* Analogue 1 */   
      slcd_SendText(gstr(&str->AnalogueIn1), DOUT_VAL2R_X, DOUT_VAL3_Y, 0, LEFT_ALIGN);      
      break;

   case 6:
      /* Analogue 2 */   
      slcd_SendText(gstr(&str->AnalogueIn2), DOUT_VAL2R_X, DOUT_VAL3_Y, 0, LEFT_ALIGN);      
      break;

   case 7:
      /* Totalizer */   
      slcd_SendText(gstr(&str->Totalizer), DOUT_VAL2R_X, DOUT_VAL3_Y, 0, LEFT_ALIGN);      
      break;

   case 8:
      /* belt cut */   
      slcd_SendText(gstr(&str->BeltCutCal), DOUT_VAL2R_X, DOUT_VAL3_Y, 0, LEFT_ALIGN);      
      break;

   case 9:
      /* belt tension */   
      slcd_SendText(gstr(&str->Tension), DOUT_VAL2R_X, DOUT_VAL3_Y, 0, LEFT_ALIGN);      
      break;
      
    case 10:
      /*P.E.R.A */
      slcd_SendText("P.E.R.A", DOUT_VAL2R_X, DOUT_VAL3_Y, 0, LEFT_ALIGN);      
      break;
   }
   
}

/*
** ------------------------------------------------------------------------------
**		Function: void PaintDigitalOut(void)
** ------------------------------------------------------------------------------
*/

void PaintDigitalOut(void)
{
   byte Buf[30];
   
   slcd_SetFont(24, 'B');
   slcd_SetColour(DarkGrey, White);  
      
   /* display select Output */
   sprintf(Buf, "%s   %u", gstr(&str->Output), OutputIndex+1);
   slcd_SendText(Buf, 20, DOUT_OUTPUT_Y, 0, LEFT_ALIGN);

   /* set colours back */
   slcd_SetColour(LightBlue, White);       

   if(PanelSize == PSZ_1024_600)
      slcd_SetFont(14, 0);
   else
      slcd_SetFont(16, 'B');  
  
             
   /* Alarms */      
   sprintf(Buf, "%.1f    ", mbSlave.AlarmHi[OutputIndex]);
   slcd_SendText(&Buf, 50, DOUT_VAL2_Y, 0, LEFT_ALIGN);    

   sprintf(Buf, "%.1f    ", mbSlave.AlarmLo[OutputIndex]);
   slcd_SendText(&Buf, 50, DOUT_VAL3_Y, 0, LEFT_ALIGN); 
   
   /* output delay */   
   OutputDelayReg = mbSlave.OutputDelay[OutputIndex]*100;  
   sprintf(Buf, "%u mS    ", OutputDelayReg);
   slcd_SendText(&Buf, DOUT_VAL2R_X, DOUT_VAL2_Y, 0, LEFT_ALIGN);  
   
   DisplayOutputFunction();
   
}

/*
** ------------------------------------------------------------------------------
**		Function: void DisplayOutputLEDs(void)
** ------------------------------------------------------------------------------
*/

void DisplayOutputLEDs(void)
{

   if(mbSlave.Outputs!=OutPutImg)
   {
      OutPutImg = mbSlave.Outputs;
         
      /* output 1 */
      if(mbSlave.Outputs&0x01)
         slcd_DisplayBmp(29, 160, DOUT_LED_Y); 
      else
         slcd_DisplayBmp(28, 160, DOUT_LED_Y); 
      
      /* output 2 */
      if(mbSlave.Outputs&0x02)
         slcd_DisplayBmp(29, 220, DOUT_LED_Y); 
      else
         slcd_DisplayBmp(28, 220, DOUT_LED_Y); 
      
      /* output 3 */
      if(mbSlave.Outputs&0x04)
         slcd_DisplayBmp(29, 280, DOUT_LED_Y); 
      else
         slcd_DisplayBmp(28, 280, DOUT_LED_Y); 
      
      /* output 4 */
      if(mbSlave.Outputs&0x08)
         slcd_DisplayBmp(29, 340, DOUT_LED_Y); 
      else
         slcd_DisplayBmp(28, 340, DOUT_LED_Y); 
   }
}

/*
** ------------------------------------------------------------------------------
**		Function: void UpdateDigitalOut(void)
** ------------------------------------------------------------------------------
*/

void UpdateDigitalOut(void)
{
   /* requested update */
   if (winUpdate1==1)
   {
      /* stop counter */
      winUpdate1 = 0;
      
   }

   /* time to update? */
   if (!winTimer1)
   {
      winTimer1 = 25;

      DisplayOutputLEDs();
      /* read outputs */
      mbTable[enOutputs].RdFlg = 0x1;
   }
}

/*
** ------------------------------------------------------------------------------
**		Function: byte winDigitalOutHandler(void)
** ------------------------------------------------------------------------------
*/

byte winDigitalOutHandler(void)
{
   switch (winDigitalOutState)
   {
   case WIN_DIGITAL_OUT_PREPAINT:
      /* get analog parameters from slave */
      ReadDigitalOutParameters();

      /* set delay for parameters to arrive from MCT  */
      winUpdate1 = 15;
      OutputIndex = 0;
            
      winDigitalOutState = WIN_DIGITAL_OUT_PAINT;
      break;
      
   case WIN_DIGITAL_OUT_PAINT:
      if(winUpdate1==1)
      {
         winUpdate1 = 0;

         slcd_SetColour(DarkGrey, DarkGrey);
         slcd_Send("z");

         slcd_Send("xc all");
         /* display menu screen */
         slcd_DisplayBmp(10, 0, 0);

         DisplayTitle("MS Instrumentos");

         slcd_SetFont(24, 0);
         slcd_SetColour(DarkGrey, White);

         /* display page title  */
         slcd_SendText(gstr(&str->DigitalOutputs), 15, 60, 0, LEFT_ALIGN);

         /* define back hotspot */
         slcd_MakeHotSpot(128, 560, 10, 50, 50);
         
         slcd_SetFont(16, 'B');
         /* display status LEDs */
         slcd_SendText(gstr(&str->Output), 10, DOUT_LED_Y, 'T', LEFT_ALIGN);

         /* make the image differ to force update */
         OutPutImg = mbSlave.Outputs+1;
         DisplayOutputLEDs();
        
         /* make page select buttons */
         slcd_MakeButton(1, 1, 483, DOUT_BTN_Y, 20, 21);
         slcd_MakeButton(2, 1, 552, DOUT_BTN_Y, 22, 21);         
         
         slcd_SetFont(16, 0);
         
         slcd_SendText(gstr(&str->TriggerHi),   20,  DOUT_LBL2_Y, 'T', LEFT_ALIGN);
         slcd_SendText(gstr(&str->TriggerLo),   20,  DOUT_LBL3_Y, 'T', LEFT_ALIGN);
         slcd_SendText(gstr(&str->OutputDelay), 360, DOUT_LBL2_Y, 'T', LEFT_ALIGN);
         slcd_SendText(gstr(&str->Function),   360, DOUT_LBL3_Y, 'T', LEFT_ALIGN);
         
         /* define hotspots (x, y, width, height) */
         slcd_MakeHotSpot(129, 50,  DOUT_VAL2_Y, 55, DOUT_HS_H);
         slcd_MakeHotSpot(130, 50,  DOUT_VAL3_Y, 55, DOUT_HS_H);
         slcd_MakeHotSpot(131, DOUT_VAL2R_X, DOUT_VAL2_Y, 55, DOUT_HS_H);
         slcd_MakeHotSpot(132, DOUT_VAL2R_X, DOUT_VAL3_Y, 55, DOUT_HS_H);
                  
         PaintDigitalOut();                
                       
         /* update parameters */
         winUpdate1 = 1;
         
         /* move to update state */      
         winDigitalOutState = WIN_DIGITAL_OUT_UPDATE;       
      }
      break;

   
   case WIN_DIGITAL_OUT_UPDATE:
      /* is there a key to process? */
      if (slcdKey)
      {
         /* call key handler */
         winDigitalOutKeyHandler(slcdKey);      
         /* now the key has been processed clear it */
         slcdKey = 0; 
      }

      UpdateDigitalOut();

      /* has any data been remotely changed? */
      if(mbSlave.DataUpdate)
      {
         /* clear data update flag */
         mbSlave.DataUpdate = 0;
         mbTable[enDataUp].WrFlg = 1;   
         
         /* read analog parameters */
         ReadDigitalOutParameters();  
         
         /* set update timer */                   
         winUpdate1 = 100;
      }      
      return 0;

  case WIN_DIGITAL_OUT_NUMKEYPAD:
      /* see if key pad is returning */
      if(winKeyPadHandler())
      {
         /* move to update state */      
         winDigitalOutState = WIN_DIGITAL_OUT_PAINT; 
         
         winUpdate1 = 1;
      }
      break;
            
   case WIN_DIGITAL_OUT_UNLOAD:
      /* do any necessary clearing up */
      winDigitalOutState = WIN_DIGITAL_OUT_PREPAINT;  

      /* set return menu */
      winActiveWin = INPUTSOUTPUTS_WINDOW;

      /* return from key pad */
      return 1;
   }   
}



