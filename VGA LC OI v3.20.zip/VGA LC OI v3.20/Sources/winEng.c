#include <hidef.h>                           /* common defines and macros */
#include "derivative.h"                      /* derivative information */

/*
** ------------------------------------------------------------------------------
   
   File   : winEng.c 
   Aurthor: 
   
   Description:  
   
   Version Log          Notes                                     Changes Made by                                        
   --------------       -----                                     ---------------
   14-04-09:            Created                                   Stuart


** ------------------------------------------------------------------------------
                                    
                                    Overview
                                            
** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

/* library headers */
#include "stdio.h"

/* Application headers */
#include "Subs.h"
#include "SlcdSubs.h"
#include "ModbusM Int.h"
#include "ModBusM.h"
#include "EEPROM.h"
#include "SLCD 260217.h"
#include "winMain.h"
#include "winKey.h"
#include "winConfirm.h"
#include "Language.h"




/* Implements this interface: */
#define WINENG_C
#include "winEng.h"

#pragma CODE_SEG WINENG_Code
#pragma DATA_SEG WINENG_Data


/* private */
static byte winEngState;
static byte winEngPage;



/* public */



/*
** ------------------------------------------------------------------------------
**		LanguageText
** ------------------------------------------------------------------------------
*/

byte *LanguageText1[]=
{
"English", "Portuguese"
};




void winEngMenuKeyHandler(byte key)
{
   switch (key)
   {
   case 1:      /* Tacho */     
      /* move to paint state */      
      winEngState = WIN_ENG_PAINT; 
      /* send command to execute macro 2 */
      slcdCallMacro(2);
      /* general page */            
      winEngPage = PAGE1;
      break;

   case 2:      /* AD7730 */     
      /* move to paint state */      
      winEngState = WIN_ENG_PAINT; 
      /* send command to execute macro 2 */
      slcdCallMacro(2);
      /* Constituents page */            
      winEngPage = PAGE2;
      break;
      
   case 3:      /* EEPROM */     
      /* move to paint state */      
      winEngState = WIN_ENG_PAINT; 
      /* send command to execute macro 2 */
      slcdCallMacro(2);
      /* Constants page */            
      winEngPage = PAGE3;
      break;

   case 4:      /*  */     
      /* move to paint state */      
      //winEngState = WIN_ENG_PAINT; 
      /* send command to execute macro 2 */
      //slcdCallMacro(2);
      /* Thermocouple page */            
      //winEngPage = PAGE4;
      break;

   case 5:      /*  */     
      /* move to paint state */      
      //winEngState = WIN_ENG_PAINT; 
      /* send command to execute macro 2 */
      //slcdCallMacro(2);
      /* languages page */            
      //winEngPage = PAGE5;
      break;

   case 6:      /*  */     
      /* move to paint state */      
      //winEngState = WIN_ENG_PAINT; 
      /* send command to execute macro 2 */
      //slcdCallMacro(2);
      /* EEPROM page */            
      //winEngPage = PAGE6;
      break;

   case 128:       /* EXIT */
      /* shut down main window handler */
      winEngState = WIN_ENG_UNLOAD;     
      break;
   }
}



/*
** ------------------------------------------------------------------------------
**		Function: void winPage5EngKeyHandler(byte key)
** ------------------------------------------------------------------------------
*/

void winPage4EngKeyHandler(byte key)
{
   switch (key)
   {
   case 131:
      /* English */
      EEWR_8(&EEPROM.Language, ENGLISH);  
      LangInit();
      winUpdate1 = 1;
      break;        

   case 132:
      /* Portuguees  */
      EEWR_8(&EEPROM.Language, PORTUGUESE);  
      LangInit();
      winUpdate1 = 1;
      break;       
   }
}


/*
** ------------------------------------------------------------------------------
**		Function: void winPage3EngKeyHandler(byte key)
** ------------------------------------------------------------------------------
*/

void winPage3EngKeyHandler(byte key)
{
   switch (key)
   {
   default:
      break;
   }
}





/*
** ------------------------------------------------------------------------------
**		Function: void winPage1EngKeyHandler(byte key)
** ------------------------------------------------------------------------------
*/

void winPage1EngKeyHandler(byte key)
{
   switch (key)
   {
 
   }
}

/*
** ------------------------------------------------------------------------------
**		Function: void winEngKeyHandler(byte key)
** ------------------------------------------------------------------------------
*/

void winEngKeyHandler(byte key)
{
   switch (key)
   {
   case 128:       /* EXIT */
      /* shut down main window handler */
      winEngState = WIN_ENG_PAINT_MENU;     
      break;

   default:
      /* Update selected page */
      switch (winEngPage) 
      {
      case PAGE1:      /*  Tacho Page */
         winPage1EngKeyHandler(key);
         break;

      case PAGE2:      /*  AD7730 Page */
         //winPage2EngKeyHandler(key);
         break;

      case PAGE3:      /*  EEPROM */
         winPage3EngKeyHandler(key);
         break;
      }
      break;            
   }
}

/*
** ------------------------------------------------------------------------------
**		Function: void wePaintEEprom(void)
** ------------------------------------------------------------------------------
*/

void wePaintEEprom(void)
{
   /* send command to execute macro 2 */
   slcdCallMacro(2);
         
   /* set forground and back ground colour */
   slcdSetColour(DarkGrey, White);
   /* set font */         
   slcdSetFont(F24B);             
   
   /* display page title  */
   DisplayText(gstr(&str->EEPROM), 16,  7, 'T');
   
   /* send macro 27 to make hotspots */
   slcdCallMacro(27);

   /* set forground and back ground colour */
   slcdSetColour(DarkGrey, White);
   /* set font */
   slcdSetFont(F16);         
               
   /* restore instrument setting  */
   DisplayText(gstr(&str->Restore_Instrument),  87, 103, 'T');
   DisplayText(gstr(&str->Settings),            87, 142, 'T');
   
   /* backup instrument settings */ 
   DisplayText(gstr(&str->Backup_Instrument),   87, 209, 'T');
   DisplayText(gstr(&str->Settings),            87, 248, 'T');

   /* restore factory defults */ 
   DisplayText(gstr(&str->Restore_Factory),     87, 315, 'T');
   DisplayText(gstr(&str->Defaults),            87, 354, 'T');

   if(PassWord==8228)
   {
      /* set forground and back ground colour */
      slcdSetColour(LightGrey, White);
               
      slcd_CmdQueue("bd 4 310 106 1 \" \" 0 0 4 3");
      slcd_CmdQueue("r 380 106 600 170 1");             

      /* set forground and back ground colour */
      slcdSetColour(DarkGrey, White);
            
      /* Erase External EEPROM */
      DisplayText(gstr(&str->Erase),                  380,  103, 'T');   
      DisplayText("EEPROM",                 380,  142, 'T');       
   }
}

/*
** ------------------------------------------------------------------------------
**		Function: void wePaintEEprom(void)
** ------------------------------------------------------------------------------
*/

void weUpdateEEprom(void)
{
  
}

/*
** ------------------------------------------------------------------------------
**		Function: void wePaintLanguages(void)
** ------------------------------------------------------------------------------
*/

void wePaintLanguages(void)
{
   /* send command to execute macro 2 */
   slcdCallMacro(2);
         
   /* set forground and back ground colour */
   slcdSetColour(DarkGrey, DarkGrey);
   /* set font */
   #ifdef FIVEPOINTSEVEN      
   slcdSetFont(F24B);         
   #else
   if(EEPROM.Language==4)
      slcdSetFont(FCH16);         
   else                     
      slcdSetFont(F32B);         
   #endif 
   
   /* display page title  */
   DisplayText(gstr(&str->Languages), 16, 7, 'T');

   /* display page title  */
   DisplayText(gstr(&str->Select_Language), 16, 89, 'T');   

   /* set font */
   slcdSetFont(F16B);         

   /* make hotspots */
   MakeHotSpot(131, 28,  194, 134, 240);
   MakeHotSpot(132, 28,  266, 134, 310);
   MakeHotSpot(133, 28,  336, 134, 380);
   MakeHotSpot(134, 28,  408, 134, 450);
   
   MakeHotSpot(135, 240, 194, 488, 240);
   MakeHotSpot(136, 240, 266, 488, 310);
   MakeHotSpot(137, 240, 336, 488, 380);
   MakeHotSpot(138, 240, 408, 488, 450);    
      
   /* force update */
   winUpdate1 = 1;
}

/*
** ------------------------------------------------------------------------------
**		Function: void weUpdateLanguages(void)
** ------------------------------------------------------------------------------
*/

void weUpdateLanguages(void)
{
   byte i;

   /* requested update */
   if (winUpdate1==1)
   {
      winUpdate1 = 0;
     
      for(i=0;i<1;i++)
      {
         if(EEPROM.Language==i)
            /* set colours back */
            slcdSetColour(LightBlue, Grey);         
         else
            /* set colours back */
            slcdSetColour(DarkGrey, White);         
         
         /* display language */
         DisplayText(LanguageText1[i],  27,  (ccY1+((35*i)*2)), 0);    
      }
   }
}






  



/*
** ------------------------------------------------------------------------------
**		Function: void ReadTacho(void)
** ------------------------------------------------------------------------------
*/

void ReadTacho(void)
{

}

/*
** ------------------------------------------------------------------------------
**		Function: void wePaintTacho(void)
** ------------------------------------------------------------------------------
*/

void wePaintTacho(void)
{

   /* send command to execute macro 2 */
   slcdCallMacro(2);
      
 
   /* force quick update */
   winTimer1 = 50;
   winUpdate1 = 50;
}

/*
** ------------------------------------------------------------------------------
**		Function: void weUpdateTacho(void)
** ------------------------------------------------------------------------------
*/

void weUpdateTacho(void)
{   
   /* time to update? */
   if (!winTimer1)
   {
      winTimer1 = 50;

  
   }

   /* requested update */
   if (winUpdate1==1)
   {
      /* stop counter */
      winUpdate1 = 0;

   
   }
}

/*
** ------------------------------------------------------------------------------
**		Function: void winEngHandler(void)
** ------------------------------------------------------------------------------
*/

void winEngHandler(void)
{
   switch (winEngState)
   {
   case WIN_ENG_PAINT_MENU:
      /* send command to execute macro 2 */
      slcdCallMacro(2);
      /* send macro 3 to make hotspots */
      slcdCallMacro(3);

      /* set forground and back ground colour */
      slcdSetColour(DarkGrey, White);
                  
      /* set font */
      slcdSetFont(F24B);                
      
      /* display page title  */
      DisplayText(gstr(&str->SelectMenu), 16, 7, 'T');
      
      /* set font */
      slcdSetFont(F16B);                
            
      /* Cal parameters  */
      DisplayText(gstr(&str->Tacho),     87, 103, 'T');
      DisplayText(gstr(&str->Input),     87, 142, 'T');
      
      /* calibration check */ 
      DisplayText(gstr(&str->AD7730),    87, 209, 'T');
      DisplayText(gstr(&str->Converter), 87, 248, 'T');
      
      /* diagnostics */
      DisplayText(gstr(&str->EEPROM),    87, 315, 'T');
            
      /* Cal routine */
      //slcdDisplayText(gstr(&str->Thermocouple), getX(285),  getY(58), 'T');      

      //slcdDisplayText(gstr(&str->Languages), getX(285),  getY(118), 'T');      
         
      /* FieldBus */
      //slcdDisplayText(gstr(&str->EEPROM), getX(285),  getY(178), 'T');         
      
      /* move to select menu state */      
      winEngState = WIN_ENG_SELECT_MENU;        
      break;
      
   case WIN_ENG_SELECT_MENU:
      /* is there a key to process? */
      if (slcdKey)
      {
         /* call key handler */
         winEngMenuKeyHandler(slcdKey);      
         /* now the key has been processed clear it */
         slcdKey = 0; 
      }   
      break;
      
   
   case WIN_ENG_PAINT:
      /* paint selected page */
      switch (winEngPage) 
      {
      case PAGE1:      /* page 1 */
         wePaintTacho();               
         /* move to update state */      
         winEngState = WIN_ENG_UPDATE;       
         break;

      case PAGE2:      /* page 2 */
         //wePaintAD7730();    
         break;

      case PAGE3:      /* page 3 */
         wePaintEEprom();    
         /* move to update state */      
         winEngState = WIN_ENG_UPDATE;       
         break;

      case PAGE4:      /* page 4 */
         //wePaintThermocouple();    
         /* move to update state */      
         winEngState = WIN_ENG_UPDATE;       
         break;

      case PAGE5:      /* page 5 */
         //wePaintLanguages();    
         /* move to update state */      
         winEngState = WIN_ENG_UPDATE;       
         break;

      case PAGE6:      /* page 6 */
         //wePaintEEprom();    
         /* move to update state */      
         winEngState = WIN_ENG_UPDATE;       
         break;
      }   
      break;

   case WIN_ENG_UPDATE:
      /* is there a key to process? */
      if (slcdKey)
      {
         /* call key handler */
         winEngKeyHandler(slcdKey);      
         /* now the key has been processed clear it */
         slcdKey = 0; 
      }
   
      /* Update selected page */
      switch (winEngPage) 
      {
      case PAGE1:      /*  page 1 */
         weUpdateTacho();         
         break;

      case PAGE2:      /*  page 2 */
         //weUpdateAD7730();
         break;

      case PAGE3:      /*  page 3 */
         weUpdateEEprom();
         break;

      case PAGE4:      /*  page 4 */
         //weUpdateThermocouple();
         break;

      case PAGE5:      /*  page 5 */
         //weUpdateLanguages();
         break;
      
      case PAGE6:      /*  page 6 */
         //weUpdateEEprom();
         break;
      }    

      /* has any data been remotely changed? */
      if(mbSlave.DataUpdate)
      {
         /* clear data update flag */
         mbSlave.DataUpdate = 0;
         mbTable[enDataUp].WrFlg = 1;   
         
         
         /* Update selected page */
         switch (winEngPage) 
         {
         case PAGE1:      /*  page 1 */
            ReadTacho(); 
            break;

         case PAGE2:      /*  page 2 */
            //ReadAD7730(); 
            break;

         case PAGE3:      /*  page 3 */
            //ReadEEPROM(); 
            break;

         case PAGE4:      /*  page 4 */
            break;

         case PAGE5:      /*  page 5 */
            break;
         
         case PAGE6:      /*  page 6 */
            break;
         }              
         
         /* set update timer */                   
         winUpdate1 = 50;
      }          
              
      break;

  case WIN_ENG_NUMKEYPAD:
      /* see if key pad is returning */
      if(winKeyPadHandler())
         /* move to update state */      
         winEngState = WIN_ENG_PAINT;          
      break; 

  case WIN_ENG_CONFIRM:
      /* see if confirmation win is returning */
      switch(winConfirmHandler()) 
      {
      case 1:
         /* move to update state */      
         winEngState = WIN_ENG_PAINT;          
         break;

      case 2:
         /* move to update state */      
         winEngState = WIN_ENG_PAINT;
         break;
      }
      break; 
      
   case WIN_ENG_UNLOAD:
      /* do any necessary clearing up */
      winEngState = WIN_ENG_PAINT_MENU;  

      
      /* switch to menu screen */
      winActiveWin = SETUP_WINDOW;      
      break;
   }   
}



