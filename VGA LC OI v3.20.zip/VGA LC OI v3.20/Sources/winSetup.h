/*
** ------------------------------------------------------------------------------
   
   File   : winSetup.h 
   Aurthor: Stuart Clarke

** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

#ifndef WINSETUP_H
#define WINSETUP_H


/* public defines */

/*
** ------------------------------------------------------------------------------
**		#define : win setup handler states 
** ------------------------------------------------------------------------------
*/

#define WIN_SETUP_PAINT             0
#define WIN_SETUP_UPDATE            1
#define WIN_SETUP_UNLOAD            2
#define WIN_SETUP_ENTER_PASSWORD    3



#ifndef WINSETUP_C


/* public variables */
#pragma DATA_SEG WINSETUP_Data

#endif   /* WINMENU_C */      




/* public functions */
#pragma CODE_SEG WINSETUP_Code

/*
** ------------------------------------------------------------------------------
**		Function: void winSetupHandler(void)
** ------------------------------------------------------------------------------
*/

void winSetupHandler(void);


#endif   /* WINSETUP_H */
