#include <hidef.h>                           /* common defines and macros */
#include "derivative.h"       /* derivative information */

/*
** ------------------------------------------------------------------------------
   
   File   : Flash.c 
   Aurthor: 
   
   Description:  
   
   Version Log          Notes                                     Changes Made by                                        
   --------------       -----                                     ---------------
   25-06-11:            Created                                   Stuart Clarke
        
** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

/* library headers */


/* Application headers */
#include "Serial.h"


/* Implements this interface: */
#define FLASH_C
#include "Flash.h"

#pragma STRING_SEG ROM_FE00_SEG
#pragma CODE_SEG   ROM_F200_SEG
#pragma DATA_SEG   FLASH_DATA

/* private */



/* public */

/*
** ------------------------------------------------------------------------------
**		Function: void _Flash_Init(void)
** ------------------------------------------------------------------------------
*/

void _Flash_Init(void)
{
   /* Initialize the flash Clock */
   FCLKDIV = 0x41;
}

/*
** ------------------------------------------------------------------------------
**		Linker symbols
** ------------------------------------------------------------------------------
*/

#define __SEG_START_REF(a) __SEG_START_ ## a
#define __SEG_END_REF(a)   __SEG_END_ ## a
#define __SEG_SIZE_REF(a)  __SEG_SIZE_ ## a

#define __SEG_START_DEF(a) extern char __SEG_START_REF(a) []
#define __SEG_END_DEF(a)   extern char __SEG_END_REF(a) []
#define __SEG_SIZE_DEF(a)  extern char __SEG_SIZE_REF(a) []

__SEG_START_DEF(ROM_F000_SEG);
__SEG_END_DEF(ROM_F000_SEG);
__SEG_SIZE_DEF(ROM_F000_SEG);

/*
** ------------------------------------------------------------------------------
**		Function: static void CopyCodeToRAM(void)
** ------------------------------------------------------------------------------
*/

void CopyCodeToRAM(void)
{
   byte *Src;
   byte *Dst;
   word  SegSize;
   word  x;

   Src     = (byte *)__SEG_START_REF(ROM_F000_SEG);		/* RAM code resides in Flash from 0xf000 - 0xf1ff */
   Dst     = (byte *)0x3e00;					               /* copied to the upper 512 bytes of RAM */
   SegSize = (word)__SEG_SIZE_REF(ROM_F000_SEG);

   for (x = 0; x < SegSize; x++)	            
      *Dst++ = *Src++;
}

/*
** ------------------------------------------------------------------------------
**		Function: byte ErasePage(byte Page, word Sect, byte SectCnt)
** ------------------------------------------------------------------------------
*/

byte ErasePage(byte Page, word Sect, byte SectCnt)
{
   byte i;
   word j;

   /* red led on */
   PTP_PTP5 = 0;  
      
   /* erase 16 sectors in each page */      
   for (i = 0; i < SectCnt; i++)
   {
      PPAGE = Page;
      
      /* erase a sector */
      if (EraseFlashCmd(Page, Sect, SectorEraseCmd))			
      {
         _SendMsg("Sector Erase Error\r");	      
         return 1;
      }         
      
      /* check one word at a time */
      for (j = 0; j < 512; j++)								   
      {
         if (*((word *)Sect) != 0xFFFF)				/* erased? */
         {
            _SendMsg("Sector Erase Verify Error\r");	      
            return 1;
         }
         Sect += 2;
      }
   }   

   /* red led off */
   PTP_PTP5 = 1;  
   
   return 0; 
}

/*
** ------------------------------------------------------------------------------
**		Function: byte EraseBlock(byte Page, word Sect)
** ------------------------------------------------------------------------------
*/

byte EraseBlock(byte Page, word Sect)
{
   /* red led on */
   PTP_PTP5 = 0;  
         
   /* perform a mass erase on a block */
   if (EraseFlashCmd(Page, Sect, MassEraseCmd))	
   {
      _SendMsg("Block Erase Error\r");	
      return 1;      
   }

   /* perform a mass erase verify on the erased block */
   if (EraseFlashCmd(Page, Sect, EraseVerfCmd) || !(FSTAT&BLANK))	
   {
      _SendMsg("Block Erase Verify Error\r");	      
      return 1;
   } 

   /* red led off */
   PTP_PTP5 = 1;  
         
   return 0;  
}

/*
** ------------------------------------------------------------------------------
**		Function: byte EraseFlash(void)
** ------------------------------------------------------------------------------
*/

byte EraseFlash(void)
{
   word i;
   byte Buf[40];

   _strcpy1(Buf, "Flash Block Erase E08000 - E78000\r");
   _SendMsg(Buf);	      
   
   if(EraseBlock(0xE0, 0x8000))
      return 1;

   /* load page erase string */      
   _strcpy1(Buf, "Flash Page Erase F88000 - F8BFFF\r");
                        
   /* must perform a Page/sector erase on block 0 because the bootloader is protected */
   for (i = 0; i < 7; i++)			
   {
      _SendMsg(Buf);

      if(ErasePage(0xF8+i, 0x8000, 16))
         return 1;

      /* switch to hex address */   
      if(i==1)
      {
         Buf[18] = 'A';
         Buf[27] = 'A';      
      }
      else
      {
         Buf[18]++;
         Buf[27]++;      
      }
   }
   
   /* load boot page erase string */      
   _strcpy1(Buf, "Flash Page Erase FF8000 - FFB000\r");
   _SendMsg(Buf);

   if(ErasePage(0xFF, 0x8000, 12))
      return 1;

   /* send erase info string */
   _SendMsg("Erase Complete\r");	 
         
   return 0;     
}

/*
** ------------------------------------------------------------------------------
**		Function: byte GetHexByte(byte *Adr)
** ------------------------------------------------------------------------------
*/

byte GetHexByte(byte *Adr)
{
   byte i = 0;
   
   /* get first nibble */
   if(*Adr>='0' && *Adr<='9')
      i = *Adr - '0';      
   else
      i = *Adr - 'A'+10;      
   
   i<<=4;

   /* get second nibble */
   Adr++;
   
   if(*Adr>='0' && *Adr<='9')
      i += *Adr - '0';      
   else
      i += *Adr - 'A'+10;      
         
   return i;   
}

/*
** ------------------------------------------------------------------------------
**		Function: byte GetHexWord(word *Adr)
** ------------------------------------------------------------------------------
*/

word GetHexWord(word *Adr)
{
   word  w = 0;

   w = GetHexByte(Adr);
   w<<=8;
   w |= GetHexByte(Adr+1);   
   
   return w;      
}

/*
** ------------------------------------------------------------------------------
**		Function: byte *ProgramS1(void)
** ------------------------------------------------------------------------------
*/

byte *ProgramS1(void)
{ 
   s1Type sRecord;
   
   volatile byte   *Ptr1 = (byte *)0x3100;
   volatile byte   *Ptr2 = (byte *)0x3508;
   byte   i, j, CheckSum;
        
   /* get s record header info */
   sRecord.ByteCount = GetHexByte((byte *)0x3502);
   /* load checksum with byte count */
   CheckSum = sRecord.ByteCount;
   
   /* get address */   
   sRecord.Address = GetHexWord((word *)0x3504);
   /* add address to check sum */      
   CheckSum += GetHexByte((byte *)0x3504);
   CheckSum += GetHexByte((byte *)0x3506);
   
   sRecord.ByteCount -=3;
   
   /* now check the check sum */   
   for(i=0;i<sRecord.ByteCount;i++) 
   {
      /* convert data from ASCI to Hex and add to check sum */
      j = GetHexByte(Ptr2);
      CheckSum += j;
      
      /* move ptr to next hex pair */
      Ptr2+=2;
      /* save int data */      
      *Ptr1++ = j;
   }

   /* get checksum from s record */   
   sRecord.CheckSum  = GetHexByte(Ptr2);   
   /* ones compliment */
   CheckSum = ~CheckSum;				
   
   if (CheckSum != sRecord.CheckSum)           /* calculated checksum == received checksum ? */
   {
      return("Checksum Error");				      /* no. return an error */
   }
   else
   {
      /* dont re program bootloader sector */
      if(sRecord.Address<0xF000)
      {
         /* check which fixed page is required */
         if(sRecord.Address>0x3FFF && sRecord.Address<0x8000)
         {
            i = ProgFlashBlock(0xFE, (word *)sRecord.Address, (word *)0x3100, sRecord.ByteCount);
            if(!i)	
            {
               return "OK\r";
            }
            else
            {
               if(i==3)
                  return("Flash Programming Error\r");
               else
                  return("Flash Verify Error\r");
            }
         }
         else
         {
            if(sRecord.Address>0xBFFF && sRecord.Address<0xF000)
            {
               
               i = ProgFlashBlock(0xFF, (word *)sRecord.Address, (word *)0x3100, sRecord.ByteCount);	
               if(!i)	
               {
                  return "OK\r";
               }
               else
               {
                  if(i==3)
                     return("Flash Programming Error\r");
                  else
                     return("Flash Verify Error\r");
               }
            }
            else
            {
               return("Address Error\r");               
            }
         }
      }
      else
      {
         return "OK\r";   
      }
   }
}	

/*
** ------------------------------------------------------------------------------
**		Function: byte *ProgramS2(void)
** ------------------------------------------------------------------------------
*/

byte *ProgramS2(void)
{ 
   s2Type sRecord;
   byte   i, j, CheckSum;
   byte   *Ptr1 = (byte *)0x3100;
   byte   *Ptr2 = (byte *)0x350A;
   
   /* get s reacord header info */
   sRecord.ByteCount = GetHexByte((byte *)0x3502);
   /* load checksum with byte count */
   CheckSum = sRecord.ByteCount;
   
   /* get page */   
   sRecord.Page = GetHexByte((word *)0x3504);
   /* add to check sum */      
   CheckSum += sRecord.Page;

   /* get address */      
   sRecord.Address   = GetHexWord((word *)0x3506);
   /* add address to check sum */      
   CheckSum += GetHexByte((byte *)0x3506);
   CheckSum += GetHexByte((byte *)0x3508);
   
   sRecord.ByteCount -=4;   
   
   /* now check the check sum */   
   for(i=0;i<sRecord.ByteCount;i++) 
   {
      /* convert data from ASCI to Hex and add to check sum */
      j = GetHexByte(Ptr2);
      CheckSum += j;
      
      /* move ptr to next hex pair */
      Ptr2+=2;
      /* save int data */      
      *Ptr1++ = j;
   }

   /* get checksum from s record */   
   sRecord.CheckSum  = GetHexByte(Ptr2);
   /* ones compliment */
   CheckSum = ~CheckSum;				
   
   if (CheckSum != sRecord.CheckSum)           /* calculated checksum == received checksum ? */
   {
      return("Checksum Error");				      /* no. return an error */
   }
   else
   {
      /* check which page is required */
      if(sRecord.Address>0x7FFF && sRecord.Address<0xBFFF)
      {
         i = ProgFlashBlock(sRecord.Page, (word *)sRecord.Address, (word *)0x3100, sRecord.ByteCount);
         if(!i)	
         {
            return "OK\r";
         }
         else
         {
            if(i==3)
               return("Flash Programming Error\r");
            else
               return("Flash Verify Error\r");
         }
      }
      else
      {
         return("Address Error\r");               
      }
   }   
}	

/*
** ------------------------------------------------------------------------------
**		#pragma: Ram Relocation segment 
** ------------------------------------------------------------------------------
*/

#pragma CODE_SEG ROM_F000_SEG

/*
** ------------------------------------------------------------------------------
**		Function: byte EraseFlashCmd(ulong FlashAddress, byte FlashCmd)
** ------------------------------------------------------------------------------
*/

byte EraseFlashCmd(byte Page, word Sector, byte FlashCmd)
{
   /* clear the error flags */
   FSTAT = ACCERR + PVIOL;				
   //PPAGE = (FlashAddress - 0x400000) / FPageWsize;	
   PPAGE = Page;	
   
   //*(word *)(((FlashAddress - 0x400000) % FPageWsize) + FPageWstart) = 0xffff;
   *(word *)Sector = 0xffff;
   FCMD  = FlashCmd;
   FSTAT = CBEIF;			
   
   /* launch the command */
   if ((FSTAT & (ACCERR + PVIOL)) != 0)	/* problem executing the command? */
      return(4);  /* flash erase error */
   
   while (!(FSTAT&CCIF));
   
   return(0);
}

/*
** ------------------------------------------------------------------------------
**		Function: byte ProgFlashBlock(byte PPAGEVal, word *PPAGEWinAddr, word *DataBuff, word NumWords)
** ------------------------------------------------------------------------------
*/

byte ProgFlashBlock(byte Page, word *AdrPtr, word *DataPtr, word ByteCnt)
{
   word  x, WordCnt;
     
   WordCnt = ByteCnt/2;      
   PPAGE = Page;

      
   for (x = 0; x < WordCnt; x++)
   {
      /* wait here until the command buffer has room for the next command */
      while ((FSTAT & CBEIF)==0);
   
      FSTAT = ACCERR + PVIOL;		         /* clear the error flags */
      
      *AdrPtr = *DataPtr;		            /* write a word to Flash */
      
      FCMD  = ProgCmd;			            /* write the program command to the command register */
      FSTAT = CBEIF;			               /* launch the command */
      
      if ((FSTAT & (ACCERR + PVIOL)) != 0)/* problem executing the command? */
         return 3;
      
      while ((FSTAT & CCIF)==0);

      if(*AdrPtr != *DataPtr)
         return 4;
      
      AdrPtr++;
      DataPtr++;            
   }
   
   /* odd no of bytes? */
   if(ByteCnt&0x01)
   {
      /* program last byte */

      /* wait here until the command buffer has room for the next command */
      while (!(FSTAT & CBEIF));
      FSTAT = ACCERR + PVIOL;		         /* clear the error flags */
      
      /* get odd byte */
      x = *(byte *)DataPtr;
      x<<=8;
      x |= 0x00FF;
       
      *AdrPtr = x;
      
      FCMD  = ProgCmd;			            /* write the program command to the command register */
      FSTAT = CBEIF;			               /* launch the command */
      
      if ((FSTAT & (ACCERR + PVIOL)) != 0)/* problem executing the command? */
         return 3;
      
      while ((FSTAT & CCIF)==0);

      if(*AdrPtr != x)
         return 4;      
   }   

   return 0;
}


