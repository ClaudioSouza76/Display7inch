#include <hidef.h>                           /* common defines and macros */
#include "derivative.h"                      /* derivative information */

/*
** ------------------------------------------------------------------------------
   
   File   : winDigits.c 
   Aurthor: 
   
   Description:  
   
   Version Log          Notes                                     Changes Made by                                        
   --------------       -----                                     ---------------
   25-07-10:            Created                                   Stuart


** ------------------------------------------------------------------------------
                                    
                                    Overview
                                            
** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

/* library headers */
#include "stdio.h"
#include "float.h"
#include "math.h"

/* Application headers */
#include "CRG 100110.h" 
#include "Subs.h"
#include "ModBusM Int.h"
#include "ModBusM.h"
#include "EEPROM.h"
#include "SLCD 260217.h"
#include "winMain.h"
#include "winKey.h"
#include "Language.h"
#include "SlcdSubs.h"

/* Implements this interface: */
#define WINDIGITS_C
#include "winDigits.h"

#pragma CODE_SEG WINDIGITS_Code
#pragma DATA_SEG WINDIGITS_Data


/* private */
static byte winDigitsState;
static byte winDigitsPage;


/* public */



/*
** ------------------------------------------------------------------------------
**		Function: void winDigitsKeyHandler(byte key)
** ------------------------------------------------------------------------------
*/

void winDigitsKeyHandler(byte key)
{   
   switch (key)
   {
   case 128:       /* EXIT */
      /* shut down num key window handler */
      winDigitsState = WIN_DIGITS_UNLOAD;  
      break;  
      
   case 130:      /* Rate Damping */
      /* move to key pad handler sate */
      winDigitsState = WIN_DIGITS_NUMKEYPAD; 
      
      /* copy parameter data to key structure */
      strcpy(NumKeyData.Name, gstr(&str->Digits));  
      NumKeyData.KeyBoardType = NUMBER;
      NumKeyData.Type = BYTE;
      NumKeyData.iMax = 3;
      NumKeyData.Flag = enDigits;
      NumKeyData.DataPtr = (void *)&mbSlave.Digit;     
      break;      
         
   }
}

/*
** ------------------------------------------------------------------------------
**		Function: void ReadDigitsParameters(void)
** ------------------------------------------------------------------------------
*/

void ReadDigitsParameters(void)
{
   mbTable[enDigits].RdFlg = 0x1;
   

}

/*
** ------------------------------------------------------------------------------
**		Function: void PaintDigitsPage(void)
** ------------------------------------------------------------------------------
*/

void PaintDigitsPage(void)
{   
   byte Buf[25];

   slcd_SetFont(16, 'B');  
   
   /* set colours back */
   slcd_SetColour(DarkGrey, White);         

   /* display headings */
   slcd_SendText(gstr(&str->Digits),  27, ccY0, 'T', LEFT_ALIGN);     
   
   slcd_MakeHotSpot(130, 220, 130, 298, 170);
   
   /* force update */
   winUpdate1 = 1;
}


/*
** ------------------------------------------------------------------------------
**		Function: void UpdateDigits(void)
** ------------------------------------------------------------------------------
*/

void UpdateDigits(void)
{   
   byte Buf[25];
   
   /* requested update */
   if (winUpdate1==1)
   {
      /* stop counter */
      winUpdate1 = 0;

      /* set colours back */
      slcd_SetColour(LightBlue, White);       
      slcd_SetFont(16, 'B');  
      
      /* Rate Damp */
      sprintf(Buf, "%u", mbSlave.Digit);
      DisplayText(&Buf, 227, ccY0, 0);   //Before getY(ccY1),0);    
   }

   /* time to update? */
   if (!winTimer1)
   {
      //winTimer1 = 25;

     
   }
}

/*
** ------------------------------------------------------------------------------
**		Function: byte winDigitsHandler(void)
** ------------------------------------------------------------------------------
*/

byte winDigitsHandler(void)
{
   switch (winDigitsState)
   {
   case WIN_DIGITS_PREPAINT:
      /* get analog parameters from slave */
      ReadDigitsParameters();
      winDigitsState = WIN_DIGITS_PAINT;
      break;
      
   case WIN_DIGITS_PAINT:
         slcd_SetColour(DarkGrey, DarkGrey);
      slcd_Send("z");

      slcd_Send("xc all");     
      /* display menu screen */
      //DisplayBmp(16, 0, 0, LEFT_ALIGN); 
      slcd_DisplayBmp(10, 0, 0); 

      DisplayTitle("MS Instrumentos");
      
      slcd_SetFont(24, 0);
      slcd_SetColour(DarkGrey, White); 
      slcd_SendText(gstr(&str->Digits), 15, 60, 0, LEFT_ALIGN);
      
      /* define back hotspot */
      //slcd_CmdQueue("x 128 560 10 630 60");
      slcd_MakeHotSpot(128, 560, 10, 50, 50);
      
      /* update parameters */
      winUpdate1 = 1;
      
      /* move to update state */      
      winDigitsState = WIN_DIGITS_PAINT_PAGE;       
      break;

   case WIN_DIGITS_PAINT_PAGE:
                  
      PaintDigitsPage();
      
      /* move to update state */      
      winDigitsState = WIN_DIGITS_UPDATE;       
      break;

   case WIN_DIGITS_UPDATE:
      /* is there a key to process? */
      if (slcdKey)
      {
         /* call key handler */
         winDigitsKeyHandler(slcdKey);      
         /* now the key has been processed clear it */
         slcdKey = 0; 
      }

      UpdateDigits();

      /* has any data been remotely changed? */
      if(mbSlave.DataUpdate)
      {
         /* clear data update flag */
         mbSlave.DataUpdate = 0;
         mbTable[enDataUp].WrFlg = 1;   
         
         /* read analog parameters */
         ReadDigitsParameters();  
         
         /* set update timer */                   
         winUpdate1 = 100;
      }      
      break;

  case WIN_DIGITS_NUMKEYPAD:
      /* see if key pad is returning */
      if(winKeyPadHandler())
         /* move to update state */      
         winDigitsState = WIN_DIGITS_PAINT;   
      break;

   case WIN_DIGITS_UNLOAD:
      /* do any necessary clearing up */
      winDigitsState = WIN_DIGITS_PREPAINT;  

      /* clear page */
      winDigitsPage = 0;
      
      /* switch to menu screen */
      winActiveWin = SPECIALFUNC_WINDOW;  


      /* return from key pad */
      return 1;
   }   
}



