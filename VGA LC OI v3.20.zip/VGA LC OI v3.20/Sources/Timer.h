/*
** ------------------------------------------------------------------------------
   
   File   : Timer.h 
   Aurthor: Stuart Clarke
        
** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

#ifndef TIMER_H
#define TIMER_H


/* public defines */

#ifndef TIMER_C


/* public variables */
#pragma DATA_SEG   TIMER_DATA

extern word _Timer1S;

#endif   /* TIMER_C */ 


/* public functions */

#pragma CODE_SEG   ROM_F200_SEG

/*
** ------------------------------------------------------------------------------
**		Function: void _Timer_Init(void)
** ------------------------------------------------------------------------------
*/

void _Timer_Init(void);

/*
** ------------------------------------------------------------------------------
**		#pragma: Ram Relocation segment 
** ------------------------------------------------------------------------------
*/

#pragma CODE_SEG ROM_F000_SEG

/*
** ------------------------------------------------------------------------------
**		Function: static void _ETC0_Interrupt(void)
** ------------------------------------------------------------------------------
*/

__interrupt void near _ETC0_Interrupt(void);


/*
** ------------------------------------------------------------------------------
**		Function: static void _ETC1_Interrupt(void)
** ------------------------------------------------------------------------------
*/

__interrupt void near _ETC1_Interrupt(void);

#endif   /* TIMER_H */
