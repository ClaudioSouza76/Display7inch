#include <hidef.h>                           /* common defines and macros */
#include "derivative.h"                      /* derivative information */

/*
** ------------------------------------------------------------------------------
   
   File   : winCalFunction.c 
   Aurthor: 
   
   Description:  
   
   Version Log          Notes                                     Changes Made by                                        
   --------------       -----                                     ---------------
   25-07-10:            Created                                   Stuart


** ------------------------------------------------------------------------------
                                    
                                    Overview
                                            
** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

/* library headers */
#include "stdio.h"
#include "float.h"
#include "math.h"

/* Application headers */
#include "CRG 100110.h" 
#include "Subs.h"
#include "ModBusM Int.h"
#include "ModBusM.h"
#include "EEPROM.h"
#include "SLCD 260217.h"
#include "winMain.h"
#include "winKey.h"
#include "Language.h"
#include "SlcdSubs.h"

/* Implements this interface: */
#define WINCALFUNCTION_C
#include "winCalFunctions.h"

#pragma CODE_SEG WINCALFUNCTION_CODE
#pragma DATA_SEG WINCALFUNCTION_DATA


/* private */
static byte winCalFunctionsState;
static byte winCalFunctionsPage;


/* public */



/*
** ------------------------------------------------------------------------------
**		Function: void winCalFunctionsKeyHandler(byte key)
** ------------------------------------------------------------------------------
*/

void winCalFunctionsKeyHandler(byte key)
{   
   switch (key)
   {             
   case 128:       /* EXIT */
      /* shut down num key window handler */
      winCalFunctionsState = WIN_CAL_FUNCTION_UNLOAD;  
      break;  
      
   case 130:      /* Cal Time */
      /* move to key pad handler sate */
      winCalFunctionsState = WIN_CAL_FUNCTION_NUMKEYPAD; 
      
      /* copy parameter data to key structure */
      strcpy(NumKeyData.Name, gstr(&str->MinCalTime));  
      NumKeyData.KeyBoardType = NUMBER;
      NumKeyData.Type = BYTE;
      NumKeyData.Attributes = EPROM;
      NumKeyData.iMax = 60;
      NumKeyData.iMin = 1;
      NumKeyData.DataPtr = (void *)&EEPROM.MinCalTime;     
      break;      

   case 131:      /* Cal Time */
      /* move to key pad handler sate */
      winCalFunctionsState = WIN_CAL_FUNCTION_NUMKEYPAD; 
      
      /* copy parameter data to key structure */
      strcpy(NumKeyData.Name, gstr(&str->MaxCalTime));  
      NumKeyData.KeyBoardType = NUMBER;
      NumKeyData.Type = BYTE;
      NumKeyData.Attributes = EPROM;
      NumKeyData.iMax = 60;
      NumKeyData.iMin = 1;
      NumKeyData.DataPtr = (void *)&EEPROM.MaxCalTime;     
      break;      
      
  case 132:      /* Zero mV limit */
      /* move to key pad handler sate */
      winCalFunctionsState = WIN_CAL_FUNCTION_NUMKEYPAD; 
      
      /* copy parameter data to key structure */
      strcpy(NumKeyData.Name, gstr(&str->CalZeroLimit));  
      NumKeyData.KeyBoardType = NUMBER;
      NumKeyData.Type = FLOAT;
      NumKeyData.Attributes = EPROM;
      NumKeyData.fMax = 10;
      NumKeyData.fMin = 0.5;
      NumKeyData.DataPtr = (void *)&EEPROM.ZeroMvLimit;     
      break; 
      
      case 133:      /* Fator K */
      /* move to key pad handler sate */
      winCalFunctionsState = WIN_CAL_FUNCTION_NUMKEYPAD; 
      
      /* copy parameter data to key structure */
      strcpy(NumKeyData.Name, "Fator K");  
      NumKeyData.KeyBoardType = NUMBER;
      NumKeyData.Type = FLOAT;
      //NumKeyData.Attributes = EPROM;
      NumKeyData.fMax = 2;
      NumKeyData.fMin = 0;
      NumKeyData.Flag  = enFactork;
      NumKeyData.DataPtr = (void *)&mbSlave.fFactorK;
      break; 
      
  case 134:      /* Fator Kd */
      /* move to key pad handler sate */
      winCalFunctionsState = WIN_CAL_FUNCTION_NUMKEYPAD;
      
      /* copy parameter data to key structure */
      strcpy(NumKeyData.Name, "Corrige Zero");  
      NumKeyData.KeyBoardType = NUMBER;
      NumKeyData.Type = FLOAT;
      //NumKeyData.Attributes = EPROM;
      NumKeyData.fMax = 9.999;
      NumKeyData.fMin = -9.999;
      NumKeyData.Flag  = enCorrZero;
      NumKeyData.DataPtr = (void *)&mbSlave.CorrZero;
      break; 
             
   }
}

/*
** ------------------------------------------------------------------------------
**		Function: void ReadCalFunctionsParameters(void)
** ------------------------------------------------------------------------------
*/

void ReadCalFunctionsParameters(void)
{
   mbTable[enPulseDelay].RdFlg = 0x1;
   mbTable[enPulseRate].RdFlg = 0x1;  
   mbTable[enPulseCutoff].RdFlg = 0x1;     
   mbTable[enPulseTotalEn].RdFlg = 0x1;
   mbTable[enFactork].RdFlg = 0x1;
   mbTable[enCorrZero].RdFlg = 0x1;
   
}

/*
** ------------------------------------------------------------------------------
**		Function: void PaintCalFunctionsPage(void)
** ------------------------------------------------------------------------------
*/

void PaintCalFunctionsPage(void)
{   
   byte Buf[25];
    
   if(PanelSize == PSZ_1024_600)
      slcd_SetFont(14, 0);  
   else
      slcd_SetFont(16, 0);  
   
   /* set colours back */
   slcd_SetColour(DarkGrey, White);         

   /* display headings */
   slcd_SendText(gstr(&str->MinCalTime),    27, 100, 'T', LEFT_ALIGN);     
   slcd_SendText(gstr(&str->Time),          27, 124, 'T', LEFT_ALIGN);     
   
   slcd_SendText(gstr(&str->MaxCalTime),    27, 180, 'T', LEFT_ALIGN);        
   slcd_SendText(gstr(&str->Time),          27, 204, 'T', LEFT_ALIGN);     
   
   slcd_SendText(gstr(&str->CalZeroLimit),  27, 260, 'T', LEFT_ALIGN);
   
   slcd_SendText("Fator K:",  27, 340, 'T', LEFT_ALIGN);  
   
   slcd_SendText("Corr Zero:", 27, 420, 'T', LEFT_ALIGN);        
   
   if(PanelSize == PSZ_1024_600)
      slcd_SetFont(14, 0);  
   else
      slcd_SetFont(16, 0);   

   //slcdslcd_SendText(gstr(&str->PulseWidth),  getX(20),   getY(ccY1), 'T');  
   //slcdslcd_SendText(gstr(&str->PulseRate),   getX(20),   getY(ccY2), 'T');  
   //slcdslcd_SendText(gstr(&str->PulseTest),   getX(20),   getY(ccY3), 'T');  
      
   //slcdslcd_SendText(gstr(&str->Total),       getX(245),  getY(ccY1), 'T');     
   //slcdslcd_SendText(gstr(&str->TotalReset),  getX(245),  getY(ccY2), 'T');    
   //slcdslcd_SendText(gstr(&str->CutOff),      getX(245),  getY(ccY3), 'T');  
   
   /* set colours back */
   slcd_SetColour(LightBlue, White);         

   /* totalizer delay  */
   sprintf(Buf, "%u min ", (word)EEPROM.MinCalTime);
   slcd_SendText(&Buf, 220, 100, 0, LEFT_ALIGN);     

   sprintf(Buf, "%u min ", (word)EEPROM.MaxCalTime);
   slcd_SendText(&Buf, 220, 180, 0, LEFT_ALIGN);     

   sprintf(Buf, "%u mV ", (word)EEPROM.ZeroMvLimit);
   slcd_SendText(&Buf, 220, 260, 0, LEFT_ALIGN);     

   /* totalizer Rate */
   //sprintf(Buf, "%.3f t ", mbSlave.PulseRate);
   //slcdslcd_SendText(&Buf, getX(165), getY(ccY2), 0);  
   
   /* Cut off Rate */
   //sprintf(Buf, "%.3f t ", mbSlave.TotalCutoff);
   //slcdslcd_SendText(&Buf, getX(405), getY(ccY3), 'T'); 
   
    sprintf(Buf, "%.3f ",mbSlave.fFactorK);
   slcd_SendText(&Buf, 220, 340, 0, LEFT_ALIGN);  
   
   sprintf(Buf, "%.3f ",mbSlave.CorrZero);
   slcd_SendText(&Buf, 220, 420, 0, LEFT_ALIGN);        

   /* set colours back */
   slcd_SetColour(DarkGrey, White);         
     
   slcd_MakeHotSpot(130, 220, 100, 32, 128);
   slcd_MakeHotSpot(131, 220, 180, 32, 128);
   slcd_MakeHotSpot(132, 220, 260, 32, 128);   
   //slcd_CmdQueue("xs 132 270 167 303 189");
   slcd_MakeHotSpot(133, 220, 340, 32, 128);
   slcd_MakeHotSpot(134, 220, 420, 32, 128);
 
   /* force update */
   //winUpdate1 = 1;
}


/*
** ------------------------------------------------------------------------------
**		Function: void UpdateCalFunctions(void)
** ------------------------------------------------------------------------------
*/

void UpdateCalFunctions(void)
{      
   /* requested update */
   if (winUpdate1==1)
   {
      /* stop counter */
      winUpdate1 = 0;   
      
   }

   /* time to update? */
   if (!winTimer1)
   {
      //winTimer1 = 25;
      
   }
}

/*
** ------------------------------------------------------------------------------
**		Function: byte winCalFunctionsHandler(void)
** ------------------------------------------------------------------------------
*/

byte winCalFunctionsHandler(void)
{
   switch (winCalFunctionsState)
   {
   case WIN_CAL_FUNCTION_PREPAINT:
      /* get analog parameters from slave */
      ReadCalFunctionsParameters();
      winCalFunctionsState = WIN_CAL_FUNCTION_PAINT;
      break;
      
   case WIN_CAL_FUNCTION_PAINT:
       slcd_SetColour(DarkGrey, DarkGrey);
      slcd_Send("z");

      slcd_Send("xc all");     
      /* display menu screen */
      //DisplayBmp(16, 0, 0, LEFT_ALIGN); 
      slcd_DisplayBmp(10, 0, 0); 

      DisplayTitle("MS Instrumentos");
      
      slcd_SetFont(24, 0);
      slcd_SetColour(DarkGrey, White); 
      slcd_SendText(gstr(&str->CalFunctions), 15, 60, 0, LEFT_ALIGN);
      
      /* define back hotspot */
      //slcd_CmdQueue("x 128 560 10 630 60");
      slcd_MakeHotSpot(128, 560, 10, 50, 50);
      
      /* update parameters */
      winUpdate1 = 1;
      
      /* move to update state */      
      winCalFunctionsState = WIN_CAL_FUNCTION_PAINT_PAGE;       
      break;

   case WIN_CAL_FUNCTION_PAINT_PAGE:
   
              
      PaintCalFunctionsPage();
      
      /* move to update state */      
      winCalFunctionsState = WIN_CAL_FUNCTION_UPDATE;       
      break;

   case WIN_CAL_FUNCTION_UPDATE:
      /* is there a key to process? */
      if (slcdKey)
      {
         /* call key handler */
         winCalFunctionsKeyHandler(slcdKey);      
         /* now the key has been processed clear it */
         slcdKey = 0; 
      }

      UpdateCalFunctions();

      /* has any data been remotely changed? */
      if(mbSlave.DataUpdate)
      {
         /* clear data update flag */
         mbSlave.DataUpdate = 0;
         mbTable[enDataUp].WrFlg = 1;   
         
         /* read analog parameters */
         ReadCalFunctionsParameters();  
         
         /* set update timer */                   
         winUpdate1 = 100;
      }      
      return 0;

  case WIN_CAL_FUNCTION_NUMKEYPAD:
      /* see if key pad is returning */
      if(winKeyPadHandler())
         /* move to update state */      
         winCalFunctionsState = WIN_CAL_FUNCTION_PAINT;   
      break;

   case WIN_CAL_FUNCTION_UNLOAD:
      /* do any necessary clearing up */
      winCalFunctionsState = WIN_CAL_FUNCTION_PREPAINT;  

      /* clear page */
      winCalFunctionsPage = 0;
      
      /* switch to menu screen */
      winActiveWin = ENGINEERING_WINDOW;  


      /* return from key pad */
      return 1;
   }   
}



