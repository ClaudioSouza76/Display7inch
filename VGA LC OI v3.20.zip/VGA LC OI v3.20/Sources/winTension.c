#include <hidef.h>                           /* common defines and macros */
#include "derivative.h"                      /* derivative information */

/*
** ------------------------------------------------------------------------------
   
   File   : winTension.c 
   Aurthor: 
   
   Description:  
   
   Version Log          Notes                                     Changes Made by                                        
   --------------       -----                                     ---------------
   28-02-11:            Created                                   Stuart
   24-04-25:            Change.                                   Souza


** ------------------------------------------------------------------------------
                                    
                                    Overview
                                            
** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

/* library headers */
#include "stdio.h"
#include "float.h"
#include "math.h"

/* Application headers */
#include "CRG 100110.h" 
#include "Subs.h"
#include "ModBusM Int.h"
#include "ModBusM.h"
#include "EEPROM.h"
#include "SLCD 260217.h"
#include "winMain.h"
#include "winKey.h"
#include "Language.h"
#include "SlcdSubs.h"

/* Implements this interface: */
#define WINTENSION_C
#include "winTension.h"

#pragma CODE_SEG WINTENSION_CODE
#pragma DATA_SEG WINTENSION_DATA


/* private */
static byte winTensionsState;
static byte winTensionsPage;

float tempMassCapture;
float tempFactor;


/* public */


/*
** ------------------------------------------------------------------------------
**		Function: void winTensionsKeyHandler(byte key)
** ------------------------------------------------------------------------------
*/

void winTensionsKeyHandler(byte Key)
{
  switch(Key)
  {
    case 1:         /*Collect Data*/
    
      if(mbSlave.TensionCalFlg != 0)
      {
        mbSlave.TensionCalFlg = 0;
      }
          
      if(mbSlave.TensionCalFlg == 0)
      {
        mbSlave.TensionMassCaptureEn = 1;
        mbSlave.TensionCalFlg = 1;
        mbTable[enTensionFlg].WrFlg = 1;
        
      }

      break;
      
    case 2:         /*Save Span Tension*/
      
      mbSlave.TensionSpanEn = 1;
          
     // if(mbSlave.TensionMassCapture	!= 0.00)
      //{
        mbSlave.TensionCalEn = 1;
        mbTable[enTensionCal].WrFlg = 1;
        

        mbSlave.TensionMassCapture = tempMassCapture;	        
        mbTable[enTensionCapture].WrFlg = 1;

      //}
      break;
      
    case 128:       /* EXIT */
      /* shut down num key window handler */
      winTensionsState = WIN_TENSION_UNLOAD;  
      break; 
      
    case 131:
    
      winTensionsState = WIN_TENSION_NUMKEYPAD;
      /* copy parameter data to key structure */
      strcpy(NumKeyData.Name, "Tensao Correia Kg.f");  
      NumKeyData.KeyBoardType = NUMBER;
      NumKeyData.Type = FLOAT;
      NumKeyData.Attributes = EPROM;
      NumKeyData.fMax = 100000.0;
      NumKeyData.fMin = 0.0;
      NumKeyData.DataPtr = (void *)&EEPROM.MinTension;   
      break;
      
   case 132:
    
      winTensionsState = WIN_TENSION_NUMKEYPAD;
      /* copy parameter data to key structure */
      strcpy(NumKeyData.Name, "Massa Maxima Kg/m");  
      NumKeyData.KeyBoardType = NUMBER;
      NumKeyData.Type = FLOAT;
      NumKeyData.Attributes = EPROM;
      NumKeyData.fMax = 9999.0;
      NumKeyData.fMin = 0.0;
      NumKeyData.DataPtr = (void *)&EEPROM.MassTension;   
      break;
   
   case 133:
    
      winTensionsState = WIN_TENSION_NUMKEYPAD;
      /* copy parameter data to key structure */
      strcpy(NumKeyData.Name, "Tensao Correia Kg.f");  
      NumKeyData.KeyBoardType = NUMBER;
      NumKeyData.Type = FLOAT;
      NumKeyData.Attributes = EPROM;
      NumKeyData.fMax = 100000.0;
      NumKeyData.fMin = 0.0;
      NumKeyData.DataPtr = (void *)&EEPROM.MaxTension;   
      break;
  }
}

/*
** ------------------------------------------------------------------------------
**		Function: void ReadTensionParameters(void)
** ------------------------------------------------------------------------------
*/

void ReadTensionParameters(void)
{
   mbTable[enTensionHi].RdFlg = 0x1;
   mbTable[enTensionLo].RdFlg = 0x1; 
   mbTable[enMass].RdFlg = 0x1;
   mbTable[enAnInOut1].RdFlg = 0x1;  
   mbTable[enTensionAvg].RdFlg = 0x1;    //Teste
   
   mbTable[enTensionFlg].RdFlg = 0x1;   //Teste
   mbTable[enTensionCapture].RdFlg = 0x1;
   mbTable[enTensionViewCapture].RdFlg = 0x1;
   mbTable[enTension_x_K].RdFlg = 0x1;
   mbTable[enTensionFactor_K].RdFlg = 0x1;
}


/*
** ------------------------------------------------------------------------------
**		Function: void winPaintTensionPage(void)
** ------------------------------------------------------------------------------
*/

void winPaintTensionPage(void)
{
  byte Buf[25];
  lButtonType Button;                     //Config of the slcd to creat a button.
  byte ButtonText1[20], ButtonText2[20];
  
  if(PanelSize == PSZ_1024_600)
   slcd_SetFont(14, 0);
  else
   slcd_SetFont(16, 0);
  
  slcd_SendText("Calibrar Span", 20, 60, 0, LEFT_ALIGN);
      
   
  /* set colours back */
  slcd_SetColour(DarkGrey, White);     
  

  /* display headings */
  slcd_SendText(gstr(&str->TensionHi),    600,   100, 0, LEFT_ALIGN); 
  
  slcd_SendText("Peso:",      40,   100, 0, LEFT_ALIGN);
  slcd_SendText("Kg/m",       300,  100, 0, LEFT_ALIGN);
  
  slcd_SendText("Coletar:",   40,   150, 0, LEFT_ALIGN);
  
  slcd_SendText("Dados",      20,   215, 0, LEFT_ALIGN);
  
  //slcdDisplayLine(10,245,620,245);
  
  slcd_SendText("Peso: 0.0 Kg/m - Tensao: ", 40, ccY2, 0, LEFT_ALIGN);
  
  slcd_SendText("   0.0   Kg/m a min. tensao = ", 40, ccY2+20, 0, LEFT_ALIGN);
  
  slcd_SendText("Kg/m a max. tensao = ", 140, ccY3-20, 0, LEFT_ALIGN);
  
 
  slcd_SendText("Tempo Real:", 20, ccY4, 0, LEFT_ALIGN);
  
  slcd_SendText("C.C.(mV)", 250, ccY4, 0, LEFT_ALIGN);
  
  
  if(mbSlave.AnInType[0]==0)
     slcd_SendText("T (mA)", 500, ccY4, 0, LEFT_ALIGN);
  else
    slcd_SendText("T (V)", 500, ccY4, 0, LEFT_ALIGN);
  
  
  slcd_SetColour(Red, White);       

   /* totalizer delay  */
   if(mbSlave.AnInType[0] == 0)
      sprintf(Buf, "%.2f mA", mbSlave.TensionHi);
   else
      sprintf(Buf, "%.2f V", mbSlave.TensionHi);
   
   slcd_SendText(&Buf, 700, 100, 0, LEFT_ALIGN); 
       

   if(mbSlave.AnInType[0] == 0)
      sprintf(Buf, "%.2f mA", mbSlave.TensionLo);
   else 
      sprintf(Buf, "%.2f V", mbSlave.TensionLo);
   
   slcd_SendText(&Buf, 430, ccY2, 0, LEFT_ALIGN); 
   
   
   //Primeiro tenho que clicar no bot�o para puxar o valor do Peso
   if(!mbSlave.TensionMassCapture)
   {
      mbSlave.TensionMassCapture = mbSlave.TensionViewCal;		
   }
   
   slcd_SendText("                ", 140, 100, 0, LEFT_ALIGN);
   
   sprintf(Buf, "%.1f", mbSlave.TensionMassCapture);
   slcd_SendText(&Buf, 140, 100, 0, LEFT_ALIGN);
   
   slcd_SetFont(16, 0);  
   
   /* set colours back */
   slcd_SetColour(LightBlue, White);
   
   
   sprintf(Buf,"%.1f Kg.f", EEPROM.MinTension);
   slcd_SendText(&Buf, 460, ccY2+20, 0, LEFT_ALIGN);
   
   sprintf(Buf,"%.1f", EEPROM.MassTension);
   slcd_SendText(&Buf, 20, ccY3-20, 0, LEFT_ALIGN);
   
   sprintf(Buf,"%.1f Kg.f", EEPROM.MaxTension);
   slcd_SendText(&Buf, 460, ccY3-20, 0, LEFT_ALIGN);
     
   
   
   
   
   /* force update */
   winUpdate1 = 1;
   
   slcd_SetColour(White, White);

  /* make capture value to span tension */
  Button.Id = 1;
  Button.x = 250;
  Button.y = 150;
  Button.type = 2;
  Button.state = mbSlave.TensionMassCaptureEn;	
  strcpy(ButtonText1, "Iniciar");                                                                   
  strcpy(ButtonText2, "Coletando");
  Button.text0 = ButtonText1;
  Button.text1 = ButtonText2;
  Button.dx0 = 11;
  Button.dy0 = 3;
  Button.dx1 = 2;
  Button.dy1 = 3;
  Button.bmp0 = 5;
  Button.bmp1 = 4; 
  
  MakeLatchingButton(&Button);   
  
   /* make calibration */
   Button.Id = 2;
   Button.x = 450;
   Button.y = 150;
   Button.type = 2;
   Button.state = mbSlave.TensionSpanEn;
   strcpy(ButtonText1, "Aceitar"); 
   strcpy(ButtonText2, "Aceitar");      
   Button.text0 = ButtonText1;
       
   /* define start/stop button */
   MakeLatchingButton(&Button);   
   
   //CaptureMassTension();
   
   /* set colours back */
   slcd_SetColour(DarkGrey, White);         
     
   slcd_MakeHotSpot(131, 320, 300, 32, 128);
   slcd_MakeHotSpot(132, 10,  360, 32, 128);
   slcd_MakeHotSpot(133, 320, 360, 32, 128);
  
        
}

/*
** ------------------------------------------------------------------------------
**		Function: void CaptureMassTension(void)
** ------------------------------------------------------------------------------
*/

void CaptureMassTension(void)
{
   byte Buf[20];
   
   slcd_SetFont(16, 'B');
   slcd_SetColour(Red, White);
      
   /* format Peso  */       
   sprintf(Buf, "%.2f  ",mbSlave.MassMv	);
   
   /* display Peso */
   slcd_SendText(&Buf, 290, 500, 0, LEFT_ALIGN);    
     
   /* format value Tension * K */
   sprintf(Buf, "%.1f ", mbSlave.Tension_x_K);
   /* Display value Tension * K */
   slcd_SendText(&Buf, 520, 500, 0, LEFT_ALIGN);
         
   mbTable[enMassMv].RdFlg = 1; 
   mbTable[enAnInOut1].RdFlg =1; //Teste  
   
   mbTable[enTensionFlg].RdFlg = 1; //Teste
   mbTable[enTensionCal].RdFlg = 1;
   mbTable[enTensionViewCapture].RdFlg = 1;
   mbTable[enTension_x_K].RdFlg = 1;
   mbTable[enTensionFactor_K].RdFlg = 1;
   
}

/*
** ------------------------------------------------------------------------------
**		Function: void winUpdateTension(void)
** ------------------------------------------------------------------------------
*/

void winUpdateTension(void)
{

  byte Buf[20];
  
  /* requested update */
   if (winUpdate1==1)
   {
      /* stop counter */
      winUpdate1 = 0;   
      
   }

   /* time to update? */
   if (!winTimer1)
   {
      winTimer1 = 100;
      
   }
   
   if (!winTimer2)
   {
      winTimer2 = 20;
      
      CaptureMassTension();
      
      if (mbSlave.TensionCalFlg == 4)
      {
        
        mbTable[enTensionAvg].RdFlg = 1;
        mbTable[enTensionHi].WrFlg = 0x1;
        mbSlave.TensionHi = mbSlave.TensionAverage;  //10*(1/mbSlave.TensionAverage);
               
        mbSlave.TensionCalFlg = 0;
        mbTable[enTensionFlg].WrFlg = 1; 
        
        mbSlave.TensionMassCaptureEn = 0;
        
        /* set colours back */
        slcd_SetColour(Black, White);  

        sprintf(Buf, "%.2f ",mbSlave.TensionHi);        
        slcd_SendText(&Buf, 700, 100, 0, LEFT_ALIGN);  
        
        tempMassCapture = mbSlave.Mass;
        mbSlave.TensionMassCapture = tempMassCapture;
        mbTable[enTensionCapture].WrFlg = 1;
        
        slcd_SendText("          ", 140, 100, 0, LEFT_ALIGN);
        sprintf(Buf, "%.1f ", mbSlave.TensionMassCapture);
        slcd_SendText(&Buf, 140, 100, 0, LEFT_ALIGN);	 
                
        winPaintTensionPage();
               
        /* beepa ! */
       slcd_Send("beep 1000"); 		  
                                                        	
      }
      
      if(mbSlave.TensionCalEn == 2)
      {
        mbSlave.TensionSpanEn = 0;
        
        mbSlave.TensionCalEn = 0;
        mbTable[enTensionCal].WrFlg = 1;
        
        winPaintTensionPage();
         /* beepa ! */
        slcd_Send("beep 1000"); 
       
      }
      slcd_SetFont(16, 'B');
      slcd_SetColour(DarkGrey, White); 
      
      mbTable[enMass].RdFlg = 1; 
      mbTable[enAnInOut1].RdFlg = 1; //Teste      
            
   }

}

/*
** ------------------------------------------------------------------------------
**		Function: byte winTensionHandler(void)
** ------------------------------------------------------------------------------
*/

byte winTensionHandler(void)
{
  byte Buf[20];
  switch (winTensionsState)
   {
   case WIN_TENSION_PREPAINT:
      /* get analog parameters from slave */
      ReadTensionParameters();
      winTensionsState = WIN_TENSION_PAINT;
      break;
      
   case WIN_TENSION_PAINT:
      slcd_SetColour(DarkGrey, DarkGrey);
      slcd_Send("z");

      slcd_Send("xc all");     
      /* display menu screen */
      //DisplayBmp(16, 0, 0, LEFT_ALIGN); 
      slcd_DisplayBmp(10, 0, 0); 

      DisplayTitle("MS Instrumentos");
      
      slcd_SetFont(24, 0);
      slcd_SetColour(DarkGrey, White); 
      slcd_SendText(gstr(&str->TensionScreenTitle), 15, 60, 0, LEFT_ALIGN);
      
      /* define back hotspot */
      //slcd_Send("x 128 560 10 630 60");
      slcd_MakeHotSpot(128, 560, 10, 50, 50);
      
      winPaintTensionPage();
            	                                                                    
      /* update parameters */
      winUpdate1 = 1;
      
      /* move to update state */      
      winTensionsState = WIN_TENSION_UPDATE; //WIN_TENSION_PAINT_PAGE;       
      break;

   case WIN_TENSION_PAINT_PAGE:
   
         
      winPaintTensionPage();
            
      winUpdate1 = 1;
      
      /* move to update state */      
      winTensionsState = WIN_TENSION_UPDATE;       
      break;

   case WIN_TENSION_UPDATE:
      /* is there a key to process? */
      if (slcdKey)
      {
         /* call key handler */
         winTensionsKeyHandler(slcdKey);      
         /* now the key has been processed clear it */
         slcdKey = 0; 
      }

      winUpdateTension();

      /* has any data been remotely changed? */
      if(mbSlave.DataUpdate)
      {
         /* clear data update flag */
         mbSlave.DataUpdate = 0;
         mbTable[enDataUp].WrFlg = 1;   
         
         /* read analog parameters */
         ReadTensionParameters();  
         
         /* set update timer */                   
         winUpdate1 = 100;
      }     
       
      return 0;

  case WIN_TENSION_NUMKEYPAD:
      /* see if key pad is returning */
      if(winKeyPadHandler())
         /* move to update state */      
         winTensionsState = WIN_TENSION_PAINT;   
      break;

   case WIN_TENSION_UNLOAD:
      /* do any necessary clearing up */
      winTensionsState = WIN_TENSION_PREPAINT;  

      /* clear page */
      winTensionsPage = 0;
      
      /* switch to menu screen */
      winActiveWin = ENGINEERING_WINDOW;  


      /* return from key pad */
      return 1;
   }   
}