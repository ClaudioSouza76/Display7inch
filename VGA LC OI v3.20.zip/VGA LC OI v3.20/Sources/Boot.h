/*
** ------------------------------------------------------------------------------
   
   File   : Vectors.h 
   Aurthor: Stuart Clarke
        
** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

#ifndef Boot_H
#define Boot_H


/* public defines */

/*
** ------------------------------------------------------------------------------
**		#define : base addresses for interrupt relocation 
** ------------------------------------------------------------------------------
*/

#define CPU12XVBR 0x3D00

#define ETC0      0x0077
#define ETC1      0x0076
#define SCI0      0x006B

#ifndef BOOT_C


/* public variables */
#pragma DATA_SEG   BOOT_DATA

extern byte BootExitTimer;

#endif   /* BOOT_C */ 


/* public functions */

#pragma CODE_SEG   ROM_F200_SEG

/*
** ------------------------------------------------------------------------------
**		Function: ExitBootLoader
** ------------------------------------------------------------------------------
*/

volatile void ExitBootLoader(void);

#endif   /* BOOT_H */
