/*
** ------------------------------------------------------------------------------
   
   File   : winBasicConfig.h 
   Aurthor: Stuart Clarke

** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

#ifndef WINENGINEERING_H
#define WINENGINEERING_H


/* public defines */

/*
** ------------------------------------------------------------------------------
**		#define : user menu handler states 
** ------------------------------------------------------------------------------
*/

#define WIN_ENGINEERING_PREPAINT     0
#define WIN_ENGINEERING_PAINT        1
#define WIN_ENGINEERING_UPDATE       2
#define WIN_ENGINEERING_NUMKEYPAD    3
#define WIN_ENGINEERING_UNLOAD       4
#define WIN_ENGINEERING_ENTER_PASSWORD 5


#ifndef WINENGINEERING_C

/* public variables */
#pragma DATA_SEG WINENGINEERING_DATA

extern byte winEngineeringReturnWin;

#endif   /* WINENGINEERING_C */      


/* public functions */
#pragma CODE_SEG WINENGINEERING_CODE


/*
** ------------------------------------------------------------------------------
**		Function: void ReadEngineeringParameters(void)
** ------------------------------------------------------------------------------
*/

void ReadEngineeringParameters(void);

/*
** ------------------------------------------------------------------------------
**		Function: byte winEngineeringHandler(void)
** ------------------------------------------------------------------------------
*/

byte winEngineeringHandler(void);

#endif   /* WINENGINEERING_H */
