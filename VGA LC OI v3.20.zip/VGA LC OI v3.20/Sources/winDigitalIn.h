/*
** ------------------------------------------------------------------------------
   
   File   : winBasicConfig.h 
   Aurthor: Stuart Clarke

** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

#ifndef WINDIGITALIN_H
#define WINDIGITALIN_H


/* public defines */

/*
** ------------------------------------------------------------------------------
**		#define : user menu handler states 
** ------------------------------------------------------------------------------
*/

#define WIN_DIGITAL_IN_PREPAINT     0
#define WIN_DIGITAL_IN_PAINT        1
#define WIN_DIGITAL_IN_PAINTPAGE    2
#define WIN_DIGITAL_IN_UPDATE       3
#define WIN_DIGITAL_IN_NUMKEYPAD    4
#define WIN_DIGITAL_IN_UNLOAD       5
#define WIN_DIGITAL_IN_ENTER_PASSWORD 6


#ifndef WINDIGITALIN_C

/* public variables */
#pragma DATA_SEG WINDIGITALIN_DATA

extern byte winDigitalInReturnWin;

#endif   /* WINDIGITALIN_C */      


/* public functions */
#pragma CODE_SEG WINDIGITALIN_CODE


/*
** ------------------------------------------------------------------------------
**		Function: void ReadDigitalInParameters(void)
** ------------------------------------------------------------------------------
*/

void ReadDigitalInParameters(void);

/*
** ------------------------------------------------------------------------------
**		Function: byte winDigitalInHandler(void)
** ------------------------------------------------------------------------------
*/

byte winDigitalInHandler(void);

/*
** ------------------------------------------------------------------------------
**		Function: void PaintDigitalIn(void)
** ------------------------------------------------------------------------------
*/

void PaintDigitalIn(void);

/*
** ------------------------------------------------------------------------------
**		Function: DisplayInputFunction(void)
** ------------------------------------------------------------------------------
*/

void DisplayInputFunction(void);

#endif   /* WINDIGITALIN_H */
