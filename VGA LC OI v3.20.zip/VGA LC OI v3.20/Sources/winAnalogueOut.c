#include <hidef.h>                           /* common defines and macros */
#include "derivative.h"                      /* derivative information */

/*
** ------------------------------------------------------------------------------
   
   File   : winAnalogueOut.c 
   Aurthor: 
   
   Description:  
   
   Version Log          Notes                                     Changes Made by                                        
   --------------       -----                                     ---------------
   08-10-11:            Created                                   Stuart


** ------------------------------------------------------------------------------
                                    
                                    Overview
                                            
** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

/* library headers */
#include "stdio.h"
#include "float.h"
#include "math.h"

/* Application headers */
#include "CRG 100110.h" 
#include "Subs.h"
#include "ModBusM Int.h"
#include "ModBusM.h"
#include "EEPROM.h"
#include "SLCD 260217.h"
#include "winMain.h"
#include "winKey.h"
#include "Language.h"
#include "SlcdSubs.h"

/* Implements this interface: */
#define WINANALOGUEOUT_C
#include "winAnalogueOut.h"

#pragma CODE_SEG WINANALOGUEOUT_CODE
#pragma DATA_SEG WINANALOGUEOUT_DATA


/* private */
static byte winAnalogueOutState;
static byte AnalogIndex;
static byte AnalogFixFlg;



/* public */
byte winAnalogueOutReturnWin;

/* Analogue Outputs screen layout (640x480 logical, scaled by slcd_SendText) */
#define AOUT_Y_OFF      40    /* page title now at y=60 (was y=7) */
#define AOUT_CHANNEL_Y  (89  + AOUT_Y_OFF)
#define AOUT_BTN_Y      (89  + AOUT_Y_OFF)
#define AOUT_ROW1_Y     180   /* first data row (was ccY0) */
#define AOUT_ROW_DY     36    /* standard row spacing */
#define AOUT_ROW(n)     (AOUT_ROW1_Y + (((n) - 1) * AOUT_ROW_DY))
#define AOUT_VAL_L_X    227
#define AOUT_VAL_R_X    540
#define AOUT_LBL_L_X    27
#define AOUT_LBL_R_X    327
#define AOUT_FIX1_Y     (AOUT_ROW(2) - 15)
#define AOUT_FIX2_Y     (AOUT_ROW(3) - 15)
#define AOUT_FUNC_CLR_X 493
#define AOUT_HS_W_L     78
#define AOUT_HS_W_R     126
#define AOUT_HS_H       40

/*
** ------------------------------------------------------------------------------
**		Function: DisplayAnalogueFunction(void)
** ------------------------------------------------------------------------------
*/

void DisplayAnalogueFunction(void)
{   
   /* set colours back */
   slcd_SetColour(LightBlue, White);       
   if(PanelSize == PSZ_1024_600)
      slcd_SetFont(14, 0);
   else
      slcd_SetFont(16, 'B'); 
   
   /* clear previous string */
   slcd_SendText("            ", AOUT_FUNC_CLR_X, AOUT_ROW(1), 0, LEFT_ALIGN);      
   
   switch (mbSlave.AnFunction[AnalogIndex])
   {
   default:
   case 0:
      /* function delay */   
      slcd_SendText("NA", AOUT_VAL_R_X, AOUT_ROW(1), 0, LEFT_ALIGN);      
      break;

   case 1:
      /* flow Rate */   
      slcd_SendText(gstr(&str->Flow), AOUT_FUNC_CLR_X, AOUT_ROW(1), 0, LEFT_ALIGN);      
      break;

   case 2:
      /* Total */   
      slcd_SendText(gstr(&str->Total), AOUT_FUNC_CLR_X, AOUT_ROW(1), 0, LEFT_ALIGN);      
      break;

   case 3:
      /* Mass */   
      slcd_SendText(gstr(&str->Mass), AOUT_FUNC_CLR_X, AOUT_ROW(1), 0, LEFT_ALIGN);      
      break;

   case 4:
      /* Speed */   
      slcd_SendText(gstr(&str->Speed), AOUT_FUNC_CLR_X, AOUT_ROW(1), 0, LEFT_ALIGN);      
      break;

   case 5:
      /* Analogue 1 */   
      slcd_SendText(gstr(&str->AnalogueIn1), AOUT_FUNC_CLR_X, AOUT_ROW(1), 0, LEFT_ALIGN);      
      break;

   case 6:
      /* Analogue 2 */   
      slcd_SendText(gstr(&str->AnalogueIn2), AOUT_FUNC_CLR_X, AOUT_ROW(1), 0, LEFT_ALIGN);      
      break;

   case 7:
      /* tension */   
      slcd_SendText(gstr(&str->Tension), AOUT_FUNC_CLR_X, AOUT_ROW(1), 0, LEFT_ALIGN);      
      break;

   }
}

/*
** ------------------------------------------------------------------------------
**		Function: void winAnalogueOutKeyHandler(byte key)
** ------------------------------------------------------------------------------
*/

void winAnalogueOutKeyHandler(byte key)
{   
   byte Buf[25];
   
   switch (key)
   {
   case 1:
     
      /* increment analogue select register */      
      if(++AnalogIndex>1)
         AnalogIndex = 0;
      
      /* set font */      
      slcd_SetFont(24, 'B');                
      
      /* set colours back */
      slcd_SetColour(DarkGrey, White);  
      
      /* display selected analog channel */
      sprintf(Buf, "%s %u ", gstr(&str->Analog), AnalogIndex+1);
      slcd_SendText(Buf, 107, AOUT_CHANNEL_Y, 0, LEFT_ALIGN); 

      //slcd_CmdQueue("xic 2 0 0 405 230 460 255");  
      
      /* update analogue parameters */
      ReadAnalogueOutParameters();
      /* update parameters */
      winUpdate1 = 100;
      break;

   case 2:     /* fix Analog at 2 mA */      
      /* set fix flag */
      AnalogFixFlg = 1;
      
      /* set write flag for select channel */
      if(!AnalogIndex)
      {
         mbTable[enAnOut1].WrFlg = 0x1;
         /* force mb table index An Wr flag */
         mbTableIndex = enAnOut1;         
      }
      else if (AnalogIndex==1)
      {
         mbTable[enAnOut2].WrFlg = 0x1;
         /* force mb table index An Wr flag */
         mbTableIndex = enAnOut2;         
      }

      /* set output value */
      mbSlave.AnOutput[AnalogIndex] = 2.0;
      break;      

   case 3:     /* fix Analog at 18 mA */      
      /* set fix flag */
      AnalogFixFlg = 2;

      /* set write flag for select channel */
      if(!AnalogIndex)
      {
         mbTable[enAnOut1].WrFlg = 0x1;
         /* force mb table index An Wr flag */
         mbTableIndex = enAnOut1;         
      }
      else if (AnalogIndex==1)
      {
         mbTable[enAnOut2].WrFlg = 0x1;
         /* force mb table index An Wr flag */
         mbTableIndex = enAnOut2;         
      }

      
      /* set output value */
      mbSlave.AnOutput[AnalogIndex] = 18.0;
      break;      
      
   case 128:       /* EXIT */
      /* shut down num key window handler */
      winAnalogueOutState = WIN_ANALOGUE_OUT_UNLOAD;  
      break;  
      
   case 130:      /* AnHi hotspot */
      /* move to key pad handler sate */
      winAnalogueOutState = WIN_ANALOGUE_OUT_NUMKEYPAD; 
      
      /* copy parameter data to key structure */
      strcpy(NumKeyData.Name, gstr(&str->Analog_Hi) );  
      NumKeyData.KeyBoardType = NUMBER;
      NumKeyData.Type = FLOAT;
      NumKeyData.fMax = 99999.9;
      NumKeyData.fMin = -100.0;
      NumKeyData.Index = 0;
     
      if(!AnalogIndex)
         NumKeyData.Flag  = enAnHi1;
      else if(AnalogIndex==1) 
         NumKeyData.Flag  = enAnHi2;
      
      NumKeyData.DataPtr = (void *)&mbSlave.AnHi[AnalogIndex];
      break;      

   case 131:      /* AnLo hotspot */
      /* move to key pad handler sate */
      winAnalogueOutState = WIN_ANALOGUE_OUT_NUMKEYPAD; 
      
      /* copy parameter data to key structure */
      strcpy(NumKeyData.Name, gstr(&str->Analog_Lo) );  
      NumKeyData.Type = FLOAT;
      NumKeyData.KeyBoardType = NUMBER;
      NumKeyData.fMax = 99999.9;
      NumKeyData.fMin = -100.0;
      NumKeyData.Index = 0;
      if(!AnalogIndex)
         NumKeyData.Flag  = enAnLo1;
      else if(AnalogIndex==1) 
         NumKeyData.Flag  = enAnLo2;
      
      NumKeyData.DataPtr = (void *)&mbSlave.AnLo[AnalogIndex];
      break; 


   case 132:
      if(mbSlave.AnMode & (0x01<<AnalogIndex))
         mbSlave.AnMode &=~ (0x01<<AnalogIndex);
      else
         mbSlave.AnMode |= (0x01<<AnalogIndex);

      /* set write flag */
      mbTable[enAnMode].WrFlg = 1;
      /* call for an update */
      winUpdate1 = 1;
      break;
      
   
   case 133:      /* An Allocation */
      /* switch to next function */
      if(mbSlave.AnFunction[AnalogIndex]<7)
         mbSlave.AnFunction[AnalogIndex]++;
      else
         mbSlave.AnFunction[AnalogIndex] = 0;
      
      /* */
      switch (AnalogIndex)
      {
      case 0:
         mbTable[enAnFunc1].WrFlg = 0x1; 
         break;

      case 1:
         mbTable[enAnFunc2].WrFlg = 0x1; 
         break;
      }
      
      DisplayAnalogueFunction();
      break;             

   case 134:      /* An Adjust */
      /* only adjust if analogue chaneel is fixed */
      if(AnalogFixFlg)
      {
         /* move to key pad handler sate */
         winAnalogueOutState = WIN_ANALOGUE_OUT_NUMKEYPAD; 
         
         /* copy parameter data to key structure */
         strcpy(NumKeyData.Name, gstr(&str->Analog_Adjust) );  
         NumKeyData.KeyBoardType = NUMBER;
         NumKeyData.Type = FLOAT;
         
         if(AnalogFixFlg==1)
         {
            NumKeyData.fMax = 3.0;
            NumKeyData.fMin = 1.0;
         }
         else
         {
            NumKeyData.fMax = 21.0;
            NumKeyData.fMin = 17.0;
         }
         NumKeyData.Index = 0;
         
         if(!AnalogIndex)
            NumKeyData.Flag  = enAnAdjust1;
         else if(AnalogIndex==1) 
            NumKeyData.Flag  = enAnAdjust2;

         
         NumKeyData.DataPtr = (void *)&mbSlave.AnAdjust[AnalogIndex];
      }
      break;       
   }
}


/*
** ------------------------------------------------------------------------------
**		Function: void ReadAnalogueOutParameters(void)
** ------------------------------------------------------------------------------
*/

void ReadAnalogueOutParameters(void)
{
   mbTable[enAnMode].RdFlg = 0x1;
   
   switch(AnalogIndex)
   {
   case 0:
      mbTable[enAnHi1].RdFlg = 0x1;
      mbTable[enAnLo1].RdFlg = 0x1;
      mbTable[enAnFunc1].RdFlg = 0x1;
      break;

   case 1:
      mbTable[enAnHi2].RdFlg = 0x1;
      mbTable[enAnLo2].RdFlg = 0x1;
      mbTable[enAnFunc1].RdFlg = 0x1;
      break;
   }

}


/*
** ------------------------------------------------------------------------------
**		Function: void UpdateAnalogueOut(void)
** ------------------------------------------------------------------------------
*/

void UpdateAnalogueOut(void)
{
   byte Buf[25];
   
   /* requested update */
   if (winUpdate1==1)
   {
      /* stop counter */
      winUpdate1 = 0;
      
   if(PanelSize == PSZ_1024_600)
      slcd_SetFont(14, 0);
   else
      slcd_SetFont(16, 'B');  
 
      
      /* set colours back */
      slcd_SetColour(LightBlue, White);         
         
      sprintf(Buf, "%.1f  ", mbSlave.AnHi[AnalogIndex]);  
      Buf[7] = 0;
      slcd_SendText(Buf, AOUT_VAL_L_X, AOUT_ROW(1), 0, LEFT_ALIGN);  
      
      sprintf(Buf, "%.1f  ", mbSlave.AnLo[AnalogIndex]);  
      Buf[7] = 0;
      slcd_SendText(Buf, AOUT_VAL_L_X, AOUT_ROW(2), 0, LEFT_ALIGN);  

      slcd_SetColour(LightBlue, White);         
      
      sprintf(Buf, "%.2f ", mbSlave.AnAdjust[AnalogIndex]);  
      Buf[7] = 0;
      slcd_SendText(Buf, AOUT_VAL_R_X, AOUT_ROW(4), 'T', LEFT_ALIGN);  

      //if(mbSlave.AnMode&(0x01<<AnalogIndex))
         //DisplayText(" mA  ", getX(170), getY(ccY4), 0);  
      //else
         //DisplayText("Volts", getX(170), getY(ccY4), 0);   
         
      /* set colours back */
      DisplayAnalogueFunction();         
   }

   /* time to update? */
   if (!winTimer1)
   {
      winTimer1 = 25;

   if(PanelSize == PSZ_1024_600)
      slcd_SetFont(14, 0);
   else
      slcd_SetFont(16, 'B');  
 
      
      /* set colours back */
      slcd_SetColour(DarkGrey, White);         
      sprintf(Buf, "%.1f  ", mbSlave.AnOutput[AnalogIndex]);  
      Buf[7] = 0;
      slcd_SendText(Buf, AOUT_VAL_L_X, AOUT_ROW(3), 0, LEFT_ALIGN);  

      switch(AnalogIndex)
      {
      case 0:
         mbTable[enAnOut1].RdFlg = 0x1;
         break;

      case 1:
         mbTable[enAnOut2].RdFlg = 0x1;
         break;
      }
   }
}

/*
** ------------------------------------------------------------------------------
**		Function: void PaintAnalogueOut(void)
** ------------------------------------------------------------------------------
*/

void PaintAnalogueOut(void)
{
   byte Buf[25];
      
   slcd_SetFont(24, 'B');  
   
   /* set colours back */
   slcd_SetColour(DarkGrey, White);         
   
   /* display selected analog channel */
   sprintf(Buf, "%s %u", gstr(&str->Analog), AnalogIndex+1);
   slcd_SendText(Buf, 107, AOUT_CHANNEL_Y, 0, LEFT_ALIGN);  
 
   /* make analog select button */      
   slcd_MakeButton(1, 1, 27, AOUT_BTN_Y, 22, 21);

   /* make fix mA buttons  */
   slcd_MakeButton(2, 1, 540, AOUT_FIX1_Y, 23, 21);
   slcd_MakeButton(3, 1, 540, AOUT_FIX2_Y, 23, 21);

   if(PanelSize == PSZ_1024_600)
      slcd_SetFont(14, 0);
   else
      slcd_SetFont(16, 'B');  
  
   
   /* set colours back */
   slcd_SetColour(DarkGrey, White);         

   /* display headings */
   slcd_SendText(gstr(&str->Analog_Hi),   AOUT_LBL_L_X, AOUT_ROW(1), 'T', LEFT_ALIGN);  
   slcd_SendText(gstr(&str->Analog_Lo),   AOUT_LBL_L_X, AOUT_ROW(2), 'T', LEFT_ALIGN);  
   slcd_SendText(gstr(&str->Output_mA),   AOUT_LBL_L_X, AOUT_ROW(3), 'T', LEFT_ALIGN);     
   
   slcd_SendText(gstr(&str->Function),    AOUT_LBL_R_X, AOUT_ROW(1), 'T', LEFT_ALIGN);  
   slcd_SendText(gstr(&str->Fix_2mA),     AOUT_LBL_R_X, AOUT_ROW(2), 'T', LEFT_ALIGN);         
   slcd_SendText(gstr(&str->Fix_18mA),    AOUT_LBL_R_X, AOUT_ROW(3), 'T', LEFT_ALIGN);         
   slcd_SendText(gstr(&str->Adjust),      AOUT_LBL_R_X, AOUT_ROW(4), 'T', LEFT_ALIGN);         

   /* define hotspots (x, y, width, height) */
   slcd_MakeHotSpot(130, 228, AOUT_ROW(1), AOUT_HS_W_L, AOUT_HS_H);
   slcd_MakeHotSpot(131, 228, AOUT_ROW(2), AOUT_HS_W_L, AOUT_HS_H);
   slcd_MakeHotSpot(132, 228, AOUT_ROW(4), AOUT_HS_W_L, AOUT_HS_H);
   slcd_MakeHotSpot(133, 480, AOUT_ROW(1), AOUT_HS_W_R, AOUT_HS_H);
   slcd_MakeHotSpot(134, 540, AOUT_ROW(4), 66, AOUT_HS_H);

   DisplayAnalogueFunction();

   /* force update */
   winUpdate1 = 1;
}

/*
** ------------------------------------------------------------------------------
**		Function: byte winAnalogueOutHandler(void)
** ------------------------------------------------------------------------------
*/

byte winAnalogueOutHandler(void)
{
   switch (winAnalogueOutState)
   {
   case WIN_ANALOGUE_OUT_PREPAINT:
      /* get analog parameters from slave */
      ReadAnalogueOutParameters();

      /* zero adjust registers */
      mbSlave.AnAdjust[0] = 0; 
      mbSlave.AnAdjust[1] = 0; 
      
      /* set delay for parameters to arrive from MCT  */
      winUpdate1 = 15;
            
      winAnalogueOutState = WIN_ANALOGUE_OUT_PAINT;
      break;
      
   case WIN_ANALOGUE_OUT_PAINT:
      if(winUpdate1==1)
      {
         winUpdate1 = 0;

         slcd_SetColour(DarkGrey, DarkGrey);
         slcd_Send("z");
         slcd_Send("xc all");
         slcd_DisplayBmp(10, 0, 0);

         DisplayTitle("MS Instrumentos");

         slcd_SetFont(24, 0);
         slcd_SetColour(DarkGrey, White);

         /* display page title  */
         slcd_SendText(gstr(&str->Analogs), 15, 60, 0, LEFT_ALIGN);

         /* define back hotspot */
         slcd_MakeHotSpot(128, 560, 10, 50, 50);

         PaintAnalogueOut();

         /* update parameters */
         winUpdate1 = 1;
            
         /* move to update state */      
         winAnalogueOutState = WIN_ANALOGUE_OUT_UPDATE;       
      }
      break;

   
   case WIN_ANALOGUE_OUT_UPDATE:
      /* is there a key to process? */
      if (slcdKey)
      {
         /* call key handler */
         winAnalogueOutKeyHandler(slcdKey);      
         /* now the key has been processed clear it */
         slcdKey = 0; 
      }

      UpdateAnalogueOut();

      /* has any data been remotely changed? */
      if(mbSlave.DataUpdate)
      {
         /* clear data update flag */
         mbSlave.DataUpdate = 0;
         mbTable[enDataUp].WrFlg = 1;   
         
         /* read analog parameters */
         ReadAnalogueOutParameters();  
         
         /* set update timer */                   
         winUpdate1 = 100;
      }      
      return 0;

  case WIN_ANALOGUE_OUT_NUMKEYPAD:
      /* see if key pad is returning */
      if(winKeyPadHandler())
      {
         /* move to update state */      
         winAnalogueOutState = WIN_ANALOGUE_OUT_PAINT; 
         
         winUpdate1 = 1;
      }
      break;
            
   case WIN_ANALOGUE_OUT_UNLOAD:
      /* do any necessary clearing up */
      winAnalogueOutState = WIN_ANALOGUE_OUT_PREPAINT;  

      AnalogIndex = 0;
      
      /* check to see if any analogues are fixed */
      if(AnalogFixFlg)
      {
         /* make sure all analogues are unfixed */         
         AnalogFixFlg = 0;
         /* set non valid adjust value to unfix */
         mbSlave.AnAdjust[0] = 21.0;      
         mbTable[enAnAdjust1].WrFlg = 0x1;
         mbSlave.AnAdjust[1] = 21.0;      
         mbTable[enAnAdjust2].WrFlg = 0x1;
         /* force mb table index An Wr flag */
         mbTableIndex = enAnOut1;         
      }
      
      /* set return menu */
      winActiveWin = INPUTSOUTPUTS_WINDOW;

      /* return from key pad */
      return 1;
   }   
}



