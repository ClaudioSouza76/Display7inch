/*
** ------------------------------------------------------------------------------
   
   File   : winMain.h 
   Aurthor: Stuart Clarke

** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

#ifndef WINMAIN_H
#define WINMAIN_H


/* public defines */


/*
** ------------------------------------------------------------------------------
**		#define : win main handler states 
** ------------------------------------------------------------------------------
*/

#define WIN_GET_PARA          0
#define WIN_PAINT             1
#define WIN_UPDATE            2
#define WIN_CALPAD            3
#define WIN_AVG               4
#define WIN_UNLOAD            5


/*
** ------------------------------------------------------------------------------
**		#define : slcd window handler 
** ------------------------------------------------------------------------------
*/

#define SPLASH_SCREEN         0
#define MODBUS_CONNECT        1
#define SPLASH_TIMEOUT        2
#define MAIN_WINDOW           3
#define USER_WINDOW           4
#define BASIC_CONFIG_WINDOW   5
#define BALANCE_DATA_WINDOW   6
#define INPUTSOUTPUTS_WINDOW  7
#define CALCONSTANTS_WINDOW   8


#define SETUP_WINDOW          9
//#define RANGES_WINDOW         10
#define CALCHECK_WINDOW       11
#define TIMEDATE_WINDOW       12
#define SPEEDCAL_WINDOW       13
#define MASSCAL_WINDOW        14
#define MASSSPANCAL_WINDOW    15
#define TENSION_WINDOW        16
#define FIELDBUS_WINDOW       17
#define ENGINEERING_WINDOW    18
#define WIN_MAIN_ENTER_PASSWORD 19

#define SPECIALFUNC_WINDOW    20
#define SIMULATION_WINDOW     21
#define FILTERING_WINDOW      22
#define DIGITS_WINDOW         23
#define TOTALIZER_WINDOW      24
#define COMPENSATION_WINDOW   25

#define AD7730_WINDOW         26
#define CALFUNC_WINDOW        27

#define DIGITALIN_WINDOW      28
#define DIGITALOUT_WINDOW     29
#define ANALOGUEIN_WINDOW     30
#define ANALOGUEOUT_WINDOW    31

#define MOVING_AVERAGE_WINDOW 32

#define HISTOGRAM_WINDOW      33

#define INSPECMEC_WINDOW 34

#define CORRECTION_WINDOW     35

#define CORRFLOW_WINDOW       36

#define DENSIDADE_CAL         37

#define DENS_DATA_WINDOW      38



/*
** ------------------------------------------------------------------------------
**		#define : diagnostic pages 
** ------------------------------------------------------------------------------
*/

#define PAGE1       0
#define PAGE2       1
#define PAGE3       2
#define PAGE4       3
#define PAGE5       4
#define PAGE6       5


/*
** ------------------------------------------------------------------------------
**		#define : alarm bits 
** ------------------------------------------------------------------------------
*/


#define ALR_HI1     0x01
#define ALR_LO1     0x02
#define ALR_HI2     0x04
#define ALR_LO2     0x08
#define ALR_HI3     0x10
#define ALR_LO3     0x20
#define ALR_HI4     0x40
#define ALR_LO4     0x80

/*
** ------------------------------------------------------------------------------
**		#define : X and Y common cordinates
** ------------------------------------------------------------------------------
*/

#define ccY0     140
#define ccY1     220
#define ccY2     300
#define ccY3     380
#define ccY4     460
#define ccY5     280

/*
** ------------------------------------------------------------------------------
**		#define : X and Y common cordinates
** ------------------------------------------------------------------------------
*/

#define wdY0     150
#define wdY1     210
#define wdY2     270
#define wdY3     330
#define wdY4     390
#define wdY5     450
#define wdY6     510


/*
** ------------------------------------------------------------------------------
**		typedef: CalType
** ------------------------------------------------------------------------------
*/

typedef struct
{
   byte  ProductText[15];
   float Span[3];
   float Zero[3];
   float AlarmHi[4];
   float AlarmLo[4];
   float Offset;
}CalType;


/*
** ------------------------------------------------------------------------------
**		Function: #ifdef FIVEPOINTSEVEN
** ------------------------------------------------------------------------------
*/

/* define for 5.7in display */

//#define FIVEPOINTSEVEN
#define SEVENPOINTONE

#ifdef FIVEPOINTSEVEN
//#warning "5.7in LCD Build" 
#else
//#warning "7.1in LCD Build" 
#endif

/*
** ------------------------------------------------------------------------------
**		Function: #ifdef FIVEPOINTSEVEN
** ------------------------------------------------------------------------------
*/

/* scales x cordinate for 5.7in display */


#ifdef FIVEPOINTSEVEN
#define getX(x)   (word)(x/1.5)
#define getY(x)   (word)(x/1.13)
#else
#define getX(x)   (word)(x/1.5)
#define getY(x)   (word)(x/1.13)
#endif 



#ifndef WINMAIN_C


/* public variables */
#pragma DATA_SEG WINMAIN_Data

extern byte winActiveWin;

extern word winTimer1;
extern word winTimer2;
extern word winTimer3;

extern byte winUpdate1;
extern byte winUpdate2;
extern word winRePaint;
extern word winSplashTimer;

extern unsigned long CalTimer;
extern long CalTimeOut;

extern word winStatusWordCopy;
extern word MotorFlagCopy;

extern word StatusImg;
extern byte StatusSeq;
extern word StatusDelay;

extern CalType	*CalArrayPtr; 

extern byte *ErrorString[13]; 


extern byte  LastFlowLen;
extern byte  LastTotalLen;
extern byte  LastMassLen;
extern byte  LastSpeedLen;

extern char DisplayString[20];




#endif   /* WINMAIN_C */      

/* public functions */
#pragma CODE_SEG WINMAIN_Code


/*
** ------------------------------------------------------------------------------
**		Function: void winUpdateStatus(byte Window)
** ------------------------------------------------------------------------------
*/

void winUpdateStatus(byte Window);

/*
** ------------------------------------------------------------------------------
**		Function: void winDisplayStatus(void)
** ------------------------------------------------------------------------------
*/

void winDisplayStatus(byte Window);

/*
** ------------------------------------------------------------------------------
**		Function: void DrawLine(byte X1, byte Y1, byte X2, byte Y2)
** ------------------------------------------------------------------------------
*/

void DrawLine(word X1, word Y1, word X2, word Y2);

/*
** ------------------------------------------------------------------------------
**		Function: void UpDateChart(byte id, word value)
** ------------------------------------------------------------------------------
*/

void UpDateChart(byte id, word value);

/*
** ------------------------------------------------------------------------------
**		Function: void MakeChart(byte X1, byte Y1, byte X2, byte Y2)
** ------------------------------------------------------------------------------
*/

void MakeChart(word X1, word Y1, word X2, word Y2, word Scale);

/*
** ------------------------------------------------------------------------------
**		Function: void winMainHandler(void)
** ------------------------------------------------------------------------------
*/

void winMainHandler(void);

/*
** ------------------------------------------------------------------------------
**		Function: void winMainCtrl(void);
** ------------------------------------------------------------------------------
*/

void winMainCtrl(void);

/*
** ------------------------------------------------------------------------------
**		Function: void MakeChart(byte X1, byte Y1, byte X2, byte Y2)
** ------------------------------------------------------------------------------
*/

void MakeChart(word X1, word Y1, word X2, word Y2, word Scale);

/*
** ------------------------------------------------------------------------------
**		Function: void winUpdateHistogramEntry(void)
** ------------------------------------------------------------------------------
*/

void winUpdateHistogramEntry(void);

/*
** ------------------------------------------------------------------------------
**		Function: void MessageError(void)
** ------------------------------------------------------------------------------
*/
void MessageError(void);
           


#endif   /* WINMAIN_H */
