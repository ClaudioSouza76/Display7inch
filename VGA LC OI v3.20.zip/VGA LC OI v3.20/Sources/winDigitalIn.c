#include <hidef.h>                           /* common defines and macros */
#include "derivative.h"                      /* derivative information */

/*
** ------------------------------------------------------------------------------
   
   File   : winDigitalIn.c 
   Aurthor: 
   
   Description:  
   
   Version Log          Notes                                     Changes Made by                                        
   --------------       -----                                     ---------------
   08-10-11:            Created                                   Stuart


** ------------------------------------------------------------------------------
                                    
                                    Overview
                                            
** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

/* library headers */
#include "stdio.h"
#include "float.h"
#include "math.h"

/* Application headers */
#include "CRG 100110.h" 
#include "Subs.h"
#include "SlcdSubs.h"
#include "ModBusM Int.h"
#include "ModBusM.h"
#include "EEPROM.h"
#include "SLCD 260217.h"
#include "winMain.h"
#include "winKey.h"
#include "Language.h"


/* Implements this interface: */
#define WINDIGITALIN_C
#include "winDigitalIn.h"

#pragma CODE_SEG WINDIGITALIN_CODE
#pragma DATA_SEG WINDIGITALIN_DATA


/* private */
static byte winDigitalInState;

static byte InputIndex;
static byte InputImg;
static word InputDelayReg;

/* public */
byte winDigitalInReturnWin;

/* Digital Inputs screen layout (640x480 logical, scaled by slcd_SendText) */
#define DIN_Y_OFF      53    /* page title now at y=60 (was y=7) */
#define DIN_LED_Y      (90  + DIN_Y_OFF)
#define DIN_BTN_Y      (89  + DIN_Y_OFF)
#define DIN_INPUT_Y    (150 + DIN_Y_OFF)
#define DIN_ROW1_Y     200   /* first field row */
#define DIN_ROW_DY     36    /* standard row spacing */
#define DIN_ROW(n)     (DIN_ROW1_Y + (((n) - 1) * DIN_ROW_DY))
#define DIN_LBL2_Y     DIN_ROW(1)
#define DIN_VAL2_Y     DIN_ROW(2)
#define DIN_LBL3_Y     DIN_ROW(3)
#define DIN_VAL3_Y     DIN_ROW(4)
#define DIN_HS_H       40

/*
** ------------------------------------------------------------------------------
**		Function: void SetInputDelay(void)
** ------------------------------------------------------------------------------
*/

void SetInputDelay(void)
{
   /* */
   InputDelayReg = InputDelayReg/100;
   mbSlave.InputDelay[InputIndex] = InputDelayReg;
}


/*
** ------------------------------------------------------------------------------
**		Function: void winDigitalInKeyHandler(byte key)
** ------------------------------------------------------------------------------
*/

void winDigitalInKeyHandler(byte key)
{   
   switch (key)
   {
   case 128:       /* EXIT */
      winDigitalInReturnWin = USER_WINDOW;
      /* shut down num key window handler */
      winDigitalInState = WIN_DIGITAL_IN_UNLOAD;  
      break;  
      
  case 129:       /* Positive */
      /* set colours back */
      slcd_SetColour(LightBlue, DarkGrey);  
      slcd_SendText(gstr(&str->Positive), 360, DIN_VAL2_Y, 0, LEFT_ALIGN);   
      slcd_SetColour(LightBlue, White);  
      slcd_SendText(gstr(&str->Negative), 480, DIN_VAL2_Y, 0, LEFT_ALIGN); 
      
      mbSlave.InputPolartiy &=~ (0x01<<InputIndex);      
      mbTable[enInPolarity].WrFlg = 0x1;  
      break;        

  case 130:       /* Negative */
      /* set colours back */
      slcd_SetColour(LightBlue, White);  
      slcd_SendText(gstr(&str->Positive), 360, DIN_VAL2_Y, 0, LEFT_ALIGN);   
      slcd_SetColour(LightBlue, DarkGrey);  
      slcd_SendText(gstr(&str->Negative), 480, DIN_VAL2_Y, 0, LEFT_ALIGN);   
      mbTable[enInPolarity].WrFlg = 0x1;  

      mbSlave.InputPolartiy |= (0x01<<InputIndex);      
      mbTable[enInPolarity].WrFlg = 0x1;  
      break;        
      
   case 1:       /* Digital Inputs */
      /* switch page */
      if(InputIndex)
         InputIndex--;
      
      PaintDigitalIn();
      break;  
      
   case 2:       /* Digital Outputs */
      /* switch page */
      if(InputIndex<3)
         InputIndex++;
      
      PaintDigitalIn();
      break; 
      
   case 131:      /* Input delay hotspot */
      /* move to key pad handler sate */
      winDigitalInState = WIN_DIGITAL_IN_NUMKEYPAD; 
      
      /* copy parameter data to key structure */
      strcpy(NumKeyData.Name, gstr(&str->InputDelay) );  
      NumKeyData.Type = WORD;
      NumKeyData.KeyBoardType = NUMBER;
      NumKeyData.iMax = 10000;
      NumKeyData.iMin = 100;
      NumKeyData.DataPtr = (void *)&InputDelayReg;      
      
      /* set func ptr */
      NumKeyData.fp = SetInputDelay;
               
      switch (InputIndex)
      {
      case 0:
         NumKeyData.Flag  = enInDelay1;
         break;

      case 1:
         NumKeyData.Flag  = enInDelay2;
         break;

      case 2:
         NumKeyData.Flag  = enInDelay3;
         break;

      case 3:
         NumKeyData.Flag  = enInDelay4;
         break;
      }      
      break;  
   
    case 132:   /* Input function hotspot */
      if(mbSlave.InputFunction[InputIndex]<1)
        mbSlave.InputFunction[InputIndex]++;
      else
        mbSlave.InputFunction[InputIndex]=0;
      
      switch (InputIndex)
      {
        case 0:
          mbTable[enInFunction1].WrFlg = 0x1;
        break;
        
        case 1:
          mbTable[enInFunction2].WrFlg = 0x1;
        break;
        
        case 2:
          mbTable[enInFunction3].WrFlg = 0x1;
        break;
        
        case 3:
          mbTable[enInFunction4].WrFlg = 0x1;
        break;
        
      }
      
      DisplayInputFunction();
      
    break;
   }
}


/*
** ------------------------------------------------------------------------------
**		Function: void ReadDigitalInParameters(void)
** ------------------------------------------------------------------------------
*/

void ReadDigitalInParameters(void)
{
   mbTable[enInputs].RdFlg = 0x1;

   mbTable[enInDelay1].RdFlg = 0x1;
   mbTable[enInDelay2].RdFlg = 0x1;
   mbTable[enInDelay3].RdFlg = 0x1;
   mbTable[enInDelay4].RdFlg = 0x1;
   
   mbTable[enInPolarity].RdFlg = 0x1;
   
   mbTable[enInFunction1].RdFlg = 0x1;
   mbTable[enInFunction2].RdFlg = 0x1;
   mbTable[enInFunction3].RdFlg = 0x1;
   mbTable[enInFunction4].RdFlg = 0x1;
   
   
}


/*
** ------------------------------------------------------------------------------
**		Function: void DisplayLEDs(void)
** ------------------------------------------------------------------------------
*/

void DisplayLEDs(void)
{

   if(mbSlave.Inputs!=InputImg)
   {
      InputImg = mbSlave.Inputs;
         
      /* input 1 */
      if(mbSlave.Inputs&0x01)
         slcd_DisplayBmp(29, 160, DIN_LED_Y); 
      else
         slcd_DisplayBmp(28, 160, DIN_LED_Y); 
      
      /* input 2 */
      if(mbSlave.Inputs&0x02)
         slcd_DisplayBmp(29, 220, DIN_LED_Y); 
      else
         slcd_DisplayBmp(28, 220, DIN_LED_Y); 
      
      /* input 3 */
      if(mbSlave.Inputs&0x04)
         slcd_DisplayBmp(29, 280, DIN_LED_Y); 
      else
         slcd_DisplayBmp(28, 280, DIN_LED_Y); 
      
      /* input 4 */
      if(mbSlave.Inputs&0x08)
         slcd_DisplayBmp(29, 340, DIN_LED_Y); 
      else
         slcd_DisplayBmp(28, 340, DIN_LED_Y); 
   }
}

/*
** ------------------------------------------------------------------------------
**		Function: void UpdateDigitalIn(void)
** ------------------------------------------------------------------------------
*/

void UpdateDigitalIn(void)
{
   /* requested update */
   if (winUpdate1==1)
   {
      /* stop counter */
      winUpdate1 = 0;
      
   }

   /* time to update? */
   if (!winTimer1)
   {
      winTimer1 = 10;

      DisplayLEDs(); 
      /* read inputs */
      mbTable[enInputs].RdFlg = 0x1;
       
   }
}

/*
** ------------------------------------------------------------------------------
**		Function: DisplayInputFunction(void)
** ------------------------------------------------------------------------------
*/

void DisplayInputFunction(void)
{   
   /* set colours back */
   slcd_SetColour(LightBlue, White);       

   if(PanelSize == PSZ_1024_600)
      slcd_SetFont(14, 0);
   else
      slcd_SetFont(16, 'B');  

      
   /* clear previous string */
   slcd_SendText("                                 ", 50, DIN_VAL3_Y, 0, LEFT_ALIGN);      
   
   switch (mbSlave.InputFunction[InputIndex])
   {
   default:
   case 0:
      /* function delay */   
      slcd_SendText("NA", 50, DIN_VAL3_Y, 0, LEFT_ALIGN);      
      break;

   case 1:
      /* PERA */   
      slcd_SendText("P.E.R.A", 50, DIN_VAL3_Y, 0, LEFT_ALIGN);      
      break;

   
   }
   
}


/*
** ------------------------------------------------------------------------------
**		Function: void PaintDigitalIn(void)
** ------------------------------------------------------------------------------
*/

void PaintDigitalIn(void)
{
   byte Buf[30];

   slcd_SetFont(24, 'B');
   slcd_SetColour(DarkGrey, White);  
      
   /* display select Input */
   sprintf(Buf, "%s   %u", gstr(&str->Input), InputIndex+1);
   slcd_SendText(Buf, 20, DIN_INPUT_Y, 0, LEFT_ALIGN);

   /* set colours back */
   slcd_SetColour(LightBlue, White);       

   if(PanelSize == PSZ_1024_600)
      slcd_SetFont(14, 0);
   else
      slcd_SetFont(16, 'B');  
             
   /* Input delay  */
   InputDelayReg = mbSlave.InputDelay[InputIndex]*100;
   sprintf(Buf, "%u mS", InputDelayReg);
   slcd_SendText(&Buf, 50, DIN_VAL2_Y, 0, LEFT_ALIGN);      
   
   /* display polartiy */
   if(!(mbSlave.InputPolartiy&(0x01<<InputIndex)))
   {
      /* set colours back */
      slcd_SetColour(LightBlue, DarkGrey);  
      slcd_SendText(gstr(&str->Positive), 360, DIN_VAL2_Y, 0, LEFT_ALIGN);   
      slcd_SetColour(LightBlue, White);  
      slcd_SendText(gstr(&str->Negative), 480, DIN_VAL2_Y, 0, LEFT_ALIGN);   
   }
   else
   {
      /* set colours back */
      slcd_SetColour(LightBlue, White);  
      slcd_SendText(gstr(&str->Positive), 360, DIN_VAL2_Y, 0, LEFT_ALIGN);   
      slcd_SetColour(LightBlue, DarkGrey);  
      slcd_SendText(gstr(&str->Negative), 480, DIN_VAL2_Y, 0, LEFT_ALIGN);   
   }
      
   /* Input function */
   sprintf(Buf, "%u", mbSlave.InputFunction[InputIndex]);
   slcd_SendText(&Buf, 50, DIN_VAL3_Y, 0, LEFT_ALIGN);   
   
   DisplayInputFunction();
            
}


/*
** ------------------------------------------------------------------------------
**		Function: byte winDigitalInHandler(void)
** ------------------------------------------------------------------------------
*/

byte winDigitalInHandler(void)
{  
   switch (winDigitalInState)
   {
   case WIN_DIGITAL_IN_PREPAINT:
      /* get analog parameters from slave */
      ReadDigitalInParameters();

      /* set delay for parameters to arrive from MCT  */
      winUpdate1 = 15;
      
      InputIndex = 0;
      InputImg = 0;
            
      winDigitalInState = WIN_DIGITAL_IN_PAINT;
      break;
      
   case WIN_DIGITAL_IN_PAINT:
      if(winUpdate1==1)
      {
         winUpdate1 = 0;

         slcd_SetColour(DarkGrey, DarkGrey);
         slcd_Send("z");

         slcd_Send("xc all");
         /* display menu screen */
         slcd_DisplayBmp(10, 0, 0);

         DisplayTitle("MS Instrumentos");

         slcd_SetFont(24, 0);
         slcd_SetColour(DarkGrey, White);

         /* display page title  */
         slcd_SendText(gstr(&str->DigitalInputs), 15, 60, 0, LEFT_ALIGN);

         /* define back hotspot */
         slcd_MakeHotSpot(128, 560, 10, 50, 50);
         
         slcd_SetFont(16, 'B');
         /* display status LEDs */
         slcd_SendText(gstr(&str->Input), 10, DIN_LED_Y, 'T', LEFT_ALIGN);

         /* make the image differ to force update */
         InputImg = mbSlave.Inputs+1;
         DisplayLEDs();
        
         /* make page select buttons */
         slcd_MakeButton(1, 1, 483, DIN_BTN_Y, 20, 21);
         slcd_MakeButton(2, 1, 552, DIN_BTN_Y, 22, 21);         
         
         slcd_SetFont(16, 0);
         
         slcd_SendText(gstr(&str->InputDelay), 20, DIN_LBL2_Y, 'T', LEFT_ALIGN);
         slcd_SendText(gstr(&str->Polarity),   360, DIN_LBL2_Y, 'T', LEFT_ALIGN);
         slcd_SendText(gstr(&str->Function),   20, DIN_LBL3_Y, 'T', LEFT_ALIGN);
         
         /* define hotspots (x, y, width, height) */
         slcd_MakeHotSpot(129, 360, DIN_VAL2_Y, 80,  DIN_HS_H);
         slcd_MakeHotSpot(130, 480, DIN_VAL2_Y, 80,  DIN_HS_H);
         slcd_MakeHotSpot(131, 50,  DIN_VAL2_Y, 55,  DIN_HS_H);
         slcd_MakeHotSpot(132, 50,  DIN_VAL3_Y, 55,  DIN_HS_H);
                  
         PaintDigitalIn();         
         
         /* update parameters */
         winUpdate1 = 1;
         
         /* move to update state */      
         winDigitalInState = WIN_DIGITAL_IN_UPDATE;       
      }
      break;

   
   case WIN_DIGITAL_IN_UPDATE:
      /* is there a key to process? */
      if (slcdKey)
      {
         /* call key handler */
         winDigitalInKeyHandler(slcdKey);      
         /* now the key has been processed clear it */
         slcdKey = 0; 
      }

      UpdateDigitalIn();

      /* has any data been remotely changed? */
      if(mbSlave.DataUpdate)
      {
         /* clear data update flag */
         mbSlave.DataUpdate = 0;
         mbTable[enDataUp].WrFlg = 1;   
         
         /* read analog parameters */
         ReadDigitalInParameters();  
         
         /* set update timer */                   
         winUpdate1 = 100;
      }      
      return 0;

  case WIN_DIGITAL_IN_NUMKEYPAD:
      /* see if key pad is returning */
      if(winKeyPadHandler())
      {
         /* move to update state */      
         winDigitalInState = WIN_DIGITAL_IN_PAINT; 
         
         winUpdate1 = 1;
      }
      break;
            
   case WIN_DIGITAL_IN_UNLOAD:
      /* do any necessary clearing up */
      winDigitalInState = WIN_DIGITAL_IN_PREPAINT;  

      /* set return menu */
      winActiveWin = INPUTSOUTPUTS_WINDOW;

      /* return from key pad */
      return 1;
   }   
}



