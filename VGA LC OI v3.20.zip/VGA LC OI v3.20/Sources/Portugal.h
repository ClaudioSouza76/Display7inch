/*
** ------------------------------------------------------------------------------
   
   File   : Potuguese.h 
   Aurthor: Stuart Clarke

** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2010 MS INSTRUMENTOS INDUSTRIAIS LTDA
   This program is the property of MS INSTRUMENTOS INDUSTRIAIS LTDA.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   MS INSTRUMENTOS INDUSTRIAIS LTDA
   Industriais Ltda 
   Estrada do Bigu?? 43 - Alto da Boa Vista 
   Rio de Janeiro RJ/Brasil
  
** ------------------------------------------------------------------------------
*/

#ifndef PORTUGUESE_H
#define PORTUGUESE_H


/* public defines */

#pragma STRING_SEG STRING_BANK

/*
** ------------------------------------------------------------------------------
**		Portuguese
**      UTF-8 accents use octal escapes (CodeWarrior \x is greedy on hex digits)
** ------------------------------------------------------------------------------
*/

byte *Portuguese[] = 
{
/* main screen */
/* Status */                  "Status",

/* menu */
/* Status: Connected */       "Status: Conectado   ",
/* Status: Connecting */      "Status: Conectando",
/* Enter Password */          "Digite Senha",
/* Select Menu */             "Selecione menu",

/* cal parameters */
/* Zero */                    "Zero",
/* Span */                    "Span",
/* Damp */                    "Damp", 
/* Avg Time */                "Tempo M\303\251dio", 
/* Alarm Hi */                "Alarme Alto",
/* Alarm Lo */                "Alarme Baixo",
/* Analog Hi */               "Anal\303\263gica Alto",
/* Analog Lo */               "Anal\303\263gica Baixo",
/* Cal: */                    "Cal:",

/* misc */
/* Change Password */         "Mudar Senha",
/* Digits */                  "D\303\255gitos",
/* Digits (Precision) */      "D\303\255gitos (Precis\303\243o)",
/* Instrument ID */           "Instrumento ID",
/* OI Version */              "SE Vers\303\243o",
/* NIR Version */             "BEM Vers\303\243o",
/* Serial No */               "NO S\303\251rie",

/* engineering */
/* Engineering */             "Engenharia",
/* ON */                      "LIG",
/* OFF */                     "DLIG",

/* Warning */                 "Aviso",
/* Are you sure you want to restore settings from backup? */    "Tem certeza quer restaurar config armazenado no backup?",
/* Are you sure you want to save settings to backup?*/           "Tem certeza quer salvar config armazenado no backup?",
/* EE CLEAR */                "EE Limpa ",
/* Restore Factory Defaults */"Restaurar Dados de F\303\241brica ",
/* Reset Product Calibrations */"Reset Product Calibrations ",
/* Languages */                "idioma",
/* Select Language */          "Selecione idioma",
/* Ananlogue */
/* Analog */                   "Anal\303\263gica",
/* Analog Allocation */        "Analog endere\303\247o",
/* Analog Adjust */            "Analog Ajuste",
/* Analog Hi */                "Analog Alto",
/* Analog Lo */                "Analog Baixo",
/* Output mA */                "Sa\303\255da mA",
/* Constituent */              "Constituinte",
/* Fix 2mA */                  "Fix 2mA",
/* Fix 18mA */                 "Fix 18mA",
/* Adjust */                   "Ajuste",

/* key pad */
/* Min: */                     "Min:",
/* Max: */                     "Max:",

/* field bus */
/* IP Address: */              "Endere\303\247o IP: ",
/* SubNet: */                  "SubNet: ",
/* DHCP */                     "DHCP ",

/* */
/* User Menu */                "Menu do usu\303\241rio",
/* Setup Menu */               "Menu configura\303\247\303\243o",
/* Save */                     "Salvar",
/* Page 1 */                   "P\303\241gina 1",
/* Page 2 */                   "P\303\241gina 2",
/* Page 3 */                   "P\303\241gina 3",
/* Restore Instrument */       "Restaurar Instrumento",
/* Settings */                 "Ajustes",
/* Backup Instrument */        "Backup Instrumento",
/* Restore Factory */          "Restaurar F\303\241brica",
/* Defaults */                 "confg original", 
/* Erase */                    "Apagar",
/* Yes */                      "Sim",
/* No */                       "N\303\243o",  

/* New strings for LC IO */

/* Setup Menu */
/* Setup */                   "Configura\303\247\303\243o",
/* Full Calibration */        "Calibra\303\247\303\243o completa  ",
/* Resolution And */          "Resolu\303\247\303\243o e",
/* Ranges */                  "Faixa opera\303\247\303\243o",
/* Speed */                   "Velocidade:",
/* Mass */                    "Massa:",
/* Calibration */             "Calibra\303\247\303\243o",

/* Time And */                "Hora e",
/* Date */                    "Data",
/* Analogs */                 "Sa\303\255da Anal\303\263gica",
/* FieldBus */                "FieldBus",

/* Ranges */
/* Rates and Ranges */        "Fluxos e limites oper.  ",
/* Scale Tag */               "Tag",
/* Rate Units */              "Unidade de Fluxo",
/* Resolution */              "Resolu\303\247\303\243o",
/* Pulse Totalizer */         "Pulso p/ Totalizador",

/* Rate Ranges */             "Faixa oper Fluxo ",
/* Speed Ranges */            "Faixa oper Velocidade",
/* Mass Ranges */             "Faixa oper Massa",
/* High End */                " Alto m\303\241ximo",
/* Low End */                 " Baixo m\303\255nimo",

/* Engineering menu */
/* Tacho */                   "Taco",
/* Input */                   "Entrada",
/* AD7730 */                  "AD7730",
/* Converter */               "Conversor",
/* EEPROM */                  "EEPROM",

/* Set Time and Date */       "Definir Hora e Data",
/* Set Time */                "Hora",
/* Set Date */                "Data",

/* Zero Calibration */        "Zero Calibra\303\247\303\243o",
/* Span Calibration */        "Span Calibra\303\247\303\243o",

/* Speed Calibration */       "Calib. Velocidade",
/* Mass Calibration */        "Calib. Massa",
/* STOP CONVEYOR! */          "Parar Transportador!",
/* RUN CONVEYOR EMPTY! */     "Acione Transportador s/ carga!",
/* Cal Duration */            "tempo p/ Cal.",
/* Frequency */               "Frequ\303\252ncia",
/* Frequency Offset */        "Frequ\303\252ncia desvio",
/* BeltSpeed */               "Velocidade correia",
/* Enter Measured Speed */    "Velocidade = m/s",

/* START */                   "INICIAR",
/* STOP */                    "PARAR",
/* ABORT */                   "ABORTAR",
/* ACCEPT */                  "ACEITAR",
/* CALIBRAITNG */             "CALIBRANDO",
/* COMPLETE */                "Conclu\303\255do       ",
/* "CALCULATE", */            "Calcular",
/* STOP CONVEYOR EMPTY! */    "PARE TRANSPORTADOR s/ carga!",

/* Counts */                  "Contagem",
/* Mass Offset */             " Massa Desvio",

/* "Enter Mass", */           "Informe PESO", 
/* "Mass Span", */            "Span de Massa", 
/* "Mass Adj", */             "Ajustar Massa",
/* "LOAD TEST WEIGHT", */     "Carga c/ Peso Teste",

/* "SpecialFunc", */          "Fun\303\247\303\265es Especiais",
/* "Simulation", */           "Simula\303\247\303\243o",
/* "Filtering", */            "Filtros",
/* "Alarm Settings", */       "Alarme ajustes ",
/* "Totalizer", */            "Totalizador",
/* "Compensation", */         "Compensa\303\247\303\243o",

/* "Rate Filter", */          "Fluxo",
/* "Mass Filter", */          "Massa",
/* "Speed Filter", */         "Velocidade",
/* "Time Constant", */        "Const.Tempo",

/* "Mass Alarms", */          "Massa",
/* "Rate Alarms", */          "Fluxo",
/* "Speed Alarms", */         "Velocidade",
/* "Deviation Alarms", */     "Desvio",

/* "High Alarm", */           "Alarme Alto",
/* "Low Alarm", */            "Alarm Baixo",
/* "Hysteresis", */           "Histeresi",

/* "PulseWidth", */           "Larg.de Pulso",
/* "PulseRate", */            "Taxa de Pulso",
/* "Cut-Off", */              "N\303\203O Totaliza",
/* "Total Reset", */          "Limpa Total ",
/* "Total", */                "Total",
/* "Pulse Test", */           "Pulso Teste",

/* Flow */                    "Fluxo:",
/* Total */                   "Total:",
/* Weight */                  "Peso: ",
/* Last Cal Check */          "Cal.:",
/* Next Cal */                "Pr\303\263xima cal:",

/* Belt Length */             "Comp.da Correia",
/* Max Scale Capacity */      "capac m\303\241xima balan\303\247a ",

/* Cal Weight */              " Peso referencia",

/* "Test Weight Cal", */      "Peso Teste",
/* "Material Weight Cal", */  "Peso Conhecido",  
/* "Belt Cut Cal", */         "Corte Correia",

/* "Average Kg/m", */         "Kg/m3 m\303\251dio",
/* "Cal Total", */            "Total ",
/* "Flow Rate %", */          " % da C.C:",
/* "Belt Distance", */        " metros de correia ",

/* "TransportCapacity", */     "Capacid. LC",
/* "Application Capacity",*/   "Fluxo Projeto",
/* "BalanceCapacity" */        "Capacidade Balan\303\247a",
/* "TestWightAppPercentage",*/ "P.Teste % da aplica\303\247\303\243o",
/* "SensibilityLC", */         "Sensibilidade LC",

/* "Material Density", */       "Densidade Aparente",
/* "BeltWidth", */              "Largura Correia",
/* "ConvayorAngle", */          "Inclin. Transportador",
/* "RollerAngle", */            "Inclina\303\247\303\243o Roletes",
/* "IdleSpacing", */            "Espa\303\247amento cavaletes",

/* "SerialNo", */               "Serial No",
/* "ShippingDate", */           "Data de Sa\303\255da",
/* "TestWeight", */             "Peso Teste",

/* "Are you sure", */          "Tem certeza ",

/* "Restoring", */            "Restaurando...",
/* "BackingUp", */            "Salvando...",
/* "Complete", */             "Conclu\303\255do",

/* "Cal Functions", */        "Fun\303\247\303\265es Calibra\303\247\303\243o",
/* "Cal Time", */             "Tempo m\303\255nimo ",
/* "exicution", */            "execu\303\247\303\243o.",


/* "Speed Sim ", */           "Velocidade simul.",   
/* "Mass Sim ", */            "Massa simul.",  

/* "mV Very High", */         "mV muito alto verifique mec\303\242nica ponte de pesagem.",  
/* "OK", */                   "OK", 
/* "Cal Zero Limit", */       "Cal Zero Limit",
/* "Max Cal Time", */         "Max Cal Time",

/* "Inputs", */               "Entrada",
/* "Outputs", */              "Sa\303\255da",

/* "Inputs And Outputs",*/    "Entradas e Sa\303\255das",
/* "Analogue", */             "Anal\303\263gica",
/* "Digital", */              "Digital",

/* "Digital Inputs", */       "Entrada Digital",
/* "Digital Outputs", */      "Sa\303\255das Digital",
/* "Analogue Inputs", */      "Entrada Anal\303\263gica",
/* "Analogue Outputs", */     "Sa\303\255das Anal\303\263gica",

/* "Input Delay", */          "Atraso de Entrada",
/* "Polarity", */             "Transi\303\247\303\243o",
/* "Function", */             "Fun\303\247\303\243o",

/* "Positive", */             "Positiva",
/* "Negative", */             "Negativa",

/* "Output", */               "Sa\303\255da",
/* "TriggerHi", */            "M\303\241ximo",
/* "TriggerLo", */            "M\303\255nimo",

/* "Output Delay", */         "Atraso de Sa\303\255da",

/* "Analogue In 1", */        "Anal\303\263gica 1",
/* "Analogue In 2", */        "Anal\303\263gica 2",

/* "Tension",*/               "Tens\303\243o",
/* "Input Type",*/            "Tipo de Entrada",

/* "Tension Hi", */           "T Alta:",
/* "Tension Lo", */           "min T:",

/* "Moving Average LC", */    "M\303\251dia M\303\263vel LC",
/* "Moving Average BT", */    "M\303\251dia M\303\263vel BT",

/* "Sample Count",      */    "Amostra de Cnt",
/* "Average Count",     */    "M\303\251dia de Cnt",

/* "Time out calibration", */ "Dados de calibra\303\247\303\243o Coletados com sucesso!!",

/* "Precision", */            "D\303\255gitos",

/* "SerNumMS", */             "Numero Serial",
/* "ModelScale",*/            "Tipo-Num.CC- NumRolete",

/* Configuration */           "Configura\303\247\303\243o",
/* Basic/Diagnostics */       "B\303\241sico/Diagn\303\263sticos",
/* Histogram */               "Histograma",
/* Configuration Basic/Diagnostics */ "Configura\303\247\303\243o B\303\241sico/Diagn\303\263sticos",
/* Time and Date */                   "Hora e Data",
/* Balance Data */                    "Dados da Balan\303\247a",
/* Calibration Constants */           "Constantes de Calibra\303\247\303\243o",

/* Balance Data screen */
/* Scale Data */                      "Dados da Balan\303\247a",
/* TAG: */                            "TAG:",
/* Model: */                          "Modelo:",
/* Serial No: */                      "N\302\272 S\303\251rie:",
/* C.C: */                            "C.C:",
/* mV/V: */                           "mV/V:",
/* Design Flow(t/h): */                "Fluxo de Projeto(t/h):",
/* Scale Cap.(t/h): */                "Capac. Balan\303\247a(t/h):",
/* Test Wt. equiv.(kg/m): */          "Capac. P.Teste equiv.(kg/m):",
/* Test Weight(%) of flow: */         "Peso Teste(%) do fluxo:",
/* Test Weight(Kg): */                "Peso Teste (Kg):",
/* Factory Date: */                   "Data Fabril:",
/* Version: */                        "Vers\303\243o:",
/* Apparent Density(Kg/m3): */        "Densidade Aparente(Kg/m\302\263):",
/* Belt Length(m): */                 "Comp. Transp. Correia(m):",
/* Belt Width(mm): */                 "Largura Correia(mm):",
/* Design Speed(m/s): */              "Vel. de Projeto(m/s):",
/* Conveyor Incline: */               "Inclina\303\247\303\243o Transportador:",
/* Roller Incline: */                 "Inclina\303\247\303\243o Rolos:",
/* Roller Spacing(m): */              "Espa\303\247amento Roletes(m):",
/* Manufactured by: */                "Fabricado por:",
/* MS Instrumentos Industriais Ltda */"MS Instrumentos Industriais Ltda",
/* RJ-RJ Brazil */                    "RJ-RJ Brasil",
/* http://www.msinstrumentos.com.br */ "http://www.msinstrumentos.com.br",

/* Speed Calibration screen */
/* Flow Rate */                       "Vaz\303\243o",
/* Neglected Flow */                  "Vaz\303\243o Desprezada",
/* Process Flow */                    "Vaz\303\243o de Processo",
/* Data */                            "Dados",
/* Pulses: */                         "Pulsos:",
/* Flow: */                           "Vaz\303\243o:",
/* Error: */                          "Erro:",
/* In */                              "Em",
/* v = */                             "V =",
/* m3/h */                            "m/s",
/* Back */                            "Voltar",
/* Next */                            "Siga",
/* Wait */                            "AGUARDE",

/* Engineering menu */
/* Calibration */                     "Fun\303\247\303\265es de",
/* Functions */                       "Calibra\303\247\303\243o",
/* Mechanical Assembly */             "Montagem Mec\303\242nica",
/* Evaluation */                      "Avalia\303\247\303\243o",
/* Speed Sensor */                    "Sensor de velocidade",
/* Special Functions */               "Fun\303\247\303\265es Especiais",
/* Moving Average */                  "M\303\251dia M\303\263vel",
/* Belt Tension */                    "Tens\303\243o da Correia",
/* Mechanical Inspection */           "Inspe\303\247\303\243o Mec\303\242nica",
/* Actual Zero: */					          "Zero Atual:",
/* New Zero: */						            "Novo Zero:",
/* Actual Zero in: */	                "Zero Atual em:",
/* mV: */							                "mV:",

};

#pragma STRING_SEG DEFAULT



#endif   /* PORTUGUESE_H */
