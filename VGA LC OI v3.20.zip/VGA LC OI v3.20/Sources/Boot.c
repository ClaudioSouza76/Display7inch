#include <hidef.h>                           /* common defines and macros */
#include "derivative.h"       /* derivative information */

/*
** ------------------------------------------------------------------------------
   
   File   : Boot.c 
   Aurthor: 
   
   Description:  
   
   Version Log          Notes                                     Changes Made by                                        
   --------------       -----                                     ---------------
   25-06-11:            Created                                   Stuart Clarke
        
** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

/* library headers */


/* Application headers */
#include "Serial.h"
#include "Flash.h"
#include "Timer.h"


/* Implements this interface: */
#define BOOT_C
#include "Boot.h"

#pragma CODE_SEG   ROM_F200_SEG
#pragma DATA_SEG   BOOT_DATA

/* private */



/* public */
byte BootExitTimer;


/*
** ------------------------------------------------------------------------------
**		Function: BootMain
** ------------------------------------------------------------------------------
*/

volatile void BootMain(void)
{
   /* set PORTK for LEDs */
   DDRP     = 0x70;
   PTP      = 0x70;
   
	/* Setup PLL */
	SYNR  = 9;                 
	REFDV = 0;      
	          
	/* Turn the PLL on */
	PLLCTL_PLLON = 1;          
	/* Wait for the PLL to lock */
	while(!CRGFLG_LOCK);     

	/* Derive system clocks from PLLCLK (Bus Clock = PLLCLK / 2) */	   
	CLKSEL_PLLSEL = 1;  	  

	   
   /* set the CPU12X interrupt vector base address in RAM. */
   IVBR = (CPU12XVBR >> 8);			                        
   /* set ETC0 vector jump address for the ram isr */
   *(word *)(CPU12XVBR + (ETC0 << 1)) = (word)_ETC0_Interrupt;    
   /* set ETC1 vector jump address for the ram isr */
   *(word *)(CPU12XVBR + (ETC1 << 1)) = (word)_ETC1_Interrupt;    
   /* set SCI0 vector jump address for the ram isr */
   *(word *)(CPU12XVBR + (SCI0 << 1)) = (word)_SCI0_Interrupt;    
   
   
   /* copy relocation segment to ram */
   CopyCodeToRAM();
   
   
   /* setup flash clock  */
   _Flash_Init();
   /* set up timer */   
   _Timer_Init();
      
   /* set up UART */
   _SCI_Init(_115200, (_EIGHTBIT|_NOPARITY), (__RE|__TE|__RIEN));   
     
   /* load boot exit timer */
   BootExitTimer = 120;
         
   EnableInterrupts;
   
   _Timer1S = 100;
   
   /* send prompt to Booter app */
   _SendMsg(">\r");
   
   for(;;)
   {      
      _Check_Serial();
      
      /* has 1 second elapst */
      if(!_Timer1S)
      {
         _Timer1S = 25; 
         
         /* toggle leds */
         PTP ^= 0x70; 
         
         /* is it time time to exit the boot loader */
         if(BootExitTimer&&!--BootExitTimer)
         {
            /* dont exit id the device is blank */
            if(*((word*)0xC000) != 0xFFFF)
               ExitBootLoader();      
         }          
      }
   }
}

/*
** ------------------------------------------------------------------------------
**		Function: ExitBootLoader
** ------------------------------------------------------------------------------
*/

volatile void ExitBootLoader(void)
{
   _SendMsg("Exiting Bootloader\r");
   
   /* switch off leds */
   PTP |= 0x70;    
    
   
   ECLKDIV = 10;
   /* clear the error flags */
   ESTAT   = 0x30;		               
   
   /* write a word to the sector of EEPROM to be erased */
   *(word *)0x0C00 = 0xFFFF;		      
   
   /* sector erase */
   ECMD  = 0x40;                       
   /* launch the command */
   ESTAT = 0x80;			               
 
   /* problem executing the command? */
   if ((ESTAT&0x30) != 0)	            
   {
      // umm
      //return("Failed");      
   }
   
   while(!(ESTAT&0x40));
   
   /* switch on the COP and wait for it to time out */         
   COPCTL = 0x47;
	while(1);        
}

/*
** ------------------------------------------------------------------------------
**		Function: byte Boot(void)
** ------------------------------------------------------------------------------
*/


void near Boot(void)
{
   asm
   {
      ldaa	 $C000		         ; load first location of flash
      ldab	 $C001		         ; 

      cpd	#$FFFF		         ; is the device blank?
   	beq	JumpToBoot		      ; jump in to bootloader    

      ldaa	 $0C00		         ; check eeprom boot reg 
      ldab	 $0C01		         ; 

      cpd	#$AA55		         ; is the boot reg set
   	beq	JumpToBoot		      ; jump in to bootloader    
      	
   	ldx   #$C000               ; load program start adr 
   	jmp	0,x	               ; jump to program flash

   JumpToBoot:		

   	lds	#$3D00		         ; zero out registers 
   	ldx	#$2000               ;

   ClrRam:                       

      clrw	2,x+
   	cpx	#$4000
   	bne	ClrRam 


      ldx   #BootMain            ; jump 
      jmp	0,x
   }
}

/*
** ------------------------------------------------------------------------------
**		                        Reset vector table
** ------------------------------------------------------------------------------
*/

/* ISR prototype */
typedef void (*near tIsrFunc)(void);
   
const tIsrFunc _ResetVectorTable[] @ 0xFFFA = 
{ 
   /* Reset handler name                   Address  Description */  
   Boot,                                   /* 0xFFFA  cop         */
   Boot,                                   /* 0xFFFC  clkmon      */
   Boot                                    /* 0xFFFE  reset       */
};




                              
