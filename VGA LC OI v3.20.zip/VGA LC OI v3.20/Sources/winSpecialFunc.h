/*
** ------------------------------------------------------------------------------
   
   File   : winSetup.h 
   Aurthor: Stuart Clarke

** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

#ifndef WINSPECIALFUNC_H
#define WINSPECIALFUNC_H


/* public defines */

/*
** ------------------------------------------------------------------------------
**		#define : win setup handler states 
** ------------------------------------------------------------------------------
*/

#define WIN_SPECIALFUNC_PAINT             0
#define WIN_SPECIALFUNC_UPDATE            1
#define WIN_SPECIALFUNC_UNLOAD            2
#define WIN_SPECIALFUNC_ENTER_PASSWORD    3



#ifndef WINSPECIALFUNC_C


/* public variables */
#pragma DATA_SEG WINSPECIALFUNC_Data

#endif   /* WINMENU_C */      




/* public functions */
#pragma CODE_SEG WINSPECIALFUNC_Code

/*
** ------------------------------------------------------------------------------
**		Function: void winSpecialFuncHandler(void)
** ------------------------------------------------------------------------------
*/

void winSpecialFuncHandler(void);


#endif   /* WINSPECIALFUNC_H */
