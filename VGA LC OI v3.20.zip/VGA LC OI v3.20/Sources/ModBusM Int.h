/*
** ------------------------------------------------------------------------------
   
   File   : ModBusM Int.h 
   Aurthor: Stuart Clarke

** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

//#include "main.h"

#ifndef MODBUSINT_H
#define MODBUSINT_H


/* public defines */

/*
** ------------------------------------------------------------------------------
**		#define: table defines 
** ------------------------------------------------------------------------------
*/

#define mbStr			0x01
#define mbByte			0x02
#define mbWord			0x04
#define mbLong			0x08
#define mbFloat		0x10
#define mbReadOnly	0x20
#define mbNonVol     0x40



/*
** ------------------------------------------------------------------------------
**		define: T3 timeout delays 
** ------------------------------------------------------------------------------
*/

#define T3_9600         3281
#define T3_19200        1640
#define T3_28800        1093
#define T3_38400        820

/*
** ------------------------------------------------------------------------------
**		#define: board type defines 
** ------------------------------------------------------------------------------
*/

#define A1186_01  0x0001

#define A1197_04  0x0010
#define A1197_05  0x0020

#define A1225_01  0x0100

#define A1149_06  0x1000
 
/*
** ------------------------------------------------------------------------------
**		typedef mbTabletype
** ------------------------------------------------------------------------------
*/

typedef struct 
{
	word 	Adr;
	byte 	Size;
	byte 	Atrib;
	byte  RdFlg;
	byte  WrFlg;
	word 	*RamPtr;	
	void  (*fp)(byte);
}mbTabletype;


/*
** ------------------------------------------------------------------------------
**		DataType: mbSlaveType
** ------------------------------------------------------------------------------
*/

typedef struct
{
   byte  VerMoStr[20];
   word  BoardType;
   byte  SerNo[11];
   byte  VersionString[12];
   byte  Tag[17];
   byte  CompanyName[21];
   
   float Rate;
   float Total;
   float Mass;
   float Speed;

   byte  Units[4];
   
   word  Damp[4];
   float Span[4];
   float Zero[4];
   float AlarmHi[4];   
   float AlarmLo[4];   

   word  PulseTotal;

   byte  Name[4][21];

   word  Status;
   float VCC1;
   float VCC2;
   float VP;
   float VN;
   
   float AnOutput[2];
   float AnHi[2];
   float AnLo[2];
   byte  AnFunction[2];
   float AnAdjust[2];
   byte  AnMode;

   byte  Digit;
  
   byte  DataUpdate;
   word  eeClearFlg;
   word  PassWord;
   byte  OiLock;
  
   byte  AsciId;       
   
   word  BusType;
   long  IpAdr;
   long  SubNet;
   byte  DHCP;
   byte  PbNodeAdr;
   byte  Endian;   
   byte  StationName[17];
   
   byte  ADStatus;
   word  ADMode;
   unsigned long  ADFilter;
   byte  ADDac;
   unsigned long  ADOffset;
   unsigned long  ADGain;
   unsigned long  ADData;
   float  MassAverage;
   
   byte  MCalFlag;
   byte  MZeroCalStartStop;
   byte  MSpanCalStartStop;
   float  MassAdj;
   long  MassOffset;
   float MassMv;
      
   byte Time[10];
   byte Date[14];
      
   float Frequency;
   byte  TCalFlag;
   byte  ZeroCalStartStop;
   byte  SpanCalStartStop;
   word  TachoOffset;
   float AvgSpeed;
   byte  CalibrationFlag;
   
   float BeltSpeed;
   float BeltLength;
   float BeltTravel;
   
   byte  RateDampEn;
   byte  MassDampEn;
   byte  TachoDampEn;
   
   word  AlarmFlag;
   
   word  PulseDelay;
   float PulseRate;
   float TotalCutoff;
   byte  PulseTotalEn; 
   
   byte  TotalizerReset;
   byte  TotalizerTest;

   byte LastCalTime[10];
   byte LastCalDate[14];   
   byte NextCalDate[14]; 
   
   float SpeedSim;
   float MassSim;  

   byte SpeedSimEn;
   byte MassSimEn;  
   
   byte Inputs;
   word InputDelay[4];
   byte InputPolartiy;
   byte InputFunction[4];
   
   byte Outputs;
   word OutputDelay[4];
   byte OutputFunction[4];
   
   float AnalogueIn[2];
   float AnalogueOut[2];
   
   float AnInSpan[2];
   float AnInZero[2];
   byte  AnInDamp[2];
   byte  AnInFunc[2];
   
   float BeltTension;
   byte  AnInType[2];
   
   float TensionHi;
   float TensionLo;   
   float TensionAverage;
   byte  TensionSpanEn;
   byte  TensionMassCaptureEn;
   float TensionMassCapture;
   byte  TensionCalFlg;
   byte  TensionCalEn;
   float TensionViewCal;
   float TensionFactor_K;
   float Tension_x_K;
   
   byte AdcSampleCnt;
   byte AdcAvgCnt;
   
   byte StdEn;
   byte SdFlag;
   word SdSampleRate;
   float RateSd;
   
   float ZeroShift;
   float SpanShift;
   
   float DigitTotal;   
   
   byte MovingAverageLCen;
   byte MovingAverageBTen;
   word MovingAverageLC;
   word MovingAverageBT;
   
   float CorrZero;
      
   float fFactorK;
   
   float fTesteT;
   
   byte ActionPERA;
   
   
   
}mbSlaveType;

/*
** ------------------------------------------------------------------------------
**		enum: modbus table enumerates 
** ------------------------------------------------------------------------------
*/

enum
{
   enVersion      =  0,
   enBtype        =  1,
   enSerNo        =  2,
   enTag          =  3,   
   enCompanyName  =  4,   

   
   enRate         =  5, 
   enRateDamp     =  6,  
   enAlrHi1       =  7,
   enAlrLo1       =  8,
   enUnits1       =  9,
   enRateDampEn   =  10,

   enTotal        =  11, 
   enAlrHi2       =  12,
   
   enAlrLo2       =  13,
   enUnits2       =  14,
   
   enMass         =  15,
   enMassDamp     =  16,
   enMassSpan     =  17,
   enMassZero     =  18,
   enAlrHi3       =  19,
   enAlrLo3       =  20,
   enUnits3       =  21,
   enMassDampEn   =  22,   
   enZeroShift    =  23,   
   enSpanShift    =  24,   
      
   enSpeed        =  25,   
   enSpeedDamp    =  26,
   enSpeedSpan    =  27,
   enSpeedZero    =  28,
   enAlrHi4       =  29,
   enAlrLo4       =  30,
   enUnits4       =  31,
   enTachoDampEn  =  32,
   
   enAnOut1       =  33,
   enAnHi1        =  34,
   enAnLo1        =  35,
   enAnFunc1      =  36,
   enAnAdjust1    =  37,
   
   enAnMode       =  38,

   enAnOut2       =  39,
   enAnHi2        =  40,
   enAnLo2        =  41,
   enAnFunc2      =  42,
   enAnAdjust2    =  43,


   enDigits       =  44,
   enDataUp       =  45,
   enEEClr        =  46,
   enPassWord     =  47,
   enOiLock       =  48,

   enPulseTotal   =  49,

   
   enId           =  50,
   enBusType      =  51,
   enIpAdr        =  52,
   enSubNet       =  53,
   enDHCP         =  54,
   enPbAdr        =  55,
   enEndian       =  56,
   enStationName  =  57,
   
   enAdStatus     =  58,
   enAdMode       =  59,
   enAdFilter     =  60,
   enAdDAC        =  61,
   enAdOffset     =  62,
   enAdGain       =  63,
   enAdData       =  64,
   enMassAvg      =  65,
   enMCalFlag     =  66,
   enMZeroCalStop =  67,
   enMSpanCalStop =  68,   
   enMassAdj      =  69,
   enMassOffset   =  70,
   enMassMv       =  71,
   
   enTime         =  72,
   enDate         =  73,
   
   
   enFreq         =  74,
   enTCalFlag     =  75,
   
   enZeroCalStop  =  76,
   enSpanCalStop  =  77,
   enBeltSpeed    =  78,
   enBeltLength   =  79,
   enAvgSpeed     =  80,
   enBeltTravel   =  81,
   
   enCalibrationFlag =  82,
   
   enAlarmFlag    =  83,
   
   enPulseDelay   =  84,
   enPulseRate    =  85,
   enPulseCutoff  =  86,
   enPulseTotalEn =  87,
   enTotalReset   =  88,
   enPulseTest    =  89,
   
   enLastCalDate  =  90,
   enLastCalTime  =  91,
   enNextCalDate  =  92, 
   
   enSpeedSim     =  93,
   enMassSim      =  94,            
   enSpeedSimEn   =  95,
   enMassSimEn    =  96,
   
   enInputs       =  97,
   
   enInDelay1     =  98,
   enInDelay2     =  99,
   enInDelay3     =  100,
   enInDelay4     =  101,
   
   enInPolarity   =  102,
   
   enInFunction1  =  103,
   enInFunction2  =  104,
   enInFunction3  =  105,
   enInFunction4  =  106,
   
   enOutputs      =  107,
   
   enOutDelay1    =  108,
   enOutDelay2    =  109,
   enOutDelay3    =  110,
   enOutDelay4    =  111,
   
   enOutFunction1 =  112,
   enOutFunction2 =  113,
   enOutFunction3 =  114,
   enOutFunction4 =  115,
   
   enAnIn1        =  116,
   enAnIn2        =  117,
   enAnInOut1     =  118,
   enAnInOut2     =  119,

   enAnInSpan1    =  120,
   enAnInSpan2    =  121,
   enAnInZero1    =  122,
   enAnInZero2    =  123,
   enAnInDamp1    =  124,
   enAnInDamp2    =  125,
   enAnInFunc1    =  126,
   enAnInFunc2    =  127,
   
   enBeltTension  =  128,
                       
   enAnInType1    =  129,
   enAnInType2    =  130,

   enTensionHi    =  131,
   enTensionLo    =  132,
   enTensionAvg   =  133,
   
   enTensionFlg   =  134,
   enTensionCal   =  135,
   enTensionCapture = 136,
   enTensionViewCapture = 137,
   enTensionFactor_K = 138,
   enTension_x_K =   139,
   
   enAppCapacity  =  140,

   enSampleCnt    =  141,
   enAvgCnt       =  142,
   
   enStdEn        =  143,
   enStdFlg       =  144,
   enStdRate      =  145,
   enStd          =  146,
   
   enFactork      =  147,
   enPrecision    =  148,
   enDigTotal     =  149, 
   
   enMovingAverageLCen = 150,   //Inserted by Souza
   enMovingAverageBTen = 151,   //Inserted by Souza
   
   enMovingAverageLC  = 152,     //Inserted by Souza
   enMovingAverageBT  = 153,     //Inserted by Souza
   enCorrZero   = 154,            //Inserted by Souza
   
   enActionPera = 155,
   
   //enAnInFunc3    = 155,        //Umidade
};


#ifndef MODBUSINT_C

/* public variables */
#pragma DATA_SEG MODBUSINT_Data

extern mbTabletype mbTable[];
extern const word mbTableSize;

extern mbSlaveType mbSlave;

#endif   /* MODBUSINT_C */ 


/* public functions */
#pragma CODE_SEG MODBUSINT_Code

/*
** ------------------------------------------------------------------------------
**		Function: void ModBusIntInit(void)
** ------------------------------------------------------------------------------
*/

void ModBusIntInit(void);

/*
** ------------------------------------------------------------------------------
**		Function: void mbIntSetRdFlags(void)
** ------------------------------------------------------------------------------
*/

void mbIntSetRdFlags(void);

/*
** ------------------------------------------------------------------------------
**		Function: void mbRdEditWindowProdCal(byte Index)   
** ------------------------------------------------------------------------------
*/

void mbRdEditWindowProdCal(byte Index);   

/*
** ------------------------------------------------------------------------------
**		void mbStartT3Timeout(word Baud)
** ------------------------------------------------------------------------------
*/

void mbStartT3Timeout(word Baud);
 
     
/*
** ------------------------------------------------------------------------------
**		interrupt void ECT1_Interrupt(void)
** ------------------------------------------------------------------------------
*/

#pragma CODE_SEG NON_BANKED

__interrupt void near ECT1_Interrupt(void);

/*
** ------------------------------------------------------------------------------
**		interrupt void ECT2_Interrupt(void)
** ------------------------------------------------------------------------------
*/
#pragma CODE_SEG NON_BANKED

__interrupt void near ECT2_Interrupt(void);


#endif   /* MODBUSINT_H */
