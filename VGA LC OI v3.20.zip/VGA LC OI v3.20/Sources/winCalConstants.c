#include <hidef.h>                           /* common defines and macros */
#include "derivative.h"                      /* derivative information */

/*
** ------------------------------------------------------------------------------
   
   File   : winCalConstants.c 
   Aurthor: 
   
   Description:  
   
   Version Log          Notes                                     Changes Made by                                        
   --------------       -----                                     ---------------
   14-10-10:            Created                                   Stuart


** ------------------------------------------------------------------------------
                                    
                                    Overview
                                            
** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

/* library headers */
#include "stdio.h"
#include "float.h"
#include "math.h"

/* Application headers */
#include "CRG 100110.h" 
#include "Subs.h"
#include "ModBusM Int.h"
#include "ModBusM.h"
#include "EEPROM.h"
#include "SLCD 260217.h"
#include "winMain.h"
#include "winKey.h"
#include "Language.h"
#include "winConfirm.h"
#include "SlcdSubs.h"


/* Implements this interface: */
#define WINCALCONSTANTS_C
#include "winCalConstants.h"

#pragma CODE_SEG WINCALCONSTANTS_CODE
#pragma DATA_SEG WINCALCONSTANTS_DATA


/* private */
static byte winCalConstantsState;
static byte winCalConstantsReturnWin;
static byte EEflag;
static byte OfflineCopy;
byte btCancelEn;
byte EnRunMemo;
byte PosMemory;


/*
** ------------------------------------------------------------------------------
**		Function: void winSendEEPROMCmd(void)
** ------------------------------------------------------------------------------
*/

void winSendEEPROMCmd(void)
{
   /* send eeclr command */
   mbTable[enEEClr].WrFlg = 1;   
   
   /* force mb table index to ee clear flag */
   mbTableIndex = enEEClr;
      
   /* refresh A1208 data */
   mbIntSetRdFlags();   
}                                                                                                

/*
** ------------------------------------------------------------------------------
**		Function: void winRestore(void)
** ------------------------------------------------------------------------------
*/

void winRestore(void)
{
   /* restore eeproms */
   mbSlave.eeClearFlg = 1;    
   /* send command */
   winSendEEPROMCmd();
}

/*
** ------------------------------------------------------------------------------
**		Function: void winBackup(void)
** ------------------------------------------------------------------------------
*/

void winBackup(void)
{
   /* backup eeproms */
   mbSlave.eeClearFlg = 2;    
   /* send command */
   winSendEEPROMCmd();
}

/*
** ------------------------------------------------------------------------------
**		Function: void winSetDefaults(void)
** ------------------------------------------------------------------------------
*/

void winSetDefaults(void)
{
   lButtonType Button;                     //Config of the slcd to creat a button.
  byte ButtonText1[20];
  byte Buf[50];
   
   /* Inserido por Souza */
   
   slcd_SetFont(16, 0);  
    
   /* set colours back */
   slcd_SetColour(LightBlue, White);    
   
   slcd_SendText("Selecione o dado desejado", 340, 100, 'T', LEFT_ALIGN);
   
   sprintf(Buf, "1) D: %s %s S:%.3f Z:%.3f", EEPROM.DateCall[0],EEPROM.TimeCall[0],EEPROM.SpanCal[0],EEPROM.ZeroCal[0]);
   slcd_SendText(&Buf, 340, 140, 'T', LEFT_ALIGN);

   sprintf(Buf, "2) D: %s %s S:%.3f Z:%.3f", EEPROM.DateCall[1], EEPROM.TimeCall[1],EEPROM.SpanCal[1],EEPROM.ZeroCal[1]);
   slcd_SendText(&Buf, 340, 200, 'T', LEFT_ALIGN);

   sprintf(Buf, "3) D: %s %s S:%.3f Z:%.3f", EEPROM.DateCall[2],EEPROM.TimeCall[2],EEPROM.SpanCal[2],EEPROM.ZeroCal[2]); 
   slcd_SendText(&Buf, 340, 260, 'T', LEFT_ALIGN);
         
   /* define hotspots (x, y, width, height) */
   slcd_MakeHotSpot(130, 340, 140, 100, 30);
   slcd_MakeHotSpot(131, 340, 200, 100, 30);
   slcd_MakeHotSpot(132, 340, 260, 100, 30);
  
  slcd_SetColour(White, White);
     
  Button.Id = 4;
  Button.x = 400;
  Button.y = 320;
  Button.type = 2;
  Button.state = btCancelEn;	
  strcpy(ButtonText1, "Cancelar");                                                                   
  Button.text0 = ButtonText1;
  Button.dx0 = 11;
  Button.dy0 = 3;
  Button.dx1 = 2;
  Button.dy1 = 3;
  Button.bmp0 = 5;
  Button.bmp1 = 4;

  slcd_MakeLatchingButton(&Button);
}


/*
** ------------------------------------------------------------------------------
**		Function: void winCalConstantsKeyHandler(byte key)
** ------------------------------------------------------------------------------
*/

void winCalConstantsKeyHandler(byte key)
{   
   switch (key)
   {
   case 1:
      /* display confirmation box */
      winCalConstantsState = WIN_CAL_CONSTANTS_CONFIRM;
      /* set pointer to msg box message */
      strcpy(MsgBoxData.TitleBarTxt, gstr(&str->Warning));
      
      /* set pointer to msg box message */
      MsgBoxData.MsgTxt = gstr(&str->AreYouSure); 
      /* load return function */
      MsgBoxData.fp = winRestore;
      
      EEflag = 1;
      break;
      
   case 2:
      /* display confirmation box */
      winCalConstantsState = WIN_CAL_CONSTANTS_CONFIRM;
      /* set pointer to msg box message */
      strcpy(MsgBoxData.TitleBarTxt, gstr(&str->Warning));

      /* set pointer to msg box message */
      MsgBoxData.MsgTxt = gstr(&str->AreYouSure); 
      /* load return function */
      MsgBoxData.fp = winBackup;
      
      EEflag = 2;
    break;

   case 3:
      btCancelEn = 0;
      EEflag = 2;
      winSetDefaults();
      //EEflag = 2;
      
      break;     
      
     case 4:     /* Cancelar carregar dados */
          btCancelEn = 0;
          EEflag = 0;
                                  
         /* move to update state */      
         winCalConstantsReturnWin = USER_WINDOW;
         winCalConstantsState = WIN_CAL_CONSTANTS_UNLOAD; 
           
        break;



   case 128:       /* EXIT */
      winCalConstantsReturnWin = USER_WINDOW;
      /* if an eeprom operation is taking place make them wait */
      if(!EEflag)
         /* shut down num key window handler */
         winCalConstantsState = WIN_CAL_CONSTANTS_LOADMEMO;  
         winCalConstantsReturnWin = MAIN_WINDOW;
      break; 
      
     case 130:
         PosMemory = 0;
         LoadDataMemory();

     break;
     
     case 131:
          PosMemory = 1;
          LoadDataMemory();
          
     break;
     
     case 132:
          PosMemory = 2;
          LoadDataMemory();
          
     break; 
   }
}

/*
** ------------------------------------------------------------------------------
**		Function: void LoadDataMemory(void)
** ------------------------------------------------------------------------------
*/
void LoadDataMemory(void)
{
     mbSlave.Span[2] = EEPROM.SpanCal[PosMemory];
     mbSlave.Zero[2] = EEPROM.ZeroCal[PosMemory];
     mbSlave.Span[3] = EEPROM.Speed[PosMemory];
     
     EEWR_Str((byte *)&EEPROM.MassCal[0].Date, mbSlave.Date, strlen(mbSlave.Date)); 
     EEWR_Str((byte *)&EEPROM.MassCal[0].Time, mbSlave.Time, strlen(mbSlave.Time)); 
     
     /* write to sensor */
     mbTable[enMassSpan].WrFlg = 1;  
     mbTable[enMassZero].WrFlg = 1; 
     mbTable[enSpeedSpan].WrFlg = 1;
     
     /* write to calibration flag */
     mbSlave.CalibrationFlag = mbSlave.CalibrationFlag|0x04;
     mbTable[enCalibrationFlag].WrFlg = 1;
   
     winCalConstantsReturnWin = MAIN_WINDOW;
     winCalConstantsState = WIN_CAL_CONSTANTS_LOADMEMO;  
}

/*
** ------------------------------------------------------------------------------
**		Function: void ReadCalConstantsParameters(void)
** ------------------------------------------------------------------------------
*/

void ReadCalConstantsParameters(void)
{


}


/*
** ------------------------------------------------------------------------------
**		Function: void UpdateCalConstants(void)
** ------------------------------------------------------------------------------
*/

void UpdateCalConstants(void)
{
   /* sensor is busy */
   if(EEflag && mbStatus == mbOFFLINE && !OfflineCopy)
   {
      OfflineCopy = 1;
      
      /* set colours back */
      slcd_SetColour(Red, White);         

      slcd_SetFont(16, 0);
      
      if(EEflag==1)
         /* Restoring */
         slcd_SendText(gstr(&str->Restoring), 330, 330, 0, LEFT_ALIGN);         
      else if(EEflag==2)
         /* Saving */
         slcd_SendText(gstr(&str->BackingUp), 330, 330, 0, LEFT_ALIGN);         
      else if(EEflag==3)
         /* Saving */
         slcd_SendText("Erasing", 330, 330, 0, LEFT_ALIGN);         
   }
   
   /* sensor has finished op */   
   if(EEflag && mbStatus == mbONLINE && OfflineCopy)
   {
      OfflineCopy = 0;

      /* clear title bar */
      //slcd_CmdQueue("xic 10 0 0 165 165 200 190");
      /* complete */
      slcd_SendText("               ", 330, 330, 0, LEFT_ALIGN);             
      slcd_SendText(gstr(&str->Complete), 330, 330, 0, LEFT_ALIGN);             
            
      winUpdate1 = 200;

      /* clear flag */      
      EEflag = 0;      
   }
   
   /* requested update */
   if (winUpdate1==1)
   {
      winUpdate1 = 0;
      /* clear title bar */
      //slcd_CmdQueue("xic 10 0 0 165 165 200 190");
      //DisplayText("                      ", 330, 330, 0);             
   }   
}

/*
** ------------------------------------------------------------------------------
**		Function: byte winCalConstantsHandler(void)
** ------------------------------------------------------------------------------
*/

byte winCalConstantsHandler(void)
{
   switch (winCalConstantsState)
   {
   case WIN_CAL_CONSTANTS_PREPAINT:
      /* get analog parameters from slave */
      ReadCalConstantsParameters();

      /* set delay for parameters to arrive from MCT  */
      winUpdate1 = 15;
            
      winCalConstantsState = WIN_CAL_CONSTANTS_PAINT;
      break;
      
   case WIN_CAL_CONSTANTS_PAINT:
      if(winUpdate1==1)
      {
         winUpdate1 = 0;

         slcd_SetColour(DarkGrey, DarkGrey);
         slcd_Send("z");

         slcd_Send("xc all");
         /* display menu screen */
         slcd_DisplayBmp(10, 0, 0);

         DisplayTitle("MS Instrumentos");

         slcd_SetFont(24, 0);
         slcd_SetColour(DarkGrey, White);
         slcd_SendText(gstr(&str->CalibrationConstants), 15, 60, 0, LEFT_ALIGN);

         /* define back hotspot */
         slcd_MakeHotSpot(128, 560, 10, 50, 50);

         /* display buttons */
         slcd_MakeButton(1, 1, 30,  120,  2, 3);
         slcd_MakeButton(3, 1, 30,  200,  2, 3);

         slcd_SetColour(DarkGrey, White);
         slcd_SetFont(16, 0);

         slcd_SendText(gstr(&str->Restore_Instrument),       115, 120, 0, LEFT_ALIGN);
         slcd_SendText(gstr(&str->Restore_Factory_Defaults), 115, 200, 0, LEFT_ALIGN);

         /* update parameters */
         winUpdate1 = 1;

         /* move to update state */
         winCalConstantsState = WIN_CAL_CONSTANTS_UPDATE;
      }
      return 0;

   case WIN_CAL_CONSTANTS_UPDATE:
      /* is there a key to process? */
      if (slcdKey)
      {
         /* call key handler */
         winCalConstantsKeyHandler(slcdKey);      
         /* now the key has been processed clear it */
         slcdKey = 0; 
      }

      UpdateCalConstants();

      /* has any data been remotely changed? */
      if(mbSlave.DataUpdate)
      {
         /* clear data update flag */
         mbSlave.DataUpdate = 0;
         mbTable[enDataUp].WrFlg = 1;   
         
         /* read analog parameters */
         ReadCalConstantsParameters();  
         
         /* set update timer */                   
         winUpdate1 = 100;
      }      
      //return 0;

  case WIN_CAL_CONSTANTS_NUMKEYPAD:
      /* see if key pad is returning */
      //if(winKeyPadHandler())
      //{
      //   /* move to update state */      
      //   winCalConstantsState = WIN_CAL_CONSTANTS_PREPAINT;       
      //}
      break;

 case WIN_CAL_CONSTANTS_ENTER_PASSWORD:
      /* see if key pad is returning */
      switch(winKeyPadHandler())
      {
      case 1:
         /* move to update state */      
         winCalConstantsState = WIN_CAL_CONSTANTS_PREPAINT;       
         break;

      case 2:
         /* move to update state */      
         winCalConstantsState = WIN_CAL_CONSTANTS_UNLOAD;       
         break;
      }
      break;
      
   case WIN_CAL_CONSTANTS_CONFIRM:
      /* see if confirmation win is returning */
      switch(winConfirmHandler()) 
      {
      case 1:
         /* move to update state */      
         winCalConstantsState = WIN_CAL_CONSTANTS_PREPAINT;      
         break;

      case 2:
         /* move to update state */      
         winCalConstantsState = WIN_CAL_CONSTANTS_PREPAINT;
         /* clear EE clr flag */
         EEflag = 0;                        
         break;
      }
      break; 
            
   case WIN_CAL_CONSTANTS_UNLOAD:
      /* do any necessary clearing up */
      winCalConstantsState = WIN_CAL_CONSTANTS_PREPAINT;  

      /* set return menu */
      winActiveWin = BASIC_CONFIG_WINDOW;

      /* return from key pad */
      return 1;
    case WIN_CAL_CONSTANTS_LOADMEMO:
       winCalConstantsState = WIN_CAL_CONSTANTS_PREPAINT; 
       winActiveWin =   winCalConstantsReturnWin;
        /* return from key pad */
        return 1;   
   }   
}



