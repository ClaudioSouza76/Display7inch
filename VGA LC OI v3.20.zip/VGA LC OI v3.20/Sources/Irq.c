#include <hidef.h>                           /* common defines and macros */
#include <mc9s12xd256.h>                    /* derivative information */

/*
** ------------------------------------------------------------------------------
   
   File   : Irq.c 
   Aurthor: 
   
   Description:  
   
   Version Log          Notes                                     Changes Made by                                        
   --------------       -----                                     ---------------
   29-08-08:            Created                                   Stuart Clarke
        
** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

/* library headers */


/* Application headers */
#include "main.h"
#include "Cmd.h"
#include "ModBusM Int.h"
#include "ModBusM.h"

#include "IRQ 100110.h"
#include "CRG 100110.h"
#include "PIT 100110.h"
#include "ECT 100114.h"

#include "SLCD 260217.h"

#include "winMain.h"


/* Implements this interface: */
#define IRQ_C
#include "Irq.h"

#pragma CODE_SEG IRQ_Code
#pragma DATA_SEG IRQ_Data


/* private */

/* public */


/* ISR prototype */
typedef void (*near tIsrFunc)(void);


/*
** ------------------------------------------------------------------------------
**		Function: void Irq_Init(void)
** ------------------------------------------------------------------------------
*/

void Irq_Init(void)
{
   /* shift the interrupt vectors */
   IVBR = 0xEF;
}


/*
** ------------------------------------------------------------------------------
**		Function: __interrupt void Cpu_Interrupt(void)
** ------------------------------------------------------------------------------
*/

#pragma CODE_SEG  NON_BANKED
__interrupt void near Cpu_Interrupt(void)
{


}

/*
** ------------------------------------------------------------------------------
**		Function: __interrupt void near ECT0_Interrupt(void)
** ------------------------------------------------------------------------------
*/

#pragma CODE_SEG NON_BANKED 
__interrupt void near ECT0_Interrupt(void)
{
	#pragma MESSAGE DISABLE C5919 /* conversion of floating to integral */
	TC0 += uS_to_TCR_8(10000);			
	TFLG1 = 0x01; 

   //PTP_PTP6 ^= 1;
   
   /* */
   if(SLCD.TimeOut)
      SLCD.TimeOut--;
   
   if(winSplashTimer)
      winSplashTimer--;   
   
   if(winTimer1)
      winTimer1--;
   
   if(winTimer2)
      winTimer2--;
   
   if(winTimer3)
      winTimer3--;
   
   if(winUpdate1>1)
      winUpdate1--;
   
   if(winUpdate2>1)
      winUpdate2--; 
   
   if(winRePaint>1)
      winRePaint--;
   
   if(CalTimer)
      CalTimer--;

      
   if(StartUpDelay)
      StartUpDelay--;   
}  
      
/*
** ------------------------------------------------------------------------------
**		                        Interrupt vector table
** ------------------------------------------------------------------------------
*/ 
                              
const tIsrFunc _InterruptVectorTable[] @ 0xEF10 = 
{ 
  /* ISR name                               No. Address Pri XGATE  Description */

  Cpu_Interrupt,                        /* 0x08  0xFF10   si         */
  Cpu_Interrupt,                        /* 0x09  0xFF12   ivReserved119 */
  Cpu_Interrupt,                        /* 0x0A  0xFF14   ivReserved118 */
  Cpu_Interrupt,                        /* 0x0B  0xFF16   ivReserved117 */
  Cpu_Interrupt,                        /* 0x0C  0xFF18   ivReserved116 */
  Cpu_Interrupt,                        /* 0x0D  0xFF1A   ivReserved115 */
  Cpu_Interrupt,                        /* 0x0E  0xFF1C   ivReserved114 */
  Cpu_Interrupt,                        /* 0x0F  0xFF1E   ivReserved113 */
  Cpu_Interrupt,                        /* 0x10  0xFF20   ivReserved112 */
  Cpu_Interrupt,                        /* 0x11  0xFF22   ivReserved111 */
  Cpu_Interrupt,                        /* 0x12  0xFF24   ivReserved110 */
  Cpu_Interrupt,                        /* 0x13  0xFF26   ivReserved109 */
  Cpu_Interrupt,                        /* 0x14  0xFF28   ivReserved108 */
  Cpu_Interrupt,                        /* 0x15  0xFF2A   ivReserved107 */
  Cpu_Interrupt,                        /* 0x16  0xFF2C   ivReserved106 */
  Cpu_Interrupt,                        /* 0x17  0xFF2E   ivReserved105 */
  Cpu_Interrupt,                        /* 0x18  0xFF30   ivReserved104 */
  Cpu_Interrupt,                        /* 0x19  0xFF32   ivReserved103 */
  Cpu_Interrupt,                        /* 0x1A  0xFF34   ivReserved102 */
  Cpu_Interrupt,                        /* 0x1B  0xFF36   ivReserved101 */
  Cpu_Interrupt,                        /* 0x1C  0xFF38   ivReserved100 */
  Cpu_Interrupt,                        /* 0x1D  0xFF3A   ivReserved99  */
  Cpu_Interrupt,                        /* 0x1E  0xFF3C   ivReserved98  */
  Cpu_Interrupt,                        /* 0x1F  0xFF3E   ivReserved97  */
  Cpu_Interrupt,                        /* 0x20  0xFF40   ivReserved96  */
  Cpu_Interrupt,                        /* 0x21  0xFF42   ivReserved95  */
  Cpu_Interrupt,                        /* 0x22  0xFF44   ivReserved94  */
  Cpu_Interrupt,                        /* 0x23  0xFF46   ivReserved93  */
  Cpu_Interrupt,                        /* 0x24  0xFF48   ivReserved92  */
  Cpu_Interrupt,                        /* 0x25  0xFF4A   ivReserved91  */
  Cpu_Interrupt,                        /* 0x26  0xFF4C   ivReserved90  */
  Cpu_Interrupt,                        /* 0x27  0xFF4E   ivReserved89  */
  Cpu_Interrupt,                        /* 0x28  0xFF50   ivReserved88  */
  Cpu_Interrupt,                        /* 0x29  0xFF52   ivReserved87  */
  Cpu_Interrupt,                        /* 0x2A  0xFF54   ivReserved86  */
  Cpu_Interrupt,                        /* 0x2B  0xFF56   ivReserved85  */
  Cpu_Interrupt,                        /* 0x2C  0xFF58   ivReserved84  */
  Cpu_Interrupt,                        /* 0x2D  0xFF5A   ivReserved83  */
  Cpu_Interrupt,                        /* 0x2E  0xFF5C   ivReserved82  */
  Cpu_Interrupt,                        /* 0x2F  0xFF5E   ivReserved81  */
  Cpu_Interrupt,                        /* 0x30  0xFF60   xsramav    */
  Cpu_Interrupt,                        /* 0x31  0xFF62   xsei       */
  Cpu_Interrupt,                        /* 0x32  0xFF64   xst7       */
  Cpu_Interrupt,                        /* 0x33  0xFF66   xst6       */
  Cpu_Interrupt,                        /* 0x34  0xFF68   xst5       */
  Cpu_Interrupt,                        /* 0x35  0xFF6A   xst4       */
  Cpu_Interrupt,                        /* 0x36  0xFF6C   xst3       */
  Cpu_Interrupt,                        /* 0x37  0xFF6E   xst2       */
  Cpu_Interrupt,                        /* 0x38  0xFF70   xst1       */
  Cpu_Interrupt,                        /* 0x39  0xFF72   xst0       */
  Cpu_Interrupt,                        /* 0x3A  0xFF74   pit3       */
  Cpu_Interrupt,                        /* 0x3B  0xFF76   pit2       */
  Cpu_Interrupt,                        /* 0x3C  0xFF78   pit1       */
  PIT_Interrupt,                        /* 0x3D  0xFF7A   pit0       */
  Cpu_Interrupt,                        /* 0x3E  0xFF7C   Reserved65 */
  Cpu_Interrupt,                        /* 0x3F  0xFF7E   api        */
  Cpu_Interrupt,                        /* 0x40  0xFF80   lvi        */
  Cpu_Interrupt,                        /* 0x41  0xFF82   Reserved62 */
  Cpu_Interrupt,                        /* 0x42  0xFF84   sci5       */
  Cpu_Interrupt,                        /* 0x43  0xFF86   sci4       */
  Cpu_Interrupt,                        /* 0x44  0xFF88   sci3       */
  ModBus_Interrupt,                     /* 0x45  0xFF8A   sci2       */
  Cpu_Interrupt,                        /* 0x46  0xFF8C   pwmesdn    */
  Cpu_Interrupt,                        /* 0x47  0xFF8E   portp      */
  Cpu_Interrupt,                        /* 0x48  0xFF90   can4tx     */
  Cpu_Interrupt,                        /* 0x49  0xFF92   can4rx     */
  Cpu_Interrupt,                        /* 0x4A  0xFF94   can4err    */
  Cpu_Interrupt,                        /* 0x4B  0xFF96   can4wkup   */
  Cpu_Interrupt,                        /* 0x4C  0xFF98   Reserved51 */
  Cpu_Interrupt,                        /* 0x4D  0xFF9A   Reserved50 */
  Cpu_Interrupt,                        /* 0x4E  0xFF9C   Reserved49 */
  Cpu_Interrupt,                        /* 0x4F  0xFF9E   Reserved48 */
  Cpu_Interrupt,                        /* 0x50  0xFFA0   Reserved47 */
  Cpu_Interrupt,                        /* 0x51  0xFFA2   Reserved46 */
  Cpu_Interrupt,                        /* 0x52  0xFFA4   Reserved45 */
  Cpu_Interrupt,                        /* 0x53  0xFFA6   Reserved44 */
  Cpu_Interrupt,                        /* 0x54  0xFFA8   can1tx     */
  Cpu_Interrupt,                        /* 0x55  0xFFAA   can1rx     */
  Cpu_Interrupt,                        /* 0x56  0xFFAC   can1err    */
  Cpu_Interrupt,                        /* 0x57  0xFFAE   can1wkup   */
  Cpu_Interrupt,                        /* 0x58  0xFFB0   can0tx     */
  Cpu_Interrupt,                        /* 0x59  0xFFB2   can0rx     */
  Cpu_Interrupt,                        /* 0x5A  0xFFB4   can0err    */
  Cpu_Interrupt,                        /* 0x5B  0xFFB6   can0wkup   */
  Cpu_Interrupt,                        /* 0x5C  0xFFB8   flash      */
  Cpu_Interrupt,                        /* 0x5D  0xFFBA   eeprom     */
  Cpu_Interrupt,                        /* 0x5E  0xFFBC   spi2       */
  Cpu_Interrupt,                        /* 0x5F  0xFFBE   spi1       */
  Cpu_Interrupt,                        /* 0x60  0xFFC0   iic0       */
  Cpu_Interrupt,                        /* 0x61  0xFFC2   Reserved30 */
  Cpu_Interrupt,                        /* 0x62  0xFFC4   crgscm     */
  Cpu_Interrupt,                        /* 0x63  0xFFC6   crgplllck  */
  Cpu_Interrupt,                        /* 0x64  0xFFC8   timpabovf  */
  Cpu_Interrupt,                        /* 0x65  0xFFCA   timmdcu    */
  Cpu_Interrupt,                        /* 0x66  0xFFCC   porth      */
  Cpu_Interrupt,                        /* 0x67  0xFFCE   portj      */
  Cpu_Interrupt,                        /* 0x68  0xFFD0   atd1       */
  Cpu_Interrupt,                        /* 0x69  0xFFD2   atd0       */
  SLCD_Interrupt,                       /* 0x6A  0xFFD4   sci1       */
  CMD_Interrupt,                        /* 0x6B  0xFFD6   sci0       */
  Cpu_Interrupt,                        /* 0x6C  0xFFD8   spi0       */
  Cpu_Interrupt,                        /* 0x6D  0xFFDA   timpaie    */
  Cpu_Interrupt,                        /* 0x6E  0xFFDC   timpaaovf  */
  Cpu_Interrupt,                        /* 0x6F  0xFFDE   timovf     */
  Cpu_Interrupt,                        /* 0x70  0xFFE0   timch7     */
  Cpu_Interrupt,                        /* 0x71  0xFFE2   timch6     */
  Cpu_Interrupt,                        /* 0x72  0xFFE4   timch5     */
  Cpu_Interrupt,                        /* 0x73  0xFFE6   timch4     */
  Cpu_Interrupt,                        /* 0x74  0xFFE8   timch3     */
  ECT2_Interrupt,                       /* 0x75  0xFFEA   timch2     */
  ECT1_Interrupt,                       /* 0x76  0xFFEC   timch1     */  
  ECT0_Interrupt,                       /* 0x77  0xFFEE   timch0     */
  RTI_Interrupt,                        /* 0x78  0xFFF0   rti        */
  IRQ_Interrupt,                        /* 0x79  0xFFF2   irq        */
  Cpu_Interrupt,                        /* 0x7A  0xFFF4   xirq       */
  Cpu_Interrupt,                        /* 0x7B  0xFFF6   swi        */
  Cpu_Interrupt                         /* 0x7C  0xFFF8   trap       */
};





                              
