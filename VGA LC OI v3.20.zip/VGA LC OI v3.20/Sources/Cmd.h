/* Cmd.h interface */
/*
** ------------------------------------------------------------------------------
   
   File   : Cmd.h 
   Aurthor: Stuart Clarke
        
** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2007 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp.
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
   
** ------------------------------------------------------------------------------
*/

#ifndef CMD_H
#define CMD_H

/*
** ------------------------------------------------------------------------------
**		Define: Error codes for RS232
** ------------------------------------------------------------------------------
*/

#define ACK          0
#define SYNTAX_ERR	1
#define DATA_ERR		2
#define SLEEP			1

/*
** ------------------------------------------------------------------------------
**		Define: Buffer size
** ------------------------------------------------------------------------------
*/

#define RXBUF_SZ      50
#define TXBUF_SZ      50


/*
** ------------------------------------------------------------------------------
**		DataType: CmdTabType
** ------------------------------------------------------------------------------
*/

typedef struct
{
   char *txt;
   byte con;
}CmdTabType;

/*
** ------------------------------------------------------------------------------
**		DataType: CmdType
** ------------------------------------------------------------------------------
*/

typedef struct
{
   char RxBuf[RXBUF_SZ]; 
   char *RxPtr;
     
   char TxBuf[TXBUF_SZ];   
   char *TxPtr;
   
   byte In;
   byte Init;
   byte Busy;
}CmdType;

#ifndef CMD_C

/*
** ------------------------------------------------------------------------------
**		Variables
** ------------------------------------------------------------------------------
*/

/* public variables */
#pragma DATA_SEG CMD_Data

extern byte  *RxDataPtr;
extern byte  *RxBufPtr;
extern byte  *TxBufPtr;





#endif   /* CMD_C */ 

/* public functions */
#pragma CODE_SEG CMD_Code

/*
** ------------------------------------------------------------------------------
**		Function: void CmdInit(word SCIRegPtr)
** ------------------------------------------------------------------------------
*/

void CmdInit(word SCIRegPtr);

/*
** ------------------------------------------------------------------------------
**		Function: void CmdTx(void)
** ------------------------------------------------------------------------------
*/

void CmdTx(void);

/*
** ------------------------------------------------------------------------------
**		Function: void CmdTx(byte *Ptr)
** ------------------------------------------------------------------------------
*/

void CmdSend(byte *Ptr);

/*
** ------------------------------------------------------------------------------
**		Function: void Reply(Resp)
** ------------------------------------------------------------------------------
*/

void Reply(byte Resp);

/*
** ------------------------------------------------------------------------------
**		Function: byte CmdMatch(txtplus1 *blk)
** ------------------------------------------------------------------------------
*/

byte CmdMatch(CmdTabType *blk);

/*
** ------------------------------------------------------------------------------
**		Function: void CheckCmdInput(void)
** ------------------------------------------------------------------------------
*/

void CheckCmdInput(void);

/*
** ------------------------------------------------------------------------------
**		Function: __interrupt void near CMD_Interrupt(void)
** ------------------------------------------------------------------------------
*/

#pragma CODE_SEG NON_BANKED 
__interrupt void near CMD_Interrupt(void);
#pragma CODE_SEG DEFAULT
     
#endif   /* CMD_H */


