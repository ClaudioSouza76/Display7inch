#include <hidef.h>                           /* common defines and macros */
#include "derivative.h"                      /* derivative information */

/*
** ------------------------------------------------------------------------------
   
   File   : winAnalogueIn.c 
   Aurthor: 
   
   Description:  
   
   Version Log          Notes                                     Changes Made by                                        
   --------------       -----                                     ---------------
   08-10-11:            Created                                   Stuart


** ------------------------------------------------------------------------------
                                    
                                    Overview
                                            
** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

/* library headers */
#include "stdio.h"
#include "float.h"
#include "math.h"

/* Application headers */
#include "CRG 100110.h" 
#include "Subs.h"
#include "ModBusM Int.h"
#include "ModBusM.h"
#include "EEPROM.h"
#include "SLCD 260217.h"
#include "winMain.h"
#include "winKey.h"
#include "Language.h"
#include "SlcdSubs.h"

/* Implements this interface: */
#define WINANALOGUEIN_C
#include "winAnalogueIn.h"

#pragma CODE_SEG WINANALOGUEIN_CODE
#pragma DATA_SEG WINANALOGUEIN_DATA


/* private */
static byte winAnalogueInState;
static byte AnalogInIndex;



/* public */
byte winAnalogueInReturnWin;

/* Analogue Inputs screen layout (640x480 logical, scaled by slcd_SendText) */
#define AIN_Y_OFF       40    /* page title now at y=60 (was y=7) */
#define AIN_CHANNEL_Y   (89  + AIN_Y_OFF)
#define AIN_BTN_Y       (89  + AIN_Y_OFF)
#define AIN_ROW1_Y      180   /* first data row below channel selector */
#define AIN_ROW_DY      36    /* standard row spacing */
#define AIN_ROW(n)      (AIN_ROW1_Y + (((n) - 1) * AIN_ROW_DY))
#define AIN_LBL_L_X     28
#define AIN_LBL_R_X     330
#define AIN_VAL_L_X     230
#define AIN_VAL_R_X     540
#define AIN_HS_W_L      78
#define AIN_HS_W_R      80
#define AIN_HS_H        40

/*
** ------------------------------------------------------------------------------
**		Function: DisplayAnalogueInFunction(void)
** ------------------------------------------------------------------------------
*/

void DisplayAnalogueInFunction(void)
{   
   /* set colours back */
   slcd_SetColour(LightBlue, White);       
   if(PanelSize == PSZ_1024_600)
      slcd_SetFont(14, 0);
   else
      slcd_SetFont(16, 'B'); 
   
   /* clear previous string */
   slcd_SendText("            ", AIN_VAL_R_X, AIN_ROW(3), 0, LEFT_ALIGN);      
   
   switch (mbSlave.AnInFunc[AnalogInIndex])
   {
   default:
   case 0:
      /* function delay */   
      slcd_SendText("NA", AIN_VAL_R_X, AIN_ROW(3), 0, LEFT_ALIGN);      
      break;

   case 1:
      /* Belt Tension */   
      slcd_SendText(gstr(&str->Tension), AIN_VAL_R_X, AIN_ROW(3), 0, LEFT_ALIGN);      
      break;

   case 2:
      /* Inclinometer  */   
      slcd_SendText("Inclin", AIN_VAL_R_X, AIN_ROW(3), 0, LEFT_ALIGN);      
      break;
    
   case 3:
      /* Umidade  */
      slcd_SendText("Umidade", AIN_VAL_R_X, AIN_ROW(3), 0, LEFT_ALIGN);
      break;
   }
}

/*
** ------------------------------------------------------------------------------
**		Function: DisplayAnalogueInType(void)
** ------------------------------------------------------------------------------
*/

void DisplayAnalogueInType(void)
{   
   /* set colours back */
   slcd_SetColour(LightBlue, White);       
   if(PanelSize == PSZ_1024_600)
      slcd_SetFont(14, 0);
   else
      slcd_SetFont(16, 'B'); 
   
   /* clear previous string */
   slcd_SendText("            ", AIN_VAL_L_X, AIN_ROW(4), 0, LEFT_ALIGN);      
   
   switch (mbSlave.AnInType[AnalogInIndex])
   {
   default:
   case 0:
      /* function delay */   
      slcd_SendText("4-20mA", AIN_VAL_L_X, AIN_ROW(4), 0, LEFT_ALIGN);      
      break;

   case 1:
      /* Belt Tension */   
      slcd_SendText("0-10v", AIN_VAL_L_X, AIN_ROW(4), 0, LEFT_ALIGN);      
      break;
      
   case 2:
      /* Belt Tension */   
      slcd_SendText("0-5v", AIN_VAL_L_X, AIN_ROW(4), 0, LEFT_ALIGN);      
      break;      
   }
}

/*
** ------------------------------------------------------------------------------
**		Function: void winAnalogueInKeyHandler(byte key)
** ------------------------------------------------------------------------------
*/

void winAnalogueInKeyHandler(byte key)
{   
   byte Buf[30];
   
   switch (key)
   {
   case 128:       /* EXIT */
      winAnalogueInReturnWin = USER_WINDOW;
      /* shut down num key window handler */
      winAnalogueInState = WIN_ANALOGUE_IN_UNLOAD;  
      break;  
      
   case 1:
     
      /* increment analogue select register */      
      if(++AnalogInIndex>1)
         AnalogInIndex = 0;
      
      /* set font */
      slcd_SetFont(24, 'B');  
      
      /* set colours back */
      slcd_SetColour(DarkGrey, White);  
      
      /* display selected analog channel */
      sprintf(Buf, "%s %u ", gstr(&str->Analog), AnalogInIndex+1);
      slcd_SendText(Buf, 107, AIN_CHANNEL_Y, 0, LEFT_ALIGN); 

      //slcd_CmdQueue("xic 2 0 0 405 230 460 255");  
      
      /* update analogue parameters */
      ReadAnalogueInParameters();
      /* update parameters */
      winUpdate1 = 100;
      break;  
      
  case 130:      /* AnIn Span hotspot */
      /* move to key pad handler sate */
      winAnalogueInState = WIN_ANALOGUE_IN_NUMKEYPAD; 
      
      /* copy parameter data to key structure */
      strcpy(NumKeyData.Name, gstr(&str->Span) );  
      NumKeyData.KeyBoardType = NUMBER;
      NumKeyData.Type = FLOAT;
      NumKeyData.fMax = 1000.0;
      NumKeyData.fMin = 0.0;
      NumKeyData.Index = 0;
     
      if(!AnalogInIndex)
         NumKeyData.Flag  = enAnInSpan1;
      else if(AnalogInIndex==1) 
         NumKeyData.Flag  = enAnInSpan2;
      
      NumKeyData.DataPtr = (void *)&mbSlave.AnInSpan[AnalogInIndex];
      break;      

  case 131:      /* AnIn Zero hotspot */
      /* move to key pad handler sate */
      winAnalogueInState = WIN_ANALOGUE_IN_NUMKEYPAD; 
      
      /* copy parameter data to key structure */
      strcpy(NumKeyData.Name, gstr(&str->Zero) );  
      NumKeyData.KeyBoardType = NUMBER;
      NumKeyData.Type = FLOAT;
      NumKeyData.fMax = 1000.0;
      NumKeyData.fMin = -1000.0;
      NumKeyData.Index = 0;
     
      if(!AnalogInIndex)
         NumKeyData.Flag  = enAnInZero1;
      else if(AnalogInIndex==1) 
         NumKeyData.Flag  = enAnInZero2;
      
      NumKeyData.DataPtr = (void *)&mbSlave.AnInZero[AnalogInIndex];
      break;      

  case 132:      /* AnIn Damp hotspot */
      /* move to key pad handler sate */
      winAnalogueInState = WIN_ANALOGUE_IN_NUMKEYPAD; 
      
      /* copy parameter data to key structure */
      strcpy(NumKeyData.Name, gstr(&str->Damp) );  
      NumKeyData.KeyBoardType = NUMBER;
      NumKeyData.Type = BYTE;
      NumKeyData.iMax = 100.0;
      NumKeyData.iMin = 0.0;
      NumKeyData.Index = 0;
     
      if(!AnalogInIndex)
         NumKeyData.Flag  = enAnInDamp1;
      else if(AnalogInIndex==1) 
         NumKeyData.Flag  = enAnInDamp2;
      
      NumKeyData.DataPtr = (void *)&mbSlave.AnInDamp[AnalogInIndex];
      break;      

  case 133:      /* AnInType */
      /* switch to next function */
      if(mbSlave.AnInType[AnalogInIndex]<2)
         mbSlave.AnInType[AnalogInIndex]++;
      else
         mbSlave.AnInType[AnalogInIndex] = 0;
      
      /* */
      switch (AnalogInIndex)
      {
      case 0:
         mbTable[enAnInType1].WrFlg = 0x1; 
         break;

      case 1:
         mbTable[enAnInType2].WrFlg = 0x1; 
         break;
      }
      
      DisplayAnalogueInType();
      break; 
      
  case 134:      /* ADC input sample count */
      /* move to key pad handler sate */
      winAnalogueInState = WIN_ANALOGUE_IN_NUMKEYPAD; 
      
      /* copy parameter data to key structure */
      strcpy(NumKeyData.Name, gstr(&str->SampleCount) );  
      NumKeyData.KeyBoardType = NUMBER;
      NumKeyData.Type = BYTE;
      NumKeyData.iMax = 16;
      NumKeyData.iMin = 1;
      NumKeyData.Index = 0;
      NumKeyData.Flag  = enSampleCnt;

      NumKeyData.DataPtr = (void *)&mbSlave.AdcSampleCnt;
      break; 
            
  case 135:      /* Allocation */
      /* switch to next function */
      if(mbSlave.AnInFunc[AnalogInIndex]<3)
         mbSlave.AnInFunc[AnalogInIndex]++;
      else
         mbSlave.AnInFunc[AnalogInIndex] = 0;
      
      /* */
      switch (AnalogInIndex)
      {
      case 0:
         mbTable[enAnInFunc1].WrFlg = 0x1; 
         break;

      case 1:
         mbTable[enAnInFunc2].WrFlg = 0x1; 
         break;
               
      case 2:
        //mbTable[enAnInFunc3].WrFlg = 0x1;
        break;
      }
      
      DisplayAnalogueInFunction();
      break; 
      
  case 136:      /* ADC input average count */
      /* move to key pad handler sate */
      winAnalogueInState = WIN_ANALOGUE_IN_NUMKEYPAD; 
      
      /* copy parameter data to key structure */
      strcpy(NumKeyData.Name, gstr(&str->AverageCount) );  
      NumKeyData.KeyBoardType = NUMBER;
      NumKeyData.Type = BYTE;
      NumKeyData.iMax = 16;
      NumKeyData.iMin = 1;
      NumKeyData.Index = 0;
      NumKeyData.Flag  = enAvgCnt;

      NumKeyData.DataPtr = (void *)&mbSlave.AdcAvgCnt;
      break;                                   
   }
}


/*
** ------------------------------------------------------------------------------
**		Function: void ReadAnalogueInParameters(void)
** ------------------------------------------------------------------------------
*/

void ReadAnalogueInParameters(void)
{
   switch(AnalogInIndex)
   {
   case 0:
      mbTable[enAnInSpan1].RdFlg = 0x1;
      mbTable[enAnInZero1].RdFlg = 0x1;
      mbTable[enAnInDamp1].RdFlg = 0x1;
      mbTable[enAnIn1].RdFlg     = 0x1;
      mbTable[enAnInOut1].RdFlg  = 0x1;
      mbTable[enAnInFunc1].RdFlg = 0x1;
      mbTable[enAnInType1].RdFlg = 0x1;
      break;

   case 1:
      mbTable[enAnInSpan2].RdFlg = 0x1;
      mbTable[enAnInZero2].RdFlg = 0x1;
      mbTable[enAnInDamp2].RdFlg = 0x1;
      mbTable[enAnIn2].RdFlg     = 0x1;
      mbTable[enAnInOut2].RdFlg  = 0x1;
      mbTable[enAnInFunc2].RdFlg = 0x1;
      mbTable[enAnInType2].RdFlg = 0x1;
      break;
   }   
   
   mbTable[enSampleCnt].RdFlg = 0x1;
   mbTable[enAvgCnt].RdFlg = 0x1;
}


/*
** ------------------------------------------------------------------------------
**		Function: void UpdateAnalogueIn(void)
** ------------------------------------------------------------------------------
*/

void UpdateAnalogueIn(void)
{
   byte Buf[25];
   
   /* requested update */
   if (winUpdate1==1)
   {
      /* stop counter */
      winUpdate1 = 0;

      if(PanelSize == PSZ_1024_600)
         slcd_SetFont(14, 0);
      else
         slcd_SetFont(16, 'B');  
 
      
      /* set colours back */
      slcd_SetColour(LightBlue, White);         
         
      sprintf(Buf, "%.2f  ", mbSlave.AnInSpan[AnalogInIndex]);  
      Buf[7] = 0;
      slcd_SendText(Buf, AIN_VAL_L_X, AIN_ROW(1), 0, LEFT_ALIGN);  
      
      sprintf(Buf, "%.2f  ", mbSlave.AnInZero[AnalogInIndex]);  
      Buf[7] = 0;
      slcd_SendText(Buf, AIN_VAL_L_X, AIN_ROW(2), 0, LEFT_ALIGN);  

      sprintf(Buf, "%u  ", mbSlave.AnInDamp[AnalogInIndex]);  
      Buf[7] = 0;
      slcd_SendText(Buf, AIN_VAL_L_X, AIN_ROW(3), 0, LEFT_ALIGN);  

      DisplayAnalogueInFunction();
      
      sprintf(Buf, "%u  ", mbSlave.AdcSampleCnt);  
      Buf[7] = 0;
      slcd_SendText(Buf, AIN_VAL_L_X, AIN_ROW(5), 0, LEFT_ALIGN);       
      
      DisplayAnalogueInType();

      sprintf(Buf, "%u  ", mbSlave.AdcAvgCnt);  
      Buf[7] = 0;
      slcd_SendText(Buf, AIN_VAL_R_X, AIN_ROW(5), 0, LEFT_ALIGN);       

   }

   /* time to update? */
   if (!winTimer1)
   {
      winTimer1 = 25;

      if(PanelSize == PSZ_1024_600)
         slcd_SetFont(14, 0);
      else
         slcd_SetFont(16, 'B');  
 
      
      /* set colours back */
      slcd_SetColour(DarkGrey, White);         
      sprintf(Buf, "%.2f  ", mbSlave.AnalogueIn[AnalogInIndex]);  
      Buf[7] = 0;
      slcd_SendText(Buf, AIN_VAL_R_X, AIN_ROW(1), 0, LEFT_ALIGN);  

      sprintf(Buf, "%.2f  ", mbSlave.AnalogueOut[AnalogInIndex]);  
      Buf[7] = 0;
      slcd_SendText(Buf, AIN_VAL_R_X, AIN_ROW(2), 0, LEFT_ALIGN);  

      switch(AnalogInIndex)
      {
      case 0:
         mbTable[enAnIn1].RdFlg = 0x1;
         mbTable[enAnInOut1].RdFlg = 0x1;
         break;

      case 1:
         mbTable[enAnIn2].RdFlg = 0x1;
         mbTable[enAnInOut2].RdFlg = 0x1;
         break;
      }
   }
}

/*
** ------------------------------------------------------------------------------
**		Function: void PaintAnalogueIn(void)
** ------------------------------------------------------------------------------
*/

void PaintAnalogueIn(void)
{
   byte Buf[25];
      
   slcd_SetFont(24, 'B');  
   
   /* set colours back */
   slcd_SetColour(DarkGrey, White);         
   
   /* display selected analog channel */
   sprintf(Buf, "%s %u", gstr(&str->Analog), AnalogInIndex+1);
   slcd_SendText(Buf, 107, AIN_CHANNEL_Y, 0, LEFT_ALIGN);  
   
   /* make analog select button */      
   slcd_MakeButton(1, 1, 27, AIN_BTN_Y, 22, 21);

   if(PanelSize == PSZ_1024_600)
      slcd_SetFont(14, 0);
   else
      slcd_SetFont(16, 'B');  
  
   
   /* set colours back */
   slcd_SetColour(DarkGrey, White);         

   /* display headings */
   slcd_SendText(gstr(&str->Span),         AIN_LBL_L_X, AIN_ROW(1), 'T', LEFT_ALIGN);  
   slcd_SendText(gstr(&str->Zero),         AIN_LBL_L_X, AIN_ROW(2), 'T', LEFT_ALIGN);  
   slcd_SendText(gstr(&str->Damp),         AIN_LBL_L_X, AIN_ROW(3), 'T', LEFT_ALIGN);     
   slcd_SendText(gstr(&str->InputType),    AIN_LBL_L_X, AIN_ROW(4), 'T', LEFT_ALIGN); 
   slcd_SendText(gstr(&str->SampleCount),  AIN_LBL_L_X, AIN_ROW(5), 'T', LEFT_ALIGN); 
   
   slcd_SendText(gstr(&str->Input),           AIN_LBL_R_X, AIN_ROW(1), 'T', LEFT_ALIGN);  
   slcd_SendText(gstr(&str->Output),          AIN_LBL_R_X, AIN_ROW(2), 'T', LEFT_ALIGN);         
   slcd_SendText(gstr(&str->Function),        AIN_LBL_R_X, AIN_ROW(3), 'T', LEFT_ALIGN);         
   slcd_SendText(gstr(&str->AverageCount),    AIN_LBL_R_X, AIN_ROW(5), 'T', LEFT_ALIGN);         

   /* define hotspots (x, y, width, height) */
   slcd_MakeHotSpot(130, 228, AIN_ROW(1), AIN_HS_W_L, AIN_HS_H);
   slcd_MakeHotSpot(131, 228, AIN_ROW(2), AIN_HS_W_L, AIN_HS_H);
   slcd_MakeHotSpot(132, 228, AIN_ROW(3), AIN_HS_W_L, AIN_HS_H);
   slcd_MakeHotSpot(133, 228, AIN_ROW(4), AIN_HS_W_L, AIN_HS_H);
   slcd_MakeHotSpot(134, 228, AIN_ROW(5), AIN_HS_W_L, AIN_HS_H);
   slcd_MakeHotSpot(135, 490, AIN_ROW(3), AIN_HS_W_R, AIN_HS_H);   
   slcd_MakeHotSpot(136, 490, AIN_ROW(5), AIN_HS_W_R, AIN_HS_H);   

   /* force update */
   winUpdate1 = 1;
}

/*
** ------------------------------------------------------------------------------
**		Function: byte winAnalogueInHandler(void)
** ------------------------------------------------------------------------------
*/

byte winAnalogueInHandler(void)
{
   switch (winAnalogueInState)
   {
   case WIN_ANALOGUE_IN_PREPAINT:
      /* get analog parameters from slave */
      ReadAnalogueInParameters();

      /* set delay for parameters to arrive from MCT  */
      winUpdate1 = 15;
      
      AnalogInIndex = 0;
            
      winAnalogueInState = WIN_ANALOGUE_IN_PAINT;
      break;
      
   case WIN_ANALOGUE_IN_PAINT:
      if(winUpdate1==1)
      {
         winUpdate1 = 0;

         slcd_SetColour(DarkGrey, DarkGrey);
         slcd_Send("z");
         slcd_Send("xc all");
         slcd_DisplayBmp(10, 0, 0);

         DisplayTitle("MS Instrumentos");

         slcd_SetFont(24, 0);
         slcd_SetColour(DarkGrey, White);

         /* display page title  */
         slcd_SendText(gstr(&str->AnalogueInputs), 15, 60, 0, LEFT_ALIGN);

         /* define back hotspot */
         slcd_MakeHotSpot(128, 560, 10, 50, 50);

         PaintAnalogueIn();
      
         /* update parameters */
         winUpdate1 = 1;
      
         /* move to update state */      
         winAnalogueInState = WIN_ANALOGUE_IN_UPDATE;       
      }
      break;

   
   case WIN_ANALOGUE_IN_UPDATE:
      /* is there a key to process? */
      if (slcdKey)
      {
         /* call key handler */
         winAnalogueInKeyHandler(slcdKey);      
         /* now the key has been processed clear it */
         slcdKey = 0; 
      }

      UpdateAnalogueIn();

      /* has any data been remotely changed? */
      if(mbSlave.DataUpdate)
      {
         /* clear data update flag */
         mbSlave.DataUpdate = 0;
         mbTable[enDataUp].WrFlg = 1;   
         
         /* read analog parameters */
         ReadAnalogueInParameters();  
         
         /* set update timer */                   
         winUpdate1 = 100;
      }      
      return 0;

  case WIN_ANALOGUE_IN_NUMKEYPAD:
      /* see if key pad is returning */
      if(winKeyPadHandler())
      {
         /* move to update state */      
         winAnalogueInState = WIN_ANALOGUE_IN_PAINT; 
         
         winUpdate1 = 1;
      }
      break;
            
   case WIN_ANALOGUE_IN_UNLOAD:
      /* do any necessary clearing up */
      winAnalogueInState = WIN_ANALOGUE_IN_PREPAINT;  

      /* set return menu */
      winActiveWin = INPUTSOUTPUTS_WINDOW;

      /* return from key pad */
      return 1;
   }   
}



