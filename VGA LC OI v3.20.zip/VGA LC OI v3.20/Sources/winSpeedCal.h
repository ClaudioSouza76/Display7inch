/*
** ------------------------------------------------------------------------------
   
   File   : winSpeedCal.h 
   Aurthor: Stuart Clarke

** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

#ifndef WINSPEEDCAL_H
#define WINSPEEDCAL_H


/* public defines */


/*
** ------------------------------------------------------------------------------
**		#define : diagnostics handler states 
** ------------------------------------------------------------------------------
*/

#define WIN_SPEEDCAL_PREPAINT     0
#define WIN_SPEEDCAL_PAINT        1
#define WIN_SPEEDCAL_UPDATE       2
#define WIN_SPEEDCAL_NUMKEYPAD    3
#define WIN_SPEEDCAL_UNLOAD       4




#ifndef WIN_SPEEDCAL_C

/* public variables */
#pragma DATA_SEG WINSPEEDCAL_Data


#endif   /* WINSPEEDCAL_C */      


/* public functions */
#pragma CODE_SEG WINSPEEDCAL_Code

/*
** ------------------------------------------------------------------------------
**		Function: void ReadSpeedCalParameters(void)
** ------------------------------------------------------------------------------
*/

void ReadSpeedCalParameters(void);

/*
** ------------------------------------------------------------------------------
**		Function: void scDisplayFrequency(void)
** ------------------------------------------------------------------------------
*/

void scDisplayFrequency(void);

/*
** ------------------------------------------------------------------------------
**		Function: void scDisplaySpeed(void)
** ------------------------------------------------------------------------------
*/

void scDisplaySpeed(void);

/*
** ------------------------------------------------------------------------------
**		Function: void scDisplayCalError(void)
** ------------------------------------------------------------------------------
*/

void scDisplayCalError(void);

/*
** ------------------------------------------------------------------------------
**		Function: void scDisplayCalDate(void)
** ------------------------------------------------------------------------------
*/

void scDisplayCalDate(void);

/*
** ------------------------------------------------------------------------------
**		Function: void scDisplayCalSpeed(void)
** ------------------------------------------------------------------------------
*/

void scDisplayCalSpeed(void);

/*
** ------------------------------------------------------------------------------
**		Function: byte winSpeedCalHandler(void)
** ------------------------------------------------------------------------------
*/

byte winSpeedCalHandler(void);

#endif   /* WINSPEEDCAL_H */
