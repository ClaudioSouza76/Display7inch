/*
** ------------------------------------------------------------------------------
   
   File   : winBasicConfig.h 
   Aurthor: Stuart Clarke

** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

#ifndef WINCALCONSTANTS_H
#define WINCALCONSTANTS_H


/* public defines */

/*
** ------------------------------------------------------------------------------
**		#define : user menu handler states 
** ------------------------------------------------------------------------------
*/

#define WIN_CAL_CONSTANTS_PREPAINT     0
#define WIN_CAL_CONSTANTS_PAINT        1
#define WIN_CAL_CONSTANTS_UPDATE       2
#define WIN_CAL_CONSTANTS_NUMKEYPAD    3
#define WIN_CAL_CONSTANTS_UNLOAD       4
#define WIN_CAL_CONSTANTS_ENTER_PASSWORD 5
#define WIN_CAL_CONSTANTS_CONFIRM      6
#define WIN_CAL_CONSTANTS_LOADMEMO     7


#ifndef WINCALCONSTANTS_C

/* public variables */
#pragma DATA_SEG WINCALCONSTANTS_DATA

extern byte winCalConstantsReturnWin;

#endif   /* WINCALCONSTANTS_C */      


/* public functions */
#pragma CODE_SEG WINCALCONSTANTS_CODE


/*
** ------------------------------------------------------------------------------
**		Function: void ReadCalConstantsParameters(void)
** ------------------------------------------------------------------------------
*/

void ReadCalConstantsParameters(void);

/*
** ------------------------------------------------------------------------------
**		Function: byte winCalConstantsHandler(void)
** ------------------------------------------------------------------------------
*/

byte winCalConstantsHandler(void);


void LoadDataMemory(void);

#endif   /* WINCALCONSTANTS_H */
