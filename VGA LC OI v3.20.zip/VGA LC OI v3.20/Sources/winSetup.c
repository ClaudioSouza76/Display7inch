#include <hidef.h>                           /* common defines and macros */
#include "derivative.h"                      /* derivative information */

/*
** ------------------------------------------------------------------------------
   
   File   : winSetup.c 
   Aurthor: 
   
   Description:  
   
   Version Log          Notes                                     Changes Made by                                        
   --------------       -----                                     ---------------
   10-11-08:            Created                                   Stuart


** ------------------------------------------------------------------------------
                                    
                                    Overview
                                            
** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

/* library headers */
#include "string.h"

/* Application headers */
#include "SLCD 260217.h"
#include "winMain.h"
#include "winKey.h"
#include "Language.h"
#include "ModBusM Int.h"
#include "EEPROM.h"
#include "SlcdSubs.h"

/* Implements this interface: */
#define WINSETUP_C
#include "winSetup.h"

#pragma CODE_SEG WINSETUP_Code
#pragma DATA_SEG WINSETUP_Data


/* private */
static byte winSetupState;
static byte winReturnWin;

/* public */

/*
** ------------------------------------------------------------------------------
**		Function: void winMenuKeyHandler(byte key)
** ------------------------------------------------------------------------------
*/

void winMenuKeyHandler(byte key)
{
   switch (key)
   {
   case 1:      /* Full Calibration */     
      /* switch to menu screen */
      //winReturnWin = RANGES_WINDOW;
      /* shut down main window handler */
      //winSetupState = WIN_SETUP_UNLOAD;     
      break;
      
   case 3:      /* Speed Cal */     
      /* switch to menu screen */
      winReturnWin = SPEEDCAL_WINDOW;
      /* shut down main window handler */
      winSetupState = WIN_SETUP_UNLOAD;     
      break;

   case 4:      /* Mass Cal */     
      /* switch to menu screen */
      winReturnWin = MASSCAL_WINDOW;
      /* shut down main window handler */
      winSetupState = WIN_SETUP_UNLOAD;     
      break;

   case 5:      /* Time and Date */     
      /* switch to menu screen */
      winReturnWin = TIMEDATE_WINDOW;
      /* shut down main window handler */
      winSetupState = WIN_SETUP_UNLOAD;     
      break;     
      
   case 128:       /* EXIT */
      /* switch to menu screen */
      //winReturnWin = USER_WINDOW;
      winReturnWin = USER_WINDOW;
      /* shut down main window handler */
      winSetupState = WIN_SETUP_UNLOAD;     
      break;
   }
}

/*
** ------------------------------------------------------------------------------
**		Function: void winSetupHandler(void)
** ------------------------------------------------------------------------------
*/

void winSetupHandler(void)
{
   switch (winSetupState)
   {
   case WIN_SETUP_PAINT:
      /* send command to execute macro 2 */
      slcdCallMacro(2);
      /* send macro 3 to make hotspots */
      slcdCallMacro(3);

      /* set forground and back ground colour */
      slcdSetColour(DarkGrey, White);
      
      if(EEPROM.Language==4)
         slcdSetFont(FCH16);         
      else       
         slcdSetFont(F32B);   
            
      /* display page title  */
      slcdDisplayText(gstr(&str->Setup), 16, 7, 'T');

      
      if(EEPROM.Language==4)
         slcdSetFont(FCH16);         
      else 
         slcdSetFont(F24B);         
                  
      /* Display menu choices  */
      DisplayText(gstr(&str->FullCalibration), 130, 116,  'T');
      
      DisplayText(gstr(&str->ResolutionAnd),   130, 236, 'T');
      DisplayText(gstr(&str->Ranges),          130, 240, 'T');      
      
      DisplayText(gstr(&str->Speed),           130, 356, 'T');
      DisplayText(gstr(&str->Calibration),     130, 400, 'T');
            
            
      DisplayText(gstr(&str->Mass),            570,  116,  'T');      
      DisplayText(gstr(&str->Calibration),     570,  160,  'T');
      
      DisplayText(gstr(&str->TimeAnd),         570,  236, 'T');      
      DisplayText(gstr(&str->Date),            570,  280, 'T');      
      
      DisplayText(gstr(&str->Analogs),         570,  356, 'T');      
      
      /* move to update state */      
      winSetupState = WIN_SETUP_UPDATE;       
      break;
      
   case WIN_SETUP_UPDATE:
      /* is there a key to process? */
      if (slcdKey)
      {
         /* call key handler */
         winMenuKeyHandler(slcdKey);      
         /* now the key has been processed clear it */
         slcdKey = 0; 
      }
      break;

   case WIN_SETUP_ENTER_PASSWORD:
      /* see if key pad is returning */
      switch(winKeyPadHandler())
      {
      case 1:
         /* move to update state */      
         winSetupState = WIN_SETUP_PAINT;       
         break;

      case 2:
         /* move to update state */      
         winSetupState = WIN_SETUP_UNLOAD;       
         break;

      case 3:
         /* move to update state */      
         winSetupState = WIN_SETUP_UNLOAD;       
         /* Open engineering */
         winReturnWin = ENGINEERING_WINDOW; 
         break;
      }
      break;
      
   case WIN_SETUP_UNLOAD:
      /* do any necessary clearing up */
      winSetupState = WIN_SETUP_PAINT;  
      /* set return menu */
      winActiveWin = winReturnWin;
      /* clear return win */ 
      winReturnWin = MAIN_WINDOW;
      break;
   }   
}



