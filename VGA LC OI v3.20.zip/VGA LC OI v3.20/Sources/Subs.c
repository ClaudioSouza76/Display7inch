#include <hidef.h>                           /* common defines and macros */
#include <mc9s12xd256.h>                    /* derivative information */

/*
** ------------------------------------------------------------------------------
   
   File   : Subs.c 
   Aurthor: 
   
   Description:  
   
   Version Log          Notes                                     Changes Made by                                        
   --------------       -----                                     ---------------
   06-11-08:            Created                                   Stuart


** ------------------------------------------------------------------------------
                                    
                                    Overview
                                            
** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

/* library headers */
#include "string.h"
#include "stdio.h"
#include "math.h"

/* Application headers */
#include "Main.h"
#include "Cmd.h"
#include "EEPROM.h"
#include "ModBusM Int.h"
#include "LED 100118.h"
#include "SLCD 260217.h"
#include "ModBusM.h"
#include "winMain.h"
#include "ADC 100118.h"
#include "CRG 100110.h"

/* Implements this interface: */
#define SUBS_C
#include "Subs.h"

#pragma CODE_SEG SUBS_Code
#pragma DATA_SEG SUBS_Data


/* private */

#pragma DATA_SEG RAM_PAGE1
static float far fifoArray[szArray];
static float far SampleArray[szArray];


/* public */
#pragma DATA_SEG RAM_PAGE2
float far HistogramArray[szArray];


#pragma DATA_SEG SUBS_Data


/* private */
static byte slcdStatusCopy; 
static byte mbStatusCopy;

static byte psuStatusCopy;
static byte psuStatus;

static word subsResetTimer;
static byte subsResetSeq;

static word subsBootTimer;
static byte subsBootSeq;


static float *InPtr;
static float *OutPtr;

static word  SampleTimer;

static float SampleSum;
static word  SampleCnt;

static word  fifoInx;

static float StdDevSum;


static float FirstTerm; 
static float SecondTerm; 
static float Result;

static word  sInx;

static word  HistInx;

 
/* public */
byte subsStatusWord;
byte subsSwitchInputs;

float psuVS;
float psuVCC2;

float SampleMean;
float StdDev;

/*
** ------------------------------------------------------------------------------
**		EEPROM Cmd Table
** ------------------------------------------------------------------------------
*/

#pragma INTO_ROM
static const CmdTabType SubsTab[]=
{
"SW?",         1,
"VS?",         2,
"VCC2?",       3,
"BOARD?",      4,

"SPEEDCAL?",   5,

"FL?",         6,
"TEST=",       7,

"SD?",         8,
"MEAN?",       9,

"SCNT?",       10,
"SARRAY?",     11,

"",			   0
};

/*
** ------------------------------------------------------------------------------
**		Function: byte SubsCmdParser(void)
** ------------------------------------------------------------------------------
*/

byte SubsCmdParser(void)
{
   byte Buf[15];
   word i, j;
   float f;
   
   switch(CmdMatch((CmdTabType *)&SubsTab))
   {
	case 1:         /* SW? */
	   sprintf(TxBufPtr, "%X", subsSwitchInputs);
	   CmdTx();
		break;  	

	case 2:         /* VS? */
	   sprintf(TxBufPtr, "%.1f", psuVS);
	   CmdTx();
		break;  	

	case 3:         /* VCC? */
	   sprintf(TxBufPtr, "%.1f", psuVCC2);
	   CmdTx();
		break; 
		
   case 4:         /* BOARD? */
	   //if (BoardType == _1162)
	      //sprintf(TxBufPtr, "%s", "A1162");
	   //else
	      sprintf(TxBufPtr, "%s", "900-125");
	   CmdTx();
      break;
      
	case 5:			/* SPEEDCAL? */
      i = sscanf(RxDataPtr, "%u", &j);
      if (i!=1||j>2)      
      {
         Reply(DATA_ERR);
      }
      else
      {          		   		
   		j = GetSpeedPtr(j);
   		sprintf(TxBufPtr, "%s%s %.1f m/s", EEPROM.SpeedCal[j].Time, EEPROM.SpeedCal[j].Date, EEPROM.SpeedCal[j].Speed);
   		CmdTx();
      }
		break;      
  	   
	case 6:			/* FL? */
      i = sscanf(RxDataPtr, "%f", &f);
      if (i!=1)      
      {
         Reply(DATA_ERR);
      }
      else
      {          		   		
   		if(f<-0.0)
   		   sprintf(TxBufPtr, "%u", 1);
   		else
   		   sprintf(TxBufPtr, "%u", 2);
   		
   		CmdTx();
      }
		break; 

	case 7:			/* TEST= */
      i = sscanf(RxDataPtr, "%s %f", &Buf, &f);
      if (i!=2)      
      {
         Reply(DATA_ERR);
      }
      else
      {          		   		
   		sprintf(TxBufPtr, Buf, f);
   		
   		CmdTx();
      }
		break; 
		
	case 8:         /* SD? */
	   sprintf(TxBufPtr, "%f", StdDev);
	   CmdTx();
		break; 		

	case 9:         /* MEAN? */
	   sprintf(TxBufPtr, "%f", SampleMean);
	   CmdTx();
		break; 		
		  	   
	case 10:         /* SCNT? */
	   sprintf(TxBufPtr, "%u", SampleCnt);
	   CmdTx();
		break; 
		
	case 11:         /* SARRAY? */
	   sprintf(TxBufPtr, "%u %f", sInx, SampleArray[sInx++]);
	   CmdTx();
		
		if(sInx==99)
		   sInx = 0;
		
		break; 
				  	   
   default:
      return 0;
   }
   
   /* Command processed */   
   return 1;
}

/*
** ------------------------------------------------------------------------------
**		Function: void SubsInit(void)
** ------------------------------------------------------------------------------
*/

void SubsInit(void)
{
   subsResetSeq   = 0;
   subsResetTimer = 0;  

   subsBootSeq   = 0;
   subsBootTimer = 0; 
   
   /* is hystogram enabled? */
   if(EEPROM.Histogram)
      subsSetHistogramRate();  
}

/*
** ------------------------------------------------------------------------------
**		Function: byte subsGetBoardType(void)
** ------------------------------------------------------------------------------
*/

byte subsGetBoardType(void)
{
   /* if we are running in an 900-125 board PT7 should be low in 
      a an A1162 board it should be high  */   

   /* switch on port T pin 7 pull down */
   PPST = 0x80;
   PERT = 0x80;

   if(PTT&0x80)
      /* A1162 */
      return _1162;
   else
      /* 900-125 */
      return _900_125;
}

/*
** ------------------------------------------------------------------------------
**		Function: byte *subsGetStatusString(byte Error)
** ------------------------------------------------------------------------------
*/

byte *subsGetStatusString(byte Error)
{
   /* return pointer to fault string */
   switch (Error)
   {
   case ERR_ONE:
       return "Display Offline";

   case ERR_TWO:
       return "485 Offline";

   case ERR_THREE:
         return "VS Low";
       
   case ERR_FOUR:
         return "VS Hi";

                                     
   default:
      return "485 Online";    
   }
}

/*
** ------------------------------------------------------------------------------
**		Function: void subsErrorHandler(void)
** ------------------------------------------------------------------------------
*/

void subsErrorHandler(void)
{
   /* check the slcd driver for errors */
   if(slcdStatus != slcdStatusCopy)
   {
      slcdStatusCopy = slcdStatus;
       
      if (slcdStatus & OFFLINE)
      {
         /* set status word and led */
         subsStatusWord |= ERR_ONE;
         ledSetError(ERR_ONE);            
      }
      else
      {
         /* set status word and led */
         subsStatusWord &=~ ERR_ONE;
         ledClearError(ERR_ONE);
      }
   }
   
   /* check the com driver for errors */
   if(mbStatus != mbStatusCopy)
   {
      mbStatusCopy = mbStatus;
       
      if (mbStatus & mbOFFLINE)
      {
         /* set status word and led */
         subsStatusWord |= ERR_TWO;
         ledSetError(ERR_TWO);            
      }
      else
      {
         /* set status word and led */
         subsStatusWord &=~ ERR_TWO;
         ledClearError(ERR_TWO);
      }
   }   

   if (BoardType == _900_125)
   /* check the com driver for errors */
   if(psuStatus != psuStatusCopy)
   {
      psuStatusCopy = psuStatus;
       
      if (psuStatus & VS_LOW)
      {
         /* set status word and led */
         subsStatusWord |= ERR_THREE;
         ledSetError(ERR_THREE);            
      }
      else
      {
         /* set status word and led */
         subsStatusWord &=~ ERR_THREE;
         ledClearError(ERR_THREE);
      }

      if (psuStatus & VS_HI)
      {
         /* set status word and led */
         subsStatusWord |= ERR_FOUR;
         ledSetError(ERR_FOUR);            
      }
      else
      {
         /* set status word and led */
         subsStatusWord &=~ ERR_FOUR;
         ledClearError(ERR_FOUR);
      }      
   }   
}


/*
** ------------------------------------------------------------------------------
**		Function: void subsReadSwitches(void)
** ------------------------------------------------------------------------------
*/

void subsReadSwitches(void)
{
   /* read switch inputs */
   //if (BoardType == _1162)
   //{
      //subsSwitchInputs = (PT1AD0^0xFF);
      /* check for switch 4 S Key*/
      //if(subsSwitchInputs&0x20)
      //{

      //}
   //}
   //else
   {
      subsSwitchInputs = (PORTB&0x0F);      
      /* check for switch 6 S Key*/
      if(subsSwitchInputs&0x01)
      {

      }
   }
}


/*
** ------------------------------------------------------------------------------
**		Function: void subsCheckResetSwitch(void)
** ------------------------------------------------------------------------------
*/

void subsCheckResetSwitch(void)
{
  if(subsResetSeq)
      subsResetTimer++;
   
   switch (subsResetSeq)
   {
   case 0: 
      /* has the reset swithc been pressed */
      if (!PTP_PTP7)
         /* move to next step */
         subsResetSeq = 1;  
      break;
      
   case 1:
      /* has switch been released? */
      if(PTP_PTP7)
      {
         /* has the switch been pressed for > 1 sec? */
         if(subsResetTimer>10) 
         {
            /* has switch been pressed for > than 20 sec? */
            if(subsResetTimer>200)
               MassEraseEE();
               
      		/* Turn LEDs on and wait for COP to expire */
            PTP &=~ 0x70;      
            /* reset */
            for(;;);                        
         }
         else
         {
            /* move to first step */
            subsResetSeq = 0;  
            /* clear timer counter */   
            subsResetTimer = 0;       
         }
      }
      break;
   }
   

   if(subsBootSeq)
      subsBootTimer++;
   
   switch (subsBootSeq)
   {
   case 0: 
      /* has the reset swithc been pressed */
      if (!PORTK_PK7)
         /* move to next step */
         subsBootSeq = 1;  
      break;
   }   
}

/*
** ------------------------------------------------------------------------------
**		Function: void subsMeasurePSU(void)
** ------------------------------------------------------------------------------
*/

void subsMeasurePSU(void)
{  
   /* have we just powered up? */
	if(psuVS == 0.0)
	   /* skip damping */
	   psuVS = (ReadADC(0)/(2.2/(10.0+2.2)));   
	else
	   /* damp a bit */
	   psuVS = ((psuVS*10.0)+(ReadADC(0)/(2.2/(10.0+2.2))))/11.0;

   /* check psu Vs is in range */
   if(psuVS<9)
   {
      psuStatus |= VS_LOW;
   }
   else
   {
      psuStatus &=~ VS_LOW;   
      
      if(psuVS>25)
         psuStatus |= VS_HI;
      else
         psuStatus &=~ VS_HI;
   }
   
	/* have we just powered up? */
	if(psuVCC2 == 0.0)
	   /* skip damping */
	   psuVCC2 = (ReadADC(1)/(10.0/(2.0+10.0)));   
	else
	   /* damp a bit */
	   psuVCC2 = ((psuVCC2*10.0)+(ReadADC(1)/(10.0/(2.0+10.0))))/11.0;

   /* check psu VCC is in range */
   if(psuVCC2<4.8)
   {
      psuStatus |= VCC_LOW;
   }
   else
   {
      psuStatus &=~ VCC_LOW;   
      
      if(psuVS>5.2)
         psuStatus |= VCC_HI;
      else
         psuStatus &=~ VCC_HI;
   }
}

/*
** ------------------------------------------------------------------------------
**		Function: void GetSpeedPtr(byte Inx)
** ------------------------------------------------------------------------------
*/

byte GetSpeedPtr(byte Inx)
{ 
   byte i, j;
         
   j = EEPROM.SpeedCalPtr;
         
   for(i=Inx; i; i--)
   {
      if(j)   
         j--;
      else
         j = 2;
   }
   return j;
}

/*
** ------------------------------------------------------------------------------
**		Function: void SetSpeedCalDate(float Speed)
** ------------------------------------------------------------------------------
*/

void SetSpeedCalDate(float Speed)
{
   /* check pointer position */
   if(EEPROM.SpeedCalPtr>=2)
      EEWR_8(&EEPROM.SpeedCalPtr, 0);
   else
      EEWR_8(&EEPROM.SpeedCalPtr, EEPROM.SpeedCalPtr+1);
   
   /* save date, time and cal speed */
   EEWR_Str((byte *)&EEPROM.SpeedCal[EEPROM.SpeedCalPtr].Date, mbSlave.Date, strlen(mbSlave.Date)); 
   EEWR_Str((byte *)&EEPROM.SpeedCal[EEPROM.SpeedCalPtr].Time, mbSlave.Time, strlen(mbSlave.Time)); 
   EEWR_fl(&EEPROM.SpeedCal[EEPROM.SpeedCalPtr].Speed, Speed);     
}

/*
** ------------------------------------------------------------------------------
**		Function: void GetMassPtr(byte Inx)
** ------------------------------------------------------------------------------
*/

byte GetMassPtr(byte Inx)
{ 
   byte i, j;
         
   j = EEPROM.MassCalPtr;
         
   for(i=Inx; i; i--)
   {
      if(j)   
         j--;
      else
         j = 2;
   }
   return j;
}

/*
** ------------------------------------------------------------------------------
**		Function: void SetMassCalDate(float Ref)
** ------------------------------------------------------------------------------
*/

void SetMassCalDate(float Ref)
{
   /* check pointer position */
   if(EEPROM.MassCalPtr>=2)
      EEWR_8(&EEPROM.MassCalPtr, 0);
   else
      EEWR_8(&EEPROM.MassCalPtr, EEPROM.MassCalPtr+1);
   
   /* save date, time and cal mass */
   EEWR_Str((byte *)&EEPROM.MassCal[EEPROM.MassCalPtr].Date, mbSlave.Date, strlen(mbSlave.Date)); 
   EEWR_Str((byte *)&EEPROM.MassCal[EEPROM.MassCalPtr].Time, mbSlave.Time, strlen(mbSlave.Time)); 
   EEWR_fl(&EEPROM.MassCal[EEPROM.MassCalPtr].TestWeight, Ref);     
}

/*
** ------------------------------------------------------------------------------
**		Function: void GetMassZeroPtr(byte Inx)
** ------------------------------------------------------------------------------
*/

byte GetMassZeroPtr(byte Inx)
{ 
   byte i, j;
         
   j = EEPROM.MassZeroCalPtr;
         
   for(i=Inx; i; i--)
   {
      if(j)   
         j--;
      else
         j = 2;
   }
   return j;
}

/*
** ------------------------------------------------------------------------------
**		Function: void SetMassZeroCalDate(float Ref)
** ------------------------------------------------------------------------------
*/

void SetMassZeroCalDate(float Zero)
{
   /* check pointer position */
   if(EEPROM.MassZeroCalPtr>=2)
      EEWR_8(&EEPROM.MassZeroCalPtr, 0);
   else
      EEWR_8(&EEPROM.MassZeroCalPtr, EEPROM.MassZeroCalPtr+1);
   
   /* save date, time and cal mass */
   EEWR_Str((byte *)&EEPROM.MassZeroCal[EEPROM.MassZeroCalPtr].Date, mbSlave.Date, strlen(mbSlave.Date)); 
   EEWR_Str((byte *)&EEPROM.MassZeroCal[EEPROM.MassZeroCalPtr].Time, mbSlave.Time, strlen(mbSlave.Time)); 
   EEWR_fl(&EEPROM.MassZeroCal[EEPROM.MassZeroCalPtr].Zero, Zero);     
}

/*
** ------------------------------------------------------------------------------
**		Function: void subsSetHistogramRate(void)
** ------------------------------------------------------------------------------
*/

void subsSetHistogramRate(void)
{
   switch(EEPROM.SampleRate)
   {
   case 0:
      /* 1 second */
      SampleTimer = 100;
      break; 
      
   case 1:
      /* 12.4 sec */
      SampleTimer = 1240;
      break; 

   case 2:
      /* 4.96 min */
      SampleTimer = 29760;
      break; 

   case 3:
      /* 34 min */
      SampleTimer = 2040;
      break; 

   case 4:
      /* 1.7 hours */
      SampleTimer = 6120;
      break; 
   }
}


/*
** ------------------------------------------------------------------------------
**		Function: void subsSampleTimer(void)
** ------------------------------------------------------------------------------
*/

void subsSampleTimer(void)
{
   word i;
   volatile float f, x, y, z;
   
   /* is histogram enabled */
   if(EEPROM.Histogram)
   {
      if(SampleTimer) 
      {
         SampleTimer--;    
      }
      else
      {
         subsSetHistogramRate();
         
         /* time to sample! */ 
         
         /* do we have a full data set yet? */
         
         //if(SampleCnt<szArray)  
         if(SampleCnt<sizeof(fifoArray)/4)  
            SampleCnt++;   

         /* place data in fifo array */
         if(fifoInx>=sizeof(fifoArray)/4)
            fifoInx = 0;
         
         fifoArray[fifoInx++] = mbSlave.Rate;
         
         /* place the data in numerical order */
         //subsSortNumericalOrder();
         
         /* now calculate sample mean */                 
                  
         /* clear the sum register */   
         SampleSum = 0;
         /* sum the sd */
         for(i=0;i<SampleCnt;i++)
            //SampleSum += SampleArray[i];
            SampleSum += fifoArray[i];

         /* get the mean */         
         SampleMean = SampleSum/SampleCnt;



         /* now we need the SD */
         
         /* clear the sum register */   
         StdDevSum = 0;
         
         for(i=0;i<SampleCnt;i++)
         {
            /* get the variance from the mean */
            f = fifoArray[i]-SampleMean;
            /* square it */
            f = f*f;
            /* and sum it */
            StdDevSum += f;   
         }          
         
         /* get standard diviation */
         StdDev = sqrt(StdDevSum/SampleCnt);


         /* ok where is the array entry point */
         //HistInx = 145-(SampleCnt/2);
         HistInx = (sizeof(fifoArray)/8)-(SampleCnt/2);
         
                     
         /* do z and x calculations */

         /* get y */
         y = (EEPROM.GraphLimit-(-EEPROM.GraphLimit))/SampleCnt;
         /* get z */
         z = (-EEPROM.GraphLimit);

         for (i=0;i<SampleCnt; i++)
         {
            SampleArray[i] = z*StdDev+SampleMean; 
            
            z += y;  
         }
         
         /* calculate the first term */
         FirstTerm = 1.0 / (StdDev * sqrt(2.0 * 3.14159265));

         /* now calculate the distribution array */
         for (i=0;i<SampleCnt; i++)
         {
            /* second term */
            SecondTerm = -( (SampleArray[i] - SampleMean) * (SampleArray[i] - SampleMean) / (2.0 * StdDev * StdDev) );
              
            /* and result */
            HistogramArray[HistInx+i] = FirstTerm * exp(SecondTerm); 
         }
         
         /* force display update */
         winUpdate1 = 1;
      }
   }
}

