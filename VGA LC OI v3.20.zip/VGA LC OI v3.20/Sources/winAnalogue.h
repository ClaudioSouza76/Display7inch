/*
** ------------------------------------------------------------------------------
   
   File   : winAnalogue.h 
   Aurthor: Stuart Clarke

** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

#ifndef WINANALOG_H
#define WINANALOG_H


/* public defines */


/*
** ------------------------------------------------------------------------------
**		#define : diagnostics handler states 
** ------------------------------------------------------------------------------
*/

#define WIN_ANALOG_PREPAINT     0
#define WIN_ANALOG_PAINT        1
#define WIN_ANALOG_UPDATE       2
#define WIN_ANALOG_NUMKEYPAD    3
#define WIN_ANALOG_UNLOAD       4




#ifndef WINANALOG_C

/* public variables */
#pragma DATA_SEG WINANALOG_Data


#endif   /* WINANALOG_C */      


/* public functions */
#pragma CODE_SEG WINANALOG_Code

/*
** ------------------------------------------------------------------------------
**		Function: void ReadAnalogParameters(void)
** ------------------------------------------------------------------------------
*/

void ReadAnalogParameters(void);

/*
** ------------------------------------------------------------------------------
**		Function: byte winAnalogHandler(void)
** ------------------------------------------------------------------------------
*/

byte winAnalogHandler(void);

#endif   /* WINANANLOG_H */
