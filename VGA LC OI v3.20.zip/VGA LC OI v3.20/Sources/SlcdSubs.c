#include <hidef.h>                           /* common defines and macros */
#include "derivative.h"       /* derivative information */

/*
** ------------------------------------------------------------------------------
   
   File   : SlcdSubs.c 
   Aurthor: 
   
   Description:  
   
   Version Log          Notes                                     Changes Made by                                        
   --------------       -----                                     ---------------
   30-08-12:            Created                                   Stuart
   

** ------------------------------------------------------------------------------
                                    
                                    Overview
                                            
** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

/* library headers */
#include "stdio.h"


/* Application headers */
#include "Main.h"
#include "EEPROM.h"

#include "SLCD 260217.h"


/* Implements this interface: */
#define SLCDSUBS_C
#include "SlcdSubs.h"

#pragma CODE_SEG SLCDSUBS_Code
#pragma DATA_SEG SLCDSUBS_Data


byte slcdVer[64];
byte PanelSize;

word xoff;
word yoff;

float xratio; 
float yratio;


/* private */
byte ForImg, BackImg;
byte LastForImg, LastBackImg;
byte FontImg[14];
byte LastFont[14];

/*
** ------------------------------------------------------------------------------
**		Function: void slcdSubsSetOffsets(void)
** ------------------------------------------------------------------------------
*/

void slcdSubsSetOffsets(void)
{
   switch(PanelSize)
   {
   default:    /* 5.7 Reach */
      /* Screen offsets */
      xoff = 0;
      yoff = 0;
      xratio = 1;
      yratio = 1;         
      break;

   case PSZ_1024_600:      /* 7in Riverdi */    
      /* Screen offsets */ 
      xoff = (1024-640)/2;
      yoff = (600-480)/2;

      xratio = 1;
      yratio = 1;
      break;      
   }   
}

/*
** ------------------------------------------------------------------------------
**		Function: void DisplayTitle(byte *Title)
** ------------------------------------------------------------------------------
*/

void DisplayTitle(byte *Title)
{
   word x1, y1;
 
    /* clear font images */
   memset(FontImg, 0, 10);
     
   slcd_SetFont(24, 0);
   slcd_SetColour(White, White);
   
   /* display page title  */
   slcd_SendText(Title, 12, 7, 'T', LEFT_ALIGN);
}

/*
** ------------------------------------------------------------------------------
**		Function: void OffsetOff(void)
** ------------------------------------------------------------------------------
*/

void OffsetOff(void)
{
   xoff = 0;
   yoff = 0;  

   xratio = 1.6;
   yratio = 1.25;
}

/*
** ------------------------------------------------------------------------------
**		Function: void DisplayBmp(byte BmpId, word x, word y)
** ------------------------------------------------------------------------------
*/

void DisplayBmp(byte BmpId, word x, word y)
{
   byte Buf[20];
   
   /* format display bmp command */
   sprintf(Buf, "xi %u %u %u", BmpId, (word)(x * xratio)+xoff, (word)(y * yratio)+yoff);
   /* send command */
   slcd_CmdQueue(Buf);   
}

/*
** ------------------------------------------------------------------------------
**		Function: void ClearButton(byte id)
** ------------------------------------------------------------------------------
*/

void ClearButton(byte id)
{
   byte Buf[10];

   sprintf(Buf, "bc %u", id);
   slcd_CmdQueue(Buf);
}

/*
** ------------------------------------------------------------------------------
**		Function: void MakeButton(byte id, byte type, word x, word y, word BmpUp, word BmpDn)
** ------------------------------------------------------------------------------
*/

void MakeButton(byte id, byte Type, word x, word y, word BmpUp, word BmpDn)
{
   byte Buf[60];

   sprintf(Buf, "bd %u %u %u %u \"\" %u %u %u %u", id, (word)(x * xratio)+xoff, (word)(y * yratio)+yoff, Type, 0, 0, BmpUp, BmpDn);
   slcd_CmdQueue(Buf);
}

/*
** ------------------------------------------------------------------------------
**		Function: void MakeLatchingButtonCT(byte id, byte *Str1, byte *Str2, word x, word y, word BmpUp, word BmpDn)
** ------------------------------------------------------------------------------
*/

void MakeLatchingButtonCT(byte id, byte *Str1, byte *Str2, word x, word y, word BmpUp, word BmpDn)
{
   byte Buf[60];

   sprintf(Buf, "bdc %u %u %u 2 \"%s\" \"%s\" %u %u", id, (word)(x * xratio)+xoff, (word)(y * yratio)+yoff, Str1, Str2, BmpUp, BmpDn);
   slcd_CmdQueue(Buf);
}

/*
** ------------------------------------------------------------------------------
**		Function: void slcdMakeLatchingButton(ButtonType * button)
** ------------------------------------------------------------------------------
*/

void MakeLatchingButton(ButtonType * button)
{
   byte Buf[60];

   //sprintf(Buf, "bd %u %u %u %u%u \"%s\" \"\" 0 0 %u %u", Id, x, y, type, State, Ptr, BmpUp, BmpDn);
   sprintf(Buf, "bd %u %u %u %u%u \"%s\" \"%s\" %u %u %u %u %u %u", 
   button->Id, 
   (word)(button->x * xratio)+xoff, 
   (word)(button->y * yratio)+yoff, 
   button->type, 
   button->state, 
   button->text0,
   button->text1, 
   button->dx0, 
   button->dy0, 
   button->dx1, 
   button->dy1, 
   button->bmp0, 
   button->bmp1 
   );
   slcd_CmdQueue(Buf);
}

/*
** ------------------------------------------------------------------------------
**		Function: void MakeButtonCT(byte id, byte *Str, byte Type, word x, word y, word BmpUp, word BmpDn)
** ------------------------------------------------------------------------------
*/

void MakeButtonCT(byte id, byte *Str, byte Type, word x, word y, word BmpUp, word BmpDn)
{
   byte Buf[60];

   sprintf(Buf, "bdc %u %u %u %u \"%s\" %u %u", id, (word)(x * xratio)+xoff, (word)(y * yratio)+yoff, Type, Str, BmpUp, BmpDn);
   slcd_CmdQueue(Buf);
}

/*
** ------------------------------------------------------------------------------
**		Function: void MakeHotSpot(byte id, word x, word y, word xsz, word ysz)
** ------------------------------------------------------------------------------
*/

void MakeHotSpot(byte id, word x, word y, word xsz, word ysz)
{
   byte Buf[25];
   
   //sprintf(Buf, "xs %u %u %u %u %u", id, (word)(x * xratio)+xoff, (word)(y * yratio)+yoff, ((word)(x * xratio)+xoff+(word)(xsz * xratio)), ((word)(y * yratio)+yoff+(word)(ysz * yratio)));
   sprintf(Buf, "xs %u %u %u %u %u", id, (word)(x * xratio)+xoff, (word)(y * yratio)+yoff, ((word)xoff+(word)(xsz * xratio)), ((word)yoff+(word)(ysz * yratio)));
   slcd_CmdQueue(Buf);
}

/*
** ------------------------------------------------------------------------------
**		Function: void slcdMakeButtonTextXY(byte Id, word x, word y, byte *Ptr, word x1, word y1, word BmpUp, word BmpDn)
** ------------------------------------------------------------------------------
*/

void MakeButtonTextXY(byte Id, word x, word y, byte *Ptr, word x1, word y1, word BmpUp, word BmpDn)
{
   byte Buf[60];

   sprintf(Buf, "bd %u %u %u 1 \"%s\" %u %u %u %u", Id, (word)(x * xratio)+xoff, (word)(y * yratio)+yoff, Ptr, x1, y1, BmpUp, BmpDn);
   slcd_CmdQueue(Buf);
}

/*
** ------------------------------------------------------------------------------
**		Function: void DisplayText(byte *Ptr, word x, word y)
** ------------------------------------------------------------------------------
*/

void DisplayText(byte *Ptr, word x, word y, byte Argument)
{
   byte Buf[150];
   
   if(Argument)
      sprintf(Buf, "t %c%s%c %u %u %c", '"', Ptr, '"', (word)(x * xratio)+xoff, (word)(y * yratio)+yoff, Argument);
   else
      sprintf(Buf, "t %c%s%c %u %u", '"', Ptr, '"', (word)(x * xratio)+xoff, (word)(y * yratio)+yoff);
   
   slcd_CmdQueue(&Buf);
}

/*
** ------------------------------------------------------------------------------
**		Function: void slcd_SendText(byte *Ptr, word x, word y, byte Type, byte Align)
** ------------------------------------------------------------------------------
*/

void slcd_SendText(byte *Ptr, word x, word y, byte Type, byte Align)
{
   byte Buf[150];
   
   if(Align != LEFT_ALIGN)
      slcd_TextAlign(Align);

   /* get rid of any quotes " marks */
   //RemoveQuotes(Ptr);
   
   if(Type)
      sprintf(Buf, "t %c%s%c %u %u %c", '"', Ptr, '"', (word)(x * xratio)+xoff, (word)(y * yratio)+yoff, Type);
   else
      sprintf(Buf, "t %c%s%c %u %u", '"', Ptr, '"', (word)(x * xratio)+xoff, (word)(y * yratio)+yoff);
   
   /* send command */
   slcd_Send(Buf);   
}

/*
** ------------------------------------------------------------------------------
**		Function: void slcd_AppendText(byte *Ptr)
** ------------------------------------------------------------------------------
*/

void slcd_AppendText(byte *Ptr)
{
   byte Buf[150];
   
   /* get rid of any quotes " marks */
   //RemoveQuotes(Ptr);
   
   sprintf(Buf, "t %c%s%c", '"', Ptr, '"');
   
   /* send command */
   slcd_Send(Buf);   
}

/*
** ------------------------------------------------------------------------------
**		Function: void slcd_SetColour(byte f, byte b)
** ------------------------------------------------------------------------------
*/

void slcd_SetColour(byte f, byte b)
{   
   byte Buf[10];
   
   /* save last settings for restore */
   LastForImg  = f; 
   LastBackImg = b;
   
   /* are  the required colours already selected */
   if(ForImg != f || BackImg != b)
   {
      /* save last settings for restore */
      //LastForImg  = ForImg; 
      //LastBackImg = BackImg;
            
      /* copy colours */
      ForImg  = f; 
      BackImg = b;
      
      /* set forground and background colours */
      sprintf(Buf, "s %u %u", f, b);
      slcd_Send(&Buf);
   }
}

/*
** ------------------------------------------------------------------------------
**		Function: void slcd_SetFont(byte Size, byte Type)
** ------------------------------------------------------------------------------
*/

void slcd_SetFont(byte Size, byte Type)
{
   static byte *FontPtr;
   
   switch (Size)
   {
   case 8:    /* size 8 */

      #ifdef UNICODE         

      if(EEPROM.Language == TAIWANESE || EEPROM.Language==CHINESE||EEPROM.Language == RUSSIAN)
      {         
         if(EEPROM.Language == RUSSIAN)
            FontPtr = FRS8;
         else
            FontPtr = FCH16;
      }
      else 
         FontPtr = F8;            

      #else
      //if(EEPROM.Language == POLISH || EEPROM.Language == GREEK)
         //FontPtr = FRS8;
      //else
         FontPtr = F8;
      #endif 
      
      break;
      
   case 14:    /* size 14 */

      #ifdef UNICODE         
      if(EEPROM.Language == TAIWANESE || EEPROM.Language==CHINESE||EEPROM.Language == RUSSIAN)
      {         
         if(EEPROM.Language == RUSSIAN)
            FontPtr = FRS16;
         else
            FontPtr = FCH16;
      }
      else 
      {
         if(Type == 'B')
            FontPtr = F14B;
         else
            FontPtr = F14;
      }

      #else
      //if(EEPROM.Language == POLISH || EEPROM.Language == GREEK)
         //FontPtr = FRS16;
      //else
      {
         
         //if(Type == 'B')
            //FontPtr = F14B;
         //else
            FontPtr = F14;
      }
      #endif
            
      break;
      
   case 16:    /* size 16 */
      #ifdef UNICODE         
      if(EEPROM.Language == TAIWANESE || EEPROM.Language==CHINESE||EEPROM.Language == RUSSIAN)
      {         
         if(EEPROM.Language == RUSSIAN)
            FontPtr = FRS16;
         else
            FontPtr = FCH16;
      }
      else 
      {
         if(Type == 'B')
            FontPtr = F16B;
         else
            FontPtr = F16;
      }

      #else
      //if(EEPROM.Language == POLISH || EEPROM.Language == GREEK)
         //FontPtr = FRS16;
      //else
      {
         
         if(Type == 'B')
            FontPtr = F16B;
         else
            FontPtr = F16;
      }
      #endif
      break;
      
   case 24:    /* size 24 */
      #ifdef UNICODE         
      if(EEPROM.Language == TAIWANESE || EEPROM.Language==CHINESE||EEPROM.Language == RUSSIAN)
      {         
         if(EEPROM.Language == RUSSIAN)
            FontPtr = FRS24;
         else
            FontPtr = FCH24;
      }
      else 
      {
         if(Type == 'B')
            FontPtr = F24B;
         else
            FontPtr = F24;
      }

      #else
      //if(EEPROM.Language == POLISH || EEPROM.Language == GREEK)
         //FontPtr = FRS24;
      //else
      {
         
         if(Type == 'B')
            FontPtr = F24B;
         else
            FontPtr = F24;
      }
      #endif
      break;
      
   case 31:    /* size 32 Use for numbers only */
             /* To force size 32 even when in Chinese mode Use only for numbers */
             
      #ifdef UNICODE         
      
      if(EEPROM.Language == RUSSIAN)
      {
         FontPtr = FRS32;  
      }
      else 
      {
         if(Type == 'B')
            FontPtr = F32B;
         else
            FontPtr = F32;
      }

      #else
      
      //if(EEPROM.Language == POLISH || EEPROM.Language == GREEK)
      //{
         //FontPtr = FRS32;  
      //}
      //else
      {
         
         if(Type == 'B')
            FontPtr = F32B;
         else
            FontPtr = F32;
      }
      #endif
      break;

   case 32:    /* size 32 */
      #ifdef UNICODE         
      if(EEPROM.Language == TAIWANESE || EEPROM.Language==CHINESE||EEPROM.Language == RUSSIAN)
      {         
         if(EEPROM.Language == RUSSIAN)
            FontPtr = FRS32;
         else
            FontPtr = FCH24;
      }
      else 
      {
         if(Type == 'B')
            FontPtr = F32B;
         else
            FontPtr = F32;
      }

      #else
      //if(EEPROM.Language == POLISH || EEPROM.Language == GREEK)
         //FontPtr = FRS32;
      //else
      {
         
         if(Type == 'B')
            FontPtr = F32B;
         else
            FontPtr = F32;
      }
      #endif
      break;
      
   //case 48:    /* size 48 */
      //#ifdef UNICODE         
      //FontPtr = F48;
      //#else
      //if(EEPROM.Language == POLISH)
         //FontPtr = FRS32;
      //else
         //FontPtr = F48;
      //#endif
      //break;      
   
   case 64:    /* size 64 */
      #ifdef UNICODE         
//      if(EEPROM.Language == TAIWANESE || EEPROM.Language==CHINESE)
//         /* chinese */
//         FontPtr = FCH24;         
//      else 
         FontPtr = F64;
      #else
      //if(EEPROM.Language == POLISH)
         //FontPtr = FRS32;
      //else
         FontPtr = F64;
      #endif
      break;      
   
   //case 100: 
      //FontPtr = AN100;
      //break;   

   //case 150: 
      //FontPtr = AN150;
      //break;   

   //case 250: 
      //FontPtr = AN250;
      //break;   
   }
   
   /* save last font for restore */
   strcpy(LastFont, FontPtr);
   
   /* is the font already set? */
   if(strcmp(FontImg, FontPtr))
   {
      /* save last font for restore */
      //strcpy(LastFont, FontImg);
      
      /* copy new font to img */
      strcpy(FontImg, FontPtr);
      
      /* send command */
      slcd_Send(FontImg);   
   }
}

/*
** ------------------------------------------------------------------------------
**		Function: void slcd_DisplayBmp(byte BmpId, word x, word y)
** ------------------------------------------------------------------------------
*/

void slcd_DisplayBmp(byte BmpId, word x, word y)
{
   byte Buf[20];
   
   /* format display bmp command */
   sprintf(Buf, "xi %u %u %u", BmpId, (word)(x * xratio)+xoff, (word)(y * yratio)+yoff);
   /* send command */
   slcd_Send(Buf);   
}

/*
** ------------------------------------------------------------------------------
**		Function: void slcd_MakeHotSpot(byte id, word x, word y, word xsz, word ysz)
** ------------------------------------------------------------------------------
*/

void slcd_MakeHotSpot(byte id, word x, word y, word xsz, word ysz)
{
   byte Buf[25];
   
   sprintf(Buf, "xs %u %u %u %u %u", id, (word)(x * xratio)+xoff, (word)(y * yratio)+yoff, ((word)(x * xratio)+xoff+(word)(xsz * xratio)), ((word)(y * yratio)+yoff+(word)(ysz * yratio)));
   slcd_Send(Buf);
}

/*
** ------------------------------------------------------------------------------
**		Function: void slcd_MakeLatchingButtonCT(byte id, byte *Str1, byte *Str2, word x, word y, word BmpUp, word BmpDn)
** ------------------------------------------------------------------------------
*/

void slcd_MakeLatchingButtonCT(byte id, byte *Str1, byte *Str2, word x, word y, word BmpUp, word BmpDn)
{
   byte Buf[60];

   sprintf(Buf, "bdc %u %u %u 2 \"%s\" \"%s\" %u %u", id, (word)(x * xratio)+xoff, (word)(y * yratio)+yoff, Str1, Str2, BmpUp, BmpDn);
   slcd_Send(Buf);
}

/*
** ------------------------------------------------------------------------------
**		Function: void slcd_MakeButton(byte id, byte type, word x, word y, word BmpUp, word BmpDn)
** ------------------------------------------------------------------------------
*/

void slcd_MakeButton(byte id, byte Type, word x, word y, word BmpUp, word BmpDn)
{
   byte Buf[60];

   sprintf(Buf, "bd %u %u %u %u \"\" %u %u %u %u", id, (word)(x * xratio)+xoff, (word)(y * yratio)+yoff, Type, 0, 0, BmpUp, BmpDn);
   slcd_Send(Buf);
}


/*
** ------------------------------------------------------------------------------
**		Function: void slcd_MakeButtonCT(byte id, byte *Str, byte Type, word x, word y, word BmpUp, word BmpDn)
** ------------------------------------------------------------------------------
*/

void slcd_MakeButtonCT(byte id, byte *Str, byte Type, word x, word y, word BmpUp, word BmpDn)
{
   byte Buf[60];

   sprintf(Buf, "bdc %u %u %u %u \"%s\" %u %u", id, (word)(x * xratio)+xoff, (word)(y * yratio)+yoff, Type, Str, BmpUp, BmpDn);
   slcd_Send(Buf);
}

/*
** ------------------------------------------------------------------------------
**		Function: void slcd_CallMacro(byte No)
** ------------------------------------------------------------------------------
*/

void slcd_CallMacro(byte No)
{
   byte Buf[12];
   
   sprintf(Buf, "m %u", No);
   slcd_Send(&Buf);

   /* macros change fonts and colours */
   /* clear colour images */   
   ForImg = 0;
   BackImg = 0;
   /* clear font images */
   memset(FontImg, 0, 10);
}

/*
** ------------------------------------------------------------------------------
**		Function: void slcd_MakeButtonTextXY(byte Id, word x, word y, byte *Ptr, word x1, word y1, word BmpUp, word BmpDn)
** ------------------------------------------------------------------------------
*/

void slcd_MakeButtonTextXY(byte Id, word x, word y, byte *Ptr, word x1, word y1, word BmpUp, word BmpDn)
{
   byte Buf[60];

   sprintf(Buf, "bd %u %u %u 1 \"%s\" %u %u %u %u", Id, (word)(x * xratio)+xoff, (word)(y * yratio)+yoff, Ptr, x1, y1, BmpUp, BmpDn);
   slcd_Send(Buf);
}

/*
** ------------------------------------------------------------------------------
**		Function: void slcd_MakeLatchingButton(ButtonType * button)
** ------------------------------------------------------------------------------
*/

void slcd_MakeLatchingButton(ButtonType * button)
{
   byte Buf[60];

   sprintf(Buf, "bd %u %u %u %u%u \"%s\" \"%s\" %u %u %u %u %u %u",
   button->Id,
   (word)(button->x * xratio)+xoff,
   (word)(button->y * yratio)+yoff,
   button->type,
   button->state,
   button->text0,
   button->text1,
   button->dx0,
   button->dy0,
   button->dx1,
   button->dy1,
   button->bmp0,
   button->bmp1
   );
   slcd_Send(Buf);
}

/*
** ------------------------------------------------------------------------------
**		Function: void slcdTextAlign(byte Align)
** ------------------------------------------------------------------------------
*/

void slcd_TextAlign(byte Align)
{
   byte Buf[10];
   
   switch(Align)
   {
   case  LEFT_ALIGN:
      strcpy(Buf, "ta LT"); 
      break;

   case  CENTER_ALIGN:
      strcpy(Buf, "ta CT"); 
      break;

   case  RIGHT_ALIGN:
      strcpy(Buf, "ta RT"); 
      break;
      
   case  LEFT_BOTTOM_ALIGN:
      strcpy(Buf, "ta LB"); 
      break;

   case  CENTER_BOTTOM_ALIGN:
      strcpy(Buf, "ta CB"); 
      break;

   case  RIGHT_BOTTOM_ALIGN:
      strcpy(Buf, "ta RB"); 
      break;      
   }
   
   /* send command */
   slcd_Send(Buf);   
}

/*
** ------------------------------------------------------------------------------
**		Function: void slcdDrawRectangle2(word x1, word y1, word xSz, word ySz)
** ------------------------------------------------------------------------------
*/

void slcdDrawRectangle2(word x1, word y1, word xSz, word ySz)
{
   byte Buf[25];
   
   sprintf(Buf, "r %u %u %u %u 1", (word)(x1 * xratio)+xoff, (word)(y1 * yratio)+yoff, (word)(x1 * xratio)+(word)(xSz * xratio)+xoff, (word)(y1 * yratio)+(word)(ySz * yratio)+yoff);
   
   slcd_Send(Buf); 
}

/*
** ------------------------------------------------------------------------------
**		Function: void slcdDrawRectangle(word x1, word y1, word xSz, word ySz)
** ------------------------------------------------------------------------------
*/

void slcdDrawRectangle(word x1, word y1, word xSz, word ySz)
{
   slcd_SetColour(LightGrey, White);
   slcdDrawRectangle2(x1, y1, xSz, ySz);
}

/*
** ------------------------------------------------------------------------------
**		Function: void slcd_SetButtonState(byte Id, byte State)
** ------------------------------------------------------------------------------
*/

void slcd_SetButtonState(byte Id, byte State)
{
   byte Buf[12];
   
   sprintf(Buf, "ssb %u %u", Id, State);
   slcd_Send(Buf);      
}

#pragma CODE_SEG DEFAULT







