#include <hidef.h>                           /* common defines and macros */
#include <mc9s12xd256.h>                    /* derivative information */

/*
** ------------------------------------------------------------------------------
   
   File   : ModBus Int.c 
   Aurthor: 
   
   Description:  
   
   Version Log          Notes                                     Changes Made by                                        
   --------------       -----                                     ---------------
   28-11-08:            Created                                   Stuart


** ------------------------------------------------------------------------------
                                    
                                    Overview
                                            
** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

/* library headers */
#include "string.h"

/* Application headers */
#include "Main.h"
#include "ECT 100114.h"
#include "ModBusM.h"
#include "winMain.h"
#include "EEPROM.h"

/* Implements this interface: */
#define MODBUSINT_C
#include "ModBusM Int.h"

#pragma CODE_SEG MODBUSINT_Code
#pragma DATA_SEG MODBUSINT_Data


/* private */
float Dummy;

/* public */
mbSlaveType mbSlave;


/*
** ------------------------------------------------------------------------------
**		mbTabletype: mbTable
** ------------------------------------------------------------------------------
*/

mbTabletype mbTable[]={	
/* enum Address   Length	Attributes			Rd Wr Flags	     Variable Address	*/
   
	/* General */
	  30000, 	 10,	mbStr|mbReadOnly,       0,        0,        (word *)&mbSlave.VerMoStr,              0,  //1     	 
  	30050, 	 1,		mbWord|mbReadOnly,      0,        0,		    (word *)&mbSlave.BoardType,             0,  //2
  	30051, 	 5,		mbStr,                  0,        0,	      (word *)&mbSlave.SerNo,                 0,  //3
  	30056, 	 8,		mbStr,                  0,        0,		    (word *)&mbSlave.Tag,                   0,  //4
  	30064, 	 10,	mbStr,                  0,        0,		    (word *)&mbSlave.CompanyName,           0,  //5

	/* Rate */
  	31000, 	 2,		mbFloat|mbReadOnly,		  0,		    0,		    (word *)&mbSlave.Rate,     	 	          0,  //6
  	31006,   1,		mbWord,	                0,		    0,		    (word *)&mbSlave.Damp[0],	              0,  //7
  	31011, 	 2,		mbFloat,	              0,	      0,        (word *)&mbSlave.AlarmHi[0],            0,  //8
  	31013, 	 2,		mbFloat,	              0,	      0,        (word *)&mbSlave.AlarmLo[0],            0,  //9
  	31015, 	 1,		mbByte,                 0,		    0,		    (word *)&mbSlave.Units[0],              0,  //10
  	31031, 	 1,		mbByte,	                0,	      0,	      (word *)&mbSlave.RateDampEn,            0,  //11
  	
  	/* Total */
  	31100, 	 2,		mbFloat|mbReadOnly,		  0,		    0,	    	(word *)&mbSlave.Total,                 0,  //12
   //31106,  1,		mbByte,	                0,		    0,		    (word *)&mbSlave.Damp[1],	              0,
  	31111, 	 2,		mbFloat,	              0,	      0,        (word *)&mbSlave.AlarmHi[1],            0,  //13
  	31113, 	 2,		mbFloat,	              0,	      0,        (word *)&mbSlave.AlarmLo[1],            0,  //14
    31115, 	 1,		mbByte,	                0,		    0,		    (word *)&mbSlave.Units[1],	            0,  //15
  	
  	/* Mass */
  	31200, 	 2,		mbFloat|mbReadOnly,     0,		    0,		    (word *)&mbSlave.Mass,                  0,  //16
  	31206, 	 1,		mbWord,	                0,		    0,		    (word *)&mbSlave.Damp[2],               0,  //17
  	31207, 	 2,		mbFloat,	              0,	      0,	      (word *)&mbSlave.Span[2],               0,  //18
  	31209, 	 2,		mbFloat,	              0,	      0,	      (word *)&mbSlave.Zero[2],               0,  //19
  	31211, 	 2,		mbFloat,	              0,	      0,        (word *)&mbSlave.AlarmHi[2],            0,  //20
  	31213, 	 2,		mbFloat,	              0,	      0,        (word *)&mbSlave.AlarmLo[2],            0,  //21
  	31215, 	 1,		mbByte,	                0,		    0,		    (word *)&mbSlave.Units[2],              0,  //22
  	31231, 	 1,		mbByte,	                0,	      0,	      (word *)&mbSlave.MassDampEn,            0,  //23
  	31232, 	 2,		mbFloat,	              0,        0,        (word *)&mbSlave.ZeroShift,             0,  //24
  	31234, 	 2,		mbFloat,	              0,        0,        (word *)&mbSlave.SpanShift,             0,  //25
  	  	
  	/* Speed */
  	31300, 	 2,		mbFloat|mbReadOnly,     0,		    0,		    (word *)&mbSlave.Speed,                 0,  //26
  	31306, 	 1,		mbWord,	                0,		    0,		    (word *)&mbSlave.Damp[3],               0,  //27
  	31307, 	 2,		mbFloat,	              0,	      0,	      (word *)&mbSlave.Span[3],               0,  //28
  	31309, 	 1,		mbWord,	                0,	      0,	      (word *)&mbSlave.TachoOffset,           0,  //29
  	31311, 	 2,		mbFloat,	              0,	      0,	      (word *)&mbSlave.AlarmHi[3],            0,  //29
  	31313, 	 2,		mbFloat,	              0,	      0,	      (word *)&mbSlave.AlarmLo[3],            0,  //30
  	31315, 	 1,		mbByte,	                0,		    0,		    (word *)&mbSlave.Units[3],              0,  //31
  	31331, 	 1,		mbByte,	                0,	      0,	      (word *)&mbSlave.TachoDampEn,           0,  //32
  	  	   
   /* Analogues */
  	32300, 	 2,		mbFloat,                0,		    0,		    (word *)&mbSlave.AnOutput[0],           0,  //33
  	32302, 	 2,		mbFloat,                0,	      0,	      (word *)&mbSlave.AnHi[0],               0,  //34
  	32304, 	 2,		mbFloat,                0,	      0,	      (word *)&mbSlave.AnLo[0],               0,  //35
    32306, 	 1,		mbByte,                 0,	      0,	      (word *)&mbSlave.AnFunction[0],         0,  //36
    32311, 	 2,		mbFloat,                0,	      0,	      (word *)&mbSlave.AnAdjust[0],           0,  //37
   
    32313, 	 1,		mbByte,                 0,	      0,	      (word *)&mbSlave.AnMode,                0,  //38

  	32320, 	 2,		mbFloat,                0,		    0,		    (word *)&mbSlave.AnOutput[1],           0,  //39
  	32322, 	 2,		mbFloat,                0,	      0,	      (word *)&mbSlave.AnHi[1],               0,  //40
  	32324, 	 2,		mbFloat,                0,	      0,	      (word *)&mbSlave.AnLo[1],               0,  //41
    32326, 	 1,		mbByte,                 0,	      0,	      (word *)&mbSlave.AnFunction[1],         0,  //42
    32331, 	 2,		mbFloat,                0,	      0,	      (word *)&mbSlave.AnAdjust[1],           0,  //43
  
   /* Misc */
    32900, 	 1,		mbByte,		              0,        0,		    (word *)&mbSlave.Digit,	                0,  //44
    32908, 	 1,		mbByte,                 0,		    0,		    (word *)&mbSlave.DataUpdate,            0,  //45
    32909, 	 1,		mbWord,                 0,		    0,		    (word *)&mbSlave.eeClearFlg,            0,  //46
    32911, 	 1,		mbWord,                 0,		    0,		    (word *)&mbSlave.PassWord,              0,  //47
    32912, 	 1,		mbByte,                 0,		    0,		    (word *)&mbSlave.OiLock,                0,  //48
      
   /* Pulse totalizer */
    32920, 	 1,		mbWord,		              0,        0,		    (word *)&mbSlave.PulseTotal,	          0,  //49
   
   /* Buses */
    32950, 	 1,		mbByte,	                0,		    0,		    (word *)&mbSlave.AsciId,                0,  //50
    32960, 	 1,		mbWord,	                0,		    0,		    (word *)&mbSlave.BusType,               0,  //51
    32961, 	 2,		mbLong,	                0,        0,		    (word *)&mbSlave.IpAdr,                 0,  //52
    32963, 	 2,		mbLong,	                0,        0,		    (word *)&mbSlave.SubNet,                0,  //53
    32965, 	 1,		mbByte,	                0,		    0,		    (word *)&mbSlave.DHCP,                  0,  //54
    32966, 	 1,		mbByte,	                0,        0,		    (word *)&mbSlave.PbNodeAdr,             0,  //55
    32967, 	 1,		mbByte,	                0,		    0,		    (word *)&mbSlave.Endian,                0,  //56
    32968, 	 8,		mbStr,                  0,        0,		    (word *)&mbSlave.StationName,           0,  //57
        
   /* AD7730 */
    34000, 	 1,		mbByte|mbReadOnly,	    0,		    0,	      (word *)&mbSlave.ADStatus,              0,  //58
    34001, 	 1,		mbWord,	                0,		    0,	      (word *)&mbSlave.ADMode,                0,  //59
    34002, 	 2,		mbLong,	                0,		    0,        (word *)&mbSlave.ADFilter,              0,  //60
    34004, 	 1,		mbByte,	                0,		    0,        (word *)&mbSlave.ADDac,                 0,  //61
    34005, 	 2,		mbLong,	                0,		    0,        (word *)&mbSlave.ADOffset,              0,  //62
    34007, 	 2,		mbLong,	                0,		    0,        (word *)&mbSlave.ADGain,                0,  //63
    34009, 	 2,		mbLong|mbReadOnly,      0,		    0,        (word *)&mbSlave.ADData,                0,  //64
   
    34011, 	 2,		mbFloat|mbReadOnly,     0,		    0,        (word *)&mbSlave.MassAverage,           0,  //65
    34013, 	 1,		mbByte,                 0,		    0,        (word *)&mbSlave.MCalFlag,              0,  //66
    34014, 	 1,		mbByte,	                0,		    0,	      (word *)&mbSlave.MZeroCalStartStop,     0,  //67
    34015, 	 1,		mbByte,	                0,		    0,	      (word *)&mbSlave.MSpanCalStartStop,     0,  //68
    34016, 	 2,		mbFloat,	              0,		    0,        (word *)&mbSlave.MassAdj,               0,  //69
    34018, 	 2,		mbLong,	                0,		    0,        (word *)&mbSlave.MassOffset,            0,  //70
    34020, 	 2,		mbFloat|mbReadOnly,     0,		    0,        (word *)&mbSlave.MassMv,                0,
      
   /* Time and Date */     
    34100, 	 5,		mbStr,	                0,		    0,        (word *)&mbSlave.Time,                  0,  //71
    34105, 	 5,		mbStr,                  0,		    0,        (word *)&mbSlave.Date,                  0,  //72

   /* Tacho */
    34200, 	 2,		mbFloat,	              0,		    0,	      (word *)&mbSlave.Frequency,             0,  //73
    34202, 	 1,		mbByte,	                0,		    0,	      (word *)&mbSlave.TCalFlag,              0,  //74
                                                    
    34203, 	 1,		mbByte,	                0,		    0,	      (word *)&mbSlave.ZeroCalStartStop,      0,  //75
    34204, 	 1,		mbByte,	                0,		    0,	      (word *)&mbSlave.SpanCalStartStop,      0,  //76
    34205, 	 2,		mbFloat,	              0,		    0,        (word *)&mbSlave.BeltSpeed,             0,  //77
    34207, 	 2,		mbFloat,	              0,		    0,        (word *)&mbSlave.BeltLength,            0,  //78
    34209, 	 2,		mbFloat,	              0,		    0,	      (word *)&mbSlave.AvgSpeed,              0,  //79
    34211, 	 2,		mbFloat,	              0,		    0,	      (word *)&mbSlave.BeltTravel,            0,  //81
    34213, 	 1,		mbByte,	                0,		    0,        (word *)&mbSlave.CalibrationFlag,       0,  //82
   
   /* alarm flag */
    34300, 	 1,		mbWord|mbReadOnly,      0,		    0,	      (word *)&mbSlave.AlarmFlag,             0,  //83
   
   /* Totalizer */
    34400, 	 1,		mbWord,                 0,		    0,	      (word *)&mbSlave.PulseDelay,            0,  //84 
    34401, 	 2,		mbFloat,                0,		    0,	      (word *)&mbSlave.PulseRate,             0,  //85 
    34403, 	 2,		mbFloat,                0,		    0,	      (word *)&mbSlave.TotalCutoff,           0,  //86 
    34405, 	 1,		mbByte,                 0,		    0,	      (word *)&mbSlave.PulseTotalEn,          0,  //87 
    34406, 	 1,		mbByte,                 0,		    0,	      (word *)&mbSlave.TotalizerReset,        0,  //88                   
    34407, 	 1,		mbByte,                 0,		    0,	      (word *)&mbSlave.TotalizerTest,         0,  //89
    
    34500, 	 5,		mbStr|mbReadOnly,	      0,		    0,        (word *)&mbSlave.LastCalTime,           0,  //90                
    34505, 	 5,		mbStr|mbReadOnly,       0,		    0,        (word *)&mbSlave.LastCalDate,           0,  //91
    34510, 	 5,		mbStr|mbReadOnly,       0,		    0,        (word *)&mbSlave.NextCalDate,           0,  //92
   
    34550, 	 2,		mbFloat,	              0,		    0,        (word *)&mbSlave.SpeedSim,              0,  //93
    34552, 	 2,		mbFloat,	              0,		    0,        (word *)&mbSlave.MassSim,               0,  //94
    34554, 	 1,		mbByte,	                0,	      0,        (word *)&mbSlave.SpeedSimEn,            0,  //95
    34555, 	 1,		mbByte,	                0,	      0,        (word *)&mbSlave.MassSimEn,             0,  //96
    
   /* Inputs */
    34556, 	 1,		mbByte,	                0,	      0,        (word *)&mbSlave.Inputs,                0,  //97

    34557, 	 1,		mbWord,	                0,	      0,        (word *)&mbSlave.InputDelay[0],         0,  //98
    34558, 	 1,		mbWord,	                0,	      0,        (word *)&mbSlave.InputDelay[1],         0,  //99
    34559, 	 1,		mbWord,	                0,	      0,        (word *)&mbSlave.InputDelay[2],         0,  //100
    34560, 	 1,		mbWord,	                0,	      0,        (word *)&mbSlave.InputDelay[3],         0,  //101
    
    34561, 	 1,		mbByte,	                0,	      0,        (word *)&mbSlave.InputPolartiy,         0,  //102
   
    34563, 	 1,		mbWord,	                0,	      0,        (word *)&mbSlave.InputFunction[0],      0,  //103
    34564, 	 1,		mbWord,	                0,	      0,        (word *)&mbSlave.InputFunction[1],      0,  //104
    34565, 	 1,		mbWord,	                0,	      0,        (word *)&mbSlave.InputFunction[2],      0,  //105
    34566, 	 1,		mbWord,	                0,	      0,        (word *)&mbSlave.InputFunction[3],      0,  //106
    
    34567, 	 1,		mbByte,	                0,	      0,        (word *)&mbSlave.Outputs,               0,  //107

    34568, 	 1,		mbWord,	                0,	      0,        (word *)&mbSlave.OutputDelay[0],        0,  //108                
    34569, 	 1,		mbWord,	                0,	      0,        (word *)&mbSlave.OutputDelay[1],        0,  //109                
    34570, 	 1,		mbWord,	                0,	      0,        (word *)&mbSlave.OutputDelay[2],        0,  //110               
    34571, 	 1,		mbWord,	                0,	      0,        (word *)&mbSlave.OutputDelay[3],        0,  //111               
   
    34572, 	 1,		mbByte,	                0,	      0,        (word *)&mbSlave.OutputFunction[0],     0,  //112               
    34573, 	 1,		mbByte,	                0,	      0,        (word *)&mbSlave.OutputFunction[1],     0,  //113               
    34574, 	 1,		mbByte,	                0,	      0,        (word *)&mbSlave.OutputFunction[2],     0,  //114              
    34575, 	 1,		mbByte,	                0,	      0,        (word *)&mbSlave.OutputFunction[3],     0,  //115              

    34576, 	 2,		mbFloat|mbReadOnly,     0,		    0,	      (word *)&mbSlave.AnalogueIn[0],         0,  //116
    34578, 	 2,		mbFloat|mbReadOnly,     0,		    0,	      (word *)&mbSlave.AnalogueIn[1],         0,  //117
    34580, 	 2,		mbFloat|mbReadOnly,     0,		    0,	      (word *)&mbSlave.AnalogueOut[0],        0,  //118
    34582, 	 2,		mbFloat|mbReadOnly,     0,		    0,	      (word *)&mbSlave.AnalogueOut[1],        0,  //119
   
    34584, 	 2,		mbFloat,                0,	      0,	      (word *)&mbSlave.AnInSpan[0],           0,  //120
    34586, 	 2,		mbFloat,                0,	      0,	      (word *)&mbSlave.AnInSpan[1],           0,  //121
    34588, 	 2,		mbFloat,                0,        0,	      (word *)&mbSlave.AnInZero[0],           0,  //122
    34590, 	 2,		mbFloat,                0,	      0,	      (word *)&mbSlave.AnInZero[1],           0,  //123
    34592, 	 1,		mbByte,                 0,		    0,	      (word *)&mbSlave.AnInDamp[0],           0,  //124
    34593, 	 1,		mbByte,                 0,		    0,	      (word *)&mbSlave.AnInDamp[1],           0,  //125
    34594, 	 1,		mbByte,                 0,		    0,      	(word *)&mbSlave.AnInFunc[0],           0,  //126
    34595, 	 1,		mbByte,                 0,		    0,	      (word *)&mbSlave.AnInFunc[1],           0,  //127

    34596, 	 2,		mbFloat|mbReadOnly,     0,		    0,        (word *)&mbSlave.BeltTension,           0,  //128
   
    34598, 	 1,		mbByte,                 0,		    0,	      (word *)&mbSlave.AnInType[0],           0,  //129
    34599, 	 1,		mbByte,                 0,		    0,      	(word *)&mbSlave.AnInType[1],           0,  //130
   
    34600, 	 2,		mbFloat,                0,	      0,	      (word *)&mbSlave.TensionHi,             0,  //131
    34602, 	 2,		mbFloat,                0,	      0,	      (word *)&mbSlave.TensionLo,             0,  //132
    34604, 	 2,		mbFloat|mbReadOnly,     0,	      0,	      (word *)&mbSlave.TensionAverage,        0,  //133
    
    34606,   1,   mbByte,                 0,        0,        (word *)&mbSlave.TensionCalFlg,         0,  //134
    34607,   1,   mbByte,                 0,        0,        (word *)&mbSlave.TensionCalEn,          0,  //135
    34608,   2,   mbFloat,                0,        0,        (word *)&mbSlave.TensionMassCapture,    0,  //136
    34700,   2,   mbFloat,                0,        0,        (word *)&mbSlave.TensionViewCal,        0,  //137
    34702,   2,   mbFloat,                0,        0,        (word *)&mbSlave.TensionFactor_K,       0,  //138
    34704,   2,   mbFloat,                0,        0,        (word *)&mbSlave.Tension_x_K,           0,	//139                 
   
    34706, 	 2,		mbFloat,                0,	      0,	      (word *)&EEPROM.ApplicationCapacity,    0,  //140
      
    34800, 	 1,		mbByte,                 0,		    0,        (word *)&mbSlave.AdcSampleCnt,          0,  //141                 
    34801, 	 1,		mbByte,                 0,		    0,        (word *)&mbSlave.AdcAvgCnt,             0,  //142                 
  
    34802, 	 1,		mbByte,                 0,		    0,        (word *)&mbSlave.StdEn,                 0,  //143
    34803, 	 1,		mbByte|mbReadOnly,      0,		    0,        (word *)&mbSlave.SdFlag,                0,  //144
    34804, 	 1,		mbWord,                 0,	      0,        (word *)&mbSlave.SdSampleRate,          0,  //145
    34805, 	 2,		mbFloat|mbReadOnly,     0,	      0,        (word *)&mbSlave.RateSd,                0,  //146
                                                                                                     
    35001,   2,   mbFloat,                0,        0,        (word *)&mbSlave.fFactorK,              0,  //147
    35002,   2,   mbFloat,                0,        0,        (word *)&Dummy,                         0,  //148
         
    36001,   2,   mbFloat|mbReadOnly,     0,        0,        (word*)&mbSlave.DigitTotal,             0,  //149
    
    36101,   1,   mbByte,                 0,        0,        (word *)&mbSlave.MovingAverageLCen,     0,  //150
    36103,   1,   mbByte,                 0,        0,        (word *)&mbSlave.MovingAverageBTen,     0,  //151
    36105,   1,   mbWord,                 0,        0,        (word *)&mbSlave.MovingAverageLC,       0,	//152
    36107,   1,   mbWord,                 0,        0,        (word *)&mbSlave.MovingAverageBT,       0,  //153
       
    37101,   2,   mbFloat,                0,        0,        (word *)&mbSlave.CorrZero,              0,  //154
    
    37201,   2,   mbByte,                 0,        0,        (word *)&mbSlave.ActionPERA,            0,  //155
   
};
   
//#define mbTableSize sizeof(mbTable)/sizeof(mbTabletype)
const word mbTableSize = sizeof(mbTable)/sizeof(mbTabletype)-1;

/*
** ------------------------------------------------------------------------------
**		Function: void mbIntSetRdFlags(void)
** ------------------------------------------------------------------------------
*/

void ModBusIntInit(void)
{


}

/*
** ------------------------------------------------------------------------------
**		Function: void mbIntSetRdFlags(void)
** ------------------------------------------------------------------------------
*/

void mbIntSetRdFlags(void)
{
   word i;
   
   for(i=1;i<=mbTableSize;i++)
      mbTable[i].RdFlg = 1; 
      
   
   mbTable[enAppCapacity].WrFlg = 1;    
}

/*
** ------------------------------------------------------------------------------
**		void mbStartT3Timeout(word Baud)
** ------------------------------------------------------------------------------
*/

void mbStartT3Timeout(word Baud)
{	
   #pragma MESSAGE DISABLE C5919 /* conversion of floating to integral */
   
   switch (Baud)
   {
   default:
   case 38400:
      /* load T3 timeout to compare register */
   	TC1 = TCNT + uS_to_TCR_8(T3_19200);			
   	/* clear interrupt flag */
   	TFLG1 = 0x02; 
      /* enable irq */	   
   	TIE |= 0x02;   
   	break;
   }
}


/*
** ------------------------------------------------------------------------------
**		interrupt void ECT1_Interrupt(void)
** ------------------------------------------------------------------------------
*/
#pragma CODE_SEG NON_BANKED

__interrupt void near ECT1_Interrupt(void)
{

   /* 
      This IRQ is enabled every time a characted is received on SCI
      when in modbus mode. The interrupt will exicute after period
      equal to the time it takes for 3.5 characters to be transmitted 
      at the releven baud rate.    
      A silent period of > 3.5 characters indicates the end of a MB
      PDU.  
   */
   /* Reset compare interrupt request flag */   
	TFLG1 = 0x02;            
	/* disable IRQ */	
	TIE &=~ 0x02;				

   mbT3Timeout();
}
/*
** ------------------------------------------------------------------------------
**		interrupt void ECT2_Interrupt(void)
** ------------------------------------------------------------------------------
*/
#pragma CODE_SEG NON_BANKED

__interrupt void near ECT2_Interrupt(void)
{
	#pragma MESSAGE DISABLE C5919 /* conversion of floating to integral */
	TC2 += uS_to_TCR_8(10000);			
	TFLG1 = 0x04; 
      
   mbMsgTimer();
}



