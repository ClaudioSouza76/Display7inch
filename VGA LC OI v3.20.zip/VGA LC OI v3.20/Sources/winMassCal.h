/*
** ------------------------------------------------------------------------------
   
   File   : winSpeedCal.h 
   Aurthor: Stuart Clarke

** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

#ifndef WINMASSCAL_H
#define WINMASSCAL_H


/* public defines */


/*
** ------------------------------------------------------------------------------
**		#define : diagnostics handler states 
** ------------------------------------------------------------------------------
*/

#define WIN_MASSCAL_PREPAINT     0
#define WIN_MASSCAL_PAINT        1
#define WIN_MASSCAL_UPDATE       2
#define WIN_MASSCAL_NUMKEYPAD    3
#define WIN_MASSCAL_MSGBOX       4
#define WIN_MASSCAL_UNLOAD       5

/*
** ------------------------------------------------------------------------------
**		#define : mass cal types
** ------------------------------------------------------------------------------
*/

#define MASS_ZERO_CAL         1
#define MASS_ZERO_LENGTH_CAL  2

#define CHART_X   30
#define CHART_Y   280 //300


#ifndef WIN_MASSCAL_C

/* public variables */
#pragma DATA_SEG WINMASSCAL_Data

extern float MassZeroError;
extern float OldMassZero;


#endif   /* WINMASSCAL_C */      


/* public functions */
#pragma CODE_SEG WINMASSCAL_Code

/*
** ------------------------------------------------------------------------------
**		Function: void ReadMassCalParameters(void)
** ------------------------------------------------------------------------------
*/

void ReadMassCalParameters(void);

/*
** ------------------------------------------------------------------------------
**		Function: void DisplayBeltTravel(void)
** ------------------------------------------------------------------------------
*/

void DisplayCurrentZero(void);

/*
** ------------------------------------------------------------------------------
**		Function: void DisplayNewZero(void)
** ------------------------------------------------------------------------------
*/

void DisplayNewZero(void);

/*
** ------------------------------------------------------------------------------
**		Function: void DisplayPulseRate(float PulseRate)
** ------------------------------------------------------------------------------
*/

void DisplayPulseRate(float PulseRate);

/*
** ------------------------------------------------------------------------------
**		Function: void DisplayMassZeroCalDate(void)
** ------------------------------------------------------------------------------
*/

void DisplayMassZeroCalDate(void);

/*
** ------------------------------------------------------------------------------
**		Function: void DisplayMassZeroError(void)
** ------------------------------------------------------------------------------
*/

void DisplayMassZeroError(void);

/*
** ------------------------------------------------------------------------------
**		Function: byte winMassCalHandler(void)
** ------------------------------------------------------------------------------
*/

byte winMassCalHandler(void);

#endif   /* WINMASSCAL_H */
