/*
** ------------------------------------------------------------------------------
   
   File   : winMassSpanCal.h 
   Aurthor: Stuart Clarke

** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

#ifndef WINMASSSPANCAL_H
#define WINMASSSPANCAL_H


/* public defines */


/*
** ------------------------------------------------------------------------------
**		#define : diagnostics handler states 
** ------------------------------------------------------------------------------
*/

#define WIN_MASSSPANCAL_PREPAINT     0
#define WIN_MASSSPANCAL_MENU         1
#define WIN_MASSSPANCAL_PAINT        2
#define WIN_MASSSPANCAL_UPDATE       3
#define WIN_MASSSPANCAL_NUMKEYPAD    4
#define WIN_MASSSPANCAL_MSGBOX       5
#define WIN_MASSSPANCAL_UNLOAD       6

/*
** ------------------------------------------------------------------------------
**		#define : span cal types 
** ------------------------------------------------------------------------------
*/

#define MASS_TEST_WEIGHT_CAL  3
#define MASS_MATERIAL_CAL     4
#define MASS_BELT_CUT_CAL     5



#ifndef WIN_MASSCAL_C

/* public variables */
#pragma DATA_SEG WINMASSSPANCAL_Data


#endif   /* WINMASSCAL_C */      


/* public functions */
#pragma CODE_SEG WINMASSSPANCAL_Code

/*
** ------------------------------------------------------------------------------
**		Function: void ReadMassSpanCalParameters(void)
** ------------------------------------------------------------------------------
*/

void ReadMassSpanCalParameters(void);

/*
** ------------------------------------------------------------------------------
**		Function: byte RecordNextDateCal(void)
** ------------------------------------------------------------------------------
*/
void RecordNextDateCal(void);

/*
** ------------------------------------------------------------------------------
**		Function: void RecordLastCall(void)
** ------------------------------------------------------------------------------
*/

void RecordLastCall(void);

/*
** ------------------------------------------------------------------------------
**		Function: void DisplayMassError(void)
** ------------------------------------------------------------------------------
*/

void DisplayMassError(void);

/*
** ------------------------------------------------------------------------------
**		Function: void DisplayNewSpan(void)
** ------------------------------------------------------------------------------
*/

void DisplayNewSpan(void);

/*
** ------------------------------------------------------------------------------
**		Function: void DisplayMassSpan(void)
** ------------------------------------------------------------------------------
*/

void DisplayMassSpan(void);

/*
** ------------------------------------------------------------------------------
**		Function: void DisplayMassCalDate(void)
** ------------------------------------------------------------------------------
*/

void DisplayMassCalDate(void);

/*
** ------------------------------------------------------------------------------
**		Function: void DisplayLastRefWeight(void)
** ------------------------------------------------------------------------------
*/

void DisplayLastRefWeight(void);


/*
** ------------------------------------------------------------------------------
**		Function: byte winMassSpanCalHandler(void)
** ------------------------------------------------------------------------------
*/

byte winMassSpanCalHandler(void);

#endif   /* WINMASSSPANCAL_H */
