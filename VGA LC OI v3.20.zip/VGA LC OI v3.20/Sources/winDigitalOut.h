/*
** ------------------------------------------------------------------------------
   
   File   : winBasicConfig.h 
   Aurthor: Stuart Clarke

** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

#ifndef WINDIGITALOUT_H
#define WINDIGITALOUT_H


/* public defines */

/*
** ------------------------------------------------------------------------------
**		#define : user menu handler states 
** ------------------------------------------------------------------------------
*/

#define WIN_DIGITAL_OUT_PREPAINT     0
#define WIN_DIGITAL_OUT_PAINT        1
#define WIN_DIGITAL_OUT_PAINTPAGE    2
#define WIN_DIGITAL_OUT_UPDATE       3
#define WIN_DIGITAL_OUT_NUMKEYPAD    4
#define WIN_DIGITAL_OUT_UNLOAD       5
#define WIN_DIGITAL_OUT_ENTER_PASSWORD 6


#ifndef WINDIGITALOUT_C

/* public variables */
#pragma DATA_SEG WINDIGITALOUT_DATA

extern byte winDigitalOutReturnWin;
extern byte OutputIndex;

#endif   /* WINDIGITALOUT_C */      


/* public functions */
#pragma CODE_SEG WINDIGITALOUT_CODE


/*
** ------------------------------------------------------------------------------
**		Function: void ReadDigitalOutParameters(void)
** ------------------------------------------------------------------------------
*/

void ReadDigitalOutParameters(void);

/*
** ------------------------------------------------------------------------------
**		Function: DisplayOutputFunction(void)
** ------------------------------------------------------------------------------
*/

void DisplayOutputFunction(void);


/*
** ------------------------------------------------------------------------------
**		Function: void PaintDigitalOut(void)
** ------------------------------------------------------------------------------
*/

void PaintDigitalOut(void);

/*
** ------------------------------------------------------------------------------
**		Function: byte winDigitalOutHandler(void)
** ------------------------------------------------------------------------------
*/

byte winDigitalOutHandler(void);

#endif   /* WINDIGITALOUT_H */
