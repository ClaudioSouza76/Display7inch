#include <hidef.h>                           /* common defines and macros */
#include "derivative.h"                  /* derivative information */
#include <stdio.h>                          /* To sprintf  */

/*
** ------------------------------------------------------------------------------
   
   File   : winInspecMec.c 
   Aurthor: 
   
   Description:  
   
   Version Log          Notes                                     Changes Made by                                        
   --------------       -----                                     ---------------
   25-07-10:            Created                                   Stuart


** ------------------------------------------------------------------------------
                                    
                                    Overview
                                            
** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

/* library headers */
#include "string.h"

/* Application headers */
#include "SLCD 260217.h"
#include "winMain.h"
#include "winKey.h"
#include "Language.h"
#include "ModBusM Int.h"
#include "EEPROM.h"
#include "SlcdSubs.h"

/* Implements this interface: */
#define WININSPECMEC_C
#include "winInspecMec.h"

#pragma CODE_SEG WININSPECMEC_Code
#pragma DATA_SEG WININSPECMEC_Data


/* private */
static byte winInspecMecState;
static byte winReturnWin;

/* public */

/*
** ------------------------------------------------------------------------------
**		Function: void winSpecialFuncKeyHandler(byte key)
** ------------------------------------------------------------------------------
*/

void winInspecMecKeyHandler(byte key)
{
   switch (key)
   {
         
   case 128:       /* EXIT */
      /* switch to menu screen */
      //winReturnWin = USER_WINDOW;
      winReturnWin = ENGINEERING_WINDOW;
      /* shut down main window handler */
      winInspecMecState = WIN_INSPECMEC_UNLOAD;     
      break;
      
    case 130:   /* Numero LocalTrasn */
      /* move to key pad handler sate */
         winInspecMecState = WIN_INSPECMEC_NUMKEYPAD; 
   /* copy parameter data to key structure */
        strcpy(NumKeyData.Name, "Localizacao no transportados");  
         NumKeyData.KeyBoardType = NUMBER;
         NumKeyData.Type = BYTE;
         NumKeyData.iMax = 10;
         NumKeyData.Attributes = EPROM;
         NumKeyData.DataPtr = (void *)&EEPROM.LocalTrans; 
         break;
         
    case 131:   /* Numero AlinhamRoletes */
      /* move to key pad handler sate */
          winInspecMecState = WIN_INSPECMEC_NUMKEYPAD; 
   /* copy parameter data to key structure */
        strcpy(NumKeyData.Name, "Alinhamento dos roletes");  
         NumKeyData.KeyBoardType = NUMBER;
         NumKeyData.Type = BYTE;
         NumKeyData.iMax = 10;
         NumKeyData.Attributes = EPROM;
         NumKeyData.DataPtr = (void *)&EEPROM.AlinhamRoletes;	
         break;	
         
   case 132:   /* Numero DistRoletes */
     /* move to key pad handler sate */
         winInspecMecState = WIN_INSPECMEC_NUMKEYPAD; 
   /* copy parameter data to key structure */
        strcpy(NumKeyData.Name,"Distancia entre roletes");  
         NumKeyData.KeyBoardType = NUMBER;
         NumKeyData.Type = BYTE;
         NumKeyData.iMax = 10;
         NumKeyData.Attributes = EPROM;
         NumKeyData.DataPtr = (void *)&EEPROM.DistRoletes; 
         break;
         
   case 133:   /* Numero RigidezTrans */
    /* move to key pad handler sate */
         winInspecMecState = WIN_INSPECMEC_NUMKEYPAD; 
   /* copy parameter data to key structure */
        strcpy(NumKeyData.Name, "Rigidez estrutural");  
         NumKeyData.KeyBoardType = NUMBER;
         NumKeyData.Type = BYTE;
         NumKeyData.iMax = 10;
         NumKeyData.Attributes = EPROM;
         NumKeyData.DataPtr = (void *)&EEPROM.RigidezTrans; 
         break;
         
   case 134:   /* Numero Comportamento */
   
   /* move to key pad handler sate */
      winInspecMecState = WIN_INSPECMEC_NUMKEYPAD; 
   /* copy parameter data to key structure */
        strcpy(NumKeyData.Name, "Comportamento cor./ rol.");  
         NumKeyData.KeyBoardType = NUMBER;
         NumKeyData.Type = BYTE;
         NumKeyData.iMax = 10;
         NumKeyData.Attributes = EPROM;
         NumKeyData.DataPtr = (void *)&EEPROM.Comportamento	;
         break;      
         
   case 135:   /* Numero SensorVel */
    /* move to key pad handler sate */
         winInspecMecState = WIN_INSPECMEC_NUMKEYPAD; 
   /* copy parameter data to key structure */
        strcpy(NumKeyData.Name, gstr(&str->SpeedSensor));  
         NumKeyData.KeyBoardType = NUMBER;
         NumKeyData.Type = BYTE;
         NumKeyData.iMax = 10;
         NumKeyData.Attributes = EPROM;
         NumKeyData.DataPtr = (void *)&EEPROM.SensorVel;
         break;  
   }
}

/*
** ------------------------------------------------------------------------------
**		Function: void winSpecialFuncHandler(void)
** ------------------------------------------------------------------------------
*/

void winInspecMecHandler(void)
{
   
   byte Buf[25];
   
   switch (winInspecMecState)
   {
   case WIN_INSPECMEC_PAINT:
      slcd_SetColour(DarkGrey, DarkGrey);
      slcd_Send("z");

      slcd_Send("xc all");     
      /* display menu screen */
      //DisplayBmp(16, 0, 0, LEFT_ALIGN); 
      slcd_DisplayBmp(10, 0, 0); 

      DisplayTitle("MS Instrumentos");
      
      slcd_SetFont(24, 0);
      slcd_SetColour(DarkGrey, White); 
      slcd_SendText(gstr(&str->InspecMecTitle), 15, 60, 0, LEFT_ALIGN);
      
      /* define back hotspot */
      //slcd_CmdQueue("x 128 560 10 630 60");
      slcd_MakeHotSpot(128, 560, 10, 50, 50);
      
      /*   Testar a variavel */   
      //sprintf(Buf, "%u %u %u %u %u %u", EEPROM.LocalTrans, EEPROM.AlinhamRoletes, EEPROM.DistRoletes, EEPROM.RigidezTrans, EEPROM.Comportamento, EEPROM.SensorVel );
      //slcdslcd_SendText(&Buf, 45, 50, 0);   
      
       if(EEPROM.LocalTrans == 0) {
          slcd_SetColour(Red, White);
          slcd_SendText(" ? ", Col1-55,LN1+10,'T', LEFT_ALIGN);      
      }else if(EEPROM.LocalTrans == 3){
          slcd_SetColour(Green, White);
          slcd_SendText(" OK ", Col1-75,LN1+10,'T', LEFT_ALIGN);
      } else{
          slcd_SetColour(Blue, White);
          slcd_SendText(" * ", Col1-55,LN1+10,'T', LEFT_ALIGN);
      }

      if(EEPROM.AlinhamRoletes == 0){
          slcd_SetColour(Red, White);
          slcd_SendText(" ? ", Col1-55,LN2+10,'T', LEFT_ALIGN); 
      }else if(EEPROM.AlinhamRoletes == 8){
           slcd_SetColour(Green, White);
           slcd_SendText(" OK ", Col1-75,LN2+10,'T', LEFT_ALIGN);  
      } else{
           slcd_SetColour(Blue, White);
          slcd_SendText(" * ", Col1-55,LN2+10,'T', LEFT_ALIGN);
      }
     
      
       if(EEPROM.DistRoletes == 0){
          slcd_SetColour(Red, White);
          slcd_SendText(" ? ", Col1-55,LN3+10,'T', LEFT_ALIGN);  
      } else if(EEPROM.DistRoletes == 5){
         slcd_SetColour(Green, White);
         slcd_SendText(" OK ", Col1-75,LN3+10,'T', LEFT_ALIGN);
      } else{
          slcd_SetColour(Blue, White);
          slcd_SendText(" * ", Col1-55,LN3+10,'T', LEFT_ALIGN);
      }
      
       if(EEPROM.RigidezTrans == 0){
         slcd_SetColour(Red, White);
          slcd_SendText(" ? ", Col2-55,LN1+10,'T', LEFT_ALIGN);   
      } else  if(EEPROM.RigidezTrans  == 9){
          slcd_SetColour(Green, White);
          slcd_SendText(" OK ", Col2-75,LN1+10,'T', LEFT_ALIGN); 
      }else {
          slcd_SetColour(Blue, White);
          slcd_SendText(" * ", Col2-55,LN1+10,'T', LEFT_ALIGN);
      }
      
       if(EEPROM.Comportamento == 0){
          slcd_SetColour(Red, White);
          slcd_SendText(" ? ", Col2-55,LN2+10,'T', LEFT_ALIGN);     
      } else if(EEPROM.Comportamento ==1){
          slcd_SetColour(Green, White);
          slcd_SendText(" OK ", Col2-75,LN2+10,'T', LEFT_ALIGN);
      } else {
          slcd_SetColour(Blue, White);
          slcd_SendText(" * ", Col2-55,LN2+10,'T', LEFT_ALIGN);
      }
      
       if(EEPROM.SensorVel == 0){
         slcd_SetColour(Red, White);
          slcd_SendText(" ? ", Col2-55,LN3+10,'T', LEFT_ALIGN);       
      } else if(EEPROM.SensorVel == 1){
          slcd_SetColour(Green, White);
          slcd_SendText(" OK ", Col2-75,LN3+10,'T', LEFT_ALIGN); 
      } else{
          slcd_SetColour(Blue, White);
          slcd_SendText(" * ", Col2-55,LN3+10,'T', LEFT_ALIGN);
      }

      slcd_SetFont(14, 0);         
      slcd_SetColour(DarkGrey, White);                  
      /* Display menu choices  */   
          
      //slcd_SendText("Localizacao no \nTransportador", Col1, LN1,  'T');
      slcd_SendText("Localizacao no",    Col1, LN1,  'T', LEFT_ALIGN);
      slcd_SendText("Transportador",     Col1, LN1+20,  'T', LEFT_ALIGN);

      //slcd_SendText("Alinhamento dos \nRoletes", Col1, LN2,  'T');
      slcd_SendText("Alinhamento dos",   Col1, LN2,  'T', LEFT_ALIGN);
      slcd_SendText("Roletes",           Col1, LN2+20,  'T', LEFT_ALIGN);

      //slcd_SendText("Distancia entre \nRoletes", Col1, LN3,  'T');
      slcd_SendText("Distancia entre",   Col1, LN3,  'T', LEFT_ALIGN);
      slcd_SendText("Roletes",           Col1, LN3+20,  'T', LEFT_ALIGN);
      
      //slcd_SendText("Rigidez Estrutural \n do Transportador", Col2, LN1,  'T');
      slcd_SendText("Rigidez Estrutural",   Col2, LN1,  'T', LEFT_ALIGN);
      slcd_SendText("do Transportador",     Col2, LN1+20,  'T', LEFT_ALIGN);

      //slcd_SendText("Comportamento \nCorreia / Roletes", Col2, LN2,  'T');
      slcd_SendText("Comportamento",        Col2, LN2,  'T', LEFT_ALIGN);
      slcd_SendText("Correia / Roletes",    Col2, LN2+20,  'T', LEFT_ALIGN);

      //slcd_SendText("Sensor de \nVelocidade", Col2, LN3,  'T');
      slcd_SendText("Sensor de ",           Col2, LN3,  'T', LEFT_ALIGN);
      slcd_SendText("Velocidade",           Col2, LN3+20,  'T', LEFT_ALIGN);
              
      //slcd_MakeHotSpot(130, 3,   104, 100, 80);      /*  Localiza?ao no transportador*/
      //slcd_MakeHotSpot(131, 3,   220, 103, 80);      /* Alinhamento dos Roletes */
      //slcd_MakeHotSpot(132, 3,   340, 103, 80);      /* Distancia entre Roletes */
      //slcd_MakeHotSpot(133, 350, 104, 100, 80);      /* Rigidez Estrutural */ 
      //slcd_MakeHotSpot(134, 350, 220, 100, 80);      /* Comportamento correia */
      //slcd_MakeHotSpot(135, 350, 340, 100, 80);      /* Sensor de Velocidade */

      slcd_MakeHotSpot(130, 3,   104, 50, 50);      /* Localiza?ao no transportador*/
      slcd_MakeHotSpot(131, 3,   220, 50, 50);      /* Alinhamento dos Roletes */
      slcd_MakeHotSpot(132, 3,   340, 50, 50);      /* Distancia entre Roletes */
      slcd_MakeHotSpot(133, 350, 104, 50, 50);      /* Rigidez Estrutural */ 
      slcd_MakeHotSpot(134, 350, 220, 50, 50);      /* Comportamento correia */
      slcd_MakeHotSpot(135, 350, 340, 50, 50);      /* Sensor de Velocidade */
          
      /* move to update state */      
      winInspecMecState = WIN_INSPECMEC_UPDATE;       
      break;
      
   case WIN_INSPECMEC_UPDATE:
      /* is there a key to process? */
      if (slcdKey)
      {
         /* call key handler */
         winInspecMecKeyHandler(slcdKey);      
         /* now the key has been processed clear it */
         slcdKey = 0; 
      }
      break;
      
    case   WIN_INSPECMEC_NUMKEYPAD :
          /* see if key pad is returning */
        if(winKeyPadHandler())
         /* move to update state */      
               winInspecMecState = WIN_INSPECMEC_PAINT;   
      break;      
    break;
      
   case WIN_INSPECMEC_UNLOAD:
      /* do any necessary clearing up */
      winInspecMecState = WIN_INSPECMEC_PAINT;  
      /* set return menu */
      winActiveWin = winReturnWin;
      /* clear return win */ 
      winReturnWin = ENGINEERING_WINDOW;
      break;
   }   
}