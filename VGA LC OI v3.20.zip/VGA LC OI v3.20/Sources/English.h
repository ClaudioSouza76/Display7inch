/*
** ------------------------------------------------------------------------------
   
   File   : English.h 
   Aurthor: Stuart Clarke

** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

#ifndef ENGLISH_H
#define ENGLISH_H


/* public defines */

#pragma STRING_SEG STRING_BANK

/*
** ------------------------------------------------------------------------------
**		English
** ------------------------------------------------------------------------------
*/

byte *English[] = 
{
/* main screen */
"Status",

/* menu */
"Status: Connected ",
"Status: Connecting",
"Enter Password",
"Select Menu",

/* cal parameters */
"Zero",
"Span",
"Damp", 
"Avg Time", 
"Alarm Hi",
"Alarm Lo",
"Analog Hi",
"Analog Lo",
"Cal:",

/* misc */
"Change Password",
"Digits",
"Digits (Precision)",
"Instrument ID",
"OI Version",
"NIR Version",
"Serial No",

/* engineering */
"Engineering",
"ON",
"OFF",

"Warning",
"Are you sure you want to restore settings from backup?",
"Are you sure you want to save settings to backup?",
"EE CLEAR",
"Restore Factory Defaults ",
"Reset Product Calibrations ",
"Languages",
"Select Language",

/* Ananlogue */
"Analog",
"Analog Allocation",
"Analog Adjust",
"Analog Hi",
"Analog Lo",
"Output mA",
"Constituent",
"Fix 2mA",
"Fix 18mA",
"Adjust",

/* key pad */
"Min:",
"Max:",

/* field bus */
"IP Address: ",
"SubNet: ",
"DHCP ",

/* */
"User Menu",
"Setup Menu",
"Save",
"Page 1",
"Page 2",
"Page 3",
"Restore Instrument",
"Settings",
"Backup Instrument",
"Restore Factory",
"Defaults", 
"Erase",
"Yes",
"No",  

/* New strings for LC IO */

/* Setup Menu */
"Setup",
"Full Calibration",
"Resolution And",
"Ranges",
"Speed",
"Mass",
"Calibration",

"Time And",
"Date",
"Analogs",
"FieldBus",

/* Ranges */
"Rates and Ranges",
"Scale Tag",
"Rate Units",
"Resolution",
"Pulse Totalizer",

"Rate Ranges",
"Speed Ranges",
"Mass Ranges",
"High End",
"Low End",

/* Engineering menu */
"Tacho",
"Input",
"AD7730",
"Converter",
"EEPROM",

"Set Time and Date",
"Set Time",
"Set Date",

"Zero Calibration",
"Span Calibration",

"Speed Calibration",
"Mass Calibration",
"STOP CONVEYOR!",
"RUN CONVEYOR EMPTY!",
"Cal Duration",
"Frequency",
"Frequency Offset",
"Belt Speed",
"Enter Measured Speed",

"START",
"STOP",
"ABORT",
"ACCEPT",
"CALIBRAITNG",
"COMPLETE",
"CALCULATE",
"STOP CONVEYOR EMPTY!",

"Counts",
"Mass Offset",
"Enter Mass",
"Mass Span", 
"Mass Adj",
"LOAD TEST WEIGHT",

"Special Functions",
"Simulation",
"Filtering",
"Alarm Settings",
"Totalizer",
"Compensation",

"Rate Filter",
"Mass Filter",
"Speed Filter",

"Time Constant",

"Mass Alarms",
"Rate Alarms",
"Speed Alarms",
"Deviation Alarms",

"High Alarm",
"Low Alarm",
"Hysteresis",

"PulseWidth",
"PulseRate",
"Cut-Off",
"Total Reset",
"Total",
"Pulse Test",

"Flow:",
"Total:",
"Weight:",
"Last Cal Check",
"Next Check",

"Belt Length",
"Max Scale Capacity",
"Cal Weight",

"Test Weight Cal",
"Material Weight Cal",    
"Belt Cut Cal", 

"Average Kg/m",
"Cal Total",
"Flow Rate %",
"Belt Distance",  
   
"Transport Capacity",
"Application Capacity",
"Balance Capacity",
"Test Wight Application %",
"Sensibility LC",

"Material Density",
"Belt Width",
"Convayor Angle",
"Roller Angle",
"Idle Spacing",

"Serial No",
"Shipping Date",

"Test Weight",


"Are you sure?",

"Restoring",
"BackingUp",
"Complete",

"Cal Functions",
"Minimum Cal ",
"Time",             

"Speed Simulator",   
"Mass Simulator",  

"mV Very High", 
"OK",
"Cal Zero Limit", 
"Maximum Cal",

"Inputs",
"Outputs",

"Inputs And Outputs",

"Analogue",
"Digital",

"Digital Inputs",
"Digital Outputs",
"Analogue Inputs",
"Analogue Outputs",

"Input Delay",
"Polarity",
"Function",

"Positive",
"Negative",

"Output",
"TriggerHi",
"TriggerLo",
"Output Delay",

"Analogue In 1",
"Analogue In 2",

"Tension",
"Input Type",
"Tension Hi",
"Tension Lo",

"Moving Average LC",
"Moving Average BT",

"Sample Count",
"Average Count",

"Time out calibration",

"Precision",
"Serial No MS",
"Model Scale",

"Configuration",
"Basic/Diagnostics",
"Histogram",
"Configuration Basic/Diagnostics",
"Time and Date",
"Balance Data",
"Calibration Constants",

/* Balance Data screen */
"Scale Data",
"TAG:",
"Model:",
"Serial No:",
"C.C:",
"mV/V:",
"Design Flow(t/h):",
"Scale Cap.(t/h):",
"Test Wt. equiv.(kg/m):",
"Test Weight(%) of flow:",
"Test Weight(Kg):",
"Factory Date:",
"Version:",
"Apparent Density(Kg/m3):",
"Belt Length(m):",
"Belt Width(mm):",
"Design Speed(m/s):",
"Conveyor Incline:",
"Roller Incline:",
"Roller Spacing(m):",
"Manufactured by:",
"MS Instrumentos Industriais Ltda",
"RJ-RJ Brazil",
"http://www.msinstrumentos.com.br",

/* Speed Calibration screen */
"Flow Rate",
"Neglected Flow",
"Process Flow",
"Data",
"Pulses:",
"Flow:",
"Error:",
"Em",
"V = ",
"m/s",
"Back",
"Next",
"WAIT",

/* Engineering menu */
"Calibration",
"Functions",
"Mechanical Assembly",
"Evaluation",
"Speed Sensor",
"Special Functions",
"Moving Average",
"Belt Tension",
"Mechanical Inspection",

};

#pragma STRING_SEG DEFAULT



#endif   /* ENGLISH_H */









