#include <hidef.h>                           /* common defines and macros */
#include "derivative.h"                      /* derivative information */

/*
** ------------------------------------------------------------------------------
   
   File   : winHistogram.c 
   Aurthor: 
   
   Description:  
   
   Version Log          Notes                                     Changes Made by                                        
   --------------       -----                                     ---------------
   28-02-11:            Created                                   Stuart


** ------------------------------------------------------------------------------
                                    
                                    Overview
                                            
** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

/* library headers */
#include "stdio.h"
#include "float.h"
#include "math.h"

/* Application headers */
#include "CRG 100110.h" 
#include "Subs.h"
#include "ModBusM Int.h"
#include "ModBusM.h"
#include "EEPROM.h"
#include "SLCD 260217.h"
#include "winMain.h"
#include "winKey.h"
#include "Language.h"
#include "SlcdSubs.h"

/* Implements this interface: */
#define WINHISTOGRAM_C
#include "winHistogram.h"

#pragma CODE_SEG WINHISTOGRAM_CODE
#pragma DATA_SEG WINHISTOGRAM_DATA


/* private */
static byte winHistogramsState;
static byte winHistogramsPage;


/* public */



/*
** ------------------------------------------------------------------------------
**		Function: void DisplaySampleRate(void)
** ------------------------------------------------------------------------------
*/

void DisplaySampleRate(void)
{
   slcdSetFont(F16);  
   
   /* set colours back */
   slcdSetColour(LightBlue, White);         

   switch(EEPROM.SampleRate)   
   {
   case 0:
      DisplayText("1 sec   ", 360, ccY0, 0);    
      break;

   case 1:
      DisplayText("1 Hour   ", 360, ccY0, 0);    
      break;

   case 2:
      DisplayText("24 Hours  ", 360, ccY0, 0);    
      break;

   case 3:
      DisplayText("7 Day     ", 360, ccY0, 0);    
      break;

   case 4:
      DisplayText("30 Days  ", 360, ccY0, 0);    
      break;
   }
}

/*
** ------------------------------------------------------------------------------
**		Function: void winHistogramsKeyHandler(byte key)
** ------------------------------------------------------------------------------
*/

void winHistogramsKeyHandler(byte key)
{   
   switch (key)
   {             
   case 128:       /* EXIT */
      /* shut down num key window handler */
      winHistogramsState = WIN_HISTOGRAM_UNLOAD;  
      break;  
   
   case 130:
      
      if(EEPROM.SampleRate<3)
         EEWR_8(&EEPROM.SampleRate, EEPROM.SampleRate+1);   
      else
         EEWR_8(&EEPROM.SampleRate, 0);   

      DisplaySampleRate();  
      subsSetHistogramRate(); 
      break;
      
   case 131:    /*  */
      slcdSetFont(F24B);  
      slcdSetColour(LightBlue, White);         

      if(EEPROM.Histogram)
      {
         EEWR_8(&EEPROM.Histogram, 0);  
         DisplayText("Habilitar   ", 200, 240, 0);     
      }
      else
      {
         EEWR_8(&EEPROM.Histogram, 1);  
         DisplayText("Desativar  ", 200, 240, 0);     
      }
      
      //mbTable[enStdEn].WrFlg = 0x1;
      break;                 
   }
}

/*
** ------------------------------------------------------------------------------
**		Function: void ReadHistogramParameters(void)
** ------------------------------------------------------------------------------
*/

void ReadHistogramParameters(void)
{
   //mbTable[enStdEn].RdFlg = 0x1;
   //mbTable[enStdRate].RdFlg = 0x1;  
}




/*
** ------------------------------------------------------------------------------
**		Function: void PaintHistogramPage(void)
** ------------------------------------------------------------------------------
*/

void PaintHistogramPage(void)
{   
   byte Buf[25];
    
   if(PanelSize == PSZ_1024_600)
      slcdSetFont(F14);  
   else
      slcdSetFont(F16);  
   
   /* set colours back */
   slcdSetColour(DarkGrey, White);         

   /* display headings */
   DisplayText("Intervalo de captura (Hora):", 40, ccY0, 'T');     

   /* set colours back */
   slcdSetColour(LightBlue, White);         

   DisplaySampleRate();   
   
   slcdSetFont(F24B);  
   
   if(EEPROM.Histogram)
      DisplayText("Desativar  ", 200, 240, 0);     
   else
      DisplayText("Habilitar  ", 200, 240, 0);     

   MakeHotSpot(130, 360, 140, 440, 164);
   MakeHotSpot(131, 258, 232, 400, 300);
    
   /* force update */
   //winUpdate1 = 1;
}


/*
** ------------------------------------------------------------------------------
**		Function: void UpdateHistogram(void)
** ------------------------------------------------------------------------------
*/

void UpdateHistogram(void)
{      
   /* requested update */
   if (winUpdate1==1)
   {
      /* stop counter */
      winUpdate1 = 0;   
      
   }

   /* time to update? */
   if (!winTimer1)
   {
      //winTimer1 = 25;
      
   }
}

/*
** ------------------------------------------------------------------------------
**		Function: byte winHistogramHandler(void)
** ------------------------------------------------------------------------------
*/

byte winHistogramHandler(void)
{
   switch (winHistogramsState)
   {
   case WIN_HISTOGRAM_PREPAINT:
      /* get analog parameters from slave */
      ReadHistogramParameters();
      winHistogramsState = WIN_HISTOGRAM_PAINT;
      break;
      
   case WIN_HISTOGRAM_PAINT:
      /* send command to execute macro 2 */
      slcdCallMacro(2);
      /* set forground and back ground colour */
      slcdSetColour(DarkGrey, DarkGrey);
      /* set font */
      slcdSetFont(F24B);         
      
      /* display page title  */
      DisplayText("Histograma", 16, 7, 'T');
      
      /* update parameters */
      winUpdate1 = 1;
      
      /* move to update state */      
      winHistogramsState = WIN_HISTOGRAM_PAINT_PAGE;       
      break;

   case WIN_HISTOGRAM_PAINT_PAGE:         

      /* clear previous hotspots */      
      slcd_CmdQueue("xc all");      
      /* remake back button */
      //slcd_CmdQueue("x 128 560 10 630 60");      
      MakeHotSpot(128, 560, 10, 630, 60); 
      /* make page select buttons */            
               
      PaintHistogramPage();
      
      /* move to update state */      
      winHistogramsState = WIN_HISTOGRAM_UPDATE;       
      break;

   case WIN_HISTOGRAM_UPDATE:
      /* is there a key to process? */
      if (slcdKey)
      {
         /* call key handler */
         winHistogramsKeyHandler(slcdKey);      
         /* now the key has been processed clear it */
         slcdKey = 0; 
      }

      UpdateHistogram();

      /* has any data been remotely changed? */
      if(mbSlave.DataUpdate)
      {
         /* clear data update flag */
         mbSlave.DataUpdate = 0;
         mbTable[enDataUp].WrFlg = 1;   
         
         /* read analog parameters */
         ReadHistogramParameters();  
         
         /* set update timer */                   
         winUpdate1 = 100;
      }      
      return 0;

  case WIN_HISTOGRAM_NUMKEYPAD:
      /* see if key pad is returning */
      if(winKeyPadHandler())
         /* move to update state */      
         winHistogramsState = WIN_HISTOGRAM_PAINT;   
      break;

   case WIN_HISTOGRAM_UNLOAD:
      /* do any necessary clearing up */
      winHistogramsState = WIN_HISTOGRAM_PREPAINT;  

      /* clear page */
      winHistogramsPage = 0;
      
      /* switch to menu screen */
      winActiveWin = USER_WINDOW;  


      /* return from key pad */
      return 1;
   }   
}



