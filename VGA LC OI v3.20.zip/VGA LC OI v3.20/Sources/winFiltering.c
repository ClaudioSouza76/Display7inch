#include <hidef.h>                           /* common defines and macros */
#include "derivative.h"                      /* derivative information */

/*
** ------------------------------------------------------------------------------
   
   File   : winFiltering.c 
   Aurthor: 
   
   Description:  
   
   Version Log          Notes                                     Changes Made by                                        
   --------------       -----                                     ---------------
   25-07-10:            Created                                   Stuart


** ------------------------------------------------------------------------------
                                    
                                    Overview
                                            
** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

/* library headers */
#include "stdio.h"
#include "float.h"
#include "math.h"

/* Application headers */
#include "CRG 100110.h" 
#include "Subs.h"
#include "ModBusM Int.h"
#include "ModBusM.h"
#include "EEPROM.h"
#include "SLCD 260217.h"
#include "winMain.h"
#include "winKey.h"
#include "Language.h"
#include "SlcdSubs.h"


/* Implements this interface: */
#define WINFILTERING_C
#include "winFiltering.h"

#pragma CODE_SEG WINFILTERING_Code
#pragma DATA_SEG WINFILTERING_Data


/* private */
static byte winFilteringState;
static byte winFilteringPage;


/* public */



/*
** ------------------------------------------------------------------------------
**		Function: void winFilteringKeyHandler(byte key)
** ------------------------------------------------------------------------------
*/

void winFilteringKeyHandler(byte key)
{   
   switch (key)
   {
   case 1:
      /* change state */
      mbSlave.RateDampEn ^= 1;
      /* set write flag */
      mbTable[enRateDampEn].WrFlg = 1;       
      break;

   case 2:
      /* change state */
      mbSlave.MassDampEn ^= 1;
      /* set write flag */
      mbTable[enMassDampEn].WrFlg = 1;       
      break;

   case 3:
      /* change state */
      mbSlave.TachoDampEn ^= 1;
      /* set write flag */
      mbTable[enTachoDampEn].WrFlg = 1;       
      break;
            
   case 128:       /* EXIT */
      /* shut down num key window handler */
      winFilteringState = WIN_FILTERING_UNLOAD;  
      break;  
      
   case 130:      /* Rate Damping */
      /* move to key pad handler sate */
      winFilteringState = WIN_FILTERING_NUMKEYPAD; 
      
      /* copy parameter data to key structure */
      strcpy(NumKeyData.Name, gstr(&str->RateFilter));  
      NumKeyData.KeyBoardType = NUMBER;
      NumKeyData.Type = WORD;
      NumKeyData.iMax = 99;
      NumKeyData.Flag = enRateDamp;
      NumKeyData.DataPtr = (void *)&mbSlave.Damp[0];     
      break;      

   case 131:      /* Mass Damping */
      /* move to key pad handler sate */
      winFilteringState = WIN_FILTERING_NUMKEYPAD; 
      
      /* copy parameter data to key structure */
      strcpy(NumKeyData.Name, gstr(&str->MassFilter));  
      NumKeyData.KeyBoardType = NUMBER;
      NumKeyData.Type = WORD;
      NumKeyData.iMin = 2;
      NumKeyData.iMax = 99;
      NumKeyData.Flag = enMassDamp;
      NumKeyData.DataPtr = (void *)&mbSlave.Damp[2];     
      break; 

   case 132:      /* Filter Damping  */
      /* move to key pad handler sate */
      winFilteringState = WIN_FILTERING_NUMKEYPAD; 
      
      /* copy parameter data to key structure */
      strcpy(NumKeyData.Name, gstr(&str->SpeedFilter));  
      NumKeyData.KeyBoardType = NUMBER;
      NumKeyData.Type = WORD;
      NumKeyData.iMax = 99;
      NumKeyData.Flag = enSpeedDamp;
      NumKeyData.DataPtr = (void *)&mbSlave.Damp[3];     
      break;
      
      case 133:      /* Fator K */
      /* move to key pad handler sate */
      winFilteringState = WIN_FILTERING_NUMKEYPAD; 
      
      /* copy parameter data to key structure */
      strcpy(NumKeyData.Name, "Fator K");  
      NumKeyData.KeyBoardType = NUMBER;
      NumKeyData.Type = FLOAT;
      NumKeyData.Attributes = EPROM;
      NumKeyData.fMax = 2;
      NumKeyData.fMin = 0;
      //NumKeyData.Flag  = enFactork;
      NumKeyData.DataPtr = (void *)&mbSlave.fTesteT;
      break;        
         
   }
}

/*
** ------------------------------------------------------------------------------
**		Function: void ReadFilterParameters(void)
** ------------------------------------------------------------------------------
*/

void ReadFilterParameters(void)
{
   mbTable[enRateDamp].RdFlg = 0x1;
   mbTable[enMassDamp].RdFlg = 0x1;
   mbTable[enSpeedDamp].RdFlg = 0x1;     

   mbTable[enRateDampEn].RdFlg = 0x1;
   mbTable[enMassDampEn].RdFlg = 0x1;
   mbTable[enTachoDampEn].RdFlg = 0x1;     

}

/*
** ------------------------------------------------------------------------------
**		Function: void PaintFilteringPage(void)
** ------------------------------------------------------------------------------
*/

void PaintFilteringPage(void)
{   
   byte Buf[25];
   lButtonType Button;   
   byte ButtonText1[20], ButtonText2[20];   
   
   if(PanelSize == PSZ_1024_600)
      slcd_SetFont(14, 0);  
   else
      slcd_SetFont(16, 'B');  
   
   /* set colours back */
   slcd_SetColour(DarkGrey, White);         

   /* display headings */
   slcd_SendText(gstr(&str->RateFilter),  27,   ccY0, 0, LEFT_ALIGN);     
   slcd_SendText(gstr(&str->MassFilter),  27,   ccY2, 0, LEFT_ALIGN);  
   slcd_SendText(gstr(&str->SpeedFilter), 327,  ccY0, 0, LEFT_ALIGN);
   
   slcd_SendText(("Fatork"), 327, ccY2, 0, LEFT_ALIGN);  

   slcd_SetFont(16, 'B');  

   slcd_SendText(gstr(&str->TC),  27,   230, 0, LEFT_ALIGN);
   slcd_SendText(gstr(&str->TC),  27,   372, 0, LEFT_ALIGN);
   slcd_SendText(gstr(&str->TC),  327,  230, 0, LEFT_ALIGN);

   /* set colours back */
   slcd_SetColour(LightBlue, White);         

   /* Rate Damp */
   sprintf(Buf, "%u s  ", mbSlave.Damp[0]);
   slcd_SendText(&Buf, 227, 230, 0, LEFT_ALIGN);

   /* Mass Damp */
   sprintf(Buf, "%u s  ", mbSlave.Damp[2]);
   slcd_SendText(&Buf, 227, 372, 0, LEFT_ALIGN);
   
   /* Speed Damp */
   sprintf(Buf, "%u s  ", mbSlave.Damp[3]);
   slcd_SendText(&Buf, 540, 230, 0, LEFT_ALIGN); 
   
   slcd_MakeHotSpot(130, 220, 240, 32, 128);
   slcd_MakeHotSpot(131, 220, 380, 32, 128);   
   slcd_MakeHotSpot(132, 540, 240, 32, 128);

   //slcd_MakeHotSpot(133 540 380 600 424");

   if(PanelSize == PSZ_1024_600)
      slcd_SetFont(14, 0);  
   
   /* set colours back */
   slcd_SetColour(Red, White); 
   
   Button.Id = 1;
   Button.x = 227;
   Button.y = ccY0;
   Button.type = 2;
   Button.state = mbSlave.RateDampEn;
   strcpy(ButtonText1, gstr(&str->OFF));      
   strcpy(ButtonText2, gstr(&str->ON));      
   Button.text0 = ButtonText1;
   Button.text1 = ButtonText2;
   Button.dx0 = 16;
   Button.dy0 = 8;
   Button.dx1 = 18;
   Button.dy1 = 2;
   Button.bmp0 = 27;
   Button.bmp1 = 26;  
       
   /* define start/stop button */
   slcd_MakeLatchingButton(&Button);  

   Button.Id = 2;
   Button.x = 227;
   Button.y = ccY2;
   Button.state = mbSlave.MassDampEn;
       
   /* define start/stop button */
   slcd_MakeLatchingButton(&Button);  

   Button.Id = 3;
   Button.x = 540;
   Button.y = ccY0;
   Button.state = mbSlave.TachoDampEn;
       
   /* define start/stop button */
   slcd_MakeLatchingButton(&Button);  

   /* force update */
   winUpdate1 = 1;
}


/*
** ------------------------------------------------------------------------------
**		Function: void UpdateFiltering(void)
** ------------------------------------------------------------------------------
*/

void UpdateFiltering(void)
{   
   byte Buf[25];
   
   /* requested update */
   if (winUpdate1==1)
   {
      /* stop counter */
      winUpdate1 = 0;

      /* set colours back */
      slcd_SetColour(LightBlue, White);       
      slcd_SetFont(16, 'B');  
      
      /* Rate Damp */
      sprintf(Buf, "%u s  ", mbSlave.Damp[0]);
      slcd_SendText(&Buf, 227, 230, 0, LEFT_ALIGN);

      /* Mass Damp */
      sprintf(Buf, "%u s  ", mbSlave.Damp[2]);
      slcd_SendText(&Buf, 227, 372, 0, LEFT_ALIGN);
      
      /* Speed Damp */
      sprintf(Buf, "%u s  ", mbSlave.Damp[3]);
      slcd_SendText(&Buf, 540, 230, 0, LEFT_ALIGN);    
   
      slcd_SetFont(14, 0); 
   }

   /* time to update? */
   if (!winTimer1)
   {
      //winTimer1 = 25;

     
   }
}

/*
** ------------------------------------------------------------------------------
**		Function: byte winFilteringHandler(void)
** ------------------------------------------------------------------------------
*/

byte winFilteringHandler(void)
{
   switch (winFilteringState)
   {
   case WIN_FILTERING_PREPAINT:
      /* get analog parameters from slave */
      ReadFilterParameters();
      winFilteringState = WIN_FILTERING_PAINT;
      break;
      
   case WIN_FILTERING_PAINT:
      slcd_SetColour(DarkGrey, DarkGrey);
      slcd_Send("z");

      slcd_Send("xc all");     
      /* display menu screen */
      //DisplayBmp(16, 0, 0, LEFT_ALIGN); 
      slcd_DisplayBmp(10, 0, 0); 

      DisplayTitle("MS Instrumentos");
      
      slcd_SetFont(24, 0);
      slcd_SetColour(DarkGrey, White); 
      slcd_SendText(gstr(&str->Filtering), 15, 60, 0, LEFT_ALIGN);
      
      /* define back hotspot */
      //slcd_CmdQueue("x 128 560 10 630 60");
      slcd_MakeHotSpot(128, 560, 10, 50, 50);
      
      /* update parameters */
      winUpdate1 = 1;
      
      /* move to update state */      
      winFilteringState = WIN_FILTERING_PAINT_PAGE;       
      break;

   case WIN_FILTERING_PAINT_PAGE:

      PaintFilteringPage();
      
      /* move to update state */      
      winFilteringState = WIN_FILTERING_UPDATE;       
      break;

   case WIN_FILTERING_UPDATE:
      /* is there a key to process? */
      if (slcdKey)
      {
         /* call key handler */
         winFilteringKeyHandler(slcdKey);      
         /* now the key has been processed clear it */
         slcdKey = 0; 
      }

      UpdateFiltering();

      /* has any data been remotely changed? */
      if(mbSlave.DataUpdate)
      {
         /* clear data update flag */
         mbSlave.DataUpdate = 0;
         mbTable[enDataUp].WrFlg = 1;   
         
         /* read analog parameters */
         ReadFilterParameters();  
         
         /* set update timer */                   
         winUpdate1 = 100;
      }      
      break;

  case WIN_FILTERING_NUMKEYPAD:
      /* see if key pad is returning */
      if(winKeyPadHandler())
         /* move to update state */      
         winFilteringState = WIN_FILTERING_PAINT;   
      break;

   case WIN_FILTERING_UNLOAD:
      /* do any necessary clearing up */
      winFilteringState = WIN_FILTERING_PREPAINT;  

      /* clear page */
      winFilteringPage = 0;
      
      /* switch to menu screen */
      winActiveWin = SPECIALFUNC_WINDOW;  


      /* return from key pad */
      return 1;
   }   
}



