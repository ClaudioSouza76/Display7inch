/*
** ------------------------------------------------------------------------------
   
   File   : winCalFunctions.h 
   Aurthor: Stuart Clarke

** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

#ifndef WINCAL_FUNCTION_H
#define WINCAL_FUNCTION_H


/* public defines */


/*
** ------------------------------------------------------------------------------
**		#define : diagnostics handler states 
** ------------------------------------------------------------------------------
*/

#define WIN_CAL_FUNCTION_PREPAINT     0
#define WIN_CAL_FUNCTION_PAINT        1
#define WIN_CAL_FUNCTION_PAINT_PAGE   2
#define WIN_CAL_FUNCTION_UPDATE       3
#define WIN_CAL_FUNCTION_NUMKEYPAD    4
#define WIN_CAL_FUNCTION_UNLOAD       5




#ifndef WIN_CAL_FUNCTION_C

/* public variables */
#pragma DATA_SEG WINCALFUNCTION_DATA


#endif   /* WINCAL_FUNCTION_C */      


/* public functions */
#pragma CODE_SEG WINCALFUNCTION_CODE

/*
** ------------------------------------------------------------------------------
**		Function: void ReadCalFuncParameters(void)
** ------------------------------------------------------------------------------
*/

void ReadCalFuncParameters(void);

/*
** ------------------------------------------------------------------------------
**		Function: byte winCalFunctionsHandler(void)
** ------------------------------------------------------------------------------
*/

byte winCalFunctionsHandler(void);

#endif   /* WINRANGES_H */
