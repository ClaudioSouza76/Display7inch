/*
** ------------------------------------------------------------------------------
   
   File   : winFiltering.h 
   Aurthor: Stuart Clarke

** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

#ifndef WINFILTERING_H
#define WINFILTERING_H


/* public defines */


/*
** ------------------------------------------------------------------------------
**		#define : diagnostics handler states 
** ------------------------------------------------------------------------------
*/

#define WIN_FILTERING_PREPAINT     0
#define WIN_FILTERING_PAINT        1
#define WIN_FILTERING_PAINT_PAGE   2
#define WIN_FILTERING_UPDATE       3
#define WIN_FILTERING_NUMKEYPAD    4
#define WIN_FILTERING_UNLOAD       5




#ifndef WIN_FILTERING_C

/* public variables */
#pragma DATA_SEG WINFILTERING_Data


#endif   /* WINFILTERING_C */      


/* public functions */
#pragma CODE_SEG WINFILTERING_Code

/*
** ------------------------------------------------------------------------------
**		Function: void ReadFilterParameters(void)
** ------------------------------------------------------------------------------
*/

void ReadFilterParameters(void);

/*
** ------------------------------------------------------------------------------
**		Function: byte winFilteringHandler(void)
** ------------------------------------------------------------------------------
*/

byte winFilteringHandler(void);

#endif   /* WINRANGES_H */
