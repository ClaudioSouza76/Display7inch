#include <hidef.h>                           /* common defines and macros */
#include "derivative.h"                      /* derivative information */

/*
** ------------------------------------------------------------------------------
   
   File   : winAlarmSettings.c 
   Aurthor: 
   
   Description:  
   
   Version Log          Notes                                     Changes Made by                                        
   --------------       -----                                     ---------------
   27-07-10:            Created                                   Stuart


** ------------------------------------------------------------------------------
                                    
                                    Overview
                                            
** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

/* library headers */
#include "stdio.h"
#include "float.h"
#include "math.h"

/* Application headers */
#include "CRG 100110.h" 
#include "Subs.h"
#include "ModBusM Int.h"
#include "ModBusM.h"
#include "EEPROM.h"
#include "SLCD 100721.h"
#include "winMain.h"
#include "winKey.h"
#include "Language.h"


/* Implements this interface: */
#define WINALARMS_C
#include "winAlarmSettings.h"

#pragma CODE_SEG WINALARMS_Code
#pragma DATA_SEG WINALARMS_Data


/* private */
static byte winAlarmsState;
static byte winAlarmsPage;


/* public */



/*
** ------------------------------------------------------------------------------
**		Function: void winAlarmsKeyHandler(byte key)
** ------------------------------------------------------------------------------
*/

void winAlarmsKeyHandler(byte key)
{   
   switch (key)
   {
   case 1:
      if(winAlarmsPage)
         winAlarmsPage--;
      
      /* move to update state */      
      winAlarmsState = WIN_ALARMS_PAINT_PAGE;         
      break;
      

   case 2:
      if(winAlarmsPage<1)
         winAlarmsPage++;
      
      /* move to update state */      
      winAlarmsState = WIN_ALARMS_PAINT_PAGE;         
      break;
      
   case 128:       /* EXIT */
      /* shut down num key window handler */
      winAlarmsState = WIN_ALARMS_UNLOAD;  
      break;  
      
   case 130:      /* Mass Alarm hotspot */
      /* move to key pad handler sate */
      winAlarmsState = WIN_ALARMS_NUMKEYPAD; 
      
      /* copy parameter data to key structure */
      strcpy(NumKeyData.Name, gstr(&str->HighAlarm) );  
      NumKeyData.Type = FLOAT;
      NumKeyData.KeyBoardType = NUMBER;
      NumKeyData.fMax = 100.0;
      NumKeyData.fMin = 0.0;
      NumKeyData.Index = 0;
      NumKeyData.Flag  = enAlrHi3;
      
      NumKeyData.DataPtr = (void *)&mbSlave.AlarmHi[2];      
      break;                

   case 131:      /* Mass Alarm hotspot */
      /* move to key pad handler sate */
      winAlarmsState = WIN_ALARMS_NUMKEYPAD; 
      
      /* copy parameter data to key structure */
      strcpy(NumKeyData.Name, gstr(&str->LowAlarm) );  
      NumKeyData.Type = FLOAT;
      NumKeyData.KeyBoardType = NUMBER;
      NumKeyData.fMax = 100.0;
      NumKeyData.fMin = 0.0;
      NumKeyData.Index = 0;
      NumKeyData.Flag  = enAlrLo3;
      
      NumKeyData.DataPtr = (void *)&mbSlave.AlarmLo[2];      
      break;                

 case 132:      /* Mass Hyst hotspot */
      /* move to key pad handler sate */
      winAlarmsState = WIN_ALARMS_NUMKEYPAD; 
      
      /* copy parameter data to key structure */
      strcpy(NumKeyData.Name, gstr(&str->Hysteresis) );  
      NumKeyData.Type = FLOAT;
      NumKeyData.KeyBoardType = NUMBER;
      NumKeyData.fMax = 100.0;
      NumKeyData.fMin = 0.0;
      NumKeyData.Index = 0;
      NumKeyData.Flag  = enHyst3;
      
      NumKeyData.DataPtr = (void *)&mbSlave.Hysteresis[2];      
      break;                
      
   case 133:      /* Rate Alarm hotspot */
      /* move to key pad handler sate */
      winAlarmsState = WIN_ALARMS_NUMKEYPAD; 
      
      /* copy parameter data to key structure */
      strcpy(NumKeyData.Name, gstr(&str->HighAlarm) );  
      NumKeyData.Type = FLOAT;
      NumKeyData.KeyBoardType = NUMBER;
      NumKeyData.fMax = 100.0;
      NumKeyData.fMin = 0.0;
      NumKeyData.Index = 0;
      NumKeyData.Flag  = enAlrHi1;
      
      NumKeyData.DataPtr = (void *)&mbSlave.AlarmHi[0];      
      break;                

   case 134:      /* Rate Alarm hotspot */
      /* move to key pad handler sate */
      winAlarmsState = WIN_ALARMS_NUMKEYPAD; 
      
      /* copy parameter data to key structure */
      strcpy(NumKeyData.Name, gstr(&str->LowAlarm) );  
      NumKeyData.Type = FLOAT;
      NumKeyData.KeyBoardType = NUMBER;
      NumKeyData.fMax = 100.0;
      NumKeyData.fMin = 0.0;
      NumKeyData.Index = 0;
      NumKeyData.Flag  = enAlrLo1;
      
      NumKeyData.DataPtr = (void *)&mbSlave.AlarmLo[0];      
      break; 

   case 135:      /* Rate Hyst hotspot */
      /* move to key pad handler sate */
      winAlarmsState = WIN_ALARMS_NUMKEYPAD; 
      
      /* copy parameter data to key structure */
      strcpy(NumKeyData.Name, gstr(&str->Hysteresis) );  
      NumKeyData.Type = FLOAT;
      NumKeyData.KeyBoardType = NUMBER;
      NumKeyData.fMax = 100.0;
      NumKeyData.fMin = 0.0;
      NumKeyData.Index = 0;
      NumKeyData.Flag  = enHyst1;
      
      NumKeyData.DataPtr = (void *)&mbSlave.Hysteresis[0];      
      break;       
      
   case 136:      /* Speed Alarm hotspot */
      /* move to key pad handler sate */
      winAlarmsState = WIN_ALARMS_NUMKEYPAD; 
      
      /* copy parameter data to key structure */
      strcpy(NumKeyData.Name, gstr(&str->HighAlarm) );  
      NumKeyData.Type = FLOAT;
      NumKeyData.KeyBoardType = NUMBER;
      NumKeyData.fMax = 100.0;
      NumKeyData.fMin = 0.0;
      NumKeyData.Index = 0;
      NumKeyData.Flag  = enAlrHi4;
      
      NumKeyData.DataPtr = (void *)&mbSlave.AlarmHi[3];      
      break;                

   case 137:      /* Speed Alarm hotspot */
      /* move to key pad handler sate */
      winAlarmsState = WIN_ALARMS_NUMKEYPAD; 
      
      /* copy parameter data to key structure */
      strcpy(NumKeyData.Name, gstr(&str->LowAlarm) );  
      NumKeyData.Type = FLOAT;
      NumKeyData.KeyBoardType = NUMBER;
      NumKeyData.fMax = 100.0;
      NumKeyData.fMin = 0.0;
      NumKeyData.Index = 0;
      NumKeyData.Flag  = enAlrLo4;
      
      NumKeyData.DataPtr = (void *)&mbSlave.AlarmLo[3];      
      break;                

   case 138:      /* Speed Hyst hotspot */
      /* move to key pad handler sate */
      winAlarmsState = WIN_ALARMS_NUMKEYPAD; 
      
      /* copy parameter data to key structure */
      strcpy(NumKeyData.Name, gstr(&str->Hysteresis) );  
      NumKeyData.Type = FLOAT;
      NumKeyData.KeyBoardType = NUMBER;
      NumKeyData.fMax = 100.0;
      NumKeyData.fMin = 0.0;
      NumKeyData.Index = 0;
      NumKeyData.Flag  = enHyst4;
      
      NumKeyData.DataPtr = (void *)&mbSlave.Hysteresis[3];      
      break;       
      
 case 139:      /* Deviation Alarm hotspot */
      /* move to key pad handler sate */
      winAlarmsState = WIN_ALARMS_NUMKEYPAD; 
      
      /* copy parameter data to key structure */
      strcpy(NumKeyData.Name, gstr(&str->HighAlarm) );  
      NumKeyData.Type = FLOAT;
      NumKeyData.KeyBoardType = NUMBER;
      NumKeyData.fMax = 100.0;
      NumKeyData.fMin = 0.0;
      NumKeyData.Index = 0;
      NumKeyData.Flag  = enAlrHi2;
      
      NumKeyData.DataPtr = (void *)&mbSlave.AlarmHi[1];      
      break;                

   case 140:      /* Deviation Alarm hotspot */
      /* move to key pad handler sate */
      winAlarmsState = WIN_ALARMS_NUMKEYPAD; 
      
      /* copy parameter data to key structure */
      strcpy(NumKeyData.Name, gstr(&str->LowAlarm) );  
      NumKeyData.Type = FLOAT;
      NumKeyData.KeyBoardType = NUMBER;
      NumKeyData.fMax = 100.0;
      NumKeyData.fMin = 0.0;
      NumKeyData.Index = 0;
      NumKeyData.Flag  = enAlrLo2;
      
      NumKeyData.DataPtr = (void *)&mbSlave.AlarmLo[1];      
      break;       
      
   case 141:      /* Deviation Hyst hotspot */
      /* move to key pad handler sate */
      winAlarmsState = WIN_ALARMS_NUMKEYPAD; 
      
      /* copy parameter data to key structure */
      strcpy(NumKeyData.Name, gstr(&str->Hysteresis) );  
      NumKeyData.Type = FLOAT;
      NumKeyData.KeyBoardType = NUMBER;
      NumKeyData.fMax = 100.0;
      NumKeyData.fMin = 0.0;
      NumKeyData.Index = 0;
      NumKeyData.Flag  = enHyst2;
      
      NumKeyData.DataPtr = (void *)&mbSlave.Hysteresis[1];      
      break;                      

   }
}

/*
** ------------------------------------------------------------------------------
**		Function: void ReadAlarmParameters(void)
** ------------------------------------------------------------------------------
*/

void ReadAlarmParameters(void)
{
   mbTable[enAlrLo1].RdFlg = 1; 
   mbTable[enAlrLo2].RdFlg = 1; 
   mbTable[enAlrLo3].RdFlg = 1; 
   mbTable[enAlrLo4].RdFlg = 1; 
   
   mbTable[enAlrHi1].RdFlg = 1; 
   mbTable[enAlrHi2].RdFlg = 1; 
   mbTable[enAlrHi3].RdFlg = 1; 
   mbTable[enAlrHi4].RdFlg = 1; 

   mbTable[enHyst1].RdFlg = 1; 
   mbTable[enHyst2].RdFlg = 1; 
   mbTable[enHyst3].RdFlg = 1; 
   mbTable[enHyst4].RdFlg = 1;    
}

/*
** ------------------------------------------------------------------------------
**		Function: void PaintAlarmsPage(void)
** ------------------------------------------------------------------------------
*/

void PaintAlarmsPage(void)
{   
   switch (winAlarmsPage)
   {
   case 0:

      slcdSetFont(F16B);  
      /* set colours */
      slcdSetColour(DarkGrey, White);         

      /* display headings */
      slcdDisplayText(gstr(&str->MassAlarms),  getX(20),   getY(80), 'T');  
      slcdDisplayText(gstr(&str->RateAlarms),  getX(245),   getY(80), 'T');  
      
      slcdSetFont(F16);  

      slcdDisplayText(gstr(&str->HighAlarm),  getX(20),  getY(ccY1), 'T');         
      slcdDisplayText(gstr(&str->LowAlarm),   getX(20),  getY(ccY2), 'T');         
      slcdDisplayText(gstr(&str->Hysteresis), getX(20),  getY(ccY3), 'T');         

      slcdDisplayText(gstr(&str->HighAlarm),  getX(245),  getY(ccY1), 'T');         
      slcdDisplayText(gstr(&str->LowAlarm),   getX(245),  getY(ccY2), 'T');         
      slcdDisplayText(gstr(&str->Hysteresis), getX(245),  getY(ccY3), 'T');         

      slcd_CmdQueue("xs 130 114 97 152 117");
      slcd_CmdQueue("xs 131 114 132 152 152");
      slcd_CmdQueue("xs 132 114 168 152 181");

      slcd_CmdQueue("xs 133 270 97 304 117");
      slcd_CmdQueue("xs 134 270 132 304 152");
      slcd_CmdQueue("xs 135 270 168 304 181");

      /* force update */
      winUpdate1 = 1;
      break;
      
   case 1:

      slcdSetFont(F16B);  
      /* set colours */
      slcdSetColour(DarkGrey, White);         

      /* display headings */
      slcdDisplayText(gstr(&str->SpeedAlarms),      getX(20),   getY(80), 'T');  
      slcdDisplayText(gstr(&str->DeviationAlarms),  getX(245),  getY(80), 'T');  
      
      slcdSetFont(F16);  

      slcdDisplayText(gstr(&str->HighAlarm),  getX(20),  getY(ccY1), 'T');         
      slcdDisplayText(gstr(&str->LowAlarm),   getX(20),  getY(ccY2), 'T');         
      slcdDisplayText(gstr(&str->Hysteresis), getX(20),  getY(ccY3), 'T');         

      slcdDisplayText(gstr(&str->HighAlarm),  getX(245),  getY(ccY1), 'T');         
      slcdDisplayText(gstr(&str->LowAlarm),   getX(245),  getY(ccY2), 'T');         
      slcdDisplayText(gstr(&str->Hysteresis), getX(245),  getY(ccY3), 'T');         

      slcd_CmdQueue("xs 136 114 97 152 117");
      slcd_CmdQueue("xs 137 114 132 152 152");
      slcd_CmdQueue("xs 138 114 168 152 181");

      slcd_CmdQueue("xs 139 270 97 304 117");
      slcd_CmdQueue("xs 140 270 132 304 152");
      slcd_CmdQueue("xs 141 270 168 304 181");
      
      /* force update */
      winUpdate1 = 1;
      break;
   }
}


/*
** ------------------------------------------------------------------------------
**		Function: void UpdateAlarms(void)
** ------------------------------------------------------------------------------
*/

void UpdateAlarms(void)
{
   byte Buf[25];
   
   /* requested update */
   if (winUpdate1==1)
   {
      /* stop counter */
      winUpdate1 = 0;

      slcdSetFont(F16B);  
      slcdSetColour(LightBlue, White);  

      switch (winAlarmsPage)
      {
      case 0:
         /* display Mass alarms */      
         sprintf(Buf, "%.1f %%", mbSlave.AlarmHi[2]);
         slcdDisplayText(&Buf, getX(170), getY(ccY1), 0);    

         sprintf(Buf, "%.1f %%", mbSlave.AlarmLo[2]);
         slcdDisplayText(&Buf, getX(170), getY(ccY2), 0);    

         sprintf(Buf, "%.1f %%", mbSlave.Hysteresis[2]);
         slcdDisplayText(&Buf, getX(170), getY(ccY3), 0);    

         /* display Rate alarms */      
         //slcd_CmdQueue("xic 2 0 0 405 110 480 140");  
         
         sprintf(Buf, "%.1f %%", mbSlave.AlarmHi[0]);
         slcdDisplayText(&Buf, getX(405), getY(ccY1), 'T');    

         //slcd_CmdQueue("xic 2 0 0 405 150 480 180");  
         
         sprintf(Buf, "%.1f %%", mbSlave.AlarmLo[0]);
         slcdDisplayText(&Buf, getX(405), getY(ccY2), 'T');    

         //slcd_CmdQueue("xic 2 0 0 405 190 480 220");  
         
         sprintf(Buf, "%.1f %%", mbSlave.Hysteresis[0]);
         slcdDisplayText(&Buf, getX(405), getY(ccY3), 'T');    
         break;
         
      case 1:
         /* display Speed alarms */      
         sprintf(Buf, "%.1f %%", mbSlave.AlarmHi[3]);
         slcdDisplayText(&Buf, getX(170), getY(ccY1), 0);    

         sprintf(Buf, "%.1f %%", mbSlave.AlarmLo[3]);
         slcdDisplayText(&Buf, getX(170), getY(ccY2), 0);
         
         sprintf(Buf, "%.1f %%", mbSlave.Hysteresis[3]);
         slcdDisplayText(&Buf, getX(170), getY(ccY3), 0);             

         /* display Deviation alarms */      
         //slcd_CmdQueue("xic 2 0 0 405 110 480 140"); 
         
         sprintf(Buf, "%.1f %%", mbSlave.AlarmHi[1]);
         slcdDisplayText(&Buf, getX(405), getY(ccY1), 'T');    

         //slcd_CmdQueue("xic 2 0 0 405 150 480 180");  
         
         sprintf(Buf, "%.1f %%", mbSlave.AlarmLo[1]);
         slcdDisplayText(&Buf, getX(405), getY(ccY2), 'T'); 
         
         //slcd_CmdQueue("xic 2 0 0 405 190 480 220"); 
         
         sprintf(Buf, "%.1f %%", mbSlave.Hysteresis[1]);
         slcdDisplayText(&Buf, getX(405), getY(ccY3), 'T');             
         break;
      }
   }

   /* time to update? */
   if (!winTimer1)
   {
      winTimer1 = 25;

     
   }
}

/*
** ------------------------------------------------------------------------------
**		Function: byte winAlarmsHandler(void)
** ------------------------------------------------------------------------------
*/

byte winAlarmsHandler(void)
{
   switch (winAlarmsState)
   {
   case WIN_ALARMS_PREPAINT:
      /* get analog parameters from slave */
      ReadAlarmParameters();
      winAlarmsState = WIN_ALARMS_PAINT;
      break;
      
   case WIN_ALARMS_PAINT:
      /* send command to execute macro 2 */
      slcdCallMacro(2);
      /* set forground and back ground colour */
      slcdSetColour(DarkGrey, DarkGrey);
      /* set font */
      slcdSetFont(F24B);         
      
      /* display page title  */
      slcdDisplayText(gstr(&str->AlarmSettings), getX(12),  getY(4), 'T');
      
      /* update parameters */
      winUpdate1 = 1;
      
      /* move to update state */      
      winAlarmsState = WIN_ALARMS_PAINT_PAGE;       
      return 0;

   case WIN_ALARMS_PAINT_PAGE:
   
      #ifdef FIVEPOINTSEVEN
      /* clear previous page */
      slcd_CmdQueue("xic 10 0 0 1 56 320 240");
      #else
      slcd_CmdQueue("xic 10 0 0 1 64 480 272");
      #endif

      /* clear previous hotspots */      
      slcd_CmdQueue("xc all");      
      /* define back hotspot */
      slcd_CmdQueue("xs 128 280 5 315 30");    
      /* make page select buttons */
      slcdMakeButton(1, getX(362), getY(50), "", 20, 21);
      slcdMakeButton(2, getX(414), getY(50), "", 22, 21);
      
               
      PaintAlarmsPage();
      
      /* move to update state */      
      winAlarmsState = WIN_ALARMS_UPDATE;       
      break;

   case WIN_ALARMS_UPDATE:
      /* is there a key to process? */
      if (slcdKey)
      {
         /* call key handler */
         winAlarmsKeyHandler(slcdKey);      
         /* now the key has been processed clear it */
         slcdKey = 0; 
      }

      UpdateAlarms();

      /* has any data been remotely changed? */
      if(mbSlave.DataUpdate)
      {
         /* clear data update flag */
         mbSlave.DataUpdate = 0;
         mbTable[enDataUp].WrFlg = 1;   
         
         /* read analog parameters */
         ReadAlarmParameters();  
         
         /* set update timer */                   
         winUpdate1 = 100;
      }      
      return 0;

  case WIN_ALARMS_NUMKEYPAD:
      /* see if key pad is returning */
      if(winKeyPadHandler())
         /* move to update state */      
         winAlarmsState = WIN_ALARMS_PAINT;   
      break;

   case WIN_ALARMS_UNLOAD:
      /* do any necessary clearing up */
      winAlarmsState = WIN_ALARMS_PREPAINT;  

      /* clear page */
      winAlarmsPage = 0;
      
      /* switch to menu screen */
      winActiveWin = BASIC_CONFIG_WINDOW;  


      /* return from key pad */
      return 1;
   }   
}



