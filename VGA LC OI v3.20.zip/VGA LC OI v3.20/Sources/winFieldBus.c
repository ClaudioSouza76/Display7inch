#include <hidef.h>                           /* common defines and macros */
#include "derivative.h"                      /* derivative information */

/*
** ------------------------------------------------------------------------------
   
   File   : winFieldBus.c 
   Aurthor: 
   
   Description:  
   
   Version Log          Notes                                     Changes Made by                                        
   --------------       -----                                     ---------------
   28-08-09:            Created                                   Stuart


** ------------------------------------------------------------------------------
                                    
                                    Overview
                                            
** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

/* library headers */
#include "stdio.h"
#include "float.h"
#include "math.h"

/* Application headers */
#include "CRG 100110.h" 
#include "Subs.h"
#include "ModBusM Int.h"
#include "ModBusM.h"
#include "EEPROM.h"
#include "SLCD 260217.h"
#include "winMain.h"
#include "winKey.h"
#include "Language.h"
#include "winConfirm.h"
#include "SlcdSubs.h"

/* Implements this interface: */
#define WINFIELDBUS_C
#include "winFieldBus.h"

#pragma CODE_SEG WINFIELDBUS_Code
#pragma DATA_SEG WINFIELDBUS_Data


/* private */
static byte winFieldBusState;
static byte EditFlag;

/* FieldBus screen layout (640x480 logical, scaled by slcd_SendText) */
#define FB_BUS_Y        110
#define FB_ROW1_Y       170   /* first data row below bus type label */
#define FB_ROW_DY       36    /* standard row spacing */
#define FB_ROW(n)       (FB_ROW1_Y + (((n) - 1) * FB_ROW_DY))
#define FB_IP_ROW_Y     FB_ROW(1)
#define FB_SUB_ROW_Y    FB_ROW(2)
#define FB_DHCP_ROW_Y   FB_ROW(3)
#define FB_STN_ROW_Y    FB_ROW(4)
#define FB_LBL_X        27
#define FB_SAVE_X       507
#define FB_IP0_X        227
#define FB_IP1_X        293
#define FB_IP2_X        360
#define FB_IP3_X        427
#define FB_DOT0_X       280
#define FB_DOT1_X       347
#define FB_DOT2_X       413
#define FB_VAL_X        227
#define FB_PB_NODE_X    240
#define FB_PB_NODE_HS_Y FB_SUB_ROW_Y
#define FB_PB_END_HS_Y  FB_DHCP_ROW_Y
#define FB_HS_H         32


/* public */


/*
** ------------------------------------------------------------------------------
**		Function: void winFieldBusKeyHandler(byte key)
** ------------------------------------------------------------------------------
*/

void winFieldBusKeyHandler(byte key)
{   
   switch (key)
   {
   case 128:       /* EXIT */
      /* shut down num key window handler */
      winFieldBusState = WIN_FIELDBUS_UNLOAD;  
      break;       

   case 130:       /* IPADR[0] */
      /* move to key pad handler sate */
      winFieldBusState = WIN_FIELDBUS_NUMKEYPAD; 
      
      /* copy parameter data to key structure */
      strcpy(NumKeyData.Name, "IP Address" );  
      NumKeyData.KeyBoardType = NUMBER;
      NumKeyData.Type = IPADR;
      NumKeyData.Index = 0;
      NumKeyData.Flag  = enIpAdr;       
        
      NumKeyData.DataPtr  = (byte *)&mbSlave.IpAdr+0;
      NumKeyData.DataPtr1 = (byte *)&mbSlave.IpAdr+1;
      NumKeyData.DataPtr2 = (byte *)&mbSlave.IpAdr+2;
      NumKeyData.DataPtr3 = (byte *)&mbSlave.IpAdr+3;
      break; 
      
  case 134:       /* SubNet[0] */
      /* move to key pad handler sate */
      winFieldBusState = WIN_FIELDBUS_NUMKEYPAD; 

      /* copy parameter data to key structure */
      strcpy(NumKeyData.Name, "SubNet" );  
      NumKeyData.KeyBoardType = NUMBER;
      NumKeyData.Type = IPADR;
      NumKeyData.Index = 0;
      NumKeyData.Flag  = enSubNet;       
               
      NumKeyData.DataPtr  = (byte *)&mbSlave.SubNet+0;
      NumKeyData.DataPtr1 = (byte *)&mbSlave.SubNet+1;
      NumKeyData.DataPtr2 = (byte *)&mbSlave.SubNet+2;
      NumKeyData.DataPtr3 = (byte *)&mbSlave.SubNet+3;
      break;       

  case 138:       /* DHCP */
      /* move to key pad handler sate */
      winFieldBusState = WIN_FIELDBUS_NUMKEYPAD; 
            
      /* copy parameter data to key structure */
      strcpy(NumKeyData.Name, gstr(&str->DHCP));  
      NumKeyData.KeyBoardType = NUMBER;
      NumKeyData.Type = BYTE;
      NumKeyData.iMax = 1;
      NumKeyData.iMin = 0;
      NumKeyData.Index = 0;
      NumKeyData.Flag  = enDHCP;
      NumKeyData.DataPtr = (void *)&mbSlave.DHCP;
      break;  

  case 139:       /* PB Adr */
      /* move to key pad handler sate */
      winFieldBusState = WIN_FIELDBUS_NUMKEYPAD; 
            
      /* copy parameter data to key structure */
      strcpy(NumKeyData.Name, "Node Address");  
      NumKeyData.KeyBoardType = NUMBER;
      NumKeyData.Type = BYTE;
      NumKeyData.iMax = 125;
      NumKeyData.iMin = 0;
      NumKeyData.Index = 0;
      NumKeyData.Flag  = enPbAdr;
      NumKeyData.DataPtr = (void *)&mbSlave.PbNodeAdr;
      break;  

  case 140:       /* Endian */
      /* move to key pad handler sate */
      winFieldBusState = WIN_FIELDBUS_NUMKEYPAD; 
            
      /* copy parameter data to key structure */
      strcpy(NumKeyData.Name, "Endian");  
      NumKeyData.KeyBoardType = NUMBER;
      NumKeyData.Type = BYTE;
      NumKeyData.iMax = 1;
      NumKeyData.iMin = 0;
      NumKeyData.Index = 0;
      NumKeyData.Flag  = enEndian;
      NumKeyData.DataPtr = (void *)&mbSlave.Endian;
      break;  
      
   case 141:       /* Station name */
      /* move to key pad handler sate */
      winFieldBusState = WIN_FIELDBUS_NUMKEYPAD; 
            
      /* copy parameter data to key structure */
      strcpy(NumKeyData.Name, "Station Name");  
      NumKeyData.KeyBoardType = LETTER;
      NumKeyData.Type = STRING;
      NumKeyData.iMin = 1;
      NumKeyData.iMax = 16;
      NumKeyData.Index = 0;
      NumKeyData.Attributes = 0;
      NumKeyData.Flag  = enStationName;
      NumKeyData.DataPtr  = (void *)&mbSlave.StationName;           
      break;        
   }
}

/*
** ------------------------------------------------------------------------------
**		Function: void ReadFielBusParameters(void)
** ------------------------------------------------------------------------------
*/

void SaveFieldBusParameters(void)
{
   /* which parameter has been saved ? */
   if(EditFlag&0x01)
   {
      //mbTable[enIpAdr].WrFlg = 0x1;
      //SaveIPAdr();
   }
      
   if(EditFlag&0x02)
   {
      //mbTable[enSubNet].WrFlg = 0x1;
      //SaveSubNet();
   }
   
   
   EditFlag = 0;
}


/*
** ------------------------------------------------------------------------------
**		Function: void ReadFielBusParameters(void)
** ------------------------------------------------------------------------------
*/

void ReadFieldBusParameters(void)
{   
   if(!EditFlag)
   {
      mbTable[enBusType].RdFlg = 0x1;

      switch (mbSlave.BusType)
      {
      case 0x85:     /* Ethernet */
      case 0x96:     /* Profinet*/
         mbTable[enIpAdr].RdFlg = 0x1;
         mbTable[enSubNet].RdFlg = 0x1;
         mbTable[enDHCP].RdFlg = 0x1;
         
         if(mbSlave.BusType == 0x96)
            mbTable[enStationName].RdFlg = 0x1;
         break;
      
      case 0x84:     /* Profinet 1P */
         mbTable[enIpAdr].RdFlg = 0x1;
         mbTable[enSubNet].RdFlg = 0x1;
         mbTable[enDHCP].RdFlg = 0x1;
         
         if(mbSlave.BusType == 0x84)
            mbTable[enStationName].RdFlg = 0x1;
         break;
         
      case 0x89:    /* Profinet IRT*/
         mbTable[enIpAdr].RdFlg = 0x1;
         mbTable[enSubNet].RdFlg = 0x1;
         mbTable[enDHCP].RdFlg = 0x1;
         
         if(mbSlave.BusType == 0x89)
            mbTable[enStationName].RdFlg = 0x1;
         break;
      
      case 0xAD:    /* Profinet IOT*/
         mbTable[enIpAdr].RdFlg = 0x1;
         mbTable[enSubNet].RdFlg = 0x1;
         mbTable[enDHCP].RdFlg = 0x1;
         
         if(mbSlave.BusType == 0xAD)
            mbTable[enStationName].RdFlg = 0x1;
         break;  
         
      case 0x05:     
         mbTable[enPbAdr].RdFlg = 0x1;
         mbTable[enEndian].RdFlg = 0x1;
         break;
      }
   }
}


/*
** ------------------------------------------------------------------------------
**		Function: void DisplaySubNet(void)
** ------------------------------------------------------------------------------
*/

void DisplaySubNet(void)
{
   byte Buf[20];
   
   slcd_SetColour(LightBlue, White);
   slcd_SetFont(16, 0);   
   
   sprintf(Buf, "%03u.", (word) *(((byte *)&mbSlave.SubNet+0)));
   slcd_SendText(Buf, FB_IP0_X, FB_SUB_ROW_Y, 0, LEFT_ALIGN); 

   sprintf(Buf, "%03u.", (word) *(((byte *)&mbSlave.SubNet+1)));
   slcd_AppendText(Buf); 

   sprintf(Buf, "%03u.", (word) *(((byte *)&mbSlave.SubNet+2)));
   slcd_AppendText(Buf); 

   sprintf(Buf, "%03u", (word) *(((byte *)&mbSlave.SubNet+3)));
   slcd_AppendText(Buf);

}

/*
** ------------------------------------------------------------------------------
**		Function: void DisplayIpAdr(void)
** ------------------------------------------------------------------------------
*/

void DisplayIpAdr(void)
{
   byte Buf[20];
   
   slcd_SetColour(LightBlue, White);
   slcd_SetFont(16, 0);
   
   sprintf(Buf, "%03u. ", (word) *(((byte *)&mbSlave.IpAdr+0)));
   slcd_SendText(Buf, FB_IP0_X, FB_IP_ROW_Y, 0, LEFT_ALIGN); 

   sprintf(Buf, "%03u. ", (word) *(((byte *)&mbSlave.IpAdr+1)));
   slcd_AppendText(Buf); 

   sprintf(Buf, "%03u. ", (word) *(((byte *)&mbSlave.IpAdr+2)));
   slcd_AppendText(Buf); 

   sprintf(Buf, "%03u", (word) *(((byte *)&mbSlave.IpAdr+3)));
   slcd_AppendText(Buf);
}

/*
** ------------------------------------------------------------------------------
**		Function: static void PaintFieldBusEth(byte showStation)
** ------------------------------------------------------------------------------
*/

static void PaintFieldBusEth(byte showStation)
{
   slcd_SetFont(24, 'B');
   slcd_SetColour(DarkGrey, White);

   if(showStation)
      slcd_SendText("ABCC ProfiNet", FB_LBL_X, FB_BUS_Y, 0, LEFT_ALIGN);
   else
      slcd_SendText("ABCC EtherNet", FB_LBL_X, FB_BUS_Y, 0, LEFT_ALIGN);

   //slcd_SetFont(8, 0);
   //slcd_MakeButtonTextXY(3, FB_SAVE_X, FB_IP_ROW_Y, gstr(&str->Save), 9, 10, 23, 21);
   //slcd_MakeButtonTextXY(4, FB_SAVE_X, FB_SUB_ROW_Y, gstr(&str->Save), 9, 10, 23, 21);

   slcd_SetFont(16, 0);

   slcd_SetColour(DarkGrey, White);
   slcd_SendText(gstr(&str->IP_Address), FB_LBL_X, FB_IP_ROW_Y, 'T', LEFT_ALIGN);
   slcd_SendText(gstr(&str->SubNet),     FB_LBL_X, FB_SUB_ROW_Y, 'T', LEFT_ALIGN);
   slcd_SendText(gstr(&str->DHCP),       FB_LBL_X, FB_DHCP_ROW_Y, 'T', LEFT_ALIGN);

   /* define hotspots (x, y, width, height) */
   slcd_MakeHotSpot(130, 228, FB_IP_ROW_Y,  52, FB_HS_H);
   //slcd_MakeHotSpot(131, 294, FB_IP_ROW_Y,  52, FB_HS_H);
   //slcd_MakeHotSpot(132, 360, FB_IP_ROW_Y,  52, FB_HS_H);
   //slcd_MakeHotSpot(133, 426, FB_IP_ROW_Y,  54, FB_HS_H);

   //slcd_SendText(".", FB_DOT0_X, FB_IP_ROW_Y,  0, LEFT_ALIGN);
   //slcd_SendText(".", FB_DOT1_X, FB_IP_ROW_Y,  0, LEFT_ALIGN);
   //slcd_SendText(".", FB_DOT2_X, FB_IP_ROW_Y,  0, LEFT_ALIGN);
   //slcd_SendText(".", FB_DOT0_X, FB_SUB_ROW_Y, 0, LEFT_ALIGN);
   //slcd_SendText(".", FB_DOT1_X, FB_SUB_ROW_Y, 0, LEFT_ALIGN);
   //slcd_SendText(".", FB_DOT2_X, FB_SUB_ROW_Y, 0, LEFT_ALIGN);

   slcd_MakeHotSpot(134, 228, FB_SUB_ROW_Y,  52, FB_HS_H);
   //slcd_MakeHotSpot(135, 294, FB_SUB_ROW_Y,  52, FB_HS_H);
   //slcd_MakeHotSpot(136, 360, FB_SUB_ROW_Y,  52, FB_HS_H);
   //slcd_MakeHotSpot(137, 426, FB_SUB_ROW_Y,  54, FB_HS_H);
   //slcd_MakeHotSpot(138, 228, FB_DHCP_ROW_Y, 52, FB_HS_H);

   if(showStation)
   {
      slcd_SendText("Station Name", FB_LBL_X, FB_STN_ROW_Y, 'T', LEFT_ALIGN);
      slcd_MakeHotSpot(141, 228, FB_STN_ROW_Y, 52, FB_HS_H);
   }
}

/*
** ------------------------------------------------------------------------------
**		Function: static void UpdateFieldBusEth(byte showStation)
** ------------------------------------------------------------------------------
*/

static void UpdateFieldBusEth(byte showStation)
{
   byte Buf[25];

   if(!EditFlag)
   {
      mbTable[enBusType].RdFlg = 0x1;
      mbTable[enIpAdr].RdFlg = 0x1;
      mbTable[enSubNet].RdFlg = 0x1;
      mbTable[enDHCP].RdFlg = 0x1;

      if(showStation)
         mbTable[enStationName].RdFlg = 0x1;
   }

   slcd_SetColour(LightBlue, White);
   slcd_SetFont(16, 0);

   DisplayIpAdr();

   //sprintf(Buf, "%03d", (word)*(((byte *)&mbSlave.IpAdr+0)));
   //Buf[7] = 0;
   //slcd_SendText(Buf, FB_IP0_X, FB_IP_ROW_Y, 0, LEFT_ALIGN);

   //sprintf(Buf, "%03d", (word)*(((byte *)&mbSlave.IpAdr+1)));
   //Buf[7] = 0;
   //slcd_SendText(Buf, FB_IP1_X, FB_IP_ROW_Y, 0, LEFT_ALIGN);

   //sprintf(Buf, "%03d", (word)*(((byte *)&mbSlave.IpAdr+2)));
   //Buf[7] = 0;
   //slcd_SendText(Buf, FB_IP2_X, FB_IP_ROW_Y, 0, LEFT_ALIGN);

   //sprintf(Buf, "%03d", (word)*(((byte *)&mbSlave.IpAdr+3)));
   //Buf[7] = 0;
   //slcd_SendText(Buf, FB_IP3_X, FB_IP_ROW_Y, 0, LEFT_ALIGN);


   DisplaySubNet();

   //sprintf(Buf, "%03d", (word)*(((byte *)&mbSlave.SubNet+0)));
   //Buf[7] = 0;
   //slcd_SendText(Buf, FB_IP0_X, FB_SUB_ROW_Y, 0, LEFT_ALIGN);

   //sprintf(Buf, "%03d", (word)*(((byte *)&mbSlave.SubNet+1)));
   //Buf[7] = 0;
   //slcd_SendText(Buf, FB_IP1_X, FB_SUB_ROW_Y, 0, LEFT_ALIGN);

   //sprintf(Buf, "%03d", (word)*(((byte *)&mbSlave.SubNet+2)));
   //Buf[7] = 0;
   //slcd_SendText(Buf, FB_IP2_X, FB_SUB_ROW_Y, 0, LEFT_ALIGN);

   //sprintf(Buf, "%03d", (word)*(((byte *)&mbSlave.SubNet+3)));
   //Buf[7] = 0;     
   //slcd_SendText(Buf, FB_IP3_X, FB_SUB_ROW_Y, 0, LEFT_ALIGN);

   sprintf(Buf, "%d", (word)mbSlave.DHCP);
   Buf[7] = 0;
   slcd_SendText(Buf, FB_VAL_X, FB_DHCP_ROW_Y, 0, LEFT_ALIGN);

   if(showStation)
   {
      sprintf(Buf, "%s", (word)mbSlave.StationName);
      Buf[16] = 0;
      slcd_SendText(Buf, FB_VAL_X, FB_STN_ROW_Y, 0, LEFT_ALIGN);
   }
}

/*
** ------------------------------------------------------------------------------
**		Function: void PaintFieldBus(void)
** ------------------------------------------------------------------------------
*/

void PaintFieldBus(void)
{
   if(mbSlave.BusType)
   {
      switch (mbSlave.BusType)
      {
      case 0x85:     /* Ethernet */
      case 0x96:     /* Profinet */
      case 0x84:     /* Profinet 1P */
      case 0x89:     /* Profinet IRT */
      case 0xAD:     /* Profinet IOT */
         PaintFieldBusEth(mbSlave.BusType != 0x85);
         winFieldBusState = WIN_FIELDBUS_UPDATE;
         break;

      case 0x05:     /* Profibus */
         slcd_SetFont(24, 'B');
         slcd_SetColour(DarkGrey, White);
         slcd_SendText("ABCC ProfiBus", FB_LBL_X, FB_BUS_Y, 0, LEFT_ALIGN);

         if(PanelSize == PSZ_1024_600)
            slcd_SetFont(14, 0);
         else
            slcd_SetFont(16, 'B');

         slcd_SendText("Node Address", FB_LBL_X, FB_SUB_ROW_Y, 'T', LEFT_ALIGN);
         slcd_SendText("Endian",       FB_LBL_X, FB_DHCP_ROW_Y, 'T', LEFT_ALIGN);

         slcd_MakeHotSpot(139, FB_PB_NODE_X, FB_PB_NODE_HS_Y, 54, FB_HS_H);
         slcd_MakeHotSpot(140, 360, FB_PB_END_HS_Y, 80, FB_HS_H);

         winFieldBusState = WIN_FIELDBUS_UPDATE;
         break;

      case 0x24:     /* Devicenet */
         slcd_SetFont(24, 'B');
         slcd_SetColour(DarkGrey, White);
         slcd_SendText("ABCC DeviceNet", FB_LBL_X, FB_BUS_Y, 0, LEFT_ALIGN);
         winFieldBusState = WIN_FIELDBUS_UPDATE;
         break;
      }
   }
   else
   {
      /* time to update? */
      if (!winTimer1)
      {
         winTimer1 = 100;

         mbTable[enBusType].RdFlg = 0x1;

         slcd_SetFont(24, 'B');
         slcd_SetColour(DarkGrey, White);
         slcd_SendText("Not Detected", FB_LBL_X, FB_BUS_Y, 0, LEFT_ALIGN);
      }
   }
}

/*
** ------------------------------------------------------------------------------
**		Function: void UpdateFieldBus(void)
** ------------------------------------------------------------------------------
*/

void UpdateFieldBus(void)
{
   byte Buf[25];
   
   /* requested update */
   if (winUpdate1==1)
   {
      /* stop counter */
      winUpdate1 = 0;
             
   }

   /* time to update? */
   if (!winTimer1)
   {
      winTimer1 = 100;

      switch (mbSlave.BusType)
      {
      case 0x85:     /* Ethernet */
      case 0x96:     /* ProfiNet */
      case 0x84:     /* Profinet 1P */
      case 0x89:     /* Profinet IRT */
      case 0xAD:     /* Profinet IOT */
         UpdateFieldBusEth(mbSlave.BusType != 0x85);
         break;

      case 0x05:     /* ProfiBus */
         if(!EditFlag)
         {
            mbTable[enPbAdr].RdFlg = 0x1;
            mbTable[enEndian].RdFlg = 0x1;
         }

         slcd_SetColour(LightBlue, White);
         slcd_SetFont(8, 0);

         sprintf(Buf, "%u", (word)mbSlave.PbNodeAdr);
         Buf[7] = 0;
         slcd_SendText(Buf, FB_PB_NODE_X, FB_SUB_ROW_Y, 0, LEFT_ALIGN);

         slcd_SetColour(DarkGrey, White);

         sprintf(Buf, "%u", (word)mbSlave.Endian);
         Buf[7] = 0;
         slcd_SendText(Buf, FB_PB_NODE_X, FB_DHCP_ROW_Y, 0, LEFT_ALIGN);
         break;
      }
   }
}

/*
** ------------------------------------------------------------------------------
**		Function: void winFieldBusHandler(void)
** ------------------------------------------------------------------------------
*/

void winFieldBusHandler(void)
{
   switch (winFieldBusState)
   {
   case WIN_FIELDBUS_PREPAINT:
      /* get fieldbus parameters from slave */
      ReadFieldBusParameters();

      slcd_SetColour(DarkGrey, DarkGrey);
      slcd_Send("z");
      slcd_Send("xc all");
      slcd_DisplayBmp(10, 0, 0);

      DisplayTitle("MS Instrumentos");

      slcd_SetFont(24, 0);
      slcd_SetColour(DarkGrey, White);

      /* display page title  */
      slcd_SendText(gstr(&str->FieldBus), 15, 60, 0, LEFT_ALIGN);

      /* define back hotspot */
      slcd_MakeHotSpot(128, 560, 10, 50, 50);

      winFieldBusState = WIN_FIELDBUS_PAINT;
      break;
      
   case WIN_FIELDBUS_PAINT:
      /* is there a key to process? */
      if (slcdKey)
      {
         /* call key handler */
         winFieldBusKeyHandler(slcdKey);      
         /* now the key has been processed clear it */
         slcdKey = 0; 
      }      
      /* paint key pad */
      PaintFieldBus();
      break;

   case WIN_FIELDBUS_UPDATE:
      /* is there a key to process? */
      if (slcdKey)
      {
         /* call key handler */
         winFieldBusKeyHandler(slcdKey);      
         /* now the key has been processed clear it */
         slcdKey = 0; 
      }

      UpdateFieldBus();

      /* has any data been remotely changed? */
      if(mbSlave.DataUpdate)
      {
         /* clear data update flag */
         mbSlave.DataUpdate = 0;
         mbTable[enDataUp].WrFlg = 1;   
         
         /* read analog parameters */
         ReadFieldBusParameters();  
         
         /* set update timer */                   
         winUpdate1 = 100;
      }      
      break;

  case WIN_FIELDBUS_NUMKEYPAD:
      /* see if key pad is returning */
      if(winKeyPadHandler())
         /* move to update state */      
         winFieldBusState = WIN_FIELDBUS_PREPAINT;   
      break;

  case WIN_FIELDBUS_CONFIRM:
      /* see if confirmation win is returning */
      if(winConfirmHandler())     
      {
         EditFlag = 0;
         /* move to update state */      
         winFieldBusState = WIN_FIELDBUS_UNLOAD;          
      }
      break; 
      
   case WIN_FIELDBUS_UNLOAD:
      
      if(EditFlag)
      {
         winFieldBusState = WIN_FIELDBUS_CONFIRM;
         
         /* set pointer to msg box message */
         strcpy(MsgBoxData.TitleBarTxt, "FieldBus Settings");

         /* set pointer to msg box message */
         MsgBoxData.MsgTxt = "Do you want to save\n fieldbus paramaters?"; 
         
         /* load return function */
         //MsgBoxData.fp = SaveFieldBusParameters;
      }
      else
      {
         /* do any necessary clearing up */
         winFieldBusState = WIN_FIELDBUS_PREPAINT;  

         /* switch to menu screen */
         winActiveWin = INPUTSOUTPUTS_WINDOW;  
      }
      /* return from key pad */
      break;
   }   
}



