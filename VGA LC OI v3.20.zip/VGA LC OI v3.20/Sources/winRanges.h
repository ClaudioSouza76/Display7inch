/*
** ------------------------------------------------------------------------------
   
   File   : winRanges.h 
   Aurthor: Stuart Clarke

** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

#ifndef WINRANGES_H
#define WINRANGES_H


/* public defines */


/*
** ------------------------------------------------------------------------------
**		#define : diagnostics handler states 
** ------------------------------------------------------------------------------
*/

#define WIN_RANGES_PREPAINT     0
#define WIN_RANGES_PAINT        1
#define WIN_RANGES_PAINT_PAGE   2
#define WIN_RANGES_UPDATE       3
#define WIN_RANGES_NUMKEYPAD    4
#define WIN_RANGES_UNLOAD       5




#ifndef WIN_RANGES_C

/* public variables */
#pragma DATA_SEG WINRANGES_Data


#endif   /* WINRANGES_C */      


/* public functions */
#pragma CODE_SEG WINRANGES_Code

/*
** ------------------------------------------------------------------------------
**		Function: void ReadRangeParameters(void)
** ------------------------------------------------------------------------------
*/

void ReadRangeParameters(void);

/*
** ------------------------------------------------------------------------------
**		Function: byte winRangesHandler(void)
** ------------------------------------------------------------------------------
*/

byte winRangesHandler(void);

#endif   /* WINRANGES_H */
