/*
** ------------------------------------------------------------------------------
   
   File   : winSetup.h 
   Aurthor: Stuart Clarke

** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

#ifndef WININSPECMEC_H
#define WININSPECMEC_H


/* public defines */

/*
** ------------------------------------------------------------------------------
**		#define : win setup handler states 
** ------------------------------------------------------------------------------
*/

#define WIN_INSPECMEC_PAINT                 0
#define WIN_INSPECMEC_UPDATE            1
#define WIN_INSPECMEC_UNLOAD            2
#define WIN_INSPECMEC_NUMKEYPAD  3
#define WIN_INSPECMEC_ENTER_PASSWORD    4


#define Col1    100
#define Col2    415
#define LN1     104
#define LN2     220
#define LN3     340



#ifndef WININSPECMEC_C


/* public variables */
#pragma DATA_SEG WININSPECMEC_Data

#endif   /* WINMENU_C */      




/* public functions */
#pragma CODE_SEG WININSPECMEC_Code

/*
** ------------------------------------------------------------------------------
**		Function: void winSpecialFuncHandler(void)
** ------------------------------------------------------------------------------
*/

void winSpecialFuncHandler(void);


#endif   /* WININSPECMEC_H */
