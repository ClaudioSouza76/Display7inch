/*
** ------------------------------------------------------------------------------
   
   File   : winHistograms.h 
   Aurthor: Stuart Clarke

** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

#ifndef WIN_HISTOGRAM_H
#define WIN_HISTOGRAM_H


/* public defines */


/*
** ------------------------------------------------------------------------------
**		#define : diagnostics handler states 
** ------------------------------------------------------------------------------
*/

#define WIN_HISTOGRAM_PREPAINT     0
#define WIN_HISTOGRAM_PAINT        1
#define WIN_HISTOGRAM_PAINT_PAGE   2
#define WIN_HISTOGRAM_UPDATE       3
#define WIN_HISTOGRAM_NUMKEYPAD    4
#define WIN_HISTOGRAM_UNLOAD       5




#ifndef WIN_HISTOGRAM_C

/* public variables */
#pragma DATA_SEG WINHISTOGRAM_DATA


#endif   /* WINCAL_HISTOGRAM_C */      


/* public functions */
#pragma CODE_SEG WINHISTOGRAM_CODE

/*
** ------------------------------------------------------------------------------
**		Function: void ReadHistogramParameters(void)
** ------------------------------------------------------------------------------
*/

void ReadHistogramParameters(void);

/*
** ------------------------------------------------------------------------------
**		Function: byte winHistogramHandler(void)
** ------------------------------------------------------------------------------
*/

byte winHistogramHandler(void);

#endif   /* WINHISTOGRAM_H */
