#include <hidef.h>                           /* common defines and macros */
#include "derivative.h"                      /* derivative information */

/*
** ------------------------------------------------------------------------------
   
   File   : winTotalizer.c 
   Aurthor: 
   
   Description:  
   
   Version Log          Notes                                     Changes Made by                                        
   --------------       -----                                     ---------------
   25-07-10:            Created                                   Stuart


** ------------------------------------------------------------------------------
                                    
                                    Overview
                                            
** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

/* library headers */
#include "stdio.h"
#include "float.h"
#include "math.h"

/* Application headers */
#include "CRG 100110.h" 
#include "Subs.h"
#include "SlcdSubs.h"
#include "ModBusM Int.h"
#include "ModBusM.h"
#include "EEPROM.h"
#include "SLCD 260217.h"
#include "winMain.h"
#include "winKey.h"
#include "Language.h"


/* Implements this interface: */
#define WINTOTALIZER_C
#include "winTotalizer.h"

#pragma CODE_SEG WINTOTALIZER_Code
#pragma DATA_SEG WINTOTALIZER_Data


/* private */
static byte winTotalizerState;
static byte winTotalizerPage;


/* public */



/*
** ------------------------------------------------------------------------------
**		Function: void winTotalizerKeyHandler(byte key)
** ------------------------------------------------------------------------------
*/

void winTotalizerKeyHandler(byte key)
{   
   switch (key)
   {
   case 1:
      /* change state */
      mbSlave.PulseTotalEn ^= 1;
      /* set write flag */
      mbTable[enPulseTotalEn].WrFlg = 1;       
      break;

   case 2:
      /* change state */
      mbSlave.TotalizerReset = 1;
      /* set write flag */
      mbTable[enTotalReset].WrFlg = 1;  
      /* clear old string */
      slcd_SendText("         ", getX(405), getY(ccY1), 0, LEFT_ALIGN);     
      break;

 case 3:
      /* change state */
      mbSlave.TotalizerTest = 1;
      /* set write flag */
      mbTable[enPulseTest].WrFlg = 1;       
      break;
      
            
   case 128:       /* EXIT */
      /* shut down num key window handler */
      winTotalizerState = WIN_TOTALIZER_UNLOAD;  
      break;  
      
   case 130:      /* Pulse Width */
      /* move to key pad handler sate */
      winTotalizerState = WIN_TOTALIZER_NUMKEYPAD; 
      
      /* copy parameter data to key structure */
      strcpy(NumKeyData.Name, gstr(&str->PulseWidth));  
      NumKeyData.KeyBoardType = NUMBER;
      NumKeyData.Type = WORD;
      NumKeyData.iMax = 5000;
      NumKeyData.iMin = 20;
      NumKeyData.Flag = enPulseDelay;
      NumKeyData.DataPtr = (void *)&mbSlave.PulseDelay;     
      break;      

   case 131:      /* Pulse Rate */
      /* move to key pad handler sate */
      winTotalizerState = WIN_TOTALIZER_NUMKEYPAD; 
      
      /* copy parameter data to key structure */
      strcpy(NumKeyData.Name, gstr(&str->PulseRate));  
      NumKeyData.KeyBoardType = NUMBER;
      NumKeyData.Type = FLOAT;
      NumKeyData.fMax = 100.0;
      NumKeyData.fMin = 0.001;
      NumKeyData.Flag = enPulseRate;
      NumKeyData.DataPtr = (void *)&mbSlave.PulseRate;     
      break;          

   case 132:      /* Cut off  */
      /* move to key pad handler sate */
      winTotalizerState = WIN_TOTALIZER_NUMKEYPAD; 
      
      /* copy parameter data to key structure */
      strcpy(NumKeyData.Name, gstr(&str->CutOff));  
      NumKeyData.KeyBoardType = NUMBER;
      NumKeyData.Type = FLOAT;
      NumKeyData.fMax = 100.0;
      NumKeyData.fMin = 0.000;
      NumKeyData.Flag = enPulseCutoff;
      NumKeyData.DataPtr = (void *)&mbSlave.TotalCutoff;     
      break; 
      
   case 133:      /* Precision Total  */
      /* move to key pad handler sate */
      winTotalizerState = WIN_TOTALIZER_NUMKEYPAD; 
      
      /* copy parameter data to key structure */
      strcpy(NumKeyData.Name, gstr(&str->Precision));  
      NumKeyData.KeyBoardType = NUMBER;
      NumKeyData.Type = BYTE;
      NumKeyData.iMax = 3;
      NumKeyData.iMin = 0;
      //NumKeyData.Flag = enPrecision;
      NumKeyData.Attributes = EPROM;
      NumKeyData.DataPtr = (void *)&EEPROM.Precision;     
      break;                   

   }
}

/*
** ------------------------------------------------------------------------------
**		Function: void ReadTotalizerParameters(void)
** ------------------------------------------------------------------------------
*/

void ReadTotalizerParameters(void)
{
   mbTable[enPulseDelay].RdFlg = 0x1;
   mbTable[enPulseRate].RdFlg = 0x1;  
   mbTable[enPulseCutoff].RdFlg = 0x1;     
   mbTable[enPulseTotalEn].RdFlg = 0x1;
   mbTable[enPrecision].RdFlg = 0x1;
}

/*
** ------------------------------------------------------------------------------
**		Function: void PaintTotalizerPage(void)
** ------------------------------------------------------------------------------
*/

void PaintTotalizerPage(void)
{   
   byte Buf[25];
   ButtonType Button;   
   byte ButtonText1[20], ButtonText2[20];   
   
   slcd_SetFont(16, 'B');  
   
   /* set colours back */
   slcd_SetColour(DarkGrey, White);         

   /* display headings */
   slcd_SendText(gstr(&str->Totalizer),  27,   ccY0, 'T', LEFT_ALIGN);     
   
   if(PanelSize == PSZ_1024_600)
      slcd_SetFont(14, 0);  
   else
      slcd_SetFont(16, 0);  

   slcd_SendText(gstr(&str->PulseWidth),  27,   230, 'T', LEFT_ALIGN);  //Before getY(ccY1), 'T');
   slcd_SendText(gstr(&str->PulseRate),   27,   283, 'T', LEFT_ALIGN);  //Before getY(ccY2), 'T');
   slcd_SendText(gstr(&str->Precision),   27,   336, 'T', LEFT_ALIGN);
   slcd_SendText(gstr(&str->PulseTest),   27,   ccY3,'T', LEFT_ALIGN);  
   
   
   slcd_SendText(gstr(&str->Total),       327,  230, 'T', LEFT_ALIGN);  //Before getY(ccY1), 'T');   
   slcd_SendText(gstr(&str->TotalReset),  327,  ccY2,'T', LEFT_ALIGN);   
   slcd_SendText(gstr(&str->CutOff),      327,  372, 'T', LEFT_ALIGN); //Before getY(ccY3), 'T');
   
   /* set colours back */
   slcd_SetColour(LightBlue, White);         

   /* totalizer delay  */
   sprintf(Buf, "%u ms ", mbSlave.PulseDelay);
   slcd_SendText(&Buf, 220, 230, 0, LEFT_ALIGN);     //Before getY(ccY1), 'T');

   /* totalizer Rate */
   sprintf(Buf, "%.3f t ", mbSlave.PulseRate);
   slcd_SendText(&Buf, 220, 283, 0, LEFT_ALIGN);     //Before getY(ccY1), 'T');
   
   /* Disgits of the Totalizer */
   sprintf(Buf, "%.u", EEPROM.Precision);
   slcd_SendText(&Buf, 220, 336, 0, LEFT_ALIGN);
   
   /* Cut off Rate */
   sprintf(Buf, "%.3f t ", mbSlave.TotalCutoff);
   slcd_SendText(&Buf, 540, 372, 'T', LEFT_ALIGN);     //Before getY(ccY3), 'T');   

   /* set colours back */
   slcd_SetColour(DarkGrey, White);         
   
   //sprintf(Buf, "%.1f t  ", mbSlave.Total);
   //slcdslcd_SendText(&Buf, getX(405), getY(ccY1), 0);  
   
   slcd_MakeHotSpot(130, 220, 240, 32, 128);    // Para largura de pulsos
   slcd_MakeHotSpot(131, 220, 284, 32, 128);    // Para Taxa de Pulsos  
   slcd_MakeHotSpot(133, 220, 328, 32, 128);    // Para digitos do totalizador
   slcd_MakeHotSpot(132, 540, 374, 32, 128);    // Para Cut Off
      
   /* make totalizer reset button */
   MakeButton(2, 1, 540, ccY2, 26, 26);
   
   /* make totalizer pulse test button */
   MakeButton(3, 1, 220, ccY3, 26, 27);   
   
   /* set colours back */
   slcd_SetColour(Red, White); 

   if(PanelSize == PSZ_1024_600)
      slcd_SetFont(14, 0);  
   else
      slcd_SetFont(16, 'B'); 
   
   Button.Id = 1;
   Button.x = 227;
   Button.y = ccY0;
   Button.type = 2;
   Button.state = mbSlave.PulseTotalEn;
   strcpy(ButtonText1, gstr(&str->ON));      
   strcpy(ButtonText2, gstr(&str->OFF));      
   Button.text0 = ButtonText2;
   Button.text1 = ButtonText1;
   Button.dx0 = 12;
   Button.dy0 = 6;
   Button.dx1 = 18;
   Button.dy1 = 6;
   Button.bmp0 = 27;
   Button.bmp1 = 26;  
       
   /* define start/stop button */
   MakeLatchingButton(&Button); 

   /*     Inserted by Souza   */
   /* define start/stop button */
   //Button.Id = 2;
   //Button.x = getX(405);
   //Button.y = getY(ccY2);
   //Button.state = mbSlave.TotalizerReset;
       
   /* define start/stop button */
   //slcdMakeLatchingButton(&Button);
   
   //I need invert state button    
   //Button.Id = 3;
   //Button.x = getX(170);
   //Button.y = getY(ccY3);
   //Button.state = mbSlave.TotalizerTest;
       
   /* define start/stop button */
   //slcdMakeLatchingButton(&Button); 
   
  /*/\     Inserted by Souza   /\*/
 
   /* force update */
   //winUpdate1 = 1;
}


/*
** ------------------------------------------------------------------------------
**		Function: void UpdateTotalizer(void)
** ------------------------------------------------------------------------------
*/

void UpdateTotalizer(void)
{   
   byte Buf[25];
   
   /* requested update */
   if (winUpdate1==1)
   {
      /* stop counter */
      winUpdate1 = 0;

      /* set colours back */
      slcd_SetColour(LightBlue, White);       
      
      if(PanelSize == PSZ_1024_600)
         slcd_SetFont(14, 0); 
      else
         slcd_SetFont(16, 0);  
      
      /* totalizer delay  */
      sprintf(Buf, "%u ms ", mbSlave.PulseDelay);
      slcd_SendText(&Buf, 220, 230, 0, LEFT_ALIGN);    //Before getY(ccY1), 'T');

      /* totalizer Rate */
      sprintf(Buf, "%.3f t ", mbSlave.PulseRate);
      slcd_SendText(&Buf, 220, 283, 0, LEFT_ALIGN);    //Before getY(ccY2), 'T');
      
      /* Disgits of the Totalizer */
      sprintf(Buf, "%u", EEPROM.Precision);
      slcd_SendText(&Buf, 220, 336, 0, LEFT_ALIGN);
     
      /* Cut off Rate */
      sprintf(Buf, "%.3f t  ", mbSlave.TotalCutoff);
      slcd_SendText(&Buf, 540, 372, 'T', LEFT_ALIGN);  //Before getY(ccY3), 'T');      
      
   }

   /* time to update? */
   if (!winTimer1)
   {
      winTimer1 = 50;

      if(PanelSize == PSZ_1024_600)
         slcd_SetFont(14, 0); 
      else
         slcd_SetFont(16, 0); 
      
      /* set colours back */
      slcd_SetColour(DarkGrey, White);         
      
      sprintf(Buf, "%.0f t ",  mbSlave.Total);
      slcd_SendText(&Buf, 540, 230, 0, LEFT_ALIGN);   //Before getY(ccY3), 'T');
      
      mbTable[enTotal].RdFlg = 1;       
   }
}

/*
** ------------------------------------------------------------------------------
**		Function: byte winTotalizerHandler(void)
** ------------------------------------------------------------------------------
*/

byte winTotalizerHandler(void)
{
   switch (winTotalizerState)
   {
   case WIN_TOTALIZER_PREPAINT:
      /* get analog parameters from slave */
      ReadTotalizerParameters();
      winTotalizerState = WIN_TOTALIZER_PAINT;
      break;
      
   case WIN_TOTALIZER_PAINT:
      slcd_SetColour(DarkGrey, DarkGrey);
      slcd_Send("z");

      slcd_Send("xc all");     
      /* display menu screen */
      //DisplayBmp(16, 0, 0, LEFT_ALIGN); 
      slcd_DisplayBmp(10, 0, 0); 

      DisplayTitle("MS Instrumentos");
      
      slcd_SetFont(24, 0);
      slcd_SetColour(DarkGrey, White); 
      slcd_SendText(gstr(&str->Totalizer), 15, 60, 0, LEFT_ALIGN);
      
      /* define back hotspot */
      //slcd_CmdQueue("x 128 560 10 630 60");
      slcd_MakeHotSpot(128, 560, 10, 50, 50);
      /* update parameters */
      winUpdate1 = 1;
      
      /* move to update state */      
      winTotalizerState = WIN_TOTALIZER_PAINT_PAGE;       
      break;

   case WIN_TOTALIZER_PAINT_PAGE:
         
      PaintTotalizerPage();
      
      /* move to update state */      
      winTotalizerState = WIN_TOTALIZER_UPDATE;       
      break;

   case WIN_TOTALIZER_UPDATE:
      /* is there a key to process? */
      if (slcdKey)
      {
         /* call key handler */
         winTotalizerKeyHandler(slcdKey);      
         /* now the key has been processed clear it */
         slcdKey = 0; 
      }

      UpdateTotalizer();

      /* has any data been remotely changed? */
      if(mbSlave.DataUpdate)
      {
         /* clear data update flag */
         mbSlave.DataUpdate = 0;
         mbTable[enDataUp].WrFlg = 1;   
         
         /* read analog parameters */
         ReadTotalizerParameters();  
         
         /* set update timer */                   
         winUpdate1 = 100;
      }      
      return 0;

  case WIN_TOTALIZER_NUMKEYPAD:
      /* see if key pad is returning */
      if(winKeyPadHandler())
         /* move to update state */      
         winTotalizerState = WIN_TOTALIZER_PAINT;   
      break;

   case WIN_TOTALIZER_UNLOAD:
      /* do any necessary clearing up */
      winTotalizerState = WIN_TOTALIZER_PREPAINT;  

      /* clear page */
      winTotalizerPage = 0;
      
      /* switch to menu screen */
      winActiveWin = SPECIALFUNC_WINDOW;  


      /* return from key pad */
      return 1;
   }   
}



