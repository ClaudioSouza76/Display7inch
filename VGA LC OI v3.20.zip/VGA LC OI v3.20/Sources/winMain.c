#include <hidef.h>                           /* common defines and macros */
#include "derivative.h"                      /* derivative information */

/*
** ------------------------------------------------------------------------------
   
   File   : winMain.c 
   Aurthor: 
   
   Description:  
   
   Version Log          Notes                                     Changes Made by                                        
   --------------       -----                                     ---------------
   01-04-09:            Created                                   Stuart


** ------------------------------------------------------------------------------
                                    
                                    Overview
                                            
** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

/* library headers */
#include "stdio.h"
#include "string.h"
#include "math.h"

/* Application headers */
#include "Main.h"
#include "ModBusM Int.h"
#include "ModBusM.h"
#include "Subs.h"
#include "SlcdSubs.h"
#include "EEPROM.h"
#include "SLCD 260217.h"
#include "CRG 100110.h"

#include "winKey.h"
#include "winUserMenu.h"
#include "winBasicConfig.h"
#include "winSpeedCal.h"
#include "winMassCal.h"
#include "winMassSpanCal.h"
#include "winTimeDate.h"
#include "winBalanceData.h"
#include "winInputsOutputs.h"
#include "winCalConstants.h"
#include "winAD7730.h"
#include "winCalFunctions.h"
#include "winSimulation.h"
#include "winDigitalIn.h"
#include "winDigitalOut.h"
#include "winAnalogueIn.h"
#include "winAnalogueOut.h"
#include "winHistogram.h"


#include "winSetup.h"
#include "winSpecialFunc.h"
#include "winFiltering.h"
#include "winTotalizer.h"
#include "winEng.h"
#include "winFieldBus.h"
#include "winEngineering.h"
#include "winDigits.h"
#include "winTension.h"
#include "winMovingAverage.h"
#include "Language.h"


/* Implements this interface */
#define WINMAIN_C
#include "winMain.h"

#pragma CODE_SEG WINMAIN_Code
#pragma DATA_SEG WINMAIN_Data


/* private */
static byte winMainState;
static byte winAlarmState;
static byte winAlarmCopy;

static word  TrendUpdateTime;
static word  TrendUpdateCounter;

static float ScaleMultiplier;

byte bInspecMec;


/* public */


byte winActiveWin;
byte winMainReturnWin;

word winTimer1;
word winTimer2;
word winTimer3;
byte winUpdate1;
byte winUpdate2;
word winRePaint;
word winSplashTimer;
unsigned long CalTimer;
long CalTimeOut;

word winStatusWordCopy;

byte OfflineFlag;

word StatusImg;
byte StatusSeq;
word StatusDelay;

byte  LastFlowLen;
byte  LastTotalLen;
byte  LastMassLen;
byte  LastSpeedLen;
byte  LastTensionLen;

byte HistogramSwitch; 

word GraphScale;

byte bInspecMec;


#define VerStr    "D210R02" 
#pragma INTO_ROM
const char DisplayString[20] = VerStr;
 
#pragma INTO_ROM
CalType	*CalArrayPtr = (CalType *)0x0000; 


const byte * ErrorString[] = 
{
"HIGH THERMISTOR",
"LOW THERMISTOR",
"HIGH SIGNAL",
"LOW SIGNAL",   
"SPI",
"LO MOTOR SPEED",
"HIGH MOTOR SPEED",   
"MOTOR STOPPED",
"VCC 3 FAULT",
"VP FAULT",
"VN FAULT",
"DIRTY WINDOW FAULT",
"THERMOCOUPLE FAULT",
"",
"",
"VCC 5 FAULT",

};


/*
** ------------------------------------------------------------------------------
**		Function: void winMainKeyHandler(byte key)
** ------------------------------------------------------------------------------
*/

void winMainKeyHandler(byte key)
{
   switch (key)
   {
   case 128:     /* Menu  key */
      /* switch to menu screen */
      winActiveWin = USER_WINDOW;
      /* shut down main window handler */
      winMainState = WIN_UNLOAD;   
      break;

   case 129:     /* Test key */
   
      break;
      
   case 130:     /* Cal Key */
      if(HistogramSwitch^=1)
         /* display histogram bmp */ 
         DisplayBmp(30, 560, 100);
      else
         /* display Home bmp */ 
         //DisplayBmp(31, 560, 100);
         DisplayBmp(31, 650, 100);
         
      winMainState = WIN_PAINT;   
      break;
   }
}

/*
** ------------------------------------------------------------------------------
**		Function: byte ReadMainParameters(void)
** ------------------------------------------------------------------------------
*/

void ReadMainParameters(void)
{
   mbTable[enTag].RdFlg = 1;    
   mbTable[enCompanyName].RdFlg = 1;    
      
   mbTable[enUnits1].RdFlg = 1;    
   mbTable[enUnits2].RdFlg = 1;    
   mbTable[enUnits3].RdFlg = 1;    
   mbTable[enUnits4].RdFlg = 1;    

   mbTable[enDigits].RdFlg = 1;    
   
   mbTable[enAlrLo1].RdFlg = 1; 
   mbTable[enAlrLo2].RdFlg = 1; 
   mbTable[enAlrLo3].RdFlg = 1; 
   mbTable[enAlrLo4].RdFlg = 1; 
   
   mbTable[enAlrHi1].RdFlg = 1; 
   mbTable[enAlrHi2].RdFlg = 1; 
   mbTable[enAlrHi3].RdFlg = 1; 
   mbTable[enAlrHi4].RdFlg = 1;
   
   mbTable[enAlarmFlag].RdFlg = 1;
   
   mbTable[enLastCalDate].RdFlg = 0x1;
   mbTable[enLastCalTime].RdFlg = 0x1;
   mbTable[enNextCalDate].RdFlg = 0x1;
   
   mbTable[enAnInFunc1].RdFlg = 0x1;
   mbTable[enAnInFunc2].RdFlg = 0x1;
   
   mbTable[enOiLock].RdFlg = 0x1;
}

/*
** ------------------------------------------------------------------------------
**		Function: void SetOpenCollector(void)
** ------------------------------------------------------------------------------
*/

void SetOpenCollector(void)
{
   if(winAlarmState  != winAlarmCopy)
   {
      /* copy alarm state */
      winAlarmCopy = winAlarmState;
      
      /* is alarm on or off */
      if(winAlarmCopy)
      {
         /* turn on open collector */   
         PORTA |= 0x01; 
      }
      else
      {
         /* turn off open collector */                     
         PORTA &=~ 0x01;
      }
   }   
}

/*
** ------------------------------------------------------------------------------
**		Function: void GetStatusString(void)
** ------------------------------------------------------------------------------
*/

void GetStatusString(void)
{
   if(StatusDelay)
      StatusDelay--;
   
   if(mbStatus == mbOFFLINE)
   {
      if(!OfflineFlag)
      {
         /* set offline flag */
         OfflineFlag = 1;
         
         /* set font and colour */
         slcdSetColour(Red, Black);
         slcdSetFont(F24B);                   

         /* display fault string */
         DisplayText("OFFLINE", 490,  488,  0);  
      }
   }
   else
   {
      /* clear offline flag */
      if(OfflineFlag)
      {
         OfflineFlag = 0;            
         /* set font */
         slcdSetFont(F24B);              

         /* clear old string */
         DisplayText("                ", 490,  488,  0);  
      }
   }

   if(!StatusDelay)
   {
      if(mbStatus != mbOFFLINE)
      {
         /* are any status bits set? */
         if(mbSlave.Status)
         {
            /* copy status */
            StatusImg = mbSlave.Status;
            
            for(;StatusSeq<16;StatusSeq++)
            {
               /* check for faults */
               if((mbSlave.Status&0xFFFE)&(0x0001<<StatusSeq))         
               {
                  /* set status delay */
                  StatusDelay = 8; 

                  /* set font and colour */
                  slcdSetColour(Red, Black);
                  /* set font */
                  slcdSetFont(F24B);                   
                  
                  /* clear old string */
                  DisplayText("                              ", 490,  488,  0);  
                  /* display fault string */
                  DisplayText(ErrorString[StatusSeq], 490,  488,  0);  

                  //StatusImg &=~ (0x0001<<StatusSeq);
                  StatusSeq++;
                  break;
               }
            }
                        
            if(StatusSeq>=13)
               StatusSeq = 0;
         }
         else
         {
            /* has the status changed */
            if(mbSlave.Status!=StatusImg)
            {
               /* copy status */
               StatusImg = mbSlave.Status;

               /* set font and colour */
               slcdSetColour(Green, Black);
               slcdSetFont(F24B);                   
               
               /* clear old string */
               DisplayText("                              ", 490,  488,  0);  
            }
         }
      }
   }
}

/*
** ------------------------------------------------------------------------------
**		Function: void DisplayScale(void)
** ------------------------------------------------------------------------------
*/

void DisplayScale(void)
{
   byte Buf[25];

   /* set font and clour */
   slcdSetFont(F10);
   slcdSetColour(Green, Black);
   
   /* format Total  */       
   if(ScaleMultiplier)
      sprintf(Buf, "%.2f   ", 100/ScaleMultiplier);  
   else
      sprintf(Buf, "%u   ", (word)GraphScale);  
   
   /* display new Total  */
   DisplayText(&Buf, 0, 206, 0);   
}

/*
** ------------------------------------------------------------------------------
**		Function: void DisplayMean(void)
** ------------------------------------------------------------------------------
*/

void DisplayMean(void)
{
   byte Buf[25];

   /* set font and clour */
   slcdSetFont(F16B);
   slcdSetColour(Green, Black);
   
   /* format Total  */       
   sprintf(Buf, "u: %.1f", SampleMean);  
   
   /* display new Total  */
   DisplayText(&Buf, 280, 194, 0);   
}

/*
** ------------------------------------------------------------------------------
**		Function: void DisplayStdDev(void)
** ------------------------------------------------------------------------------
*/

void DisplayStdDev(void)
{
   byte Buf[25];

   /* set font and clour */
   slcdSetFont(F16B);
   slcdSetColour(Green, Black);
   
   /* format Total  */       
   sprintf(Buf, "dp: %.3f", StdDev);  
   
   /* display new Total  */
   DisplayText(&Buf, 480, 194, 0);   
}


/*
** ------------------------------------------------------------------------------
**		Function: void DrawLine(byte X1, byte Y1, byte X2, byte Y2)
** ------------------------------------------------------------------------------
*/

void DrawLine(word X1, word Y1, word X2, word Y2)
{
   byte Buf[32];

   //sprintf(Buf, "l %u %u %u %u 1", X1, Y1, X2, Y2);
   sprintf(Buf, "l %u %u %u %u 1", (word)(X1 * xratio)+xoff, (word)(Y1 * yratio)+yoff, (word)(X2 * xratio)+xoff, (word)(Y2 * yratio)+yoff);


   slcd_CmdQueue(Buf);
}

/*
** ------------------------------------------------------------------------------
**		Function: void UpDateChart(byte id, word value)
** ------------------------------------------------------------------------------
*/

void UpDateChart(byte id, word value)
{
   byte Buf[50];
   
   sprintf(Buf, "cv %d %d", id, value);  
   slcd_CmdQueue(Buf);
}

/*
** ------------------------------------------------------------------------------
**		Function: void MakeChart(byte X1, byte Y1, byte X2, byte Y2)
** ------------------------------------------------------------------------------
*/

void MakeChart(word X1, word Y1, word X2, word Y2, word Scale)
{
   byte Buf[50];
   word w;
   
   /* get trend seconds period */
   w = EEPROM.TrendTime*60;
   /* get seconds per pixel */
   TrendUpdateTime = (w/248)*4;
   /* force first update */
   TrendUpdateCounter = 0;
   
   /* white back ground */
   //sprintf(Buf, "cd %u %u %u %u %u 0 1 %d %d FFF 1 009", 0, X1, Y1, X2, Y2, 1, Scale);       
   sprintf(Buf, "cd %u %u %u %u %u 0 1 %d %d FFF 1 009", 0, (word)(X1 * xratio)+xoff, (word)(Y1 * yratio)+yoff, (word)(X2 * xratio)+xoff, (word)(Y2 * yratio)+yoff, 1, Scale);       
   
   slcd_CmdQueue(Buf);
}

/*
** ------------------------------------------------------------------------------
**		Function: void MakeHistogram(byte X1, byte Y1, byte X2, byte Y2)
** ------------------------------------------------------------------------------
*/

void MakeHistogram(word X1, word Y1, word X2, word Y2, word Scale)
{
   byte Buf[50];
   
   /* black back ground */
   //sprintf(Buf, "cd %u %u %u %u %u 1 1 %d %d 000 2 0F0", 0, X1, Y1, X2, Y2, 0, Scale);          
   sprintf(Buf, "cd %u %u %u %u %u 1 1 %d %d 000 2 0F0", 0, (word)(X1 * xratio)+xoff, (word)(Y1 * yratio)+yoff, (word)(X2 * xratio)+xoff, (word)(Y2 * yratio)+yoff, 0, Scale);          

   
   slcd_CmdQueue(Buf);
}


/*
** ------------------------------------------------------------------------------
**		Function: void UpDateHistogram(void)
** ------------------------------------------------------------------------------
*/

void UpDateHistogram(void)
{
   word i, j, k;
   float f;
   
   __RESET_COP();
   
   //f = HistogramArray[145]*ScaleMultiplier;
   f = HistogramArray[sizeof(HistogramArray)/8]*ScaleMultiplier;
   
   /* first does the graph need rescaling ? */
   if(f<((float)GraphScale*0.25)||f>((float)GraphScale*0.95))   
   {
      /* rescale the graph */
      //winMainState = WIN_PAINT;       
      
      /* do we need the scale multiplier?  */
      if(HistogramArray[sizeof(HistogramArray)/8]<85)
      {
         /* scale is over range */
         
         /* set scale */
         GraphScale = 100;
         /* set multiplier */
         //ScaleMultiplier = (85/HistogramArray[145]);
         ScaleMultiplier = (85/HistogramArray[sizeof(HistogramArray)/8]);
         //MakeHistogram(30, 232, 610, 446, 100);
         MakeHistogram(64, 232, 576, 446, 100);
      }
      else
      {
         /* scale is over range */

         /* set scale */
         //GraphScale = (word)(HistogramArray[145]*1.15);
         GraphScale = (word)(HistogramArray[sizeof(HistogramArray)/8]*1.15);
         /* set multiplier */
         ScaleMultiplier = 0;
         //MakeHistogram(30, 232, 610, 446, GraphScale);
         MakeHistogram(64, 232, 576, 446, 100);
      }
      
      DisplayScale();      
   }
   else
   {
      winUpdate1 = 0;
      
      /* tell chart how many points are coming */
      slcd_SendAndWait("bcv 0 100");

      j = 0;
         
      /* copy 100 words from array */
      for (i=0;i<100;i++)
      {
         /* get word */
         k = (word)(HistogramArray[i]*ScaleMultiplier);                  
         /* copy to buffer */      
         SLCD.TxBuf[j++] = *(((byte *)&k)+1);         
         SLCD.TxBuf[j++] = *((byte *)&k);         
      }
      slcd_SendAndWaitBianry(200);

      j = 0;
      
      /* tell chart how many points are coming */
      slcd_SendAndWait("bcv 0 100");
      
      /* copy 100 words from array */
      for (i=0;i<100;i++)
      {
         /* get word */
         k = (word)(HistogramArray[100+i]*ScaleMultiplier);                  
         /* copy to buffer */      
         SLCD.TxBuf[j++] = *(((byte *)&k)+1);         
         SLCD.TxBuf[j++] = *((byte *)&k);         
      }
      slcd_SendAndWaitBianry(200);

      j = 0;
      
      /* tell chart how many points are coming */
      slcd_SendAndWait("bcv 0 100");
      
      /* copy 100 words from array */
      for (i=0;i<100;i++)
      {
         /* get word */
         k = (word)(HistogramArray[200+i]*ScaleMultiplier);                  
         /* copy to buffer */      
         SLCD.TxBuf[j++] = *(((byte *)&k)+1);         
         SLCD.TxBuf[j++] = *((byte *)&k);         
      }
      slcd_SendAndWaitBianry(200);
      
      __RESET_COP();

      j = 0;
      
      /* tell chart how many points are coming */
      slcd_SendAndWait("bcv 0 100");
      
      /* copy 100 words from array */
      for (i=0;i<100;i++)
      {
         /* get word */
         k = (word)(HistogramArray[300+i]*ScaleMultiplier);                  
         /* copy to buffer */      
         SLCD.TxBuf[j++] = *(((byte *)&k)+1);         
         SLCD.TxBuf[j++] = *((byte *)&k);         
      }
      slcd_SendAndWaitBianry(200);


      j = 0;
      
      /* tell chart how many points are coming */
      slcd_SendAndWait("bcv 0 100");
      
      /* copy 100 words from array */
      for (i=0;i<100;i++)
      {
         /* get word */
         k = (word)(HistogramArray[400+i]*ScaleMultiplier);                  
         /* copy to buffer */      
         SLCD.TxBuf[j++] = *(((byte *)&k)+1);         
         SLCD.TxBuf[j++] = *((byte *)&k);         
      }
      slcd_SendAndWaitBianry(200);

      j = 0;
      
      /* tell chart how many points are coming */
      slcd_SendAndWait("bcv 0 12");
      
      /* copy 12 words from array */
      for (i=0;i<12;i++)
      {
         /* get word */
         k = (word)(HistogramArray[500+i]*ScaleMultiplier);                  
         /* copy to buffer */      
         SLCD.TxBuf[j++] = *(((byte *)&k)+1);         
         SLCD.TxBuf[j++] = *((byte *)&k);         
      }
      slcd_SendAndWaitBianry(24);

      
      /* update mean display */
      DisplayMean();  

      /* update SD display */
      DisplayStdDev();  
   }
}


/*
** ------------------------------------------------------------------------------
**		Function: void ViewInspecMec(void)
** ------------------------------------------------------------------------------
*/
void ViewInspecMec(void){

  if(EEPROM.LocalTrans == 3) {
       if(EEPROM.AlinhamRoletes == 8){
          if(EEPROM.DistRoletes == 5){
             if(EEPROM.RigidezTrans == 9){
                if(EEPROM.Comportamento == 1){
                  if(EEPROM.SensorVel == 1){
                           bInspecMec = 0;
                  }else{
                     MessageError();                  
                  }
                }else{
                   MessageError();
                }
             }else{
                MessageError();
             }
          }else{
             MessageError();
          }
        }else{
           MessageError();                                                                               
        }
       
       } else{
          MessageError();
       }
   }  


/*
** ------------------------------------------------------------------------------
**		Function: void MessageError(void)
** ------------------------------------------------------------------------------
*/
void MessageError(void) {
          //winConfirmHandler();
            slcdCallMacro(28);
            bInspecMec = 1;
           
}

/*
** ------------------------------------------------------------------------------
**		Function: void DisplayFlowRate(void)
** ------------------------------------------------------------------------------
*/

void DisplayFlowRate(void)
{
   byte Buf[25];
   byte i;
   
   /* set big font */
   if(!HistogramSwitch)
      slcdSetFont(F32B);
     // slcdSetFont(F24x48);
   else
      //slcdSetFont(F24x48);
      slcdSetFont(F32B);      
   
   slcdSetColour(Green, Black);

   /* format Flow  */       
  // sprintf(Buf, "%u", (word)mbSlave.Rate);  
   sprintf(Buf, "%.*f ", EEPROM.Precision, (float)mbSlave.Rate);

   /* get string length  */
   i = strlen(Buf);
   
   /* has string length changed? */
   if(i!=LastFlowLen)
      /* clear display */
      if(!HistogramSwitch)         
         DisplayText("         ", 135, 4, 0);
      else         
         DisplayText("                            ", 135, 4, 0);      
   
   /* display new flow  */
   Buf[10] = 0;
   DisplayText(&Buf, 135, 4, 0);   
   mbTable[enRate].RdFlg = 1; 
   
   /* do we need to repaint the units? */
   if(i!=LastFlowLen)
   {
      /* copy last length */
      LastFlowLen = i;
      
      /* format string */
      if(!mbSlave.Units[0])
         strcpy(Buf, "t/h");
      else
         strcpy(Buf, "kg/h");
      
      /* set font and clour */
      slcdSetFont(F16B);
      slcdSetColour(LightBlue, Black);
      
      /* display new units */         
      if(!HistogramSwitch)
         DisplayText(&Buf, 80+(40*i)+15, 40, 0);   
      else
         DisplayText(&Buf, 50+(38*i)+45, 15, 0);   
   }
}

/*
** ------------------------------------------------------------------------------
**		Function: void DisplayTotal(void)
** ------------------------------------------------------------------------------
*/

void DisplayTotal(void)
{
   byte Buf[25];
   byte Bufi[25];
   //float Var;
   byte i;
   
   
   slcdSetColour(Green, Black);
   
   //Var = mbSlave.Total + mbSlave.DigitTotal;
   
   /* format Total  */       
   //sprintf(Buf, "%.0f", floorf(mbSlave.Total));  
   //sprintf(Buf, "%.*f ", EEPROM.Precision, Var);
   
   sprintf(Buf, "%.*f ", EEPROM.Precision, mbSlave.Total);

   /* get string length  */
   i = strlen(Buf);
   
   /* set big font */
   if(!HistogramSwitch)
   {
      //slcdSetFont(F32x64);
      slcdSetFont(F24x48);

      /* has string length changed? */
      if(i!=LastTotalLen)
         /* clear display */
         DisplayText("                               ", 140, 120, 0);      
      
      /* display new Total  */
      DisplayText(&Buf, 140, 120, 0);   
   }
   else
   {
      //slcdSetFont(F24x48);
      slcdSetFont(F32B);

      /* has string length changed? */
      if(i!=LastTotalLen)
         /* clear display */
         DisplayText("           ", 140, 80, 0);      
      
      /* display new Total  */
      DisplayText(&Buf, 140, 80, 0);   
   }

   mbTable[enDigTotal].RdFlg =1;
   mbTable[enTotal].RdFlg = 1;   
   
   /* do we need to repaint the units? */
   if(i!=LastTotalLen)
   {
      /* copy last length */
      LastTotalLen = i;
      
      /* format string */
      if(!mbSlave.Units[1])
         strcpy(Buf, "t");
         
      else
         strcpy(Buf, "kg");
      
      /* set font and clour */
      slcdSetFont(F16B);
      slcdSetColour(LightBlue, Black);
      
      /* display new units */         
      if(!HistogramSwitch)
         DisplayText(&Buf, 80+(56*i), 160, 0);
      else
         DisplayText(&Buf, 50+(38*i)+45, 95, 0);   
      
      
   }            
}


/*
** ------------------------------------------------------------------------------
**		Function: void DisplayMass(void)
** ------------------------------------------------------------------------------
*/

void DisplayMass(void)
{
   byte Buf[25];
   byte i;
   
   /* set big font */
   slcdSetFont(F24x48);
   slcdSetColour(Green, Black);
   
   /* format Mass  */       
   sprintf(Buf, "%.*f", mbSlave.Digit, mbSlave.Mass);

   /* get string length  */
   i = strlen(Buf);
   
   /* has string length changed? */
   if(i!=LastMassLen)
      /* clear display */
      DisplayText("                  ", 140, 240, 0);      
   
   /* display new Mass */
   DisplayText(&Buf, 140, 240, 0);  
   mbTable[enMass].RdFlg = 1;   
   
   /* do we need to repaint the units? */
   if(i!=LastMassLen)
   {
      /* copy last length */
      LastMassLen = i;
      
      /* format string */
      if(!mbSlave.Units[2])
         strcpy(Buf, "kg/m");
      else
         strcpy(Buf, "kg/m");
      
      /* set font and clour */
      slcdSetFont(F16B);
      slcdSetColour(LightBlue, Black);
      
      /* display new units */         
      DisplayText(&Buf, 80+(44*i)+40, 270, 0);   
   }           
}

/*
** ------------------------------------------------------------------------------
**		Function: void DisplaySpeed(void)
** ------------------------------------------------------------------------------
*/

void DisplaySpeed(void)
{
   byte Buf[25];
   byte i;
   
   /* set big font */
   slcdSetFont(F24x48);
   slcdSetColour(Green, Black);
   
   /* format Speed  */       
   sprintf(Buf, "%.*f", mbSlave.Digit, mbSlave.Speed);
   

   /* get string length  */
   i = strlen(Buf);
   
   /* has string length changed? */
   if(i!=LastSpeedLen)
      /* clear display */
      DisplayText("                  ", 140, 330, 0);      
   
   /* display new Speed */
   DisplayText(&Buf, 140, 330, 0);  
   mbTable[enSpeed].RdFlg = 1;   
   
   /* do we need to repaint the units? */
   if(i!=LastSpeedLen)
   {
      /* copy last length */
      LastSpeedLen = i;
      
      /* format string */
      if(!mbSlave.Units[3])
         strcpy(Buf, "m/s");
      else
         strcpy(Buf, "m/m");
      
      /* set font and clour */
      slcdSetFont(F16B);
      slcdSetColour(LightBlue, Black);
      
      /* display new units */         
      DisplayText(&Buf, 80+(44*i)+40, 360, 0);   
   }           
}

/*
** ------------------------------------------------------------------------------
**		Function: void DisplayTension(void)
** ------------------------------------------------------------------------------
*/

void DisplayTension(void)
{
   byte Buf[25];
   byte i;
   
   /* is the belt tension enabled? */
   if(mbSlave.AnInFunc[0]==1||mbSlave.AnInFunc[1]==1)
   {
      /* set big font */
      slcdSetFont(F16B);
      slcdSetColour(Green, Black);
      
      /* format Speed  */       
      sprintf(Buf, "%.*f", mbSlave.Digit, mbSlave.BeltTension);

      /* get string length  */
      i = strlen(Buf);
      
      /* has string length changed? */
      if(i!=LastTensionLen)
         /* clear display */
         DisplayText("                  ", 490, 410, 0);      
      
      /* display new Speed */
      DisplayText(&Buf, 490, 410, 0);  
      
      mbTable[enBeltTension].RdFlg = 0x1;  
      
      /* do we need to repaint the units? */
      if(i!=LastTensionLen)
      {
         /* copy last length */
         LastTensionLen = i;
         
         /* format string */
         //if(!mbSlave.Units[3])
         //   strcpy(Buf, "m/s");
         //else
         //   strcpy(Buf, "m/m");
         
         /* set font and clour */
         //slcdSetFont(F16B);
         //slcdSetColour(LightBlue, Black);
         
         /* display new units */         
         //DisplayText(&Buf, 90+(22*i)+20, 180, 0);   
      } 
   }
}


/*
** ------------------------------------------------------------------------------
**		Function: void DisplayDateTime(void)
** ------------------------------------------------------------------------------
*/

void DisplayDateTime(void)
{
   byte Buf[12];
   byte BufD[12];
   
   /* set big font */
   slcdSetFont(F16B);
   slcdSetColour(Green, Black);

   /* display Date*/
   strcpy(BufD, mbSlave.Date);
   BufD[8] = 0;      
   DisplayText(&BufD, 440, 448, 0);     
   
   /* display Time */      
   strcpy(Buf, mbSlave.Time);
   Buf[5] = 0;
   DisplayText(&Buf, 560, 448, 0);   

   mbTable[enTime].RdFlg = 0x1;
   mbTable[enDate].RdFlg = 0x1;      
}


/*
** ------------------------------------------------------------------------------
**		Function: void winUpdate(void)
** ------------------------------------------------------------------------------
*/

void winUpdate(void)
{
   
   if(!HistogramSwitch)
   {
      /* read alarm flag */
      mbTable[enAlarmFlag].RdFlg = 1;
      
      /* check alarm state will also set txt colour */
      //SetRateAlarm(); 
      if(bInspecMec==0)
      {
        DisplayFlowRate();
        
        /* check alarm state will also set txt colour */
        //SetTotalAlarm();
        
        DisplayTotal();

        /* check alarm state will also set txt colour */
        //SetMassAlarm(); 

        DisplayMass();
           
        /* check alarm state will also set txt colour */
        //SetSpeedAlarm();            

        DisplaySpeed();
        
        /* turn on open collector if any alarms are active */
        SetOpenCollector();
        
        DisplayTension();
        
        DisplayDateTime();
      }
      ViewInspecMec();  
   }
   else
   {
      /* read alarm flag */
      mbTable[enAlarmFlag].RdFlg = 1;
      
      /* check alarm state will also set txt colour */
      //SetRateAlarm(); 
      
      DisplayFlowRate();
      
      /* check alarm state will also set txt colour */
      //SetTotalAlarm();
      
      DisplayTotal(); 
   }
}


/*
** ------------------------------------------------------------------------------
**		Function: void winPaintHistogram(void)
** ------------------------------------------------------------------------------
*/

void winPaintHistogram(void)
{
   /* display arrow */
   slcd_CmdQueue("z");
   
   DisplayBmp(6, 560, 6);
   MakeHotSpot(128, 560, 0, 640, 40);   

   /* set font */
   slcdSetFont(F16B);
   
   /* set forground and back ground colour */
   slcdSetColour(LightBlue, DarkGrey);
   
   /* display Flow string  */
   DisplayText(gstr(&str->Flow) , 10, 4, 0);

   /* display Total string  */
   DisplayText(gstr(&str->Total1) , 10, 80, 0);

   /* display Total string  */
   DisplayText("Periodo (Ultimo):", 10, 156, 0);

   slcdSetColour(LightGrey, Black);
   
   /* is the histogram enabled */
   //slcd_CmdQueue("r 14 115 306 224 2");
   DrawLine(60,  228, 578, 228);   
   DrawLine(60,  448, 578, 448);   

   DrawLine(60,  230, 60,  448);   
   DrawLine(578, 230, 578, 448);   
   

   /* x points  */

   /* -3 */
   DrawLine(64,  448, 64,  456);                  
   /* -2 */
   DrawLine(145, 448, 145, 452);                     
   /* -1 */
   DrawLine(241, 448, 241, 452);                  
   /* 0 */
   DrawLine(320, 448, 320, 456);                  
   /* 1 */
   DrawLine(399, 448, 399, 452);                  
   /* 2 */
   DrawLine(495, 448, 495, 452);                     
   /* 3 */
   DrawLine(574, 448, 574, 456);                  

   /* set font */
   slcdSetFont(F13);
   slcdSetColour(LightBlue, Black);
   
   /* -3 */
   DisplayText("-3", 56,  460, 0);                  
   /* -2 */
   DisplayText("-2", 137, 460, 0);                     
   /* -1 */
   DisplayText("-1", 233, 460, 0);                  
   /* 0 */
   DisplayText("0",  318, 460, 0);                  
   /* 1 */
   DisplayText("1",  395, 460, 0);                  
   /* 2 */
   DisplayText("2",  491, 460, 0);                     
   /* 3 */              
   DisplayText("3",  570, 460, 0);                  
   
   /* display bmp */ 
   DisplayBmp(30, 560, 100);
   /* make hot spot */ 
   MakeHotSpot(130, 560, 100, 640, 230);           
   
   
   /* do we need the scale multiplier?  */
   if(HistogramArray[sizeof(HistogramArray)/8]<85)
   {
      /* scale is over range */
      
      /* set scale */
      GraphScale = 100;
      /* set multiplier */
      //ScaleMultiplier = (85/HistogramArray[145]);
      ScaleMultiplier = (85/HistogramArray[sizeof(HistogramArray)/8]);
      MakeHistogram(64, 232, 576, 446, 100);
   }
   else
   {
      /* scale is over range */

      /* set scale */
      GraphScale = (word)(HistogramArray[sizeof(HistogramArray)/8]*1.15);
      /* set multiplier */
      ScaleMultiplier = 0;
      MakeHistogram(64, 232, 576, 446, GraphScale);
   }
   
   DisplayScale();
   
   /* force unit update */
   LastFlowLen = 0;
   LastTotalLen = 0;
   LastMassLen = 0;
   LastSpeedLen = 0;  
   
   winTimer1 = 0;    
}

/*
** ------------------------------------------------------------------------------
**		Function: void winPaint(void)
** ------------------------------------------------------------------------------
*/


void winPaint(void)
{
   /* display arrow */
   DisplayBmp(6, 560, 6);
   //DisplayBmp(6, 660, 6);

   /* set font */
   slcdSetFont(F16B);
   
   /* set forground and back ground colour */
   slcdSetColour(LightBlue, Black);
   
   /* display Flow string  */
   DisplayText(gstr(&str->Flow) , 50, 25, 0);

   /* display Total string  */
   DisplayText(gstr(&str->Total1) , 52, 140, 0);

   /* display Weight string  */
   DisplayText(gstr(&str->Weight) , 52, 260, 0);

   /* display Speed string  */
   DisplayText(gstr(&str->Speed) , 10, 350, 0);

   slcdSetFont(F16);
   /* display Last Cal check  */
   DisplayText(gstr(&str->LastCalCheck) , 70, 410, 0); /*Before  5, 205, 0);*/
   DisplayText(gstr(&str->NextCal), 15, 450, 'T');     /*Before , 200, 205, 'T');*/

   /* display last cal Date */      
   slcdSetFont(F16B);
   
   /* is the belt tension enabled? */
   if(mbSlave.AnInFunc[0]==1)
      DisplayText("R = ", 440, 410, 0); 
   
   slcdSetColour(Green, Black);
   
   DisplayText(&EEPROM.MassCal[EEPROM.MassCalPtr].Date, 150, 410, 'T'); /*Before 140, 205, 'T');*/ 
   
   slcdSetColour(Red, Black);
   DisplayText(&EEPROM.NextCalDate, 150, 450, 'T');/*Before 260, 205, 'T');*/
   
   /* is the histogram enabled */
   if(EEPROM.Histogram)
   {
      /* display bmp */ 
      DisplayBmp(31, 560, 100);
      /* make hot spot */ 
      MakeHotSpot(130, 560, 100, 640, 250);           
   }
   
   /* force unit update */
   LastFlowLen = 0;
   LastTotalLen = 0;
   LastMassLen = 0;
   LastSpeedLen = 0;         
}

/*
** ------------------------------------------------------------------------------
**		Function: void winMainHandler(void)
** ------------------------------------------------------------------------------
*/

void winMainHandler(void)
{
   switch (winMainState)
   {
   case WIN_GET_PARA:
      /* read main parameters */
      ReadMainParameters();

      /* set 250 mS delay for parameters to arrive */
      winTimer1 = 25;
      /* got to next state and wait */
      winMainState = WIN_PAINT;
      break;
      
   case WIN_PAINT:
      OffsetOff();

      if(!winTimer1)
      {
         /* send command to execute macro 1 */
         slcdCallMacro(1);

         if(!HistogramSwitch)
            /* Paint screen  */
            winPaint();
         else
            /* Paint screen  */
            winPaintHistogram();

                              
         /* move to update state */      
         winMainState = WIN_UPDATE; 
         
         /* force display constituent update */
         winTimer1 = 0; 
         winTimer2 = 0;     
      }
      break;
      
   case WIN_UPDATE:

      /* is there a key to process? */
      if (slcdKey)
      {
         if(!mbSlave.OiLock)
         {
            /* call key handler */
            winMainKeyHandler(slcdKey); 
         }
         
         /* now the key has been processed clear it */
         slcdKey = 0; 
      }

      if(winUpdate1==1)
      {
         //winUpdate1 = 0;
         
         /* time to update the histogram */
         if(HistogramSwitch)
            UpDateHistogram();         
      }


      /* time to update? */
      if (!winTimer1)
      {
         winTimer1 = 25;
         
         /* handle trend update counter */
         if(TrendUpdateCounter)
            TrendUpdateCounter--;
         
         /* update status display */
         //GetStatusString();

         /* update */
         winUpdate();
      }
      
      /* time to update? */
      if (!winTimer2)
      {
         winTimer2 = 100;
         
         if(!HistogramSwitch)
            DisplayDateTime();
      }
      
      /* has any data been remotely changed? */
      if(mbSlave.DataUpdate)
      {
         /* clear data update flag */
         mbSlave.DataUpdate = 0;
         mbTable[enDataUp].WrFlg = 1;   
         
         /* read cal parameters */
         ReadMainParameters();  
         
         /* set update timer */                   
         winRePaint = 100;
      }
      
      if(winRePaint == 1)
      {
         winRePaint = 0;
         winMainState = WIN_PAINT;
      }
      
      break;
   
   case WIN_MAIN_ENTER_PASSWORD:
      /* see if key pad is returning */
      switch(winKeyPadHandler())
      {
      case 1:
         /* move to update state */      
         winMainState = WIN_PAINT;       
         break;

      case 2:
         /* move to update state */      
         //winMainState = WIN_USER_UNLOAD;       
         winActiveWin = SETUP_WINDOW;
         winMainState = WIN_GET_PARA;

         OffsetOff();
         break;

      case 3:
         /* Open engineering */
         winActiveWin = ENGINEERING_WINDOW; 
         winMainState = WIN_GET_PARA;

         OffsetOff();
         break;
      }
      break;
            
   case WIN_UNLOAD:
      /* do any necessary clearing up */
      winMainState = WIN_GET_PARA;  
      break;
   }   
}

/*
** ------------------------------------------------------------------------------
**		Function: void winMainCtrl(void)
** ------------------------------------------------------------------------------
*/

void winMainCtrl(void)
{  
   
   switch (winActiveWin) 
   {
   case  SPLASH_SCREEN:
      
      /* */
      //slcd_CmdQueue("vers"); 
      SLCD.RxPtr = SLCD.RxBuf;
      slcd_SendAndWait("vers");
      /* copy verion from buffer */
      strcpy(slcdVer, SLCD.RxBuf);

      if(!strncmp(slcdVer, "Dsp 1024x600", 12))
         PanelSize = PSZ_1024_600;
      else
         PanelSize = PSZ_640_480;

      OffsetOff();

      LangInit();
      
      /* display splash screen */
      DisplayBmp(1, 0, 0); 
      /* change handler state */
      winActiveWin = MODBUS_CONNECT;

      /* set font */
      slcdSetFont(F16);    
                
      /* set forground and back ground colour */
      slcdSetColour(Black, White);             
      /* display status */
      DisplayText(gstr(&str->StatusConnecting), 10,  10, 0);   
      /* delay for Connecting message */
      winSplashTimer = 100;
      break;
   
   case MODBUS_CONNECT:
      /* wait for it */
      if(!winSplashTimer)
      {
         /* wait on the splash screen if the modbus is down */
         if(mbStatus&mbONLINE)
         {
            /* clear the in flag */
            SLCD.In = 0;
                        
            /* display status */
            DisplayText(gstr(&str->StatusConnected), 10,  10, 0);   
            
            /* set font */
            slcdSetFont(F16);    
            
           
            strcat(mbSlave.VerMoStr,DisplayString);
            
            DisplayText(&mbSlave.VerMoStr, 260,  10, 0);   
            /* beep */
            //slcd_CmdQueue("beep 500");

            /* change handler state */
            winActiveWin = SPLASH_TIMEOUT;                       
            /* set 3 sec timeout delay for splash screen */
            winSplashTimer = 200;
         }      
      }
      break; 
            
   case SPLASH_TIMEOUT:
      /* wait for timer to run down */
      if (!winSplashTimer)
      {
         /* change handler state */
         winActiveWin = MAIN_WINDOW;
         
         /* set status delay to hold up start up faults for 10 sec */
         StatusDelay = 40;
      }
      break;
      
   case  MAIN_WINDOW:
      /* call the main window handler */
      winMainHandler(); 
      break;

   case USER_WINDOW:
      /* call the menu window handler */
      winUserMenuHandler(); 
      break;

   case BASIC_CONFIG_WINDOW:
      /* call the menu window handler */
      winBasicConfigHandler(); 
      break;
      
   case SPEEDCAL_WINDOW:
      /* call the window handler */
      winSpeedCalHandler(); 
      break;

   case MASSCAL_WINDOW:
      /* call the window handler */
      winMassCalHandler(); 
      break;

   case MASSSPANCAL_WINDOW:
      /* call the window handler */
      winMassSpanCalHandler(); 
      break;

   case TIMEDATE_WINDOW:
      /* call the window handler */
      winTimeDateHandler(); 
      break;
      
   case BALANCE_DATA_WINDOW:
      /* call the window handler */
      winBalanceDataHandler(); 
      break;
      
  case INPUTSOUTPUTS_WINDOW:
      /* call the menu window handler */
      winInputsOutputsHandler(); 
      break;

  case CALCONSTANTS_WINDOW:
      /* call the menu window handler */
      winCalConstantsHandler(); 
      break;

  case ENGINEERING_WINDOW:
      /* call the menu window handler */
      winEngineeringHandler(); 
      break;

  case AD7730_WINDOW:
      /* call the menu window handler */
      winAD7730Handler(); 
      break;

   case SETUP_WINDOW:
      /* call the menu window handler */
      winSetupHandler(); 
      break;      

  case SPECIALFUNC_WINDOW:
      /* call the menu window handler */
      winSpecialFuncHandler(); 
      break;  

  case FILTERING_WINDOW:
      /* call the menu window handler */
      winFilteringHandler(); 
      break;
      
  case TOTALIZER_WINDOW:
      /* call the menu window handler */
      winTotalizerHandler(); 
      break;      
      
   case DIGITS_WINDOW:
      /* call the diagnostics window handler */
      winDigitsHandler(); 
      break;
      
   case FIELDBUS_WINDOW:
      /* call the diagnostics window handler */
      winFieldBusHandler(); 
      break;   

   case CALFUNC_WINDOW:
      /* call the diagnostics window handler */
      winCalFunctionsHandler(); 
      break;
      
   case SIMULATION_WINDOW:
      /* call the diagnostics window handler */
      winSimulationHandler(); 
      break; 
      
   case DIGITALIN_WINDOW:
      /* call the diagnostics window handler */
      winDigitalInHandler(); 
      break;            

   case DIGITALOUT_WINDOW:
      /* call the diagnostics window handler */
      winDigitalOutHandler(); 
      break;            

   case ANALOGUEIN_WINDOW:
      /* call the diagnostics window handler */
      winAnalogueInHandler(); 
      break;            

   case ANALOGUEOUT_WINDOW:
      /* call the diagnostics window handler */
      winAnalogueOutHandler(); 
      break;            

   case TENSION_WINDOW:
      /* call the diagnostics window handler */
      winTensionHandler(); 
      break;
      
   case MOVING_AVERAGE_WINDOW:
      winMovingAverageHandler();
      break; 

   case HISTOGRAM_WINDOW:
      winHistogramHandler();
      break;  
      
   case INSPECMEC_WINDOW:
      winInspecMecHandler();
      break;      
           
   }  
}
