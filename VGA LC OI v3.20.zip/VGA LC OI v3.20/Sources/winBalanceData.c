#include <hidef.h>                           /* common defines and macros */
#include "derivative.h"                      /* derivative information */

/*
** ------------------------------------------------------------------------------
   
   File   : winBalanceData.c 
   Aurthor: 
   
   Description:  
   
   Version Log          Notes                                     Changes Made by                                        
   --------------       -----                                     ---------------
   21-10-09:            Created                                   Stuart


** ------------------------------------------------------------------------------
                                    
                                    Overview
                                            
** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

/* library headers */
#include "stdio.h"
#include "float.h"
#include "math.h"
#include "string.h"

/* Application headers */
#include "CRG 100110.h" 
#include "Subs.h"
#include "SlcdSubs.h"
#include "ModBusM Int.h"
#include "ModBusM.h"
#include "EEPROM.h"
#include "SLCD 260217.h"
#include "winMain.h"
#include "winUserMenu.h"
#include "winKey.h"
#include "Language.h"


/* Implements this interface: */
#define WINBALANCEDATA_C
#include "winBalanceData.h"

#pragma CODE_SEG WINBALANCEDATA_CODE
#pragma DATA_SEG WINBALANCEDATA_DATA


/* private */
static byte winBalanceDataState;

/* public */
byte winBalanceDataReturnWin;
byte PasswordLock;

float TestWightPercentage;

/* Balance Data screen layout (640x480 logical, scaled by slcd_SendText) */
#define BAL_FONT_DATA  8     /* body labels and values (do not use 14) */
#define BAL_LBL_X      15
#define BAL_VAL1S_R    155   /* right edge: TAG, model, C.C. values */
#define BAL_LBL2_X     165   /* paired-row labels (serial, mV/V) */
#define BAL_VAL2_R     310   /* right edge: left-half values */
#define BAL_RLBL_X     325   /* right column labels */
#define BAL_RVAL_R     625   /* right edge: right column values */
#define BAL_ROW1_Y     110   /* first row below 24pt title at y=60 */
#define BAL_ROW_DY     32    /* standard row spacing */
#define BAL_ROW(n)     (BAL_ROW1_Y + (((n) - 1) * BAL_ROW_DY))
#define BAL_FOOTER_Y   BAL_ROW(10)   /* aligned with row 10 � do not hardcode */
#define BAL_FOOTER_DY  14    /* 8pt footer line spacing */
#define BAL_HS_YT(n)      (BAL_ROW(n) - 4)
#define BAL_HS_YB(n)      (BAL_ROW(n) + 28)
#define BAL_HS_H(n)       (BAL_HS_YB(n) - BAL_HS_YT(n))
#define BAL_HS_VAL1S_X1   70
#define BAL_HS_VAL1S_X2   165
#define BAL_HS_VAL2_X1    160
#define BAL_HS_VAL2_X2    320
#define BAL_HS_RVAL_X1    320
#define BAL_HS_RVAL_X2    635
#define BAL_HS_W_VAL1S    (BAL_HS_VAL1S_X2 - BAL_HS_VAL1S_X1)
#define BAL_HS_W_VAL2     (BAL_HS_VAL2_X2 - BAL_HS_VAL2_X1)
#define BAL_HS_W_RVAL     (BAL_HS_RVAL_X2 - BAL_HS_RVAL_X1)

/*
** ------------------------------------------------------------------------------
**		Function: void UnlockPassword(void)
** ------------------------------------------------------------------------------
*/

void UnlockPassword(void)
{   
   /* allow access to parameters */
   PasswordLock = 1;
}

/*
** ------------------------------------------------------------------------------
**		Function: void CalculatePreSpan(void)
** ------------------------------------------------------------------------------
*/

void CalculatePreSpan(void)
{   
   /* claculate new span */

   /* save the span */
   mbSlave.Span[2] = ((EEPROM.ApplicationCapacity/3.6)/10.0);      
   /* write to sensor */
   mbTable[enMassSpan].WrFlg = 1;

}

/*
** ------------------------------------------------------------------------------
**		Function: void winBalanceDataKeyHandler(byte key)
** ------------------------------------------------------------------------------
*/

void winBalanceDataKeyHandler(byte key)
{   
   if(!PasswordLock)
   {
      switch (key)
      {
      case 128:       /* EXIT */
         winBalanceDataReturnWin = USER_WINDOW;
         /* shut down num key window handler */
         winBalanceDataState = WIN_BALANCE_DATA_UNLOAD;  
         break;  
      
      default:
         /* display password prompt */
         winBalanceDataState = WIN_BALANCE_DATA_ENTER_PASSWORD;     
         
         winUserReturnWin = BALANCE_DATA_WINDOW;
         
         /* copy parameter data to key structure */
         strcpy(NumKeyData.Name, gstr(&str->EnterPassword) );  
         NumKeyData.KeyBoardType = NUMBER;
         NumKeyData.Type = ENTERPASSWORD;  
         
         /* set func ptr */
         NumKeyData.fp = UnlockPassword;
              
         break;
      }
      
   }
   else
   {
      switch (key)
      {
      case 128:       /* EXIT */
         winBalanceDataReturnWin = USER_WINDOW;
         /* shut down num key window handler */
         winBalanceDataState = WIN_BALANCE_DATA_UNLOAD;  
         break;  

      
      case 130:      /* tag hotspot */
         /* move to key pad handler sate */
         winBalanceDataState = WIN_BALANCE_DATA_NUMKEYPAD; 
         
         /* copy parameter data to key structure */
         strcpy(NumKeyData.Name, "Tag");  
         NumKeyData.KeyBoardType = LETTER;
         NumKeyData.Type = STRING;
         NumKeyData.iMax = 16;
         NumKeyData.Attributes = EPROM;
         NumKeyData.DataPtr  = (void *)&EEPROM.Tag;     
         break; 

      case 131:      /* transport capacity */
         /* move to key pad handler sate */
         winBalanceDataState = WIN_BALANCE_DATA_NUMKEYPAD; 
         
         /* copy parameter data to key structure */
         strcpy(NumKeyData.Name, gstr(&str->TransportCapacity) );  
         NumKeyData.Type = FLOAT;
         NumKeyData.KeyBoardType = NUMBER;
         NumKeyData.Attributes = EPROM;
         NumKeyData.fMax = 1000.0;
         NumKeyData.fMin = 0.0;      
         
         NumKeyData.DataPtr = (void *)&EEPROM.TransportCapacity;
         /* set func ptr */
         //NumKeyData.fp = ;       
         break; 
             
      case 132:      /* Application capacity  */
         /* move to key pad handler sate */
         winBalanceDataState = WIN_BALANCE_DATA_NUMKEYPAD; 
         
         /* copy parameter data to key structure */
         strcpy(NumKeyData.Name, gstr(&str->ApplicationCapacity) );  
         NumKeyData.Type = FLOAT;
         NumKeyData.KeyBoardType = NUMBER;
         NumKeyData.Attributes = EPROM;
         NumKeyData.fMax = 20000.0;
         NumKeyData.fMin = 0.0;      
         
         NumKeyData.DataPtr = (void *)&EEPROM.ApplicationCapacity;
         /* set func ptr */
         NumKeyData.fp = CalculatePreSpan;       
         
         /* write to processor also */
          mbTable[enAppCapacity].WrFlg = 0x1;
         break;       
         
      case 133:      /* display balance capacity */
         /* move to key pad handler sate */
         winBalanceDataState = WIN_BALANCE_DATA_NUMKEYPAD; 
         
         /* copy parameter data to key structure */
         strcpy(NumKeyData.Name, gstr(&str->BalanceCapacity) );  
         NumKeyData.Type = FLOAT;
         NumKeyData.KeyBoardType = NUMBER;
         NumKeyData.Attributes = EPROM;
         NumKeyData.fMax = 10000.0;
         NumKeyData.fMin = 0.0;      
         
         NumKeyData.DataPtr = (void *)&EEPROM.BalanceCapacity;
         /* set func ptr */
         //NumKeyData.fp = ;       
         break; 
         
      case 134:      /* Test Weight Percentage */
         /* move to key pad handler sate */
         winBalanceDataState = WIN_BALANCE_DATA_NUMKEYPAD; 
         
         /* copy parameter data to key structure */
         strcpy(NumKeyData.Name, gstr(&str->TestWightAppPercentage) );  
         NumKeyData.Type = FLOAT;
         NumKeyData.KeyBoardType = NUMBER;
         NumKeyData.Attributes = EPROM;
         NumKeyData.fMax = 110.0;
         NumKeyData.fMin = 0.0;      
         
         NumKeyData.DataPtr = (void *)&EEPROM.TestWightAppPercentage;
         /* set func ptr */
         //NumKeyData.fp = ;       
         break;                   

      case 135:      /* Test Weight */
         /* move to key pad handler sate */
         winBalanceDataState = WIN_BALANCE_DATA_NUMKEYPAD; 
         
         /* copy parameter data to key structure */
         strcpy(NumKeyData.Name, gstr(&str->TestWeight) );  
         NumKeyData.Type = FLOAT;
         NumKeyData.KeyBoardType = NUMBER;
         NumKeyData.Attributes = EPROM;
         NumKeyData.fMax = 1000.0;
         NumKeyData.fMin = 0.0;      
         
         NumKeyData.DataPtr = (void *)&EEPROM.RefWeight;
         /* set func ptr */
         //NumKeyData.fp = ;       
         break;

      case 136:      /* display Shiping date  */                             
         /* move to key pad handler sate */
         winBalanceDataState = WIN_BALANCE_DATA_NUMKEYPAD; 
         
         /* copy parameter data to key structure */
         strcpy(NumKeyData.Name, gstr(&str->ShippingDate));  
         NumKeyData.KeyBoardType = NUMBER;
         NumKeyData.Type = DATE;
         NumKeyData.iMax = 10;
         NumKeyData.Attributes = EPROM;
         NumKeyData.DataPtr = (void *)&EEPROM.ShippingDate;     
         break;  

      case 137:      /* Material Density hotspot */
         /* move to key pad handler sate */
         winBalanceDataState = WIN_BALANCE_DATA_NUMKEYPAD; 
         
         /* copy parameter data to key structure */
         strcpy(NumKeyData.Name, gstr(&str->MaterialDensity) );  
         NumKeyData.Type = FLOAT;
         NumKeyData.KeyBoardType = NUMBER;
         NumKeyData.Attributes = EPROM;
         NumKeyData.fMax = 10000.0;
         NumKeyData.fMin = 0.0;
         NumKeyData.Index = 0;
         
         NumKeyData.DataPtr = (void *)&EEPROM.MaterialDensity;
         break; 

      case 138:      /* Belt Length hotspot */
         /* move to key pad handler sate */
         winBalanceDataState = WIN_BALANCE_DATA_NUMKEYPAD; 
         
         /* copy parameter data to key structure */
         strcpy(NumKeyData.Name, gstr(&str->BeltLength) );  
         NumKeyData.Type = FLOAT;
         NumKeyData.KeyBoardType = NUMBER;
         NumKeyData.fMax = 3000.0;
         NumKeyData.fMin = 0.0;
         NumKeyData.Index = 0;
         NumKeyData.Flag  = enBeltLength;
         
         NumKeyData.DataPtr = (void *)&mbSlave.BeltLength;
         break; 
     
      case 139:      /* belt width */
         /* move to key pad handler sate */
         winBalanceDataState = WIN_BALANCE_DATA_NUMKEYPAD; 
         
         /* copy parameter data to key structure */
         strcpy(NumKeyData.Name, gstr(&str->BeltWidth) );  
         NumKeyData.Type = WORD;
         NumKeyData.KeyBoardType = NUMBER;
         NumKeyData.Attributes = EPROM;
         NumKeyData.iMax = 10000;
         NumKeyData.iMin = 0;      
         
         NumKeyData.DataPtr = (void *)&EEPROM.BeltWidth;
         /* set func ptr */
         //NumKeyData.fp = ;       
         break;       
         
         
      case 140:      /* belt speed  */
         /* move to key pad handler sate */
         winBalanceDataState = WIN_BALANCE_DATA_NUMKEYPAD; 
         
         /* copy parameter data to key structure */
         strcpy(NumKeyData.Name, gstr(&str->BeltSpeed) );  
         NumKeyData.Type = FLOAT;
         NumKeyData.KeyBoardType = NUMBER;
         NumKeyData.Attributes = EPROM;
         NumKeyData.fMax = 20.0;
         NumKeyData.fMin = 0.0;
         
         NumKeyData.DataPtr = (void *)&EEPROM.BeltSpeed;
         break; 

      case 141:      /* Convayor Angle */
         /* move to key pad handler sate */
         winBalanceDataState = WIN_BALANCE_DATA_NUMKEYPAD; 
         
         /* copy parameter data to key structure */
         strcpy(NumKeyData.Name, gstr(&str->ConvayorAngle) );  
         NumKeyData.Type = FLOAT;
         NumKeyData.KeyBoardType = NUMBER;
         NumKeyData.Attributes = EPROM;
         NumKeyData.fMax = 360.0;
         NumKeyData.fMin = 0.0;
         NumKeyData.Flag  = enBeltLength;
         
         NumKeyData.DataPtr = (void *)&EEPROM.ConvayorAngle;
         break;                           
         
      case 142:      /* Roller Angle */
         /* move to key pad handler sate */
         winBalanceDataState = WIN_BALANCE_DATA_NUMKEYPAD; 
         
         /* copy parameter data to key structure */
         strcpy(NumKeyData.Name, gstr(&str->RollerAngle) );  
         NumKeyData.Type = FLOAT;
         NumKeyData.KeyBoardType = NUMBER;
         NumKeyData.Attributes = EPROM;
         NumKeyData.fMax = 360.0;
         NumKeyData.fMin = 0.0;
         NumKeyData.Flag  = enBeltLength;
         
         NumKeyData.DataPtr = (void *)&EEPROM.RollerAngle;
         break;    
         
      case 143:      /* Idle Spacing */
         /* move to key pad handler sate */
         winBalanceDataState = WIN_BALANCE_DATA_NUMKEYPAD; 
         
         /* copy parameter data to key structure */
         strcpy(NumKeyData.Name, gstr(&str->IdleSpacing) );  
         NumKeyData.Type = FLOAT;
         NumKeyData.KeyBoardType = NUMBER;
         NumKeyData.Attributes = EPROM;
         NumKeyData.fMax = 10.0;
         NumKeyData.fMin = 0.0;
         NumKeyData.Flag  = enBeltLength;
         
         NumKeyData.DataPtr = (void *)&EEPROM.IdleSpacing;
         break;            
         
     case 144:      /* Sensibility LC */
         /* move to key pad handler sate */
         winBalanceDataState = WIN_BALANCE_DATA_NUMKEYPAD; 
         
         /* copy parameter data to key structure */
         strcpy(NumKeyData.Name, gstr(&str->SensibilityLC) );  
         NumKeyData.Type = FLOAT;
         NumKeyData.KeyBoardType = NUMBER;
         NumKeyData.Attributes = EPROM;
         NumKeyData.fMax = 3.0;
         NumKeyData.fMin = 1.0;      
         
         NumKeyData.DataPtr = (void *)&EEPROM.SensibilityLC;
         /* set func ptr */
         //NumKeyData.fp = ;       
         break;
             
       case 145:      /* Serail Number MS */
           /* move to key pad handler sate */
           winBalanceDataState = WIN_BALANCE_DATA_NUMKEYPAD;
           
           /* copy parameter data to key structure */
           strcpy(NumKeyData.Name, gstr(&str->SerNumMS));  
           NumKeyData.KeyBoardType = LETTER;
           NumKeyData.Type = STRING;
           NumKeyData.iMax = 10;
           NumKeyData.Attributes = EPROM;
           NumKeyData.DataPtr = (void *)&EEPROM.SerNumEq;     
       break;
       
       case 146:      /* Modelo Balan�a */
           /* move to key pad handler sate */
           winBalanceDataState = WIN_BALANCE_DATA_NUMKEYPAD;
           
           /* copy parameter data to key structure */
           strcpy(NumKeyData.Name, gstr(&str->ModelScale));  
           NumKeyData.KeyBoardType = LETTER;
           NumKeyData.Type = STRING;
           NumKeyData.iMax = 10;
           NumKeyData.Attributes = EPROM;
           NumKeyData.DataPtr  = (void *)&EEPROM.ModeloScale;
       break;                                   
             
      }
   }
}


/*
** ------------------------------------------------------------------------------
**		Function: void ReadBalanceDataParameters(void)
** ------------------------------------------------------------------------------
*/

void ReadBalanceDataParameters(void)
{
   mbTable[enTag].RdFlg = 0x1;
   mbTable[enVersion].RdFlg = 0x1;
   
   mbTable[enBeltSpeed].RdFlg = 0x1;
   mbTable[enBeltLength].RdFlg = 0x1;
   mbTable[enSerNo].RdFlg = 0x1;

}


/*
** ------------------------------------------------------------------------------
**		Function: void MakeBalanceHotspots(void)
** ------------------------------------------------------------------------------
*/

void MakeBalanceHotspots(void)
{
   /* left column value hotspots (x, y, width, height) */
   slcd_MakeHotSpot(130, BAL_HS_VAL1S_X1, BAL_HS_YT(1), BAL_HS_W_VAL1S, BAL_HS_H(1)); /* tag */
   slcd_MakeHotSpot(146, BAL_HS_VAL1S_X1, BAL_HS_YT(2), BAL_HS_W_VAL1S, BAL_HS_H(2)); /* model */
   slcd_MakeHotSpot(131, BAL_HS_VAL1S_X1, BAL_HS_YT(3), BAL_HS_W_VAL1S, BAL_HS_H(3)); /* transport capacity */
   slcd_MakeHotSpot(132, BAL_HS_VAL2_X1,   BAL_HS_YT(4), BAL_HS_W_VAL2,   BAL_HS_H(4)); /* application capacity */
   slcd_MakeHotSpot(133, BAL_HS_VAL2_X1,   BAL_HS_YT(5), BAL_HS_W_VAL2,   BAL_HS_H(5)); /* balance capacity */
   slcd_MakeHotSpot(134, BAL_HS_VAL2_X1,   BAL_HS_YT(7), BAL_HS_W_VAL2,   BAL_HS_H(7)); /* test weight % */
   slcd_MakeHotSpot(135, BAL_HS_VAL2_X1,   BAL_HS_YT(8), BAL_HS_W_VAL2,   BAL_HS_H(8)); /* test weight */
   slcd_MakeHotSpot(136, BAL_HS_VAL2_X1,   BAL_HS_YT(9), BAL_HS_W_VAL2,   BAL_HS_H(9)); /* shipping date */

   /* mid-column value hotspots (serial, mV/V) */
   slcd_MakeHotSpot(145, BAL_HS_VAL2_X1, BAL_HS_YT(2), BAL_HS_W_VAL2, BAL_HS_H(2)); /* serial number */
   slcd_MakeHotSpot(144, BAL_HS_VAL2_X1, BAL_HS_YT(3), BAL_HS_W_VAL2, BAL_HS_H(3)); /* sensibility LC */

   /* right column value hotspots */
   slcd_MakeHotSpot(137, BAL_HS_RVAL_X1, BAL_HS_YT(1), BAL_HS_W_RVAL, BAL_HS_H(1)); /* material density */
   slcd_MakeHotSpot(138, BAL_HS_RVAL_X1, BAL_HS_YT(2), BAL_HS_W_RVAL, BAL_HS_H(2)); /* belt length */
   slcd_MakeHotSpot(139, BAL_HS_RVAL_X1, BAL_HS_YT(3), BAL_HS_W_RVAL, BAL_HS_H(3)); /* belt width */
   slcd_MakeHotSpot(140, BAL_HS_RVAL_X1, BAL_HS_YT(4), BAL_HS_W_RVAL, BAL_HS_H(4)); /* belt speed */
   slcd_MakeHotSpot(141, BAL_HS_RVAL_X1, BAL_HS_YT(5), BAL_HS_W_RVAL, BAL_HS_H(5)); /* convayor angle */
   slcd_MakeHotSpot(142, BAL_HS_RVAL_X1, BAL_HS_YT(6), BAL_HS_W_RVAL, BAL_HS_H(6)); /* roller angle */
   slcd_MakeHotSpot(143, BAL_HS_RVAL_X1, BAL_HS_YT(7), BAL_HS_W_RVAL, BAL_HS_H(7)); /* idle spacing */
}


/*
** ------------------------------------------------------------------------------
**		Function: void PaintBalanceDataNew(void)
** ------------------------------------------------------------------------------
*/

void PaintBalanceDataNew(void) 
{
   byte Buf[25];
   byte VerBuf[20];

   TestWightPercentage = ((EEPROM.ApplicationCapacity/3.6)*(EEPROM.TestWightAppPercentage/100.0))/EEPROM.BeltSpeed;

   slcd_SetFont(8, 0);
   slcd_SetColour(DarkGrey, White);

   /* left column labels */
   slcd_SendText(gstr(&str->BalanceLbl_Tag),          BAL_LBL_X, BAL_ROW(1), 0, LEFT_ALIGN);
   slcd_SendText(gstr(&str->BalanceLbl_Model),        BAL_LBL_X, BAL_ROW(2), 0, LEFT_ALIGN);
   slcd_SendText(gstr(&str->BalanceLbl_SerialNo),     BAL_LBL2_X, BAL_ROW(2), 0, LEFT_ALIGN);
   slcd_SendText(gstr(&str->BalanceLbl_CC),           BAL_LBL_X, BAL_ROW(3), 0, LEFT_ALIGN);
   slcd_SendText(gstr(&str->BalanceLbl_mVperV),       BAL_LBL2_X, BAL_ROW(3), 0, LEFT_ALIGN);
   slcd_SendText(gstr(&str->BalanceLbl_ProjFlow),     BAL_LBL_X, BAL_ROW(4), 0, LEFT_ALIGN);
   slcd_SendText(gstr(&str->BalanceLbl_ScaleCap),     BAL_LBL_X, BAL_ROW(5), 0, LEFT_ALIGN);
   slcd_SendText(gstr(&str->BalanceLbl_TestWtEquiv),  BAL_LBL_X, BAL_ROW(6), 0, LEFT_ALIGN);
   slcd_SendText(gstr(&str->BalanceLbl_TestWtPct),    BAL_LBL_X, BAL_ROW(7), 0, LEFT_ALIGN);
   slcd_SendText(gstr(&str->BalanceLbl_TestWtKg),     BAL_LBL_X, BAL_ROW(8), 0, LEFT_ALIGN);
   slcd_SendText(gstr(&str->BalanceLbl_FactoryDate),  BAL_LBL_X, BAL_ROW(9), 0, LEFT_ALIGN);
   slcd_SendText(gstr(&str->BalanceLbl_Version),      BAL_LBL_X, BAL_ROW(10), 0, LEFT_ALIGN);

   /* right column labels */
   slcd_SendText(gstr(&str->BalanceLbl_Density),      BAL_RLBL_X, BAL_ROW(1), 0, LEFT_ALIGN);
   slcd_SendText(gstr(&str->BalanceLbl_BeltLength),   BAL_RLBL_X, BAL_ROW(2), 0, LEFT_ALIGN);
   slcd_SendText(gstr(&str->BalanceLbl_BeltWidth),    BAL_RLBL_X, BAL_ROW(3), 0, LEFT_ALIGN);
   slcd_SendText(gstr(&str->BalanceLbl_DesignSpeed),  BAL_RLBL_X, BAL_ROW(4), 0, LEFT_ALIGN);
   slcd_SendText(gstr(&str->BalanceLbl_ConvIncline),  BAL_RLBL_X, BAL_ROW(5), 0, LEFT_ALIGN);
   slcd_SendText(gstr(&str->BalanceLbl_RollerIncline),BAL_RLBL_X, BAL_ROW(6), 0, LEFT_ALIGN);
   slcd_SendText(gstr(&str->BalanceLbl_RollerSpacing),BAL_RLBL_X, BAL_ROW(7), 0, LEFT_ALIGN);

   if(PasswordLock)
      slcd_SetColour(LightBlue, White);
   else
      slcd_SetColour(Blue, White);

   /* left column data */
   slcd_SendText(EEPROM.Tag, BAL_VAL1S_R, BAL_ROW(1), 0, RIGHT_ALIGN);

   strncpy(Buf, EEPROM.ModeloScale, 11);
   Buf[11] = 0;
   slcd_SendText(&Buf, BAL_VAL1S_R, BAL_ROW(2), 0, RIGHT_ALIGN);

   sprintf(Buf, "%s", EEPROM.SerNumEq);
   slcd_SendText(&Buf, BAL_VAL2_R, BAL_ROW(2), 0, RIGHT_ALIGN);

   sprintf(Buf, "%.2f", EEPROM.TransportCapacity);
   slcd_SendText(&Buf, BAL_VAL1S_R, BAL_ROW(3), 0, RIGHT_ALIGN);

   sprintf(Buf, "%.2f", EEPROM.SensibilityLC);
   slcd_SendText(&Buf, BAL_VAL2_R, BAL_ROW(3), 0, RIGHT_ALIGN);

   sprintf(Buf, "%.2f", EEPROM.ApplicationCapacity);
   slcd_SendText(&Buf, BAL_VAL2_R, BAL_ROW(4), 0, RIGHT_ALIGN);

   sprintf(Buf, "%.2f", EEPROM.BalanceCapacity);
   slcd_SendText(&Buf, BAL_VAL2_R, BAL_ROW(5), 0, RIGHT_ALIGN);

   sprintf(Buf, "%.2f", TestWightPercentage);
   slcd_SendText(&Buf, BAL_VAL2_R, BAL_ROW(6), 0, RIGHT_ALIGN);

   sprintf(Buf, "%.2f", EEPROM.TestWightAppPercentage);
   slcd_SendText(&Buf, BAL_VAL2_R, BAL_ROW(7), 0, RIGHT_ALIGN);

   sprintf(Buf, "%.2f", EEPROM.RefWeight);
   slcd_SendText(&Buf, BAL_VAL2_R, BAL_ROW(8), 0, RIGHT_ALIGN);

   sprintf(Buf, "%s", EEPROM.ShippingDate);
   slcd_SendText(&Buf, BAL_VAL2_R, BAL_ROW(9), 0, RIGHT_ALIGN);

   strncpy(VerBuf, mbSlave.VerMoStr, sizeof(VerBuf)-1);
   VerBuf[sizeof(VerBuf)-1] = 0;
   strcat(VerBuf, DisplayString);
   slcd_SendText(VerBuf, BAL_VAL2_R, BAL_ROW(10), 0, RIGHT_ALIGN);

   /* right column data */
   sprintf(Buf, "%.2f", EEPROM.MaterialDensity);
   slcd_SendText(&Buf, BAL_RVAL_R, BAL_ROW(1), 0, RIGHT_ALIGN);

   sprintf(Buf, "%.2f", mbSlave.BeltLength);
   slcd_SendText(&Buf, BAL_RVAL_R, BAL_ROW(2), 0, RIGHT_ALIGN);

   sprintf(Buf, "%u", EEPROM.BeltWidth);
   slcd_SendText(&Buf, BAL_RVAL_R, BAL_ROW(3), 0, RIGHT_ALIGN);

   sprintf(Buf, "%.2f", EEPROM.BeltSpeed);
   slcd_SendText(&Buf, BAL_RVAL_R, BAL_ROW(4), 0, RIGHT_ALIGN);

   sprintf(Buf, "%.2f", EEPROM.ConvayorAngle);
   slcd_SendText(&Buf, BAL_RVAL_R, BAL_ROW(5), 0, RIGHT_ALIGN);

   sprintf(Buf, "%.2f", EEPROM.RollerAngle);
   slcd_SendText(&Buf, BAL_RVAL_R, BAL_ROW(6), 0, RIGHT_ALIGN);

   sprintf(Buf, "%.2f", EEPROM.IdleSpacing);
   slcd_SendText(&Buf, BAL_RVAL_R, BAL_ROW(7), 0, RIGHT_ALIGN);

   slcd_SetColour(DarkGrey, White);

   /* manufacturer footer (right column, below data fields) */
   slcd_SendText(gstr(&str->BalanceLbl_ManufacturedBy), BAL_RLBL_X, BAL_FOOTER_Y, 0, LEFT_ALIGN);
   slcd_SendText(gstr(&str->BalanceLbl_MSCompany),      BAL_RLBL_X, BAL_FOOTER_Y + BAL_FOOTER_DY, 0, LEFT_ALIGN);
   slcd_SendText(gstr(&str->BalanceLbl_MSLocation),     BAL_RLBL_X, BAL_FOOTER_Y + (2 * BAL_FOOTER_DY), 0, LEFT_ALIGN);
   slcd_SendText(gstr(&str->BalanceLbl_MSWebsite),      BAL_RLBL_X, BAL_FOOTER_Y + (3 * BAL_FOOTER_DY), 0, LEFT_ALIGN);
}

/*
** ------------------------------------------------------------------------------
**		Function: void UpdateBalanceData(void)
** ------------------------------------------------------------------------------
*/

void UpdateBalanceData(void)
{   
   /* requested update */
   if (winUpdate1==1)
   {
      /* stop counter */
      winUpdate1 = 0;
      
   }

   /* time to update? */
   if (!winTimer1)
   {
      winTimer1 = 25;  
     
      
   }
}

/*
** ------------------------------------------------------------------------------
**		Function: byte winBalanceDataHandler(void)
** ------------------------------------------------------------------------------
*/

byte winBalanceDataHandler(void)
{
   switch (winBalanceDataState)
   {
   case WIN_BALANCE_DATA_PREPAINT:
      /* get analog parameters from slave */
      ReadBalanceDataParameters();

  
      /* set delay for parameters to arrive from MCT  */
      winUpdate1 = 15;
      
      winBalanceDataState = WIN_BALANCE_DATA_PAINT;
      break;
      
   case WIN_BALANCE_DATA_PAINT:
      if(winUpdate1==1)
      {
         winUpdate1 = 0;

         slcd_SetColour(DarkGrey, DarkGrey);
         slcd_Send("z");

         slcd_Send("xc all");     
         /* display menu screen */
         //DisplayBmp(16, 0, 0); 
         slcd_DisplayBmp(10, 0, 0); 

         DisplayTitle("MS Instrumentos");
         
         slcd_SetFont(24, 0);
         slcd_SetColour(DarkGrey, White); 
         slcd_SendText(gstr(&str->BalanceScreenTitle), 15, 60, 0, LEFT_ALIGN);

         /* define back hotspot */
         slcd_MakeHotSpot(128, 560, 10, 50, 50);

         MakeBalanceHotspots();

         PaintBalanceDataNew();
         
         /* update parameters */
         winUpdate1 = 1;
         
         /* move to update state */      
         winBalanceDataState = WIN_BALANCE_DATA_UPDATE;       
      }
      return 0;

   case WIN_BALANCE_DATA_UPDATE:
      /* is there a key to process? */
      if (slcdKey)
      {
         /* call key handler */
         winBalanceDataKeyHandler(slcdKey);      
         /* now the key has been processed clear it */
         slcdKey = 0; 
      }

      UpdateBalanceData();

      /* has any data been remotely changed? */
      if(mbSlave.DataUpdate)
      {
         /* clear data update flag */
         mbSlave.DataUpdate = 0;
         mbTable[enDataUp].WrFlg = 1;   
         
         /* read analog parameters */
         ReadBalanceDataParameters();  
         
         /* set update timer */                   
         winUpdate1 = 100;
      }      
      return 0;

  case WIN_BALANCE_DATA_NUMKEYPAD:
      /* see if key pad is returning */
      if(winKeyPadHandler())
      {
         /* move to update state */      
         winBalanceDataState = WIN_BALANCE_DATA_PREPAINT;       
      }
      break;

 case WIN_BALANCE_DATA_ENTER_PASSWORD:
      /* see if key pad is returning */
      switch(winKeyPadHandler())
      {
      case 1:
         /* move to update state */      
         winBalanceDataState = WIN_BALANCE_DATA_PREPAINT;       
         break;
      }
      break;
      
   case WIN_BALANCE_DATA_UNLOAD:
      /* do any necessary clearing up */
      winBalanceDataState = WIN_BALANCE_DATA_PREPAINT;  

      /* set return menu */
      winActiveWin = BASIC_CONFIG_WINDOW;
      
      PasswordLock = 0;

      /* return from key pad */
      return 1;
   }   
}



