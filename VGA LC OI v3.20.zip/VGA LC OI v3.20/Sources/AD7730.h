/*
** ------------------------------------------------------------------------------
   
   File   : AD7730.h 
   Aurthor: Stuart Clarke

** ------------------------------------------------------------------------------

   COPYRIGHT NOTIFICATION (c)2010 MS INSTRUMENTOS INDUSTRIAIS LTDA
   This program is the property of MS INSTRUMENTOS INDUSTRIAIS LTDA.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   MS INSTRUMENTOS INDUSTRIAIS LTDA
   Industriais Ltda 
   Estrada do Bigu�� 43 - Alto da Boa Vista 
   Rio de Janeiro RJ/Brasil
  
** ------------------------------------------------------------------------------
*/

#ifndef AD7730_H
#define AD7730_H


/* public defines */


/*
** ------------------------------------------------------------------------------
**		AD7730 Status register 
** ------------------------------------------------------------------------------
*/

#pragma DATA_SEG WINAD7730_DATA

/*** AD7730 Status Register ***/
typedef union {
  byte Byte;
  struct {
    byte RDY        :1;
    byte STDY       :1;
    byte STBY       :1;
    byte NOREF      :1;
    byte MS3        :1;
    byte MS2        :1;
    byte MS1        :1;
    byte MS0        :1;
  } Bits;
} STATUS_STR;

extern volatile STATUS_STR _STATUS;

#define ADSTATUS                             _STATUS.Byte
#define ADSTATUS_RDY                         _STATUS.Bits.RDY
#define ADSTATUS_STDY                        _STATUS.Bits.STDY
#define ADSTATUS_STBY                        _STATUS.Bits.STBY
#define ADSTATUS_NOREF                       _STATUS.Bits.NOREF
#define ADSTATUS_MS3                         _STATUS.Bits.MS3
#define ADSTATUS_MS2                         _STATUS.Bits.MS2
#define ADSTATUS_MS1                         _STATUS.Bits.MS1
#define ADSTATUS_MS0                         _STATUS.Bits.MS0


/*
** ------------------------------------------------------------------------------
**		AD7730 Mode register 
** ------------------------------------------------------------------------------
*/

/*** AD7730 Mode Register ***/

typedef union {
  word Word;
  struct {
    word WL        :1;
    word D0        :1;
    word D1        :1;
    word DEN       :1;
    word BU        :1;  
    word MD0       :1;
    word MD1       :1;  
    word MD2       :1;  

    word CH0       :1;    
    word CH1       :1;    
    word BO        :1;
    word CLKDIS    :1;
    word RN0       :1;
    word RN1       :1;
    word ZERO      :1;
    word HIREF     :1;
    
  } Bits;
  
 struct {
    word           :1;
    word           :1;
    word           :1;
    word           :1;
    word           :1;
    word MD        :3;
    word CH        :2;
    word           :1;
    word           :1;
    word RN        :2;
    word           :1;
    word           :1;
  } MergedBits;
    
} ADMODE_STR;

extern volatile ADMODE_STR _ADMODE;

#define ADMODE                          _ADMODE.Word
#define ADMODE_MD2                      _ADMODE.Bits.MD2
#define ADMODE_MD1                      _ADMODE.Bits.MD1
#define ADMODE_MD0                      _ADMODE.Bits.MD0
#define ADMODE_BU                       _ADMODE.Bits.BU
#define ADMODE_DEN                      _ADMODE.Bits.DEN
#define ADMODE_D1                       _ADMODE.Bits.D1
#define ADMODE_D0                       _ADMODE.Bits.D0
#define ADMODE_WL                       _ADMODE.Bits.WL
#define ADMODE_HIREF                    _ADMODE.Bits.HIREF
#define ADMODE_ZERO                     _ADMODE.Bits.ZERO
#define ADMODE_RN1                      _ADMODE.Bits.RN1
#define ADMODE_RN2                      _ADMODE.Bits.RN2
#define ADMODE_CLKDIS                   _ADMODE.Bits.CLKDIS
#define ADMODE_BO                       _ADMODE.Bits.BO
#define ADMODE_CH1                      _ADMODE.Bits.CH1
#define ADMODE_CH0                      _ADMODE.Bits.CH0


/*
** ------------------------------------------------------------------------------
**		AD7730 Filter register 
** ------------------------------------------------------------------------------
*/

/*** AD7730 Filter Register ***/

typedef union {
  unsigned long Long;
  struct {
    unsigned long SPARE     :8;
    
    unsigned long SF4       :1;
    unsigned long SF5       :1;
    unsigned long SF6       :1;
    unsigned long SF7       :1;
    unsigned long SF8       :1;
    unsigned long SF9       :1;
    unsigned long SF10      :1;
    unsigned long SF11      :1;

    unsigned long FAST      :1;  
    unsigned long SKIP      :1;
    unsigned long ZERO2     :1;  
    unsigned long ZERO3     :1;  
    unsigned long SF0       :1;
    unsigned long SF1       :1;
    unsigned long SF2       :1;
    unsigned long SF3       :1;
    
    unsigned long DL0       :1;  
    unsigned long DL1       :1;  
    unsigned long DL2       :1;  
    unsigned long DL3       :1;       
    unsigned long CHP       :1;  
    unsigned long AC        :1;  
    unsigned long ZERO1     :1;
    unsigned long ZERO0     :1;    
  } Bits;
  
 struct {
    unsigned long           :8;
    unsigned long SF        :12;
    unsigned long           :1;
    unsigned long           :1;
    unsigned long           :1;
    unsigned long           :1;    
    unsigned long DL        :4;        
    unsigned long           :1;
    unsigned long           :1;
    unsigned long           :1;
    unsigned long           :1;

  } MergedBits;
    
} ADFILTER_STR;

extern volatile ADFILTER_STR _ADFILTER;

#define ADFILTER                        _ADFILTER.Long
#define ADFILTER_SINC                   _ADFILTER.MergedBits.SF
#define ADFILTER_ZERO0                  _ADFILTER.Bits.MD1
#define ADFILTER_ZERO1                  _ADFILTER.Bits.MD0
#define ADFILTER_SKIP                   _ADFILTER.Bits.SKIP
#define ADFILTER_FAST                   _ADFILTER.Bits.FAST
#define ADFILTER_AC                     _ADFILTER.Bits.AC
#define ADFILTER_CHP                    _ADFILTER.Bits.CHP
#define ADFILTER_DL                     _ADFILTER.MergedBits.DL


/*
** ------------------------------------------------------------------------------
**		AD7730 DAC register 
** ------------------------------------------------------------------------------
*/

/*** AD7730 DAC Register ***/
typedef union {
  byte Byte;
  struct {
    byte ZERO0       :1;
    byte ZERO1       :1;
    byte DAC5        :1;
    byte DAC4        :1;
    byte DAC3        :1;
    byte DAC2        :1;
    byte DAC1        :1;
    byte DAC0        :1;
  } Bits;
} DAC_STR;

extern volatile DAC_STR _DAC;

#define ADDAC                            _DAC.Byte
#define ADDAC_ZERO0                      _DAC.Bits.ZERO0
#define ADDAC_ZERO1                      _DAC.Bits.ZERO1
#define ADDAC_DAC5                       _DAC.Bits.DAC5
#define ADDAC_DAC4                       _DAC.Bits.DAC4
#define ADDAC_DAC3                       _DAC.Bits.DAC3
#define ADDAC_DAC2                       _DAC.Bits.DAC2
#define ADDAC_DAC1                       _DAC.Bits.DAC1
#define ADDAC_DAC0                       _DAC.Bits.DAC0

/*
** ------------------------------------------------------------------------------
**		AD7730 Offset register 
** ------------------------------------------------------------------------------
*/

/*** AD7730 Offset Register ***/
typedef union {
  unsigned long Long;
  struct {
    unsigned long OFFSET      :24;
    unsigned long SPARE       :8;
  } Bits;
} OFFSET_STR;

extern volatile OFFSET_STR _OFFSET;

#define ADOFFSET                          _OFFSET.Long


/*
** ------------------------------------------------------------------------------
**		AD7730 Gain register 
** ------------------------------------------------------------------------------
*/

/*** AD7730 Gain Register ***/
typedef union {
  unsigned long Long;
  struct {
    unsigned long GAIN        :24;
    unsigned long SPARE       :8;
  } Bits;
} GAIN_STR;

extern volatile GAIN_STR _GAIN;

#define ADGAIN                            _GAIN.Long



#endif   /* AD7730_H */
