/*
** ------------------------------------------------------------------------------
   
   File   : Main.h 
   Aurthor: Stuart Clarke
        
** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2007 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp.
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
   
** ------------------------------------------------------------------------------
*/

/*
** ------------------------------------------------------------------------------
**		#define: A1162
** ------------------------------------------------------------------------------
*/

#define _1162     0
#define _900_125  1




#pragma DATA_SEG Main_Data


#ifndef MAIN_C

	#define _EXT extern  	/* make declarations */

   _EXT const char ModelString[14];
   _EXT const char VersionString[12];

#else

	#define _EXT				/* make definitions */							   
	
#endif



/* board type register */
_EXT byte BoardType;


/* Timers */
_EXT word Timer100mS;
_EXT word Timer200mS;
_EXT word Timer1S;
_EXT word StartUpDelay;
