/*
** ------------------------------------------------------------------------------
   
   File   : winConfirm.h 
   Aurthor: Stuart Clarke

** ------------------------------------------------------------------------------
   COPYRIGHT NOTIFICATION (c)2008 Process Sensors Corp.                 
   This program is the property of Process Sensors Corp.                
   It may not be reproduced, distributed, or used without permission          
   of an authorised company official.   
   
   Process Sensors Corp
   113 Cedar Street
   Milford, MA 01757 USA
   Tel: 508-473-9901
   Fax: 508-473-0715
   info@processsensors.com
  
** ------------------------------------------------------------------------------
*/

#ifndef WINCONFIRM_H
#define WINCONFIRM_H


/* public defines */


/*
** ------------------------------------------------------------------------------
**		#define : diagnostics handler states 
** ------------------------------------------------------------------------------
*/

#define WIN_CONFIRM_PAINT        0
#define WIN_CONFIRM_UPDATE       1
#define WIN_CONFIRM_UNLOAD       2


/*
** ------------------------------------------------------------------------------
**		#typedef: msg box data type 
** ------------------------------------------------------------------------------
*/

typedef struct
{
   byte *MsgTxt;
   byte TitleBarTxt[20]; 
   int  (*fp)(void);
   byte Attribute;
}MsgBoxType;


#ifndef WINCONFIRM_C

/* public variables */
#pragma DATA_SEG WINCONFIRM_Data

extern MsgBoxType MsgBoxData;

#endif   /* WINCONFIRM_C */      


/* public functions */
#pragma CODE_SEG WINCONFIRM_Code

/*
** ------------------------------------------------------------------------------
**		Function: byte winCConfirmHandler(void)
** ------------------------------------------------------------------------------
*/

byte winConfirmHandler(void);

#endif   /* WINCONFIRM_H */
